import { AuthGuard } from './auth/guards/auth.guard';
import { Routes } from '@angular/router';
import { LoginComponent } from '../app/pages/login/login.component';
import { AdminLayoutComponent } from './layout/admin/admin-layout.component';
import { AuthLayoutComponent } from './layout/auth/auth-layout.component';
import { DashboardComponent } from './pages/dashboard/dashboard.component';

export const AppRoutes: Routes = [{
    path: '',
    // component: LoginComponent, //canActivate: [AuthGuard],
    component: AuthLayoutComponent,
    children: [
        {
            path: '',
            redirectTo: 'login', //canActivate: [AuthGuard],
            pathMatch: 'full'
        },
        {
            path: 'login', //canActivate: [AuthGuard],
            loadChildren: './pages/login/login.module#LoginModule'
        },
        {
            path: 'recovery', //canActivate: [AuthGuard],
            loadChildren: './pages/recovery/recovery.module#RecoveryModule'
        },
        {
            path: 'loading', //canActivate: [AuthGuard],
            loadChildren: './pages/loading/loading.module#LoadingModule'
        },
    ]
}, {
    path: '',
    component: AdminLayoutComponent,
    children: [
        {
            path: 'dashboard', canActivate: [AuthGuard],
            component: DashboardComponent
        },
        {
            path: 'candidate', canActivate: [AuthGuard],
            loadChildren: './pages/candidate/candidate.module#CandidateModule'
        },
        // {
        //     path: 'logs', canActivate: [AuthGuard],
        //     loadChildren: './pages/logs/logs.module#LogsModule'
        // },
        {
            path: 'opportunities', canActivate: [AuthGuard],
            loadChildren: './pages/opportunities/opportunities.module#OpportunitiesModule'
        }, {
            path: 'tags', canActivate: [AuthGuard],
            loadChildren: './pages/tags/tags.module#TagsModule'
        }, {
            path: 'softskills', canActivate: [AuthGuard],
            loadChildren: './pages/softskills/softskills.module#SoftSkillsModule'
        },
        {
            path: 'matches', canActivate: [AuthGuard],
            loadChildren: './pages/matches/matches.module#MatchesModule'
        },
        {
            path: 'evaluation', canActivate: [AuthGuard],
            loadChildren: './pages/evaluations/evaluations.module#EvaluationModule'
        }
        ,
        {
            path: 'edit/:id', canActivate: [AuthGuard],
            loadChildren: './pages/candidate/edit/edit.module#EditModule'
        },
        {
            path: 'reports', canActivate: [AuthGuard],
            loadChildren: './pages/reports/reports.module#ReportsModule'
        },
        {
            path: 'opportunities/:status', canActivate: [AuthGuard],
            loadChildren: './pages/opportunities/opportunities.module#OpportunitiesModule'
        },
        {
            path: 'admin', canActivate: [AuthGuard],
            loadChildren: './pages/admin/admin.module#AdminModule'
        },
        {
            path: 'customer', canActivate: [AuthGuard],
            loadChildren: './pages/customer/customer.module#CustomerModule'
        },
        {
            path: 'logout', canActivate: [AuthGuard],
            loadChildren: './pages/logout/logout.module#LogoutModule'
        }
    ]
}];
