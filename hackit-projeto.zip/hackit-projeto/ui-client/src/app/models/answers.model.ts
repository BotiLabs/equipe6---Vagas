export class AnswersModel {
    answer: string;
    weight: number;
    

    constructor() {
        this.answer = "";
        this.weight = null;
    }
}