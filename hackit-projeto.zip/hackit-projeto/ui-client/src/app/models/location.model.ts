import { StatusCandidate } from '../common/status-candidate';
import { ActionInteraction } from '../common/action-interaction';
import { InteractionType } from '../common/interaction-type';
import { OpportunityModel } from './opportunity.model';

export class LocationModel {
    _id: string;
    streetAddress: string;
    district: string;
    state: string;
    discription:string;
    opportunityLocation:String
    clientLocation:String;
    company_id: string;
    blockedLocation: boolean;
    showDiscription: boolean;
    showDistrict: boolean;
    showState: boolean;
    showStreetAddress: boolean;
    selected: boolean;

    constructor() {
        this.streetAddress = "";
        this.district = "";
        this.state = "";
        this.discription = "";
        this.opportunityLocation = "";
        this.clientLocation = "";
        this.company_id = "";
        this.showDiscription = false;
        this.showDistrict = false;
        this.showState = false;
        this.showStreetAddress = false;
        this.selected = false;
    }

    loadFromServer(response: any) {
        this._id = response._id;
        this.streetAddress = response.streetAddress;
        this.district = response.district;
        this.state = response.state;
        this.discription = response.discription;
        this.opportunityLocation = response.opportunityLocation;
        this.clientLocation = response.clientLocation;
        this.blockedLocation = response.blockedLocation;
        this.company_id = response.company_id;
    }
}