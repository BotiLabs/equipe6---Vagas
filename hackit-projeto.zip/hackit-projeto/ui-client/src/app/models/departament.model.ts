export class DepartamentModel {
    name: string;
    number: number;
    company_id: string;


    constructor() {
            }

    loadFromServer(response){
        this.name = response.name;
        this.number = response.number;
        this.company_id = response.company_id;
    }

}
