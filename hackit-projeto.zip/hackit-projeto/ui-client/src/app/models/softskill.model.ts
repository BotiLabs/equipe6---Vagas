export class SoftSkillModel {

    _id: string;
    softskill: string;
    visible:boolean;
    company_id: string;
    
    constructor() {
        this.softskill = "";
        this.visible = true;
        this.company_id = "";
    }
    
    public loadSoftSkill(response: any) {
        this._id = response._id;
        this.softskill = response.softskill;
        this.visible = response.visible;
        this.company_id = response.company_id;
    }

}
    