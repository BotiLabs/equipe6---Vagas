export class UserInfoModel {
    _id:string;
    email: string;
    username: string;
    firstName: string;
    lastName: string;
    company_id: string;

    constructor() {
        this.email = "";
        this.username = "";
        this.firstName = "";
        this.lastName = "";
        this.company_id = "";
    }


    loadInfoOffice365(userInfo: any) {
        this.firstName = userInfo.firstName;
        this.lastName = userInfo.lastName;
        this.email = userInfo.username;
        this.username = userInfo.username;
        this.company_id = userInfo.company_id;
    }
}