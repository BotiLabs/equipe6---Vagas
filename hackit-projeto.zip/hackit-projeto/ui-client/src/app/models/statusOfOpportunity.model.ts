export class StatusOfOpportunityModel {
    name: string;
    color: string;
    number: number;
    status_id: string;


    constructor() {
        this.name = "";
        this.color = "";
        this.number = -1;
        this.status_id = "";
    }

    loadModelFromServer(response: any) {
        this.name = response.name;
        this.color = response.color;
        this.number = response.number;
        this.status_id = response.status_id;
    }
}