export class TypeModel {
    _id: string;
    description: string;
    company_id: string;
    
    constructor() {
        this.description = "";
        this.company_id = "";
    }
    
    public loadType(response: any) {
        this._id = response._id;
        this.description = response.description;
    }

}
        