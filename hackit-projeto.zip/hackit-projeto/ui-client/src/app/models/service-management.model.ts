export class ServiceManagementModel {

    _id: string;
    interactionEmail: boolean;
    reprovalEmail: boolean;
    statusRobot: boolean;


    public loadConfig(response: any) {
        this._id = response._id;
        this.interactionEmail = response.interactionEmail;
        this.reprovalEmail = response.reprovalEmail;
        this.statusRobot = response.statusRobot;
    }

}
    

