export class UserLoginModel {

    email: string;
    password: string;
    tag: string;

    constructor() {
        this.email = "";
        this.password = "";
        this.tag = "";
    }
}