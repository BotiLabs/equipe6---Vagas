export class ChartModel {
    data: any[];
    labels: string[];
    colors: any[];
    constructor() {
    this.data = [];
    this.labels = [];
    this.colors = [];
    }

    public loadChart(data, labels, colors) {
        this.data = data;
        this.labels = labels;
        this.colors = colors;
    }
}