import { StatusOpportunity } from '../common/status-opportunity';
import { BusinessUnit } from '../common/business-unit';
import { CandidateModel } from './candidate.model';
import { isNullOrUndefined } from 'util';
import { LocationModel } from './location.model';
import { StatusOfOpportunityModel } from './statusOfOpportunity.model';
import { OpportunityHistoricModel } from './opportunityHistoric.model';
import { InvolvedPeople } from './involvedPeople';
import { StatusModel } from './status.model';

export class OpportunityModel {
    priority: number;
    _id: string;
    name: string;
    businessUnit: number;
    description: string;
    responsible: string;
    emailResponsible: string;
    value: string;
    profile: number;
    location: string;
    customerName: string;
    specialities: string[] = [];
    status: StatusOpportunity;
    qtdOpportunities: number;
    statusName: string;
    number: any;
    isActive: Boolean;
    candidates: string[];
    candidatesJoin: CandidateModel[] = [];
    statusJoin: StatusOfOpportunityModel[] = [];
    registrationDate: Date;
    visible: boolean;
    opportunityLocation: LocationModel;
    company_id: string;
    initialQtd: number;
    historic: OpportunityHistoricModel[];
    emailWatching: string[];
    involvedPeople: InvolvedPeople[];

    constructor() {
        this.priority = 0;
        this.name = "";
        this.description = "";
        this.responsible = "";
        this.emailResponsible = "";
        this.value = "";
        this.profile = -1;
        this.customerName = "";
        this.location = "";
        this.businessUnit = -1;
        this.status = StatusOpportunity.Aberta;
        this.specialities = [];
        this.number = 0;
        this.isActive = true;
        this.candidates = [];
        this.candidatesJoin = new Array<CandidateModel>();
        this.statusJoin = [];
        this.registrationDate;
        this.visible = true;
        this.opportunityLocation = new LocationModel();
        this.company_id = "";
        this.initialQtd = 1;
        this.historic = [];
        this.emailWatching = [];
        this.involvedPeople = new Array<InvolvedPeople>();
        this.qtdOpportunities = 0;
    }

    public loadModelFromServer(response: any) {
        if (response.priority != isNullOrUndefined) {
            this.priority = response.priority;
        } else {
            this.priority = 0;
        }
        this._id = response._id;
        this.name = response.name;
        this.description = response.description;
        this.responsible = response.responsible;
        this.emailResponsible = response.emailResponsible;
        this.value = response.value;
        this.profile = response.profile;
        this.businessUnit = response.businessUnit;
        this.location = response.location;
        this.customerName = response.customerName;
        this.specialities = response.specialities;
        this.status = response.status;
        this.statusName = response.statusName;
        this.number = response.number;
        this.isActive = response.isActive;
        this.candidates = response.candidates;
        if (response.registrationDate) {
            this.registrationDate = response.registrationDate;
        } else {
            this.registrationDate = undefined;
        }
        this.visible = response.visible;
        this.qtdOpportunities = response.qtdOpportunities;
        this.initialQtd = response.initialQtd;
        this.opportunityLocation = response.opportunityLocation;
        this.historic = response.historic;
        this.emailWatching = response.emailWatching;
        this.involvedPeople = response.involvedPeople;
        this.statusJoin = response.statusJoin;
        // if (response.candidatesJoin !== undefined){
        //     this.populateCandidates(response.candidatesJoin);
        // }
        // if (response.statusJoin !== undefined) {
        //     this.populateStatus(response.statusJoin);
        // }
    }

    //  populateCandidates(resCandidates : any) {
    //      for (let item of resCandidates){
    //          let candidate = new CandidateModel();
    //          candidate.loadCandidate(item);
    //          this.candidatesJoin.push(candidate);
    //      }       

    populateStatus(resStatus: any) {
        for (let item of resStatus) {
            let status = new StatusOfOpportunityModel();
            status.loadModelFromServer(item);
            this.statusJoin.push(status);
        }
    }
    public formatSkills() {
        let specialitiesText: string = "";
        for (let i = 0; i < this.specialities.length; i++) {
            specialitiesText += `${this.specialities[i]}${i === (this.specialities.length - 1) ? "" : ", "}`;
        }

        return specialitiesText;
    }

    public loadSpecialities(text: string) {
        if (text === undefined || text === "") {
            this.specialities = [];
            return;
        }
        let array = text.split(';');

        for (let item of array)
            this.specialities.push(item);

    }



}