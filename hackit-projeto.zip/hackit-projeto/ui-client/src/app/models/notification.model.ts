import { StatusCandidate } from '../common/status-candidate';
import { ActionInteraction } from '../common/action-interaction';
import { InteractionType } from '../common/interaction-type';
import { OpportunityModel } from './opportunity.model';

export class NotificationModel {
    _id: String;
    userEmail: String;
    responsibleEmail: String;
    userFirstName: String;
    registrationDate: Date;
    discriptionNotification: String;
    originNotification: String;
    number: Number;
    typeOfNotification: Number;
    candidateId:String;
    watchingEmail: string;


    constructor() {
        this.userEmail = "";
        this.responsibleEmail = "";
        this.userFirstName = "";
        this.registrationDate = new Date();
        this.discriptionNotification = "";
        this.originNotification = "";
        this.number;
        this.typeOfNotification = -1;
        this.watchingEmail = "";
    }

    loadFromServer(response: any) {
        this._id = response._id;
        this.userEmail = response.userEmail;
        this.responsibleEmail = response.responsibleEmail;
        this.userFirstName = response.userFirstName;
        this.registrationDate = response.registrationDate;
        this.discriptionNotification = response.discriptionNotification;
        this.number = response.number;
        this.typeOfNotification = response.typeOfNotification;
        this.watchingEmail = response.watchingEmail;
    }
}