import { StatusCandidate } from '../common/status-candidate';
import { ActionInteraction } from '../common/action-interaction';
import { InteractionType } from '../common/interaction-type';
import { OpportunityModel } from './opportunity.model';
import { ProfileCandidate } from '../common/profile-candidate';

export class SearchCandidateModel {
    _id: String;
    number: any;
    name: string;
    userFirstName: string;
    userEmail: string;
    email: string;
    nameSearch: string;
    skills: string[];
    registrationDate: Date;
    status: any[];
    position: any[];
    company_id: string;

    constructor() {
        this.userFirstName;
        this.userEmail;
        this.nameSearch = "";
        this.number = 0;
        this.skills = [];
        this.registrationDate = new Date();
        this.name = "";
        this.email = "";
        this.status = [];
        this.position = [];
        this.company_id = "";
    }

    loadFromServer(response: any) {
        this._id = response._id;
        this.number = response.number;
        this.nameSearch = response.nameSearch;
        this.registrationDate = response.registrationDate;
        this.userFirstName = response.userFirstName;
        this.userEmail = response.userEmail;
        this.email = response.email;
        this.name = response.name;
        this.skills = response.skills;
        this.status = response.status;
        this.position = response.position;
    }
}