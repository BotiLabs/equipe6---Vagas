export class CandidateHistoricModel {
    opportunityId:String;
    opportunityNumber:number;
    opportunityName:String;
    opportunityCustomer:String;
    registrationDate:Date;
    interactions:any[];


    constructor() {
        this.opportunityId = "";
        this.opportunityNumber;
        this.opportunityName = "";
        this.opportunityCustomer = "";
        this.registrationDate;
        this.interactions = [];
    }

}