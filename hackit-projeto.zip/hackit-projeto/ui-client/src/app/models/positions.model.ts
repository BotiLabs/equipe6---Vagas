export class PositionsModel {
    name: string;
    number: number;
    company_id: string;
    companyId: string;
    


    constructor() {
            }

    loadFromServer(response){
        this.companyId = response.companyId
        this.name = response.name;
        this.number = response.number;
        this.company_id = response.company_id;
    }

}