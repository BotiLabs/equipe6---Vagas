import { StatusCandidate } from '../common/status-candidate';
import { ActionInteraction } from '../common/action-interaction';
import { InteractionType } from '../common/interaction-type';
import { OpportunityModel } from './opportunity.model';

export class LogModel {
    _id: String;
    userEmail: string;
    userFirstName: string;
    registrationDate: Date;
    discriptionLog: String;
    number: any;
    company_id: string;

    constructor() {
        this.userFirstName = "";
        this.userEmail = "";
        this.registrationDate = new Date();
        this.discriptionLog = "";
        this.number = 0;
        this.company_id = "";
    }

    loadFromServer(response: any) {
        this._id = response._id;
        this.userEmail = response.userEmail;
        this.userFirstName = response.userFirstName;
        this.registrationDate = response.registrationDate;
        this.discriptionLog = response.discriptionLog;
        this.number = response.number;
    }
}