export class CompanyModel {
    _id: string;
    name: string;
    tag: string;
    tenant: string;


    constructor() {
        this._id = "";
        this.name = "";
        this.tag = "";
        this.tenant = "";
    }

    loadFromServer(response) {
        this._id = response._id;
        this.name = response.name;
    }
}