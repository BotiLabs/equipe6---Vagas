
export class QualificationModel {
    _id: string;
    email: string;
    name: string;
    noAscentName: string;
    date: Date;
    mainSkills: string[];
    secondarySkills: string[];
    position: String;
    status: number;
    discription: string;
    desiredHiring: any[]

    constructor() {
        this.email = "";
        this.name = "";
        this.noAscentName = "";
        this.date;
        this.mainSkills = [];
        this.secondarySkills = [];
        this.position = "";
        this.status = 0;
        this.discription = "";
        this.desiredHiring = [];
    }

    public loadQualification(response: any) {
        this._id = response._id;
        this.email = response.email;
        this.name = response.name;
        this.noAscentName = response.noAscentName;
        this.date = response.date;
        this.mainSkills = response.mainSkills;
        this.secondarySkills = response.secondarySkills;
        this.position = response.position;
        this.status = response.status;
        this.discription = response.discription;
        this.desiredHiring = response.desiredHiring;
    }
}
