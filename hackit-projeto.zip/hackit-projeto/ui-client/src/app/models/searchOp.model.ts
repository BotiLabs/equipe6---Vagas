import { StatusCandidate } from '../common/status-candidate';
import { ActionInteraction } from '../common/action-interaction';
import { InteractionType } from '../common/interaction-type';
import { OpportunityModel } from './opportunity.model';

export class SearchOpModel {
    _id:String;
    number:any;
    numberOpp: any;
    customerName: string;
    userFirstName:String;
    userEmail:String;
    nameSearch:string;
    location: string;
    businessUnit: number;
    status:number;
    specialities:String[];
    registrationDate: Date; 
    priority: number;
    company_id: string;
 
    constructor() {
        this.userFirstName;
        this.userEmail;
        this.customerName = "";
        this.location = "";
        this.nameSearch = "";
        this.businessUnit=0;
        this.status=0;
        this.number = 0;
        this.numberOpp = 0;
        this.priority = -1;
        this.specialities=[];
        this.registrationDate = new Date();
        this.company_id = "";
    }

    loadFromServer(response: any) {
        this._id = response._id;
        this.number = response.number;
        this.numberOpp = response.numberOpp;
        this.customerName =  response.customerName;
        this.location = response.location;
        this.businessUnit= response.businessUnit;
        this.nameSearch = response.nameSearch;
        this.status=response.status;
        this.specialities = response.specialities;
        this.registrationDate = response.registrationDate;
        this.userFirstName = response.userFirstName;
        this.userEmail = response.userEmail;
        this.priority = response.priority;
        
      
    }
}