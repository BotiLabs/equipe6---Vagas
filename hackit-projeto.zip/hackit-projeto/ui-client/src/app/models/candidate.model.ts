import { StatusCandidate } from '../common/status-candidate';
import { ProfileCandidate } from '../common/profile-candidate';
import { OpportunityModel } from './opportunity.model';
import { HiringCandidate } from '../common/hiring-candidate';
import { StatusOfCandidateModel } from './statusOfCandidate.model';
import { CandidateHistoricModel } from './candidateHistoric.model';
export class CandidateModel {

    _id: string;
    name: string;
    silver: boolean;
    noAscentName: string;
    email: string;
    status: StatusCandidate;
    profile: ProfileCandidate;
    phone: string;
    distance: string;
    skills: string[];
    softSkills: string[];
    curriculum: string;
    yearsOfExperience: number;
    githubUrl: string;
    linkedinUrl: string;
    position: String;
    opportunities: any[];
    origin: String;
    isBlocked: boolean;
    rank: number;
    registrationDate: Date;
    hiringType: HiringCandidate;
    desiredHiring: any;
    actualValue: string;
    desiredValue: string;
    typeOfOrigin: number;
    userEmail: string;
    visible: boolean;
    originFc: boolean;
    relevance: number;
    expand: boolean;
    historic: CandidateHistoricModel[];
    mainSkills: string[];
    secondarySkills: string[];
    company_id: string;
    discription: string;
    dateOfBirth: Date;
    cep: string;
    district: string;
    statusJoin: StatusOfCandidateModel[] = [];
    city: string;
    state: string;
    approachRs: string;
    like: number;
    dislike: number;
    fillPercentage: number;

    constructor() {
        this.silver = false;
        this.like = 0;
        this.dislike = 0;
        this.name = "";
        this.noAscentName = "";
        this.distance = "-";
        this.email = "";
        this.profile = -1;
        this.phone = "";
        this.skills = [];
        this.curriculum = "";
        this.yearsOfExperience = 0;
        this.githubUrl = "";
        this.linkedinUrl = "";
        this.opportunities = [];
        this.status = StatusCandidate.Cadastrado; //Status inicial
        this.origin = "";
        this.position = "";
        this.isBlocked = false;
        this.rank = 0;
        this.registrationDate;
        this.hiringType = -1;
        this.desiredHiring = -1;
        this.actualValue = "";
        this.desiredValue = "";
        this.typeOfOrigin = 0;
        this.userEmail = "";
        this.visible = true;
        this.originFc = false;
        this.company_id = "";
        this.relevance = 0;
        this.expand = false;
        this.historic = [];
        this.mainSkills = [];
        this.secondarySkills = [];
        this.discription = "";
        this.dateOfBirth;
        this.cep = undefined;
        this.district = "";
        this.city = "";
        this.state = "";
        this.approachRs = "";
    }

    public loadCandidate(response: any) {
        this.silver = response.silver;
        this._id = response._id;
        this.originFc = response.originFc;
        this.email = response.email;
        this.distance = response.distance;
        this.name = response.name;
        this.noAscentName = response.noAscentName;
        this.githubUrl = response.githubUrl;
        this.linkedinUrl = response.linkedinUrl;
        this.skills = response.skills;
        this.profile = response.profile;
        if (response.yearsOfExperience == null || response.yearsOfExperience == undefined) {
            this.yearsOfExperience = 0;
        } else {
            this.yearsOfExperience = response.yearsOfExperience;
        }
        this.status = response.status;
        this.phone = response.phone;
        this.position = response.position === undefined ? "" : response.position;
        this.opportunities = response.opportunities;
        this.curriculum = response.curriculum;
        this.origin = response.origin === undefined ? "" : response.origin;
        if (response.isBlocked !== undefined) {
            this.isBlocked = response.isBlocked;
        }
        this.rank = response.rank;
        if (response.registrationDate) {
            this.registrationDate = response.registrationDate;
        } else {
            this.registrationDate = undefined;
        }
        if (response.hiringType != undefined)
            this.hiringType = response.hiringType;
            
        this.desiredHiring = response.desiredHiring;
        this.actualValue = response.actualValue;
        this.desiredValue = response.desiredValue;
        this.typeOfOrigin = response.typeOfOrigin;
        this.userEmail = response.userEmail;
        this.visible = response.visible;
        this.relevance = response.relevance;
        this.historic = response.historic;
        this.mainSkills = response.mainSkills;
        this.like = response.like;
        this.dislike = response.dislike;
        this.secondarySkills = response.secondarySkills;
        this.discription = response.discription;
        this.statusJoin = response.statusJoin;
        if (response.dateOfBirth)
            this.dateOfBirth = new Date(response.dateOfBirth);

        this.cep = response.cep;
        this.district = response.district;
        this.city = response.city;
        this.state = response.state;
        this.approachRs = response.approachRs === undefined ? "" : response.approachRs;
        this.fillPercentage = response.fillPercentage;
    }

    public formatSkills() {
        let skillText: string = "";
        for (let i = 0; i < this.skills.length; i++) {
            skillText += `${this.skills[i]}${i === (this.skills.length - 1) ? "" : ", "}`;
        }

        return skillText;
    }
}