export class StatusModel {

    color: string;
    icon:string;
    
    constructor() {
        this.color = "";
        this.icon = "";
    }

}
    