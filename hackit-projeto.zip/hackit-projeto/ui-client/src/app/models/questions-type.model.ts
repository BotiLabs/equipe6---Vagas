export class QuestionsType {
    theme: string;
    date: Date;
    active: boolean;
}