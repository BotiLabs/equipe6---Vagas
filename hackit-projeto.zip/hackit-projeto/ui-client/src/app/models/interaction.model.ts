import { StatusCandidate } from '../common/status-candidate';
import { ActionInteraction } from '../common/action-interaction';
import { InteractionType } from '../common/interaction-type';
import { OpportunityModel } from './opportunity.model';
import { ProfileInteraction} from '../common/profile-interaction';
export class InteractionModel {
    _id: string;
    candidateId: string;
    opportunityId: string;
    opportunityName: string;
    status: StatusCandidate;
    action: ActionInteraction;
    profile: ProfileInteraction;
    userEmail: string;
    userFirstName: string;
    registrationDate: Date;
    observation: string;
    interactionType: InteractionType;
    responsible:string;
    opportunity: any;
    visible:boolean;
    company_id:string;
    opportunityNumber:number;

    constructor() {
        this.candidateId = "";
        this.opportunityId = "";
        this.opportunityName = "";
        this.status = -1;
        this.action = -1;
        this.userFirstName = "";
        this.userEmail = "";
        this.profile = -1;
        this.registrationDate = new Date();
        this.observation = "";
        this.interactionType = -1;
        this.responsible ="";
        this.opportunity = -1;
        this.visible = true;
        this.company_id = "";
        this.opportunityNumber = undefined;
    }

    loadFromServer(response: any) {
        this._id = response._id;
        this.action = response.action;
        this.candidateId = response.candidateId;
        this.observation = response.observation;
        this.opportunityId = response.opportunityId;
        this.status = response.status;
        this.profile = response.profile;
        this.userEmail = response.userEmail;
        this.userFirstName = response.userFirstName;
        this.registrationDate = response.registrationDate;
        this.opportunityName = response.opportunityName;
        this.interactionType = response.interactionType;
        this.responsible = response.responsible;
        this.opportunity = response.opportunity;
        this.visible = response.visible;
        this.company_id = response.company_id;
        this.opportunityNumber = response.opportunityNumber;
    }
}