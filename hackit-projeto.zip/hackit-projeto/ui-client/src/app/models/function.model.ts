import { TypeModel } from './../models/type.model';

export class FunctionModel {
    _id: string;
    name: string;
    nameWithCompany: string;
    registrationDate: Date;
    company_id: string;
    visible: boolean;
    constructor() {
        this.name = "";
        this.company_id = "";
        this.nameWithCompany = "";
        this.visible = false;
    }

    public loadFunction(response: any) {
        this.name = response.name;
        this.company_id = response.company_id
        this.nameWithCompany = response.nameWithCompany
        this.visible = response.visible;
        this.registrationDate = response.registrationDate;
    }
}