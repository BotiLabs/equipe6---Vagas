export class UserModel {
    _id: String;
    firstName: string;
    lastName: string;
    email: string;
    username: string;
    password: string;
    approved: boolean;
    watch: any[];
    fullName: string;
    company_id: string;
    tag: string;
    constructor() {
        this.firstName = "";
        this.lastName = "";
        this.email = "";
        this.username = "";
        this.password = "";
        this.company_id = "";
        this.approved = false;
        this.watch = [];
        this.fullName = "";
        this.tag = "";
    }



    loadUserModel(response: UserModel) {
        this.firstName = response.firstName;
        this.lastName = response.lastName;
        this.email = response.email;
        this.username = response.username;
        this.password = response.password;
        this.watch = response.watch;
        this.approved = response.approved;
        this.fullName = response.firstName + " " + response.lastName;
        return response;
    }
}
