import { TypeModel } from './../models/type.model';

export class EvaluationModel {
    _id: string;
    name: string;
    email: string;
    date: Date;
    // type: TypeModel[];
    type: string[];
    testing: any[];
    personality: any[];
    number: number;
    company_id: string;
    discription: string;
    startedEvaluation: boolean;
    registrationDate: Date;
    userEmail: string;
    constructor() {
        this.startedEvaluation = false;
        this.name = "";
        this.email = "";
        //this.date = new Date();
        // this.type = new Array<TypeModel>();
        this.type = [];
        this.personality = [];
        this.number;
        this.company_id = "";
        this.discription = "";
    }

    public loadEvaluation(response: any) {
        this._id = response._id;
        this.startedEvaluation = response.startedEvaluation;
        this.email = response.email;
        this.date = response.date;
        this.name = response.name;
        this.type = response.type;
        this.personality = response.personality;
        this.number = response.number;
        this.discription = response.discription;
        this.registrationDate = response.registrationDate;
    }
}