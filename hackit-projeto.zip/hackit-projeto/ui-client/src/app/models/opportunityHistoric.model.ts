export class OpportunityHistoricModel {
    candidateId:String;
    candidateName:String;
    candidateEmail:String;
    registrationDate:Date;
    interactions:any[];


    constructor() {
        this.candidateId = "";
        this.candidateName = "";
        this.candidateEmail = "";
        this.registrationDate;
        this.interactions = [];
    }

}