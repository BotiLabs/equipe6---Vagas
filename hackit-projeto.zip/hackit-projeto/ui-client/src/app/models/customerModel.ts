import { StatusCandidate } from '../common/status-candidate';
import { ActionInteraction } from '../common/action-interaction';
import { InteractionType } from '../common/interaction-type';
import { OpportunityModel } from './opportunity.model';

export class CustomerModel {
    _id: string;
    name: string;
    unity: any;
    visible: boolean;
    blockedCustomer: boolean;
    company_id: string;
    locations:any;
    expand:boolean;
    registrationDate:Date;
    constructor() {
        this.name = "";
        this.company_id = "";
        this.unity = [];
        this.visible = true;
        this.unity = [];
        this.locations = [];
        this.expand = false;
        this.registrationDate = undefined;
    }

    loadFromServer(response: any) {
        this._id = response._id;
        this.company_id = response.company_id;
        this.name = response.name;
        if (response.unity) {
            this.unity = response.unity;
        } else {
            this.unity = [];
        }
        this.visible = response.visible;
        this.blockedCustomer = response.blockedCustomer;
        this.locations = response.locations;
        this.registrationDate = response.registrationDate;
    }
}