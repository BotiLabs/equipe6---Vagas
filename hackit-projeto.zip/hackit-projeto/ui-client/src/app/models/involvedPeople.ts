export class InvolvedPeople {
    name: string;
    position: string;
    email: string;

    constructor() {
        this.name = "";
        this.position = "";
        this.email = "";
    }
}