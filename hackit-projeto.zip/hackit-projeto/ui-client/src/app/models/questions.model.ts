import { AnswersModel } from './answers.model'
import { TypeModel } from './type.model';


export class QuestionModel {
    // _id: string;
    question:string;
    type: string[];
    theme: string;
    answers: AnswersModel[];

    constructor() {
        // this._id= "";
        this.question = "";
        this.type = [];
        this.theme = "";
        this.answers = new Array<AnswersModel>();
    }
    public loadQuestions(response: any) {
        // this._id = response._id;
        this.question = response.question;
        this.theme = response.theme;
        this.answers = response.answers;
        this.type = response.type;
    }
}
