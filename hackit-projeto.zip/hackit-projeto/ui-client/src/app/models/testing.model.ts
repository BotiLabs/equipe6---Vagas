export class TestingModel {
    _id: string;
    theme: string;
    question: string;
    date: Date;
    type: string;
    company_id: string;

    constructor() {
        this.theme = "";
        this.question = "";
        this.date = new Date();
        this.type = "";
        this.company_id = "";
    }
    
    loadTesting(response: any) {
        this._id = response._id;
        this.theme = response.theme;
        this.question = response.question;
        this.date = response.date;
        this.type = response.type;
    }
}