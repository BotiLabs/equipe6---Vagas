export class SelectedPeopleModel {

    id: any;
    itemName:string;
    
    constructor() {
        this.id = "";
        this.itemName = "";
    }

}
    