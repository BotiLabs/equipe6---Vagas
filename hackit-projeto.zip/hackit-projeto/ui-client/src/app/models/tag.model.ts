export class TagModel {

    _id: string;
    name: string;
    visible:boolean;
    company_id: string;
    
    constructor() {
        this.name = "";
        this.visible = true;
        this.company_id = "";
    }
    
    public loadTag(response: any) {
        this._id = response._id;
        this.name = response.name;
        this.visible = response.visible;
        this.company_id = response.company_id;
    }

}
    