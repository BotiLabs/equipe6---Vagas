import { Component, ViewEncapsulation } from '@angular/core';
import { NotificationService } from './../../_services/notification.service';
import { Router } from '@angular/router';
import { AuthService } from './../../_services/auth.service';
import { NotificationServ } from '../../_services/notificationSoquet.service';
import '../assets/plugins/toast-master/js/jquery.toast.js';
import { EnumsHelper } from './common/enums-helper';
import { environment } from '../../src/environments/environment';
import { AppRoutes } from './app.routing';
declare var $: any;


@Component({
    selector: 'app-root',
    template: '<router-outlet><app-spinner></app-spinner></router-outlet>',
    styleUrls: ['../assets/plugins/toast-master/css/jquery.toast.css'],
    encapsulation: ViewEncapsulation.None
})

export class AppComponent {
    messages;
    connection;
    connectionName;
    connectionEmail;
    connectionNotification;
    message;
    names;
    email;
    notificationSocket;
    searchSaveStatus: number = -1;
    enumsHelper: EnumsHelper = new EnumsHelper();
    constructor(
        public router: Router,
        private authService: AuthService,
        private notification: NotificationService,
        private notificationService: NotificationServ) {
        for (let route of AppRoutes[1].children) {
            if (location.href.indexOf(route.path) > -1) {
                if (location.href.indexOf('#') > -1) {
                    localStorage.setItem("locationToRedirect", location.href.substring(environment.frontUrlApi.length + 2, location.href.length))
                } else {
                    localStorage.setItem("locationToRedirect", location.href.substring(environment.frontUrlApi.length + 2, location.href.length))
                }
            }
        }
        if (environment.envName == 'prod')
            (<any>window).ga('create', 'UA-124035526-1', 'auto');

    }

    loggedIn() {
        return this.authService.loggedIn();
    }

    sendMessage(notification) {
        let userInfo = this.authService.getUserInfoModel();
        this.message = notification.discriptionNotification;
        this.email = notification.responsibleEmail;
        this.notificationSocket = notification;
        this.notificationService.sendMessage(this.message, this.email, this.notificationSocket);
        this.message = '';
    }

    ngOnInit() {
        this.connectionNotification = this.notificationService.getNotification().subscribe(notification => {
            this.notificationSocket = notification;
            this.messages = notification;
            let userInfo = this.authService.getUserInfoModel();
            var name = userInfo.firstName + " " + userInfo.lastName
            this.searchSaveStatus = 0;
            if (name == this.messages.text.userFirstName && userInfo.email == this.messages.text.responsibleEmail) {
                setTimeout(() => {
                    switch (this.searchSaveStatus) {
                        case 0:
                            this.enumsHelper.toast("Você possui uma nova notificação", "info");
                            break;
                    }
                }, 1000);
            } else {
                if (userInfo.email == this.messages.text.responsibleEmail) {
                    setTimeout(() => {
                        switch (this.searchSaveStatus) {
                            case 0:
                                this.enumsHelper.toast("Você possui uma nova notificação de " + this.messages.text.userFirstName, "info");
                                break;
                        }
                    }, 1000);
                }
            }
        })
    }

    ngOnDestroy() {
        this.connection.unsubscribe();
        this.connectionName.unsubscribe();
    }
}
