import { Component, HostBinding, OnInit, ViewEncapsulation, ViewChild, HostListener } from '@angular/core';
import { MenuItems } from '../../shared/menu-items/menu-items';
import { animate, AUTO_STYLE, state, style, transition, trigger } from '@angular/animations';
import { Routes } from '@angular/router';
import { NotificationServ } from '../../../../_services/notificationSoquet.service';
import { Router, ActivatedRoute } from '@angular/router';
import { AuthLayoutComponent } from '../auth/auth-layout.component';
import { AuthService } from './../../../../_services/auth.service';
import { NotificationModel } from '../../models/notification.model';
import { BusinessUnit } from '../../common/business-unit';
import { EnumsHelper } from '../../common/enums-helper';
import { Pipe, PipeTransform } from '@angular/core';
import * as moment from 'moment';
import { Http } from '@angular/http';
import { OpportunityModel } from '../../models/opportunity.model';
import { Location } from '@angular/common';
import { TargetLocator } from 'selenium-webdriver';
import * as $ from 'jquery';

moment.locale('pt-BR');

@Component({
  selector: 'app-admin-layout',
  templateUrl: './admin-layout.component.html',
  styleUrls: ['./admin-layout.component.css'],
  encapsulation: ViewEncapsulation.None,
  animations: [
    trigger('slideInOut', [
      state('shw-rside', style({
        transform: 'translate3d(0, 0, 0)'
      })),
      state('off', style({
        transform: 'translate3d(100%, 0, 0)'
      })),
      transition('shw-rside => off', animate('400ms ease-in-out')),
      transition('off => shw-rside', animate('400ms ease-in-out'))
    ]),
    trigger('toggledMenu', [
      state('out, void',
        style({
          overflow: 'hidden',
          height: '0px',
        })
      ),
      state('in',
        style({
          overflow: 'hidden',
          height: AUTO_STYLE,
        })
      ),
      transition('out <=> in', [
        animate('400ms ease-in-out')
      ])
    ]), trigger('toggledSubMenu', [
      state('off, void',
        style({
          overflow: 'hidden',
          height: '0px',
        })
      ),
      state('on',
        style({
          overflow: 'hidden',
          height: AUTO_STYLE,
        })
      ),
      transition('off <=> on', [
        animate('400ms ease-in-out')
      ])
    ])
  ]
})

@Pipe({
  name: 'limitTo'
})
export class AdminLayoutComponent implements OnInit {
  notificationModel: NotificationModel = new NotificationModel();
  notifications = [];
  limit: number = 5;
  routeNotification: String;
  name: string = "";
  opportunityModel: OpportunityModel = new OpportunityModel();
  image: string;
  public enumsHelper: EnumsHelper = new EnumsHelper();
  public menuType: string;
  public headerType: string;
  public sidebarType: string;
  public themeType: string;
  public toggledArrow: string;
  public selected: any;
  public ddlBusinessUnit: BusinessUnit[];
  public selectedSub: any;
  public windowHeight: number;
  public windowWidth: number;
  public settingToggle: string;
  public modal: boolean = false;

  constructor(public menuItems: MenuItems,
    private authService: AuthService,
    private router: Router,
    private notificationSqtService: NotificationServ,
    private location: Location,
    private http: Http) {
    this.image = localStorage.getItem('image');
    this.ddlBusinessUnit = this.enumsHelper.getBusinessUnitArray();
    this.themeType = 'default';
    this.toggledArrow = 'icon-arrow-left-circle';
    this.settingToggle = 'off';
    this.windowHeight = window.innerHeight - 60;
    this.windowWidth = window.innerWidth;
    if (this.windowWidth < 1170) {
      this.menuType = 'mini-sidebar';
    }
    if (this.windowWidth < 768) {
      this.toggledArrow = 'fa fa-bars';
    }
  }
  ngOnInit() {
    this.searchOnInit();
    this.notificationSqtService.getNotification().subscribe(notification => {
      this.searchOnInit();
    })
    this.fixedMessagePosition();
    var userInfo = JSON.parse(localStorage.getItem('userInfo'));
    this.name = userInfo.firstName;
    this.headerType = 'fix-header';
    this.sidebarType = 'fix-sidebar';
  }


  fixedMessagePosition() {
    let i = 0
    while (i < 500) {
      setTimeout(() => {
        let boxWhiteEl = $('.white-box');
        let boxWhiteElWidth = boxWhiteEl.width() + 15;
        let boxWhiteElLeftValue = boxWhiteEl.offset().left + 15;
        $('.fillPercentage').css({
          'width': boxWhiteElWidth + 'px',
          'left': boxWhiteElLeftValue + "px"
        });
      }, 10)
      i++
    } 

  }

  @HostListener('window:resize', ['$event'])
  onResize(event) {
    this.fixedMessagePosition();
    this.windowHeight = event.target.innerHeight - 60;
    this.windowWidth = window.innerWidth;
    if (this.windowWidth < 1170) {
      this.menuType = 'mini-sidebar';
    } else {
      this.menuType = '';
    }

    if (this.windowWidth < 768) {
      this.toggledArrow = this.menuType === 'mini-sidebar show-sidebar' ? 'fa fa-close' : 'fa fa-bars';
    } else {
      this.toggledArrow = this.menuType === 'mini-sidebar' ? 'fa fa-bars' : 'icon-arrow-left-circle';
    }
  }

  onToggled() {
    if (this.windowWidth < 768) {
      this.selectedSub = 0;
      this.selected = 0;
      this.menuType = this.menuType === 'mini-sidebar show-sidebar' ? 'mini-sidebar' : 'mini-sidebar show-sidebar';
      this.toggledArrow = this.menuType === 'mini-sidebar show-sidebar' ? 'fa fa-close' : 'fa fa-bars';
    } else {
      this.selectedSub = 0;
      this.selected = 0;
      this.toggledArrow = this.menuType === 'mini-sidebar' ? 'icon-arrow-left-circle' : 'fa fa-bars';
      this.menuType = this.menuType === 'mini-sidebar' ? '' : 'mini-sidebar';
    }
  }

  searchOnInit() {
    let userInfo = this.authService.getUserInfoModel();
    this.notificationModel.responsibleEmail = userInfo.email;
    this.notificationSqtService.search(this.notificationModel).subscribe(r => {
      this.notifications = []
      for (let cr of r.object) {
        let c = cr;
        this.notifications.push(c)
      }
    })


  }

  abrirModal() {
    this.modal = true;
  }
  fecharModal() {
    this.modal = false;
  }

  viewNotification(notification) {
    this.notificationSqtService.delete(notification).subscribe(r => {
      this.searchOnInit();
      // this.router.navigateByUrl('/candidate/edit/id' + notification.candidateId);
    });

  }

  formatDate(registrationDate: Date) {
    return moment(registrationDate).format('L');
  }
  formatTime(registrationDate: Date) {
    return moment(registrationDate).format('LT');
  }

  toggleSetting() {
    this.settingToggle = this.settingToggle === 'shw-rside' ? 'off' : 'shw-rside';
  }

  changeHeader() {
    // this.headerType = this.headerType === 'fix-header' ? '' : 'fix-header';
    this.headerType = 'fix-header';
  }

  changeSidebar() {
    // this.sidebarType = this.sidebarType === 'fix-sidebar' ? '' : 'fix-sidebar';
    this.sidebarType = 'fix-sidebar';
  }

  changeThemeType(themeColor: string) {
    this.themeType = themeColor;
  }

  onClickedOutside(e: Event) {
    if (this.windowWidth < 768) {
      this.toggledArrow = 'fa fa-bars';
      this.menuType = 'mini-sidebar';
    }
  }

  select(item) {
    this.selectedSub = 0;
    this.selected = (item !== this.selected) ? item : 0;
  }

  selectSub(item, main_item) {
    this.selectedSub = (item !== this.selectedSub) ? item : 0;
    this.selected = main_item;
  }

  Logout() {
    this.authService.logout();
    this.router.navigate(['/login']);
    return false;

  }
  closeModal() {
    this.modal = false;
  }

  hideImage() {
    this.image = "";
  }

  changeImage() {
    this.closeModal();
    this.image = localStorage.getItem('image');
    caches.open('v1').then(function (cache) {
      cache.delete(localStorage.getItem('image')).then(function (response) {
        location.reload();
      });
    })
  }
}



