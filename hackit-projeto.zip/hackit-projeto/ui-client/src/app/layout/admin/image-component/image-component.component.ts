import { AuthService } from './../../../../../_services/auth.service';
import { Component, OnInit, ViewChild, Output, EventEmitter } from '@angular/core';
import { ImageCropperComponent, CropperSettings } from "ng2-img-cropper";
import { Subscription } from 'rxjs'
import { EnumsHelper } from '../../../common/enums-helper';
import { UserModel } from '../../../models/user.model';

@Component({
  selector: 'app-image-component',
  templateUrl: './image-component.component.html',
  styleUrls: ['./image-component.component.css'] 
})



export class ImageComponentComponent implements OnInit {
  showingWebCam: boolean = false;
  base64
  limit: number = 5;
  routeNotification: String;
  name: string = "";
  user:UserModel = new UserModel();
  id = localStorage._id;
  sucesso = false;
  files;
  btnStatus: string = '';

  
  @Output() cancel = new EventEmitter();
  @Output() changeImage = new EventEmitter();
  @Output() hideImage = new EventEmitter();

  @ViewChild('cropper') cropper: ImageCropperComponent;
  public dropped(event: any) {
    this.files = event.files;
    for (var file of event.files) {
      file.fileEntry.file(info => {
        var image: any = new Image();
        var file: File = info;
        var myReader: FileReader = new FileReader();
        var that = this;
        myReader.onloadend = function (loadEvent: any) {
          image.src = loadEvent.target.result;
          that.cropper.setImage(image);

          that.picture = image;

        };
        myReader.readAsDataURL(file);
      });
    }
  }


  public fileOver(event) {
    console.log(event);
  }

  public fileLeave(event) {
    console.log(event);
  }
  data1: any;
  edited: boolean = false
  cropperSettings1: CropperSettings;
  croppedWidth: number;
  croppedHeight: number;
  picture: any;
  title: string = "some title";
  subscription: Subscription;
  enummselper: EnumsHelper = new EnumsHelper()
  constructor(
    private authService: AuthService,

  ) {
    this.cropperSettings1 = new CropperSettings();
    this.cropperSettings1.dynamicSizing = true
    this.cropperSettings1.croppedWidth = 900;
    this.cropperSettings1.croppedHeight = 900;

    this.cropperSettings1.canvasWidth = 900;
    this.cropperSettings1.canvasHeight = 900;

    this.cropperSettings1.cropperDrawSettings.strokeColor = '#0091ea';
    this.cropperSettings1.cropperDrawSettings.strokeWidth = 2;
    this.cropperSettings1.fileType = 'image/jpeg';
    this.cropperSettings1.cropperClass = 'croperXD'
    this.cropperSettings1.noFileInput = true
    this.data1 = {};


  }
  ngOnInit() {
    var userInfo = JSON.parse(localStorage.getItem('userInfo'));
    this.name = userInfo.firstName;
  }

  fileChangeListener($event) {
    this.edited = true;
    this.showingWebCam = false;
    var image: any = new Image();
    var file: File = $event.target.files[0];
    var myReader: FileReader = new FileReader();
    var that = this;
    myReader.onloadend = function (loadEvent: any) {
      image.src = loadEvent.target.result;
      that.cropper.setImage(image);
      that.picture = image;

    };
    myReader.readAsDataURL(file);
  }

  upload() {
    if (this.data1['image']) {
      this.btnStatus = 'loading';
      this.hideImage.emit();
      this.authService.uploadImageUser(this.data1['image']).subscribe(uploadedImage => {
        localStorage.setItem('image', uploadedImage.profileImage)
        setTimeout(r => {
          this.changeImage.emit();
        }, 2000)
        this.enummselper.toast("Imagem atualizada com sucesso", "success")
        this.btnStatus = ''
        this.editar();
      }, err => {
        this.enummselper.toast(err.Errors.message, "warning");
      })
    } else {
      setTimeout(r => {
        this.changeImage.emit();
      }, 2000)
      this.editar();
      this.enummselper.toast("Imagem não atualizada", "warning");
      this.btnStatus = ''
    }
  }
  onCamError(err) { }

  onCamSuccess() { }

  cancelModal() {
    this.cancel.emit();
  }

    editar(){
      let userModel = new UserModel();
      userModel.firstName = this.name;
    this.authService.editUser(userModel).subscribe(r => {
      let userInfo = JSON.parse(localStorage.getItem('userInfo'));
      userInfo.firstName = this.name;
      localStorage.setItem('userInfo', JSON.stringify(userInfo));
      
      this.enummselper.toast("Perfil atualizado com sucesso", "success")},
      (err) => {
        this.enummselper.toast("Erro na edição", "warning");
    });
  }
}
