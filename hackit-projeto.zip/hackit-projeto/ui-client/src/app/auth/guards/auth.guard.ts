import { Injectable } from '@angular/core';
import { Router, CanActivate } from '@angular/router';
import { Observable } from 'rxjs/Rx';
import { UserModel } from '../../models/user.model';
import { AuthService } from '../../../../_services/auth.service';
import { OAuthCallbackHandler } from './oauth-callback.guard'
import { EnumsHelper } from '../../common/enums-helper';
import { UserInfoModel } from '../../models/user-info.model';
declare var $: any;
@Injectable()
export class AuthGuard implements CanActivate {
    userModel: UserModel = new UserModel();
    authenticationEmail: boolean = false;
    error: String;
    enumsHelper: EnumsHelper = new EnumsHelper();
    constructor(
        private authService: AuthService,
        private router: Router) { }

    canActivate(): Observable<boolean> | boolean {
        var userInfo = JSON.parse(localStorage.getItem('userInfo'));
        if (this.authService.loggedIn()) {

            if (localStorage.getItem('email') == null || localStorage.getItem('email') == '') {
                localStorage.setItem('email', userInfo.email);
            }

            return this.authService.emailAuthentication(localStorage.getItem('email')).map(x => {
                var res = x;
                if (res.message === "Authorized") {
                    let userInfo: UserInfoModel = new UserInfoModel();
                    userInfo.email = res.user[0].email;
                    userInfo.username = res.user[0].username;
                    userInfo.firstName = res.user[0].firstName;
                    userInfo.lastName = res.user[0].lastName;
                    userInfo.company_id = res.user[0].company_id;
                    localStorage.setItem('_id', res.user[0]._id);
                    localStorage.setItem('userInfo', JSON.stringify(userInfo));
                    if (res.user[0].profileImage)
                        localStorage.setItem('image', res.user[0].profileImage);

                    return true;
                } else {
                    this.enumsHelper.toast(res.message, "warning");
                    this.authService.logout();
                }

            });

        } else {
            this.router.navigate(['/login']);
            return false;
        }
    }


    returnPassword(password) {
        return password;
    }

}