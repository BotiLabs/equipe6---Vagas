import { Injectable } from '@angular/core';
import { Router, CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs/Rx';

import { AuthService } from '../../../../_services/auth.service';
import { UserInfoModel } from '../../models/user-info.model';
import { stringify } from '@angular/core/src/util';

@Injectable()

export class OAuthCallbackHandler implements CanActivate {

    constructor(
        private router: Router,
        private authService: AuthService) { }

    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> | boolean {

        return false;
    }

} 