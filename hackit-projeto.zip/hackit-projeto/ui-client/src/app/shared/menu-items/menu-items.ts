import { Injectable } from '@angular/core';

export interface BadgeItem {
    type: string;
    value: string;
}

export interface ChildrenItems {
    state: string;
    target?: boolean;
    name: string;
    type?: string;
    children?: ChildrenItems[];
}

export interface MainMenuItems {
    state: string;
    main_state?: string;
    target?: boolean;
    name: string;
    type: string;
    icon: string;
    badge?: BadgeItem[];
    children?: ChildrenItems[];
}

export interface Menu {
    label: string;
    main: MainMenuItems[];
}

const MENUITEMS = [
    {
        label: 'Dashboard',
        main: [
            {
                state: 'dashboard',
                name: 'Dashboard',
                type: 'link',
                icon: 'icon-home',
            },
            {
                state: 'candidate',
                name: 'Candidatos',
                type: 'link',
                icon: 'icon-user'
            },
            {
                state: 'opportunities',
                name: 'Vagas',
                type: 'link',
                icon: 'icon-drawar'
            },
           
            // {
            //     state:'matches',
            //     name:'Combinações',
            //     type:'link',
            //     icon:'icon-check'
            // },

            {
                state: 'evaluation',
                name: 'Avaliações',
                type: 'link',
                icon: 'icon-note'
            },
            {
                state: 'tags',
                name: 'Tags',
                type: 'link',
                icon: 'icon-tag'
            },
            {
                state: 'softskills',
                name: 'Competências',
                type: 'link',
                icon: 'icon-layers'
            },
            // {
            //     state: 'reports',
            //     name: 'Relatórios',
            //     type: 'sub',
            //     icon: 'fa fa-file-text-o',
            //     children: [
            //         {
            //             state: 'actions',
            //             name: 'Ações'
            //         },
            //         {
            //             state: 'opportunities-closed-match',
            //             name: 'Contratações'
            //         },
            //         // {
            //         //     state: 'candidate-report',
            //         //     name: 'Fluxo do candidato'
            //         // },
            //         {
            //             state: 'media',
            //             name: 'Origem'
            //         },
            //         // {
            //         //     state: 'selection',
            //         //     name: 'Recrutamento'
            //         // },

            //         // {
            //         //     state: 'opportunities-closed',
            //         //     name: 'Vagas fechadas'
            //         // },


            //     ]
            // },
            // {
            //     state: 'customer',
            //     name: 'Clientes',
            //     type: 'link',
            //     icon: 'icon-briefcase',
            // },
            
            // {
            //     state: 'admin',
            //     name: 'Ajustes',
            //     type: 'sub',
            //     icon: 'fa fa-gears',
            //     children: [
            //         {
            //             state: 'customer',
            //             name: 'Cliente'
            //         },
                    // {
                    //     state:'logs',
                    //     name:'Logs',

                    // }, 
                    // {
                    //     state: 'users',
                    //     name: 'Usuários'
                    // },
                    // {
                    //     state:'qualification',
                    //     name:'Qualificação'
                    // },
                    // {
                    //     state: "blacklist",
                    //     name: "Candidatos com impedimento"
                    // },
                    // Comentado porque ainda está em fase de testes
            //         {
            //             state: "service-management",
            //             name: "Configurações"
            //         }
            //     ]
            // },
            //    {
            //     state:'logout',
            //     name:'Sair',
            //     type:'link',
            //     icon:'fa fa-power-off'
            // }
        ]
    },

]



@Injectable()
export class MenuItems {
    getAll(): Menu[] {
        return MENUITEMS;
    }
}
