import { NgModule } from '@angular/core';
import { Http } from '@angular/http';
import { CepModel } from './cep.model';
@NgModule()

export class CepModule {

  cepModel: CepModel = new CepModel();

  constructor(private http: Http) { }

  buscar(cep: string) {
    return this.http.get(`https://viacep.com.br/ws/${cep}/json/`)
      .toPromise()
      .then(response => this.convertToModel(response.json()));
  }

  private convertToModel(c) {
    console.log(c);
    let cep: CepModel = new CepModel();
    cep.cep = c.cep;
    cep.logradouro = c.logradouro;
    cep.complemento = c.complemento;
    cep.bairro = c.bairro;
    cep.localidade = c.localidade;
    cep.uf = c.uf;
    return cep;
  }
}
