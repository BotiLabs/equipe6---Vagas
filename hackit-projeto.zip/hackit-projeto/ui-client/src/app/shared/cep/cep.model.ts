
export class CepModel {
    cep: string;
    logradouro: string;
    complemento: string;
    bairro: string;
    localidade: string;
    uf: string;

    constructor() {
        this.cep = "";
        this.logradouro = "";
        this.complemento = "";
        this.bairro = "";
        this.localidade = "";
        this.uf = "";
    }

}