import { StatusOfOpportunityService } from './../../_services/statusOpportuniry.service';
import { LogsComponent } from './pages/logs/logs.component';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { LocationStrategy, PathLocationStrategy, HashLocationStrategy } from '@angular/common';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { HttpClient } from '../../_services/http-client';
import { OpportunityService } from '../../_services/opportunity.service';
import { CandidateService } from '../../_services/candidate.service';
import { EvaluationService } from '../../_services/evaluation.service';
import { NotificationService } from '../../_services/notification.service';
import { InteractionListenService } from '../../_services/interaction-listen.service';
import { InteractionService } from '../../_services/interaction.service';
import { MatchService } from '../../_services/match.service';
import { TagService } from '../../_services/tag.service';
import { PersonalityService } from '../../_services/personality.service';
import { OriginService } from '../../_services/origin.service';
import { PositionService } from '../../_services/position.service';
import { LogService } from '../../_services/log.service';
import { SearchOp } from '../../_services/searchOp.service';
import { SearchCandidate } from '../../_services/search-candidate.service';
import { EmailService } from '../../_services/email.service';
import { TestingService } from '../../_services/testing.service';
import { PersistenceService } from 'angular-persistence'
import { NgxPaginationModule } from 'ngx-pagination';
import { RatingModule } from "ngx-rating";
import { AppComponent } from './app.component';
import { AdminLayoutComponent } from './layout/admin/admin-layout.component';
import { AuthLayoutComponent } from './layout/auth/auth-layout.component';
import { DashboardComponent } from './pages/dashboard/dashboard.component';
import { AppRoutes } from './app.routing';
import { SharedModule } from './shared/shared.module';
import { AuthService } from '../../_services/auth.service';
import { AuthGuard } from './auth/guards/auth.guard';
import { NotificationServ } from '../../_services/notificationSoquet.service';
import { OAuthCallbackHandler } from './auth/guards/oauth-callback.guard';
import { ListComponent } from './pages/candidate/list/list.component';
import { InputTrimModule } from 'ng2-trim-directive';
import { CompanyService } from '../../_services/company.service';
import { TemplateEmail } from './pages/candidate/interaction/templateEmailInteraction';
import { QualificationService } from '../../_services/qualification.service';
import { StatusOfCandidateService } from '../../_services/statusCandidate.service';
import { CKEditorModule } from 'ng2-ckeditor';
import { ChartModule } from 'primeng/primeng';
import { PositionOpportunityService } from '../../_services/position-opportunity.service';
import { ImageComponentComponent } from './layout/admin/image-component/image-component.component';
import { ApproachService } from '../../_services/approach.server';
import { ImageCropperModule } from 'ng2-img-cropper';
import { DomainService } from '../../_services/domain.service';
import { TypeService } from '../../_services/type.service';
import { DpartamentService } from '../../_services/dpartament.service';
import { PositionsService } from '../../_services/positions.service';
import { ActionService } from '../../_services/action.service';
import { FunctionService } from '../../_services/function.service';

import { ManagementService } from '../../_services/service-management.service';
import { FastRegistrationCandidateComponent } from './pages/dashboard/fast-registration-candidate/fast-registration-candidate.component';
import { CanDeactivateService } from '../../_services/canDeactivate.service';
import { SoftSkillService } from '../../_services/softskill.service';
@NgModule({
    declarations: [
        DashboardComponent,
        AppComponent,
        AdminLayoutComponent,
        AuthLayoutComponent,
        ImageComponentComponent,
        FastRegistrationCandidateComponent,
    ],
    imports: [
        BrowserModule,
        BrowserAnimationsModule,
        RouterModule.forRoot(AppRoutes, { useHash: true }),
        SharedModule,
        FormsModule,
        HttpModule,
        NgxPaginationModule,
        RatingModule,
        InputTrimModule,
        CKEditorModule,
        ChartModule,
        ImageCropperModule
    ],
    providers: [
        { provide: LocationStrategy, useClass: HashLocationStrategy },
        CandidateService,
        AuthService,
        OAuthCallbackHandler,
        HttpClient,
        ManagementService,
        OpportunityService,
        CandidateService,
        NotificationService,
        InteractionListenService,
        InteractionService,
        TagService,
        MatchService,
        EvaluationService,
        PersonalityService,
        OriginService,
        PositionService,
        LogService,
        SearchOp,
        SearchCandidate,
        EmailService,
        TestingService,
        AppComponent,
        PersistenceService,
        AuthGuard,
        LogsComponent,
        NotificationServ,
        ListComponent,
        TemplateEmail,
        CompanyService,
        QualificationService,
        StatusOfCandidateService,
        StatusOfOpportunityService,
        PositionOpportunityService,
        ApproachService,
        OriginService,
        DomainService,
        TypeService,
        DpartamentService,
        PositionsService,
        ActionService,
        FunctionService,
        SoftSkillService,
        CanDeactivateService
    ],

    bootstrap: [AppComponent]

})
export class AppModule { }