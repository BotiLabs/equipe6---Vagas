import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LogoutComponent } from './logout.component';
import { RouterModule, Routes } from '@angular/router';
import {SharedModule} from '../../shared/shared.module';

export const LoginRoutes: Routes = [{
  path: '',
  component: LogoutComponent,
  data: {
    heading: 'Logout'
  }
}];

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(LoginRoutes),
    SharedModule
  ],
  declarations: [LogoutComponent]
})
export class LogoutModule { }



















