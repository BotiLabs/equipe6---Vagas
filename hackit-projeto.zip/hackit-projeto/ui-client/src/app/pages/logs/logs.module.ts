import { LogsComponent } from './logs.component';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from '../../shared/shared.module';
import { InputTrimModule } from 'ng2-trim-directive';

export const LogsRoutes: Routes = [
    {
    path:'',
    component: LogsComponent,
    data: {
        heading: 'Logs'
        }
    }
];

@NgModule({
    imports: [
        CommonModule,
        RouterModule.forChild(LogsRoutes),
        SharedModule,
        InputTrimModule
    ],
    declarations: [LogsComponent]
})
export class LogsModule {}