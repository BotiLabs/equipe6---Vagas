import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EditCustomerComponent } from './edit-customer.component';
import { RouterModule, Routes } from '@angular/router';
import { CurrencyMaskModule } from 'ng2-currency-mask';
import { InputTrimModule } from 'ng2-trim-directive';
import { CKEditorModule } from 'ng2-ckeditor';
import { AngularMultiSelectModule } from 'angular2-multiselect-dropdown/angular2-multiselect-dropdown';
import { SharedModule } from '../../../shared/shared.module';

export const EditCustomerRoutes: Routes = [
  {
    path: '',
    component: EditCustomerComponent,
    data: {
      heading: 'edit-customer',
      status: false
    },
  }
];

@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    CurrencyMaskModule,
    CKEditorModule,
    InputTrimModule,
    AngularMultiSelectModule,
    RouterModule.forChild(EditCustomerRoutes)
  ],
  declarations: [EditCustomerComponent]
})
export class EditCustomerModule { }
