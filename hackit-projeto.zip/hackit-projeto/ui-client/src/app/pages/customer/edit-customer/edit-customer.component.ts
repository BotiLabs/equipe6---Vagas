import { Component, OnInit, Directive, Input } from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { OpportunityService } from '../../../../../_services/opportunity.service';
import { LocationOpportunityRequest } from '../../../common/location-opportunity.request';
import { EnumsHelper } from '../../../common/enums-helper';
// import { LogsComponent } from '../../logs/logs.component';
import { LocationModel } from '../../../models/location.model';
import { CustomerModel } from '../../../models/customerModel';
import '../../../../assets/plugins/toast-master/js/jquery.toast.js';
declare var $: any;
@Component({
  selector: 'app-edit-customer',
  templateUrl: './edit-customer.component.html',
  styleUrls: ['./edit-customer.component.css']
})

// @Directive({
//   selector: '[focusDirective]'
// })
export class EditCustomerComponent implements OnInit {
  @Input() cssSelector: string;
  locationModel: LocationModel = new LocationModel();
  locationToSave: LocationModel = new LocationModel();
  locations: LocationModel[] = [];
  locationsLoaded: boolean;
  locationsInit: LocationModel[] = [];
  totalItems: number;
  locationRequest: LocationOpportunityRequest = new LocationOpportunityRequest();
  enumsHelper: EnumsHelper = new EnumsHelper();
  selected: boolean = false;
  id: string = "";
  customer: CustomerModel = new CustomerModel();
  customerId: string = '';
  locationModelForm: LocationModel = new LocationModel();
  textButton: string = '';
  isEdit: string = '';
  customerInput: boolean = false;
  customerSelected: boolean = false;
  states: string[] = ['AC', 'AL', 'AM', 'AP', 'BA', 'CE', 'DF', 'ES', 'GO', 'MA', 'MT', 'MS', 'MG',
    'PA', 'PB', 'PR', 'PE', 'PI', 'RJ', 'RN', 'RO', 'RS', 'RR', 'SC', 'SE', 'SP', 'TO'];
  constructor(
    private opportunityService: OpportunityService,
    // private log: LogsComponent,
    private route: ActivatedRoute,
    private router: Router
  ) {

    (<any>window).ga('set', 'page', 'Edição de clientes');
    (<any>window).ga('send', 'pageview');
    this.isEdit = 'fa fa-check';
    this.textButton = 'SALVAR';

    if (this.route.snapshot.params['customerId']) {
      this.textButton = 'ADICIONAR';
      this.isEdit = 'fa fa-plus';
      this.locationRequest.clientLocation = this.route.snapshot.params['customerId'];
      let customer = new CustomerModel();
      customer._id = this.locationRequest.clientLocation;
      this.opportunityService.getCustomerById(customer).subscribe(item => {
        this.customerId = item._id;
        
        this.customer.loadFromServer(item);
        this.searchLocations(1);
      });
    }
  }

  ngOnInit() {
    console.log(this.customerId);
  }

  searchLocations(page) {
    this.locations = [];
    this.locationRequest.page = page;
    this.locationsLoaded = false;
    this.opportunityService.searchLocations(this.locationRequest).subscribe(r => {
      for (let l of r.result) {
        const location = new LocationModel();
        location.loadFromServer(l);
        this.locations.push(location);
      }
      this.totalItems = r.count;
      this.locationsLoaded = true;
    });
  }

  blockLocation(l) {
    if (l.blockedLocation) {
      l.blockedLocation = !l.blockedLocation;
    } else {
      l.blockedLocation = true;
    }
    this.locationModel.loadFromServer(l);
    this.opportunityService.updateLocation(this.locationModel).subscribe(r => {

      this.locationToSave = new LocationModel();
      var descricao = 'Alterou uma localização ';
      //this.log.create(descricao);
      this.locationModel = new LocationModel();
    }, err => {
      this.locationModel = new LocationModel();
    });

  }

  updateLocation(l: LocationModel) {

    l.loadFromServer(this.locationModel);
    this.opportunityService.updateLocation(this.locationModel).subscribe(r => {
      l.showDistrict = false;
      l.showStreetAddress = false;
      l.showDiscription = false;
      l.showState = false;
      this.id = '';
      this.selected = !this.selected;
    }, err => {
      this.enumsHelper.toast(err.Errors.message, 'Warning')
    });
  }

  showInput(l: LocationModel, value) {
    if (!this.selected) {
      this.id = l._id;
      switch (value) {
        case 'discription':
          l.showDiscription = true;
          l.showStreetAddress = false;
          l.showDistrict = false;
          l.showState = false;
          break;

        case 'streetAddress':
          l.showStreetAddress = true;
          l.showDiscription = false;
          l.showDistrict = false;
          l.showState = false;
          break;

        case 'district':
          l.showDistrict = true;
          l.showStreetAddress = false;
          l.showDiscription = false;
          l.showState = false;
          break;
        case 'state':
          l.showState = true;
          l.showStreetAddress = false;
          l.showDiscription = false;
          l.showDistrict = false;
          break;
        default:

          break;
      }
      this.locationModel.loadFromServer(l);
    }

  }

  turnSelectedTrue() {
    this.selected = !this.selected;
  }

  closeInputs(l: LocationModel) {
    if (!this.selected) {
      l.showDistrict = false;
      l.showStreetAddress = false;
      l.showDiscription = false;
      l.showState = false;
    }
  }

  editCustomer() {
    if (this.customerId) {
      this.updateLocationCustomer();
    } else {
      this.createCustomer();
    }
  }

  updateLocationCustomer() {
    this.locationModelForm.clientLocation = this.customerId;
    this.customer.unity.push(this.locationModelForm);
    this.opportunityService.updateLocationCustomer(this.customer).subscribe(r => {
      this.enumsHelper.toast('Localização inserida com sucesso!', 'success');
      this.searchLocations(1);
      this.locationModelForm = new LocationModel();
    }, err => {
      let error = JSON.parse(err._body)
      this.enumsHelper.toast(error.message, 'warning')
    })
  }


  createCustomer() {
    this.customer.name = this.enumsHelper.validateAscentClientname(this.customer.name);

    var barra = "\\";
    if (this.customer.name.substring(0, 1) == "@"
      || this.customer.name.substring(0, 1) == "#"
      || this.customer.name.substring(0, 1) == "!"
      || this.customer.name.substring(0, 1) == "$"
      || this.customer.name.substring(0, 1) == "*"
      || this.customer.name.substring(0, 1) == "("
      || this.customer.name.substring(0, 1) == ")"
      || this.customer.name.substring(0, 1) == "`"
      || this.customer.name.substring(0, 1) == "´"
      || this.customer.name.substring(0, 1) == "~"
      || this.customer.name.substring(0, 1) == "^"
      || this.customer.name.substring(0, 1) == ";"
      || this.customer.name.substring(0, 1) == ":"
      || this.customer.name.substring(0, 1) == ","
      || this.customer.name.substring(0, 1) == "."
      || this.customer.name.substring(0, 1) == "<"
      || this.customer.name.substring(0, 1) == ">"
      || this.customer.name.substring(0, 1) == "?"
      || this.customer.name.substring(0, 1) == "{"
      || this.customer.name.substring(0, 1) == "/"
      || this.customer.name.substring(0, 1) == "}"
      || this.customer.name.substring(0, 1) == "'"
      || this.customer.name.substring(0, 1) == '"'
      || this.customer.name.substring(0, 1) == "+"
      || this.customer.name.substring(0, 1) == "-"
      || this.customer.name.substring(0, 1) == "_"
      || this.customer.name.substring(0, 1) == "="
      || this.customer.name.substring(0, 1) == "§"
      || this.customer.name.substring(0, 1) == '|'
      || this.customer.name.substring(0, 1) == '¨'
      || this.customer.name.substring(0, 1) == '"'
      || this.customer.name.substring(0, 1) == "'"
      || this.customer.name.substring(0, 1) == "["
      || this.customer.name.substring(0, 1) == "]"
      || this.customer.name.substring(0, 1) == barra.substring(0, 1)) {
      this.enumsHelper.toast("O nome da empresa não pode começar com caracteres especiais", "warning");
      return;
    }

    this.customer.unity.push(this.locationModelForm);
    this.opportunityService.createCustomer(this.customer).subscribe(r => {
      this.locationModelForm = new LocationModel();
      this.enumsHelper.toast("Cliente cadastrado com sucesso!", "success");
      var message = "Criou o cliente " + this.customer.name;
      //this.log.create(message);
      this.router.navigate(['/admin/edit-customer/', r._id]);
    }, (err) => {
      this.enumsHelper.toast(err.Errors.message, "success");
    })
  }

  showCustomerInput() {
    this.customerInput = true;
  }

  closeCustomerInput() {
    if (!this.customerSelected) {
      this.customerInput = false;
    }
  }

  updateCustomer() {
    this.opportunityService.updateCustomer(this.customer).subscribe(customer => {
      this.customer.name = customer.name;
      this.customerSelected = false;
      this.customerInput = false;
    }, err => {
      this.enumsHelper.toast(err.Errors.message, 'warning');
    })
  }

  turnCustomerSelectedTrue() {
    this.customerSelected = true;
  }

}





