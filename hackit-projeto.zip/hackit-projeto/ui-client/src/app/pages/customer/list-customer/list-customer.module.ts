import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { CurrencyMaskModule } from 'ng2-currency-mask';
import { InputTrimModule } from 'ng2-trim-directive';
import { CKEditorModule } from 'ng2-ckeditor';
import { AngularMultiSelectModule } from 'angular2-multiselect-dropdown/angular2-multiselect-dropdown';
import { SharedModule } from '../../../shared/shared.module';
import { ListCustomerComponent } from './list-customer.component';
import { InfiniteScrollModule } from 'ngx-infinite-scroll';

export const ListCustomerRoutes: Routes = [
  {
    path: '',
    component: ListCustomerComponent,
    data: {
      heading: 'list-customer',
      status: false
    },
  }
];

@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    CurrencyMaskModule,
    CKEditorModule,
    InputTrimModule,
    AngularMultiSelectModule,
    InfiniteScrollModule,
    RouterModule.forChild(ListCustomerRoutes)
  ],
  declarations: [ListCustomerComponent]
})
export class ListCustomerModule { }
