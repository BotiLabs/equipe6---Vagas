import { EnumsHelper } from '../../../common/enums-helper';
import { OpportunitiesRequest } from '../../../common/opportunities.request';
import { Component, OnInit } from '@angular/core';
import { OpportunityService } from '../../../../../_services/opportunity.service';
import { CustomerModel } from '../../../models/customerModel';
// import { LogsComponent } from '../../logs/logs.component';
import { CustomerRequest } from '../../../common/customer.request';
import { EventEmitterService } from '../../../../../_services/event-emitter.service';
import { LocationModel } from '../../../models/location.model';
import { trigger, style, animate, transition } from '@angular/animations';

declare var $: any;
@Component({
  selector: 'app-customer',
  templateUrl: './list-customer.component.html',
  styleUrls: ['./list-customer.component.css'],
  animations: [
    trigger('fadeInOut', [
      transition(':enter', [   // :enter is alias to 'void => *'
        style({ opacity: 0 }),
        animate(500, style({ opacity: 1 }))
      ]),
      transition(':leave', [   // :leave is alias to '* => void'
        animate(500, style({ opacity: 0 }))
      ])
    ])
  ]
})

export class ListCustomerComponent implements OnInit {
  customer: any[];
  customerModel: CustomerModel = new CustomerModel();
  opportunitiesRequest: OpportunitiesRequest = new OpportunitiesRequest();
  itemsPerPage: number[] = [10, 50, 100];
  totalItems: number;
  page: number;
  customerSave: CustomerModel[] = [];
  customerToSave: CustomerModel = new CustomerModel();
  searchSaveStatus: number = -1;
  enumsHelper: EnumsHelper = new EnumsHelper();
  customers: any[];
  customersLoaded: boolean = true;
  expand: boolean = false;
  customerRequest: CustomerRequest = new CustomerRequest();
  limit: number = 12;
  constructor(
    private opportunityService: OpportunityService
    // private log: LogsComponent,
  ) {
    (<any>window).ga('set', 'page', 'Grid de clientes');
    (<any>window).ga('send', 'pageview');
  }

  ngOnInit() {
    this.customer = [];
    this.searchCustomerName(1, false);
    this.getAllCustomers();
    $('.tst3').on('click', () => {
      setTimeout(() => {
        switch (this.searchSaveStatus) {
          case 0:
            this.enumsHelper.toast('Tag cadastrada com sucesso!', 'success');
            break
          case 1:
            this.enumsHelper.toast('Digite o nome do cliente.', 'warning');
            break;
          case 2:
            this.enumsHelper.toast('A pesquisa deve ter um nome.', 'warning');
            break;
          case 3:
            this.enumsHelper.toast('Erro ao salvar, Tag já existe ou você esqueceu de digitar o nome da tag', 'error');
            break;
          case 4:
            this.enumsHelper.toast('Cliente atualizado com sucesso!', 'success');
            break;
          case 5:
            this.enumsHelper.toast('A tag não pode começar com um espaço em branco', 'warning');
            break;
        }
      }, 1000);
    });
  }

  searchCustomerName(page: number, scroll: boolean) {
    if (!scroll) {
      this.customer = [];
  }
    this.customersLoaded = false;
    this.page = page;
    this.customerRequest.page = page;
    this.customerRequest.limit = this.limit;
    this.opportunityService.searchCustomer(this.customerRequest).subscribe(r => {
      this.customersLoaded = true;
      for (let cr of r.result) {
        let cN;
        cN = cr;
        this.customerSave.push(cr);
        this.customer.push(cN);
      }
      this.totalItems = r.count;
    });

  }


  getAllCustomers() {
    this.customers = [];

    this.opportunityService.getCustomer().subscribe(r => {
      for (let cr of r.result) {
        let cN = new CustomerModel;
        cN.loadFromServer(cr)
        this.customers.push(cN);
      }
    });

  }

  createCustomer() {
    this.customerModel.name = this.opportunitiesRequest.customerName;
    var name = this.enumsHelper.validateAscentClientname(this.customerModel.name);

    for (let c of this.customers) {
      if (name.toUpperCase() == this.enumsHelper.validateAscentClientname(c.name.toLowerCase()).toUpperCase()) {
        this.enumsHelper.toast("Já existe um cliente com este nome!", "warning");
        return;
      }
    }

    if (this.customerModel._id === undefined) {
      var barra = '\\';
      if (this.customerModel.name.substring(0, 1) == " "
        || this.customerModel.name.substring(0, 1) == ""
        || this.customerModel.name.substring(0, 1) == "@"
        || this.customerModel.name.substring(0, 1) == "#"
        || this.customerModel.name.substring(0, 1) == "!"
        || this.customerModel.name.substring(0, 1) == "$"
        || this.customerModel.name.substring(0, 1) == "*"
        || this.customerModel.name.substring(0, 1) == "("
        || this.customerModel.name.substring(0, 1) == ")"
        || this.customerModel.name.substring(0, 1) == "`"
        || this.customerModel.name.substring(0, 1) == "´"
        || this.customerModel.name.substring(0, 1) == "~"
        || this.customerModel.name.substring(0, 1) == "^"
        || this.customerModel.name.substring(0, 1) == ";"
        || this.customerModel.name.substring(0, 1) == ":"
        || this.customerModel.name.substring(0, 1) == ","
        || this.customerModel.name.substring(0, 1) == "."
        || this.customerModel.name.substring(0, 1) == "<"
        || this.customerModel.name.substring(0, 1) == ">"
        || this.customerModel.name.substring(0, 1) == "?"
        || this.customerModel.name.substring(0, 1) == "{"
        || this.customerModel.name.substring(0, 1) == "/"
        || this.customerModel.name.substring(0, 1) == "}"
        || this.customerModel.name.substring(0, 1) == "'"
        || this.customerModel.name.substring(0, 1) == '"'
        || this.customerModel.name.substring(0, 1) == "+"
        || this.customerModel.name.substring(0, 1) == "-"
        || this.customerModel.name.substring(0, 1) == "_"
        || this.customerModel.name.substring(0, 1) == "="
        || this.customerModel.name.substring(0, 1) == "§"
        || this.customerModel.name.substring(0, 1) == '|'
        || this.customerModel.name.substring(0, 1) == '¨'
        || this.customerModel.name.substring(0, 1) == '"'
        || this.customerModel.name.substring(0, 1) == "'"
        || this.customerModel.name.substring(0, 1) == "["
        || this.customerModel.name.substring(0, 1) == "]"
        || this.customerModel.name.substring(0, 1) == barra.substring(0, 1)
        || this.customerModel.name.substring(this.customerModel.name.length - 1, this.customerModel.name.length) == " ") {
        this.enumsHelper.toast("O nome não do cliente não pode começar e/ou terminar em branco ou começar com caracteres especiais", "warning");
        return;
      } this.customerModel.blockedCustomer;


      this.opportunityService.createCustomer(this.customerModel).subscribe(r => {
        this.getCustomerName();
        this.enumsHelper.toast("Cliente cadastrado com sucesso!", "success");
        this.customerModel = new CustomerModel();
        var message = "Criou o cliente " + this.customerModel.name;
        //this.log.create(message);
        this.getAllCustomers();

      }, (err) => {
        this.enumsHelper.toast(err.Errors.message, "warning");
      })
      this.customerModel = new CustomerModel();
      return;
    } else {
      this.opportunityService.updateToDelete(this.customerToSave).subscribe(r => {
        //this.notificationService.notify('Tag atualizada com sucesso!');
        this.customerToSave = new CustomerModel();
        this.searchCustomerName(1, false);
        this.searchSaveStatus = 4;
        var descricao = "Alterou um cliente ";
        //this.log.create(descricao);
        this.customerModel = new CustomerModel();
        this.getAllCustomers();
      }, err => {
        var error = JSON.parse(err._body)
        this.enumsHelper.toast(error.message, "warning");
        this.customerModel = new CustomerModel();
        return;

      });
    }
  }

  getCustomerName() {
    this.customer = [];

    this.opportunityService.getCustomer().subscribe(r => {

      for (let cr of r.result) {
        let cN = new CustomerModel;
        cN.loadFromServer(cr)
        this.customer.push(cN);
      }
      this.totalItems = r.count;
    });

  }


  setCustumerToEdit(id: string) {

    this.customerToSave = this.customerSave.find(x => x._id === id);
    this.customerModel = this.customerToSave;
    this.opportunitiesRequest.customerName = this.customerToSave.name;
  }


  blockCustomer(c) {
    if (c.blockedCustomer) {
      c.blockedCustomer = !c.blockedCustomer;
    } else {
      c.blockedCustomer = true;
    }
    this.customerModel.loadFromServer(c);
    this.opportunityService.updateCustomer(this.customerModel).subscribe(r => {
      this.customerToSave = new CustomerModel();
      let descricao = 'Alterou uma tag ';
      //this.log.create(descricao);
      this.customerModel = new CustomerModel();
    }, err => {
      this.customerModel = new CustomerModel();
    });
  }


  expandCard(c: CustomerModel) {
    c.expand = !c.expand;
  }


  expandLocation(l: LocationModel) {
    l.selected = !l.selected;
  }

  msg(locations: number) {
    let msg = "";
    switch (locations) {
      case 0:
        msg = "NENHUMA UNIDADE";
        break;
      case 1:
        msg = locations + " UNIDADE CADASTRADA";
        break;
      default:
        msg = locations + " UNIDADES CADASTRADAS";
        break;
    }
    return msg;
  }

  sendCustomer(c: CustomerModel) {
    EventEmitterService.get('customer').emit(c);
  }

  onScroll() {
    if (this.customer.length > 0) {
      console.log(this.customer)
        this.page++;
        this.searchCustomerName(this.page, true);
    }
}

}