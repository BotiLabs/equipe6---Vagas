import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EditLocationComponent } from './edit-location.component';
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from '../../../shared/shared.module';
import { CurrencyMaskModule } from "ng2-currency-mask"; 
import { InputTrimModule } from 'ng2-trim-directive';
export const EditLocationRoutes: Routes = [
  {
    path: '',
    component: EditLocationComponent,
    data: {
      heading: 'edit-location',
      status:false
    }
  }
];

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(EditLocationRoutes),
    SharedModule,
    CurrencyMaskModule,
    InputTrimModule
  ],
  declarations: [EditLocationComponent]
})
export class EditLocationModule { }
