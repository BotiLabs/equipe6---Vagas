import { Component, OnInit } from '@angular/core';
import { OpportunityService } from '../../../../../_services/opportunity.service';
import { LocationModel } from '../../../models/location.model';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { LogsComponent } from '../../logs/logs.component';
import { EnumsHelper } from '../../../common/enums-helper';
declare var $: any;


@Component({
  selector: 'app-edit-location',
  templateUrl: './edit-location.component.html',
  styleUrls: ['./edit-location.component.css']
})
export class EditLocationComponent implements OnInit {

  location: any[];
  locationModel: LocationModel = new LocationModel();
  local: any;
  success: any;
  enumsHelper: EnumsHelper = new EnumsHelper();
  states: String[] = ["AC", "AL", "AM", "AP", "BA", "CE", "DF", "ES", "GO", "MA", "MT", "MS", "MG", "PA", "PB", "PR", "PE", "PI", "RJ", "RN", "RO", "RS", "RR", "SC", "SE", "SP", "TO"];
  constructor(
    private opportunityService: OpportunityService,
    private route: ActivatedRoute,
    private log: LogsComponent,
    private router: Router,
  ) {
    (<any>window).ga('set', 'page', 'Editar localização');
    (<any>window).ga('send', 'pageview');
  }

  ngOnInit() {
    this.opportunityService.getLocationById(this.route.snapshot.params['id']).subscribe(r => {
      this.locationModel.loadFromServer(r);
    });
  }

  getLocation() {
    this.location = [];
    this.opportunityService.getLocation().subscribe(r => {
      for (let cr of r) {
        let cN = new LocationModel;
        cN.loadFromServer(cr)
        this.location.push(cN)
      }
    });
  }


  updateLocation() {
    var barra = "\\";
    if (this.locationModel.discription.substring(0, 1) == " "
      || this.locationModel.discription.substring(0, 1) == "@"
      || this.locationModel.discription.substring(0, 1) == "#"
      || this.locationModel.discription.substring(0, 1) == "!"
      || this.locationModel.discription.substring(0, 1) == "$"
      || this.locationModel.discription.substring(0, 1) == "*"
      || this.locationModel.discription.substring(0, 1) == "("
      || this.locationModel.discription.substring(0, 1) == ")"
      || this.locationModel.discription.substring(0, 1) == "`"
      || this.locationModel.discription.substring(0, 1) == "´"
      || this.locationModel.discription.substring(0, 1) == "~"
      || this.locationModel.discription.substring(0, 1) == "^"
      || this.locationModel.discription.substring(0, 1) == ";"
      || this.locationModel.discription.substring(0, 1) == ":"
      || this.locationModel.discription.substring(0, 1) == ","
      || this.locationModel.discription.substring(0, 1) == "."
      || this.locationModel.discription.substring(0, 1) == "<"
      || this.locationModel.discription.substring(0, 1) == ">"
      || this.locationModel.discription.substring(0, 1) == "?"
      || this.locationModel.discription.substring(0, 1) == "{"
      || this.locationModel.discription.substring(0, 1) == "/"
      || this.locationModel.discription.substring(0, 1) == "}"
      || this.locationModel.discription.substring(0, 1) == "'"
      || this.locationModel.discription.substring(0, 1) == '"'
      || this.locationModel.discription.substring(0, 1) == "+"
      || this.locationModel.discription.substring(0, 1) == "-"
      || this.locationModel.discription.substring(0, 1) == "_"
      || this.locationModel.discription.substring(0, 1) == "="
      || this.locationModel.discription.substring(0, 1) == "§"
      || this.locationModel.discription.substring(0, 1) == '|'
      || this.locationModel.discription.substring(0, 1) == '¨'
      || this.locationModel.discription.substring(0, 1) == '"'
      || this.locationModel.discription.substring(0, 1) == "'"
      || this.locationModel.discription.substring(0, 1) == "["
      || this.locationModel.discription.substring(0, 1) == "]"
      || this.locationModel.discription.substring(0, 1) == barra.substring(0, 1)
      || this.locationModel.discription.substring(this.locationModel.discription.length - 1, this.locationModel.discription.length) == " ") {
      this.enumsHelper.toast("A descrição da localização não pode começar com caracteres especiais e/ou terminar em branco!", "warning");
      return;
    }

    if (this.locationModel.district.substring(this.locationModel.district.length - 1, this.locationModel.district.length) == " ") {
      this.enumsHelper.toast("O bairro da localização não pode começar em branco!", "warning");
      return;
    }
    if (this.locationModel.streetAddress.substring(this.locationModel.streetAddress.length - 1, this.locationModel.streetAddress.length) == " ") {
      this.enumsHelper.toast("O logradouro da localização não pode começar em branco!", "warning");
      return;
    }

    if (this.locationModel.state.substring(this.locationModel.district.length - 1, this.locationModel.state.length) == " ") {
      this.enumsHelper.toast("O estado da localização não pode começar em branco!", "warning");
      return;
    }
    this.opportunityService.updateLocation(this.locationModel).subscribe(r => {
      this.success = true;
      let message = "Alterou a localização " + this.locationModel.discription;
      this.log.create(message);

      this.enumsHelper.toast("localização editada com sucesso.", "success");
      let url = `/admin/location-opportunity/${this.locationModel.clientLocation}`;
      this.router.navigate([url]);
      this.locationModel = new LocationModel();
    }, (err) => {
      this.enumsHelper.toast("Erro na edição", "warning");
    });

  }

  redirectLastPage() {
    this.router.navigateByUrl('admin/location-opportunity')
  }

}
