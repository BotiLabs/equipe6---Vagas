import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { SharedModule } from '../../shared/shared.module';


export const CustomerRoutes: Routes = [
  {
    path: '',
    children: [
      {
        path: '',
        loadChildren: './list-customer/list-customer.module#ListCustomerModule',
        data: {
          heading: 'edit-customer',
          status: false
        },
      },
      {
        path: 'edit-customer',
        loadChildren: './edit-customer/edit-customer.module#EditCustomerModule',
        data: {
          heading: 'Cadastrar Cliente',
          status: false
        },
      },
      {
        path: 'edit-customer/:customerId',
        loadChildren: './edit-customer/edit-customer.module#EditCustomerModule',
        data: {
          heading: 'Editar Cliente',
          status: false
        },
      },
    ]
  }
];

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(CustomerRoutes),
    SharedModule
  ]
})
export class CustomerModule { }
