import { Component, OnInit } from '@angular/core';
import { trigger, state, style, AUTO_STYLE, transition, animate } from '@angular/animations';
import { UserModel } from '../../models/user.model';
import { AuthService } from '../../../../_services/auth.service';
import { UserLoginModel } from './../../models/user-login.model';
import { UserInfoModel } from './../../models/user-info.model';
import { Router, ActivatedRoute } from '@angular/router';
import { EnumsHelper } from '../../common/enums-helper';
import { DomainService } from '../../../../_services/domain.service';
import { environment } from '../../../../src/environments/environment';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
  animations: [
    trigger('cardToggle', [
      state('collapsed, void',
        style({
          overflow: 'hidden',
          height: '0px',
        })
      ),
      state('expanded',
        style({
          height: AUTO_STYLE,
        })
      ),
      transition('collapsed <=> expanded', [
        animate('500ms ease-in-out')
      ])
    ]),
    trigger('cardToggleInverse', [
      state('collapsed, void',
        style({
          overflow: 'hidden',
          height: '0px',
        })
      ),
      state('expanded',
        style({
          height: AUTO_STYLE,
        })
      ),
      transition('collapsed <=> expanded', [
        animate('50ms ease-in-out')
      ])
    ])
  ]
})

export class LoginComponent implements OnInit {
  jsonError: string;
  password: String;
  userInfo: any;
  enumsHelper: EnumsHelper = new EnumsHelper();
  login: number = 0;
  userModel: UserModel = new UserModel();
  emailRecovery: string = "";
  passwordVerification: string = "";
  jsonSuccess: string;
  id: string;
  confirmation: string = "";
  changed: boolean = false;
  showForm: boolean = false;
  message: string = "";
  emailReturn: boolean = false;
  userLoginModel: UserLoginModel = new UserLoginModel();
  environment: any = `${environment.baseUrlApi}/token/office365`;
  public menuType: string;
  public headerType: string;
  public sidebarType: string;
  public themeType: string;
  public toggledArrow: string;
  public windowHeight: number;
  public windowWidth: number;
  public settingToggle: string;
  public cardToggle = 'collapsed';

  constructor(
    private authService: AuthService,
    private router: Router,
    private domainService: DomainService,
    private route: ActivatedRoute
  ) {
    (<any>window).ga('set', 'page', 'Tela de login');
    (<any>window).ga('send', 'pageview');
    this.themeType = 'default';
    this.toggledArrow = 'icon-arrow-left-circle';
    this.settingToggle = 'off';
    this.windowHeight = window.innerHeight - 60;
    this.windowWidth = window.innerWidth;
    if (this.windowWidth < 1170) {
      this.menuType = 'mini-sidebar';
    }
    if (this.windowWidth < 768) {
      this.toggledArrow = 'fa fa-bars';
    }
  }

  ngOnInit() {
    // this.userLoginModel.email = userInfo.email;
  }

  onLoginSubmit = async () => {
    await this.authService.authenticateUser(this.userLoginModel).subscribe(res => {
      if (res.success) {
        localStorage.setItem('email', this.userLoginModel.email)
        this.authService.emailAuthentication(this.userLoginModel.email).map(x => {
          var res = x.json();
          if (res.message === "Authorized") {
            return true;
          }
          this.router.navigate(['/login']);
          this.authService.logout();
          return false;
        });

        let userInfo = new UserInfoModel();

        userInfo.email = res.userInfo.email;
        userInfo.username = res.userInfo.username;
        userInfo.firstName = res.userInfo.firstname;
        userInfo.lastName = res.userInfo.lastname;
        userInfo.company_id = res.userInfo.company_id;
        this.authService.storeUserData(res.token, userInfo);
        if (localStorage.getItem('locationToRedirect')) {
          this.router.navigate([localStorage.getItem('locationToRedirect')]);
        } else {
          this.router.navigate(['/loading']);
        }
      }
    }, error => {
      switch (error.status) {
        case 401:
          var jsonError = JSON.parse(error._body);
          this.jsonError = jsonError.message;
          this.enumsHelper.toast(this.jsonError, 'error');
          break;
        case 400:
          var jsonError = JSON.parse(error._body);
          this.jsonError = jsonError.message;
          this.enumsHelper.toast(this.jsonError, 'warning');
          break;
        case 404:
          var jsonError = JSON.parse(error._body);
          this.jsonError = jsonError.message;
          this.enumsHelper.toast(this.jsonError, 'error');
          break;
        default:
          var jsonError = JSON.parse(error._body);
          this.jsonError = jsonError.message;
          this.enumsHelper.toast(this.jsonError, 'error');
          break;
      }

    });
  }

  loginOffice365() {
    window.location.replace(this.environment);
  }


  onResize(event) {
    this.windowHeight = event.target.innerHeight - 60;
    this.windowWidth = window.innerWidth;
    if (this.windowWidth < 1170) {
      this.menuType = 'mini-sidebar';
    } else {
      this.menuType = '';
    }

    if (this.windowWidth < 768) {
      this.toggledArrow = this.menuType === 'mini-sidebar show-sidebar' ? 'fa fa-close' : 'fa fa-bars';
    } else {
      this.toggledArrow = this.menuType === 'mini-sidebar' ? 'fa fa-bars' : 'icon-arrow-left-circle';
    }
  }

  toggleCard() {
    this.cardToggle = this.cardToggle === 'collapsed' ? 'expanded' : 'collapsed';
  }

  changeForm(login: number) {
    this.login = login;
    this.emailRecovery = "";
  }

  recoveryPassword() {
    this.emailReturn = true;
    this.authService.recoveryPassword(this.emailRecovery).subscribe(r => {
      this.enumsHelper.toast(r.message, "success");
      this.emailReturn = false;
      this.changeForm(0);
    }, err => {
      this.emailReturn = false;
      this.enumsHelper.toast(err.Errors.message, "warning");
    })
  }

  singin() {
    if (this.userModel.username == "") {
      this.enumsHelper.toast("O apelido é obrigatório", "warning");
      return;
    }

    this.authService.registerUser(this.userModel).subscribe(r => {
      this.jsonSuccess = "Você foi cadastrado com sucesso!";
      this.enumsHelper.toast(this.jsonSuccess, 'success');
      this.changeForm(0);
    }, err => {
      switch (err.status) {
        case 401:
          var jsonError = JSON.parse(err._body);
          this.jsonError = jsonError.message.toString();
          this.enumsHelper.toast(this.jsonError, 'error');
          break;
        case 404:
          var jsonError = JSON.parse(err._body);
          this.jsonError = jsonError.message.toString();
          this.enumsHelper.toast(this.jsonError, 'error');
          break;
        case 400:
          var jsonError = JSON.parse(err._body);
          this.jsonError = jsonError.message.toString();
          this.enumsHelper.toast(this.jsonError, 'error');
          break;
        default:
          var jsonError = JSON.parse(err._body);
          this.jsonError = jsonError.message.toString();
          this.enumsHelper.toast(this.jsonError, 'error');
          break;
      }
    });
  }
}
