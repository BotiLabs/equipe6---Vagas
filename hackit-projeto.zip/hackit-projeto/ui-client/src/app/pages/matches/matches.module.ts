import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatchesComponent } from './matches.component';
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from '../../shared/shared.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgxPaginationModule } from 'ngx-pagination';
export const OpportunitiesRoutes: Routes = [
  {
    path: '',
    children: [
      {
        path: '',
        component:MatchesComponent,
        data:{
          heading:"matches"
        }
      }
    ]

  }
];

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(OpportunitiesRoutes),
    FormsModule ,
    NgxPaginationModule     
  ],
  declarations: [MatchesComponent]
})
export class MatchesModule { }
