import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { CandidateModel } from '../../models/candidate.model';
import { OpportunityModel } from '../../models/opportunity.model';
import { CandidatesMatchRequest } from '../../common/candidates-match.request';
import { MatchService } from '../../../../_services/match.service';
import { CandidateService } from '../../../../_services/candidate.service';
import { OpportunityService } from '../../../../_services/opportunity.service';
import { StatusCandidate } from '../../common/status-candidate';
import { EnumsHelper } from '../../common/enums-helper';
import { NotificationService } from '../../../../_services/notification.service';
import { LogsComponent } from '../logs/logs.component';
import { Location } from '@angular/common';
@Component({
  selector: 'app-matches',
  templateUrl: './matches.component.html',
  styleUrls: ['./matches.component.css']
})
export class MatchesComponent implements OnInit {

  title: string = "";
  subtitle: string = "";
  itemsPerPage: number[] = [10, 50, 100];
  limit: number = 10;
  totalItems: number = -1;
  existDB: boolean;
  enumsHelper: EnumsHelper = new EnumsHelper();
  candidates: CandidateModel[] = [];
  candidatesMatchRequest: CandidatesMatchRequest = new CandidatesMatchRequest();
  opportunityToMatch = new OpportunityModel();
  selectedOpportunityToMatch: string;
  hasErrorOpportunity: boolean;
  specialities: string[] = [];
  opportunities: OpportunityModel[] = [];
  feedBackVisible: Boolean;
  done: boolean = false;
  cvs = [];


  constructor(
    private matchService: MatchService,
    private router: Router,
    private candidateService: CandidateService,
    private opportunityService: OpportunityService,
    private notificationService: NotificationService,
    private logs: LogsComponent,
    private _location: Location) {
    this.title = "Match de Vaga com Candidatos";
    this.subtitle = "Veja quais são os candidatos que possuem skills compativeis com a vaga selecionada";
    (<any>window).ga('set', 'page', 'Tela de matches');
    (<any>window).ga('send', 'pageview');
  }

  ngOnInit() {
    this.selectedOpportunityToMatch = "";

    if (this.matchService.hasOpportunities()) {
      this.opportunities = this.matchService.opportunities;
      this.matchService.opportunities = [];
      this.specialities = this.opportunities[0].specialities;
      this.selectedOpportunityToMatch = this.opportunities[0]._id;
      this.searchCandidates(1);
      this.feedBackVisible = true;
    } else {
      this.feedBackVisible = false;
      this.opportunityService.getAll().subscribe(res => {
        for (let item of res) {
          let opportunityItem = new OpportunityModel();
          opportunityItem.loadModelFromServer(item);
          this.opportunities.push(opportunityItem);
        }
        this.opportunities.sort(function (a, b) {
          if (a.customerName > b.customerName) {
              return 1;
          }
          if (a.customerName < b.customerName) {
              return -1;
          }
          return 0;
        });
      });
    }
  }

  setSpecialities(id: string) {
    if (id === "")
      this.hasErrorOpportunity = true;
    else {
      this.feedBackVisible = false;
      this.hasErrorOpportunity = false;
      this.specialities = [];
      this.specialities = this.opportunities.find(x => x._id === id).specialities;
      this.candidates = [];
      this.totalItems = 0;
    }
  }

  searchCandidates(page: number) {

    this.candidatesMatchRequest.page = page;
    this.candidatesMatchRequest.limit = this.limit;
    this.candidatesMatchRequest.skills = this.specialities;
    this.candidatesMatchRequest.status = [StatusCandidate.Cadastrado], StatusCandidate.EmProcesso;

    this.matchService.searchForMatch(this.candidatesMatchRequest).subscribe(res => {
      this.done = false;
      this.totalItems = res.count;
      this.existDB = res.existsInDB
      this.candidates = [];

      //console.log(res)
      if (res.count > 0 && res.existsInDB == true) {
        for (let c of res.result) {
          let candidate = new CandidateModel();
          candidate.loadCandidate(c);
          this.candidates.push(candidate);
        }
      } 
      // else {
      //   this.cvs = [];
      //   for (var i = 0; i < res.count; i++) {
      //     this.cvs[i] = [];
      //     this.cvs[i].push(res.result[i]._source.file._name);
      //     this.cvs[i].push(res.result[i]._source.source_url);
      //   }
      //   this.done = true;
      // }
      this.feedBackVisible = true;
    });
  }


  matchCandidate(candidateToMatch: CandidateModel) {

    if (this.opportunities.length == 1)
      this.opportunityToMatch = this.opportunities[0];
    else {
      if (this.selectedOpportunityToMatch === "") {
        this.hasErrorOpportunity = true;
        return;
      }
      this.opportunityToMatch = this.opportunities.find(x => x._id == this.selectedOpportunityToMatch);
    }
    candidateToMatch.status = StatusCandidate.EmProcesso;
    candidateToMatch.opportunities.push(this.opportunityToMatch._id);

    if (this.opportunityToMatch.candidatesJoin.find(x => x._id === candidateToMatch._id) === undefined)
      for (var i = 0; i <= this.opportunityToMatch.candidates.length; i++) {
        if (this.opportunityToMatch.candidates[i] == candidateToMatch._id) {
          console.log("quebrou");
          return;

        }

      }
    this.candidateService.update(candidateToMatch).subscribe(res => {
      var message = "Criou o Match entre " + candidateToMatch.name + " e a vaga " + this.opportunityToMatch.name + " do cliente " + this.opportunityToMatch.customerName;
      this.logs.create(message);
      this.opportunityToMatch.candidates.push(candidateToMatch._id);
      this.opportunityService.update(this.opportunityToMatch).subscribe(r => {
        this.notificationService.notify('Match realizado com sucesso!');
      });
    });
  }


  countCandidatesInProcess(candidatesCount: number) {
    let text: string;
    if (candidatesCount === 0)
      text = 'Nenhum candidato';

    if (candidatesCount == 1)
      text = '1 candidato';

    if (candidatesCount > 1)
      text = `${candidatesCount} candidatos`;

    return `${text} em processo`;
  }


  buildOpportunityName(opportunity: OpportunityModel) {
    return `${opportunity.customerName} / ${opportunity.number} - ${opportunity.name}
    / ${this.countCandidatesInProcess(opportunity.candidates.length)}`;
  }

  searchCandidatesSubmit() {
    this.hasErrorOpportunity = false;
    if (this.selectedOpportunityToMatch === "") {
      this.hasErrorOpportunity = true;
      return;
    }

    this.searchCandidates(1);
  }
  redirectLastPage(){
    this._location.back();
  }

}
