import { Component, OnInit } from '@angular/core';
import { CandidateService } from '../../../../../_services/candidate.service';
import { CandidateModel } from '../../../models/candidate.model';
import { EnumsHelper } from '../../../common/enums-helper';
import { CandidatesRequest } from '../../../common/candidates.request';
import * as XLSX from 'xlsx'

declare var $: any;
@Component({
  selector: 'app-media',
  templateUrl: './media.component.html',
  styleUrls: ['./media.component.css']
})

export class MediaComponent implements OnInit {
  candidates: CandidateModel[];
  candidatesRequest: CandidatesRequest = new CandidatesRequest();
  c: any;
  cand: any[] = [];
  initialDate: Date;
  finalDate: Date;
  initialDateCalc: number;
  finalDateCalc: number;
  statusSort: [number, number, number, number, number, number, number, number, number] = [0, 0, 0, 0, -1, 0, 0, 0, 0];
  totalItens: number;
  page: number;
  query: any;
  x: number = 2;
  enumsHelper: EnumsHelper = new EnumsHelper();
  export: boolean = false;
  constructor
    (private candidateService: CandidateService) {
    (<any>window).ga('set', 'page', 'Relatório de origens');
    (<any>window).ga('send', 'pageview');
  }

  ngOnInit() {
    this.searchCandidateByOrigin(1);
    for (let x; x < 10; x++) {
      console.log(this.cand[x]);
    }
  }

  onSort(event) {
    switch (this.statusSort[event]) {
      case 0:
        switch (event) {
          case 0:
            this.statusSort[event] = 1;
            this.statusSort[0] = 1;
            this.statusSort[1] = 0;
            this.candidatesRequest.sort = { "query": { "_id": 1 } }
            break;
          case 1:
            this.statusSort[event] = 1;
            this.statusSort[0] = 0;
            this.statusSort[1] = 1;
            this.candidatesRequest.sort = { "query": { "count": 1 } }
            break;
        }
        break;
      case 1:
        switch (event) {
          case 0:
            this.statusSort[event] = 2;
            this.statusSort[0] = 2;
            this.statusSort[1] = 0;
            this.candidatesRequest.sort = { "query": { "_id": -1 } }
            break;
          case 1:
            this.statusSort[event] = 2;
            this.statusSort[0] = 0;
            this.statusSort[1] = 2;
            this.candidatesRequest.sort = { "query": { "count": -1 } }
            break;
        }
        break;
      case 2:
        this.candidatesRequest.sort = undefined;
        this.statusSort[event] = 0;
        break;
    }
    this.searchCandidateByOrigin(this.page);
  }


  searchCandidateByOrigin(page) {
    this.page = page;
    this.query = {};


    if (this.initialDate && this.finalDate) {
      if (this.initialDate > this.finalDate) {
        this.enumsHelper.toast("A data inicial não pode ser maior que a data final.", "warning");
        return;
      }
      this.cand = [];
      this.cand.sort(function (a, b) {
        if (a._id > b._id) {
          return 1;
        }
        if (a._id < b._id) {
          return -1;
        }
        return 0;
      });
      this.initialDateCalc = Date.parse(this.initialDate.toString());
      this.finalDateCalc = Date.parse(this.finalDate.toString())
      var initialDate = this.initialDateCalc - 10800000;
      var finalDate = this.finalDateCalc + 75599999;
      this.query = { "initialDate": initialDate, "finalDate": finalDate, page: page }
      if (this.candidatesRequest.sort) {
        this.query['sort'] = this.candidatesRequest.sort;
      }

    } else if (this.initialDate) {
      this.cand = [];
      this.initialDateCalc = Date.parse(this.initialDate.toString());
      var initialDate = this.initialDateCalc - 10800000;
      this.query = { "initialDate": initialDate, page: page }
      if (this.candidatesRequest.sort) {
        this.query['sort'] = this.candidatesRequest.sort;
      }
    } else if (this.finalDate) {
      this.cand = [];
      this.finalDateCalc = Date.parse(this.finalDate.toString())
      var finalDate = this.finalDateCalc + 75599999;

      this.query = { "finalDate": finalDate, page: page }
      if (this.candidatesRequest.sort) {
        this.query['sort'] = this.candidatesRequest.sort;
      }
    } else {
      this.cand = [];
      this.query = { page: page }
      if (this.candidatesRequest.sort) {
        this.query['sort'] = this.candidatesRequest.sort;
      }
    }

    this.candidateService.searchByOriginWithDate(this.query).subscribe(res => {
      this.candidates = [];
      for (let cr of res.result) {
        this.c = cr;
        this.cand.push(this.c);
        if(this.c._id == ""){
          this.c._id = "Indefinido";
        }
      }
      this.totalItens = res.count;
    });

  }

  clearInitialDate() {
    this.initialDate = undefined;
  }
  clearFinalDate() {
    this.finalDate = undefined;
  }

  exportListOrigin() {
    this.export = true;
    this.candidateService.exportListo0rigin(this.query).subscribe(r => {
      this.export = false;
      if (r.length > 0) {
        const ws: XLSX.WorkSheet = XLSX.utils.aoa_to_sheet(r);

        /* generate workbook and add the worksheet */
        const wb: XLSX.WorkBook = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');

        /* save to file */
        XLSX.writeFile(wb, 'Origem.xlsx');
      } else {
        this.enumsHelper.toast("Não há dados para exportar.", "warning")
      }
    }, err => {
      this.export = false;
      this.enumsHelper.toast(err.Errors.message, "warning")
    })
  }
}
