import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MediaComponent } from './media.component';
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from '../../../shared/shared.module';

export const ReportMediaRoutes: Routes = [
    {
        path: '',
        component: MediaComponent,
        data: {
          heading: 'midia',
          status:false
        }
      }
    ];
    
    @NgModule({
      imports: [
        CommonModule,
        RouterModule.forChild(ReportMediaRoutes),
        SharedModule
      ],
      declarations: [MediaComponent]
    })
export class ReportMediaModule { }
