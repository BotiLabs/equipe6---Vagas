import * as Chartist from 'chartist';
import { Component, OnInit, Input } from '@angular/core';
import { OpportunitiesComponent } from '../../opportunities/list-opportunity/opportunities.component';
import { OpportunityModel } from '../../../models/opportunity.model';
import { OpportunityService } from '../../../../../_services/opportunity.service';
import { InteractionService } from '../../../../../_services/interaction.service';
import { CandidateService } from '../../../../../_services/candidate.service';
import { OpportunitiesRequest } from '../../../common/opportunities.request';
import { CandidatesRequest } from '../../../common/candidates.request';
import { ChartModel } from '../../../models/chart.model';
import { TagService } from '../../../../../_services/tag.service';
import { CandidateModel } from '../../../models/candidate.model';
import * as moment from 'moment';
import { race } from 'rxjs/observable/race';
import { EnumsHelper } from '../../../common/enums-helper';
moment.locale('pt-BR');
// import { Angular2Txt } from 'angular2-txt/Angular2-txt';
declare var $: any;
declare var Morris: any;

@Component({
  selector: 'app-reports',
  templateUrl: './reports.component.html',
  styleUrls: ['./reports.component.css']
})
export class ReportsComponent implements OnInit {
  titleCandidate: string;
  titleOpportunity: string;
  countOpportunities: any;
  countCandidates: any;
  candidatesRequest: CandidatesRequest;
  opportunities: OpportunityModel[];
  opportunitiesRequest: OpportunitiesRequest = new OpportunitiesRequest();
  feedBackVisible: boolean;
  totalItems: number = -1;
  opportunitySourceChart: any[];
  candidateSourceChart: any[];
  candidates: CandidateModel[];
  totalOpportunities: number;
  totalCandidates: number;
  reports: any;
  reportsByStatus: any;
  reportsContratation: any[];
  countOpportunitiesDate: number;
  enumsHelper: EnumsHelper = new EnumsHelper();
  report1: any;
  report2: any;
  report3: any;
  report4: any;
  report5: any;
  report6: any;
  cont: number = 0;
  cont1: number = 0;
  cont2: number = 0;
  cont22: number = 0;
  cont3: number = 0;
  cont33: number = 0;
  cont4: number = 0;
  cont44: number = 0;
  cont5: number = 0;
  cont6: number = 0;
  reportStatus1: number = 0;
  reportStatus2: number = 0;
  reportStatus3: number = 0;
  reportStatus4: number = 0;
  initialDate: Date;
  initialDateCalc: number;
  finalDate: Date;
  finalDateCalc: number;
  c: any;
  candidateOrigin: any[] = [];
  cand: any[] = [];
  reportProcess1: number = 0;
  reportProcess2: number = 0;
  reportProcess3: number = 0;
  reportProcess4: number = 0;
  reportProcess5: number = 0;
  reportProcess6: number = 0;
  reportProcess7: number = 0;
  reportProcess8: number = 0;
  reportProcess9: number = 0;
  reportProcess10: number = 0;
  reportProcess11: number = 0;
  reportProcess12: number = 0;
  reportProcess13: number = 0;
  reportProcess14: number = 0;
  reportProcess15: number = 0;
  reportProcess16: number = 0;
  reportProcess17: number = 0;
  reportProcess18: number = 0;
  reportProcess19: number = 0;
  reportProcess20: number = 0;
  processArray1: any;
  processArray2: any;
  processArray3: any;
  processArray4: any;
  processArray5: any;
  processPerDateArray: any;
  processInitialDate: Date;
  processFinalDate: Date;
  processInitialDateCalc: number;
  processFinalDateCalc: number;
  id: string;
  reportLoaded: boolean = false;
  // public barChartOptions: any = {
  //   scaleShowVerticalLines: true,
  //   responsive: true,
  //   mantainAspectRatio: true,
  //   scales: {
  //     yAxes: [{
  //       ticks: {
  //         beginAtZero: true
  //       }
  //     }]
  //   },
  //   tooltips: {
  //     callbacks: {
  //       title: function (tooltipItem, data) {
  //         return tooltipItem[0].xLabel;
  //       },
  //       label: function (tooltipItem, data) {
  //         if (tooltipItem.yLabel > 1) {
  //           return tooltipItem.yLabel + " vagas";
  //         }
  //         return tooltipItem.yLabel + " vagas";
  //       }
  //     }
  //   }
  // };
  public barChartLabels: string[] = [];
  public barChartType: string = 'pie';
  public barChartLegend: boolean = false;
  public barChartData: any[];
  public barChartColors: Array<any> = [{ backgroundColor: '#EC7B27' }];
  public candidateSourceData: any[] = [];
  public opportunitySourceData: any[] = [];
  public barChartLabels2: string[] = [];
  public barChartData2: any[];

  constructor(private opportunityService: OpportunityService,
    private candidateService: CandidateService,
    private interactionService: InteractionService) {
  }


  ngOnInit() {
    this.searchReportProcess(-1);
    this.searchReports();
    this.candidateSourceChart = [];
  }

  searchReports() {
    this.cont = 0;
    this.cont2 = 0;
    this.cont3 = 0;
    this.cont4 = 0;
    this.cont5 = 0;
    this.cont6 = 0;
    this.report1 = 0;
    this.report2 = 0;
    this.report3 = 0;
    this.report4 = 0;
    this.report5 = 0;
    this.report6 = 0;
    this.interactionService.getReports().subscribe(r => {
      this.reports = [];
      for (let cr of r) {
        let c = cr;
        this.reports.push(c);
      }
      for (var i = 0; i < this.reports.length; i++) {
        for (var y = 0; y < this.reports[i].action.length; y++) {
          if (this.reports[i].action[y] == 0) {
            this.cont++;
            this.report1 = this.cont;
          }
          if (this.reports[i].action[y] == 1) {
            this.cont2++;
            this.report2 = this.cont2;
          }
          if (this.reports[i].action[y] == 2) {
            this.cont3++;
            this.report3 = this.cont3;
          }
          if (this.reports[i].action[y] == 3) {
            this.cont4++;
            this.report4 = this.cont4;
          }
          if (this.reports[i].action[y] == 4) {
            this.cont5++;
            this.report5 = this.cont5;
          }
          if (this.reports[i].action[y] == 5) {
            this.cont6++;
            this.report6 = this.cont6;
          }

        }
      }
      this.reports.sort(function (a, b) {
        if (a._id > b._id) {
          return 1;
        }
        if (a._id < b._id) {
          return -1;
        }
        return 0;
      });
    })

    this.interactionService.getReportsContratation().subscribe(r => {
      this.reportsContratation = [];
      for (let cr of r) {
        let c = cr;
        this.reportsContratation.push(c);
      }

      for (var i = 0; i < this.reportsContratation.length; i++) {

        for (var y = 0; y < this.reportsContratation[i].status.length; y++) {

          if (this.reportsContratation[i].status[y] == 4) {
            this.cont3++;
            this.report3 = this.cont3;
          }

        }
      }
    })


  }
  searchReportProcess(id) {
    this.reportLoaded = true;
    this.reportsContratation = [];
    this.id = id;
    var query = {};
    if (this.processInitialDate && this.processFinalDate) {

      if (this.processInitialDate > this.processFinalDate) {
        this.enumsHelper.toast("A data inicial não pode ser maior que a data final.", "warning");
        this.reportLoaded = false;
        return;
      }
      this.initialDateCalc = Date.parse(this.processInitialDate.toString());
      this.finalDateCalc = Date.parse(this.processFinalDate.toString())
      var initialDate = this.initialDateCalc - 10800000;
      var finalDate = this.finalDateCalc + 75599999;
      query = { "initialDate": initialDate, "finalDate": finalDate, "id": this.id }
    } else if (this.processInitialDate) {
      this.initialDateCalc = Date.parse(this.processInitialDate.toString());
      var initialDate = this.initialDateCalc - 10800000;
      query = { "initialDate": initialDate, "id": this.id }
    } else if (this.processFinalDate) {
      this.finalDateCalc = Date.parse(this.processFinalDate.toString())
      var finalDate = this.finalDateCalc + 75599999;
      query = { "finalDate": finalDate, "id": this.id }
    } else {
      query = { "id": this.id }
    }
    this.interactionService.reportsContratationBetweenDate(query).subscribe(r => {
      this.reportLoaded = false;
      for (let cr of r) {
        let c = cr;
        this.reportsContratation.push(c);
      }
      this.reportProcess1 = this.reportsContratation[0];
      this.reportProcess2 = this.reportsContratation[1];
      this.reportProcess3 = this.reportsContratation[2];
      this.reportProcess4 = this.reportsContratation[3];
      this.reportProcess5 = this.reportsContratation[4];
      this.reportProcess6 = this.reportsContratation[5];
      this.reportProcess7 = this.reportsContratation[6];
      this.reportProcess8 = this.reportsContratation[7];
      this.reportProcess9 = this.reportsContratation[8];
      this.reportProcess10 = this.reportsContratation[9];
      this.reportProcess11 = this.reportsContratation[10];
      this.reportProcess12 = this.reportsContratation[11];
      this.reportProcess13 = this.reportsContratation[12];
      this.reportProcess14 = this.reportsContratation[13];
      this.reportProcess15 = this.reportsContratation[14];
      this.reportProcess16 = this.reportsContratation[15];
    })
  }

  clearProcessInitialDate() {
    this.processInitialDate = undefined;
    this.searchReportProcess(this.id);
  }
  clearProcessFinalDate() {
    this.processFinalDate = undefined;
    this.searchReportProcess(this.id);
  }
}


