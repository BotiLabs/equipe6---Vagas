import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReportsComponent } from './reports.component';
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from '../../../shared/shared.module';

export const ReportSelectionRoutes: Routes = [
    {
        path: '',
        component: ReportsComponent,
        data: {
          heading: 'selection',
          status:false
        }
      }
    ];
    
    @NgModule({
      imports: [
        CommonModule,
        RouterModule.forChild(ReportSelectionRoutes),
        SharedModule
      ],
      declarations: [ReportsComponent]
    })
export class ReportSelectionModule { }
