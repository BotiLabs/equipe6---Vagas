import { ActionsComponent } from './actions.component';
import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from '../../../shared/shared.module';

export const ActionsRoutes: Routes = [
    {
        path: '',
        component: ActionsComponent,
        data: {
          heading: 'actions',
          status:false
        }
      }
    ];
    
    @NgModule({
      imports: [
        CommonModule,
        RouterModule.forChild(ActionsRoutes),
        SharedModule
      ],
      declarations: [ActionsComponent]
    })
export class ActionsModule { }
