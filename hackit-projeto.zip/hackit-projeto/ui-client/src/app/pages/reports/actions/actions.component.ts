import { ActionInteraction } from './../../../common/action-interaction';
import { InteractionsRequest } from './../../../common/interactions.request';
import { Component, OnInit } from '@angular/core';
import { OpportunityModel } from '../../../models/opportunity.model';
import { OpportunityService } from '../../../../../_services/opportunity.service';
import { InteractionService } from '../../../../../_services/interaction.service';
import * as moment from 'moment';
import { EnumsHelper } from '../../../common/enums-helper';
import { PersistenceService } from 'angular-persistence';
import { StatusOfCandidateModel } from '../../../models/statusOfCandidate.model';
import { InteractionModel } from '../../../models/interaction.model';
import * as XLSX from 'xlsx';
import { AuthService } from '../../../../../_services/auth.service';
import { UserModel } from '../../../models/user.model';
import { ActionService } from '../../../../../_services/action.service';

declare var $: any;
moment.locale('pt-BR');
@Component({
  selector: 'app-actions',
  templateUrl: './actions.component.html',
  styleUrls: ['./actions.component.css']
})
export class ActionsComponent implements OnInit {
  opportunityModel: OpportunityModel = new OpportunityModel();
  initialDate: Date;
  finalDate: Date;
  validationSearchByDate: number = 0;
  oppInitialDateCalc: number;
  oppFinalDateCalc: number;
  result: any;
  totalItems: number;
  page: number;
  enumsHelper: EnumsHelper = new EnumsHelper();
  selectedItems = [];
  selectedItemsCargo = [];
  interactionModel: InteractionModel = new InteractionModel();
  interactions: InteractionModel[];
  candidatesLoaded: boolean = false;
  limit: number = 15;
  reportsWithDate: any;
  users: any;
  statusOfCandidateArray: StatusOfCandidateModel[];
  interactionsRequest: InteractionsRequest = new InteractionsRequest();
  ddlActions: ActionInteraction[];
  statusSort: [number, number, number, number, number] = [0, 0, 0, 0, 0];
  export: boolean = false;
  actionsArray: any = [];

  constructor(
    private opportunityService: OpportunityService,
    private interactionService: InteractionService,
    private persistenceService: PersistenceService,
    private authService: AuthService,
    private actionService: ActionService
  ) {
    this.getUsers();
    this.getAllActions();
    (<any>window).ga('set', 'page', 'Relatório de ações');
    (<any>window).ga('send', 'pageview');
  }


  ngOnInit() {
    this.ddlActions = this.enumsHelper.getEnumActionInteractionArray();
    this.searchActions(1);
  }

  loadStatus(status: number) {
    let obj = this.statusOfCandidateArray.find(x => x.number == status);
    if (obj)
      return obj;
  }

  actionConverter(action: number) {
    let stat = this.enumsHelper.getDescriptionActionInteraction(action);
    return stat;
  }


  searchActions(page) {
    this.interactionsRequest.page = page;

    this.interactionService.searchActionReport(this.interactionsRequest).subscribe(r => {
      this.interactions = r.result;
      this.totalItems = r.count;
    });
  }

  clearInitialDate() {
    this.interactionsRequest.initialDate = undefined;
  }
  clearFinalDate() {
    this.interactionsRequest.finalDate = undefined;
  }

  onSort(event) {
    // event was triggered, start sort sequence
    switch (this.statusSort[event]) {
      case 0:
        switch (event) {
          case 0:
            this.statusSort[event] = 1;
            this.statusSort[1] = 0;
            this.statusSort[2] = 0;
            this.statusSort[3] = 0;
            this.statusSort[4] = 0;
            this.interactionsRequest.sort = { "query": { "action": 1 } }
            break;
          case 1:
            this.statusSort[event] = 1;
            this.statusSort[0] = 0;
            this.statusSort[2] = 0;
            this.statusSort[3] = 0;
            this.statusSort[4] = 0;
            this.interactionsRequest.sort = { "query": { "candidate.name": 1 } }
            break;
          case 2:
            this.statusSort[event] = 1;
            this.statusSort[0] = 0;
            this.statusSort[1] = 0;
            this.statusSort[3] = 0;
            this.statusSort[4] = 0;
            this.interactionsRequest.sort = { "query": { "registrationDate": 1 } }
            break;
          case 3:
            this.statusSort[event] = 1;
            this.statusSort[0] = 0;
            this.statusSort[1] = 0;
            this.statusSort[2] = 0;
            this.statusSort[4] = 0;
            this.interactionsRequest.sort = { "query": { "opportunityName": 1 } }
            break;
          case 4:
            this.statusSort[event] = 1;
            this.statusSort[0] = 0;
            this.statusSort[1] = 0;
            this.statusSort[2] = 0;
            this.statusSort[3] = 0;
            this.interactionsRequest.sort = { "query": { "statusJoin.name": 1 } }
            break;
        }
        break;
      case 1:
        switch (event) {
          case 0:
            this.statusSort[event] = 2;
            this.statusSort[1] = 0;
            this.statusSort[2] = 0;
            this.statusSort[3] = 0;
            this.statusSort[4] = 0;
            this.interactionsRequest.sort = { "query": { "action": -1 } }
            break;
          case 1:
            this.statusSort[event] = 2;
            this.statusSort[0] = 0;
            this.statusSort[2] = 0;
            this.statusSort[3] = 0;
            this.statusSort[4] = 0;
            this.interactionsRequest.sort = { "query": { "candidate.name": -1 } }
            break;
          case 2:
            this.statusSort[event] = 2;
            this.statusSort[0] = 0;
            this.statusSort[1] = 0;
            this.statusSort[3] = 0;
            this.statusSort[4] = 0;
            this.interactionsRequest.sort = { "query": { "registrationDate": -1 } }
            break;
          case 3:
            this.statusSort[event] = 2;
            this.statusSort[0] = 0;
            this.statusSort[1] = 0;
            this.statusSort[2] = 0;
            this.statusSort[4] = 0;
            this.interactionsRequest.sort = { "query": { "opportunityName": -1 } }
            break;
          case 4:
            this.statusSort[event] = 2;
            this.statusSort[0] = 0;
            this.statusSort[1] = 0;
            this.statusSort[2] = 0;
            this.statusSort[3] = 0;
            this.interactionsRequest.sort = { "query": { "statusJoin.name": -1 } }
            break;
        }
        break;
      case 2:
        this.interactionsRequest.sort = undefined;
        this.statusSort[event] = 0;
        break;
    }
    this.searchActions(this.interactionsRequest.page);
  }

  exportList() {
    this.export = true;
    this.interactionService.exportList(this.interactionsRequest).subscribe(r => {
      this.export = false;
      if (r.length > 0) {
        const ws: XLSX.WorkSheet = XLSX.utils.aoa_to_sheet(r);

        /* generate workbook and add the worksheet */
        const wb: XLSX.WorkBook = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');

        /* save to file */
        XLSX.writeFile(wb, 'Ações.xlsx');
      } else {
        this.enumsHelper.toast("Não há dados para exportar.", "warning")
      }
    }, err => {
      this.export = false;
      this.enumsHelper.toast(err.Errors.message, "warning")
    })
  }

  getUsers() {
    this.users = []
    this.authService.getUsers().subscribe(r => {
      for (let u of r.result) {
        let user = new UserModel();
        user.loadUserModel(u);
        this.users.push(user)
      }
    })
  }

  getAllActions = async () => {
    await this.actionService.getAllActions().subscribe(actions => {
      this.actionsArray = [];
      for (let action of actions) {
        this.actionsArray.push(action);
      }
    })
  }

  loadAction(number) {
    let action = this.actionsArray.find(x => x.number == number);
    if (action)
      return action.name;
    else
      return "";
  }

}
