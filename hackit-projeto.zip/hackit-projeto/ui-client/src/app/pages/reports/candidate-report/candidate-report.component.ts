import { Component, OnInit } from '@angular/core';
import { CandidateService } from '../../../../../_services/candidate.service';
import { InteractionService } from '../../../../../_services/interaction.service';
import { OpportunityService } from '../../../../../_services/opportunity.service';
import { EnumsHelper } from '../../../common/enums-helper';
import * as moment from 'moment';
import * as XLSX from 'xlsx';
import { UserModel } from '../../../models/user.model';
import { AuthService } from '../../../../../_services/auth.service';
moment.locale('pt-BR');
declare var $: any;
@Component({
  selector: 'app-candidate-report',
  templateUrl: './candidate-report.component.html',
  styleUrls: ['./candidate-report.component.css']
})
export class CandidateReportComponent implements OnInit {
  initialDate: Date;
  finalDate: Date;
  candInitialDateCalc: number;
  candFinalDateCalc: number;
  result: any;
  totalItems: number;
  opportunities: any[];
  candidatesLoaded: boolean = false;
  page: number;
  export: boolean = false;
  exportListXlsx: any;
  statusSort: [number, number, number, number, number] = [0, 0, 0, 0, 0];
  query: any;
  users: any;
  id: any;
  constructor(
    private candidateService: CandidateService,
    private interactionService: InteractionService,
    private opportunityService: OpportunityService,
    private authService: AuthService,
    private enumsHelper: EnumsHelper
  ) { }

  ngOnInit() {
    this.searchReportCandidate(-1, 1);
  }

  searchReportCandidate(id, page) {
    this.page = page;
    this.candidatesLoaded = false;
    this.id = id;
    var query = undefined;
    query = { "page": page, limit: 10 };
    if (this.initialDate > this.finalDate) {
      this.enumsHelper.toast("A data inicial não pode ser maior que a data final.", "warning");
      this.candidatesLoaded = true;
      return;
    }
    if (this.initialDate && this.finalDate && id != -1) {
      this.candInitialDateCalc = Date.parse(this.initialDate.toString());
      this.candFinalDateCalc = Date.parse(this.finalDate.toString())
      var candInitialDate = this.candInitialDateCalc - 10800000;
      var candFinalDate = this.candFinalDateCalc + 75599999;
      query = { "initialDate": candInitialDate, "finalDate": candFinalDate, "userName": id, "page": page, limit: 10 }

    } else if (this.initialDate && this.finalDate) {

      this.candInitialDateCalc = Date.parse(this.initialDate.toString());
      this.candFinalDateCalc = Date.parse(this.finalDate.toString())
      var candInitialDate = this.candInitialDateCalc - 10800000;
      var candFinalDate = this.candFinalDateCalc + 75599999;
      query = { "initialDate": candInitialDate, "finalDate": candFinalDate, "page": page, limit: 10 }

    } else if (this.initialDate && id != -1) {
      this.candInitialDateCalc = Date.parse(this.initialDate.toString())
      var candInitialDate = this.candInitialDateCalc - 10800000;
      query = { "initialDate": candFinalDate, "userName": id, "page": page, limit: 10 }
    } else if (this.finalDate && id != -1) {
      this.candFinalDateCalc = Date.parse(this.finalDate.toString())
      var candFinalDate = this.candFinalDateCalc + 75599999;
      query = { "finalDate": candFinalDate, "userName": id, "page": page, limit: 10 }
    } else if (this.initialDate) {
      this.candInitialDateCalc = Date.parse(this.initialDate.toString());
      var candInitialDate = this.candInitialDateCalc - 10800000;
      query = { "initialDate": candInitialDate, "page": page, limit: 10 }

    } else if (this.finalDate) {
      this.candFinalDateCalc = Date.parse(this.finalDate.toString())
      var candFinalDate = this.candFinalDateCalc + 75599999;
      query = { "finalDate": candFinalDate, "page": page, limit: 10 }
    } else if (id != -1) {
      query = { "userName": id, "page": page, limit: 10 }
    }
    this.query = query;
    this.candidateService.searchReportCandidate(query).subscribe(r => {
      this.result = [];
      for (let cr of r.result) {
        let c = cr;
        this.result.push(c);
      }
      this.candidatesLoaded = true;
      this.totalItems = r.count;
      this.exportListXlsx = r.export;
    });

  }


  clearInitialDate() {
    this.initialDate = undefined;
  }

  clearFinalDate() {
    this.finalDate = undefined;
  }

  formatDate(registrationDate: Date) {
    return moment(registrationDate).format('L');
  }

  formatTime(registrationDate: Date) {
    return moment(registrationDate).format('LT');
  }

  // exportList() {
  //   this.export = true;
  //   this.candidateService.searchReportCandidateToXlsv(this.query).subscribe(r => {
  //     this.exportListXlsx = r.export;
  //     if (r.export.length > 0) {
  //       const ws: XLSX.WorkSheet = XLSX.utils.aoa_to_sheet(this.exportListXlsx);

  //       /* generate workbook and add the worksheet */
  //       const wb: XLSX.WorkBook = XLSX.utils.book_new();
  //       XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');

  //       /* save to file */
  //       XLSX.writeFile(wb, 'Fluxo-de-candidatos.xlsx');
  //       this.export = false;
  //     } else {
  //       this.enumsHelper.toast("Não há resultados para exportar", "warning")
  //       this.export = false;
  //     }

  //   });
  // }

  onSort(event) {
    // event was triggered, start sort sequence
    switch (this.statusSort[event]) {
      case 0:
        switch (event) {
          case 0:
            this.statusSort[event] = 1;
            this.statusSort[1] = 0;
            this.statusSort[2] = 0;
            this.statusSort[3] = 0;
            this.statusSort[4] = 0;
            this.query.sort = { "query": { "name": 1 } }
            break;
          case 1:
            this.statusSort[event] = 1;
            this.statusSort[0] = 0;
            this.statusSort[2] = 0;
            this.statusSort[3] = 0;
            this.statusSort[4] = 0;
            this.query.sort = { "query": { "typeOfOrigin": 1 } }
            break;
          case 2:
            this.statusSort[event] = 1;
            this.statusSort[0] = 0;
            this.statusSort[1] = 0;
            this.statusSort[3] = 0;
            this.statusSort[4] = 0;
            this.query.sort = { "query": { "registrationDate": 1 } }
            break;
          case 3:
            this.statusSort[event] = 1;
            this.statusSort[0] = 0;
            this.statusSort[1] = 0;
            this.statusSort[2] = 0;
            this.statusSort[4] = 0;
            this.query.sort = { "query": { "interactions.registrationDate": 1 } }
            break;
          case 4:
            this.statusSort[event] = 1;
            this.statusSort[0] = 0;
            this.statusSort[1] = 0;
            this.statusSort[2] = 0;
            this.statusSort[3] = 0;
            this.query.sort = { "query": { "interactions.registrationDate": 1 } }
            break;
        }
        break;
      case 1:
        switch (event) {
          case 0:
            this.statusSort[event] = 2;
            this.statusSort[1] = 0;
            this.statusSort[2] = 0;
            this.statusSort[3] = 0;
            this.statusSort[4] = 0;
            this.query.sort = { "query": { "interactions.registrationDate": -1 } }
            break;
          case 1:
            this.statusSort[event] = 2;
            this.statusSort[0] = 0;
            this.statusSort[2] = 0;
            this.statusSort[3] = 0;
            this.statusSort[4] = 0;
            this.query.sort = { "query": { "name": -1 } }
            break;
          case 2:
            this.statusSort[event] = 2;
            this.statusSort[0] = 0;
            this.statusSort[1] = 0;
            this.statusSort[3] = 0;
            this.statusSort[4] = 0;
            this.query.sort = { "query": { "registrationDate": -1 } }
            break;
          case 3:
            this.statusSort[event] = 2;
            this.statusSort[0] = 0;
            this.statusSort[1] = 0;
            this.statusSort[2] = 0;
            this.statusSort[4] = 0;
            this.query.sort = { "query": { "interaction.registrationDate": -1 } }
            break;
          case 4:
            this.statusSort[event] = 2;
            this.statusSort[0] = 0;
            this.statusSort[1] = 0;
            this.statusSort[2] = 0;
            this.statusSort[3] = 0;
            this.query.sort = { "query": { "slaApproval": -1 } }
            break;
        }
        break;
      case 2:
        this.query.sort = undefined;
        this.statusSort[event] = 0;
        break;
    }
    this.searchReportCandidate(this.id, this.page);
  }

  getUsers() {
    this.users = []
    this.authService.getUsers().subscribe(r => {
      for (let u of r.result) {
        let user = new UserModel();
        user.loadUserModel(u);
        this.users.push(user)
      }
    })
  }
}
