import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CandidateReportComponent } from './candidate-report.component';
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from '../../../shared/shared.module';
import { EnumsHelper } from '../../../common/enums-helper';
export const CandidateReportRoutes: Routes = [
    {
        path: '',
        component:CandidateReportComponent,
        data: {
          heading: 'candidate-report',
          status:false
        }
      }
    ];
    
    @NgModule({
      imports: [
        CommonModule,
        RouterModule.forChild(CandidateReportRoutes),
        SharedModule
      ],
      declarations: [CandidateReportComponent],
      providers:[
        EnumsHelper
      ],
    })
export class CandidateReportsModule { }
