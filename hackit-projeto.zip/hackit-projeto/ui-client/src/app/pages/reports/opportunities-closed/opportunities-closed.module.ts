import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { OpportunitiesClosedComponent } from './opportunities-closed.component';
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from '../../../shared/shared.module';

export const ReportOpportunitiesClosedRoutes: Routes = [
    {
        path: '',
        component: OpportunitiesClosedComponent,
        data: {
          heading: 'opportunities-closed',
          status:false
        }
      }
    ];
    
    @NgModule({
      imports: [
        CommonModule,
        RouterModule.forChild(ReportOpportunitiesClosedRoutes),
        SharedModule
      ],
      declarations: [OpportunitiesClosedComponent]
    })
export class ReportOpportunitiesClosedModule { }
