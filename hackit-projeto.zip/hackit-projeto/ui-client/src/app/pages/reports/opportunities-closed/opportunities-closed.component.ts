import { Component, OnInit } from '@angular/core';
import { OpportunityModel } from '../../../models/opportunity.model';
import { OpportunityService } from '../../../../../_services/opportunity.service';
import { InteractionService } from '../../../../../_services/interaction.service';
import * as moment from 'moment';
import { EnumsHelper } from '../../../common/enums-helper';
import * as XLSX from 'xlsx';

declare var $: any;
moment.locale('pt-BR');
@Component({
  selector: 'app-opportunities-closed',
  templateUrl: './opportunities-closed.component.html',
  styleUrls: ['./opportunities-closed.component.css']
})
export class OpportunitiesClosedComponent implements OnInit {
  opportunityModel: OpportunityModel = new OpportunityModel();
  initialDate: Date;
  finalDate: Date;
  validationSearchByDate: number = 0;
  reports: any;
  oppInitialDateCalc: number;
  oppFinalDateCalc: number;
  result: any;
  totalItems: number;
  page: number;
  export: boolean = false;
  enumsHelper: EnumsHelper = new EnumsHelper();
  exportListXlsx: any;
  statusSort: [number, number, number, number, number] = [0, 0, 0, 0, 0];
  query: any = {};
  id: any;
  constructor(
    private opportunityService: OpportunityService,
    private interactionService: InteractionService
  ) { }

  ngOnInit() {
    this.interactionService.getReports().subscribe(r => {
      this.reports = [];
      for (let cr of r) {
        let c = cr;
        this.reports.push(c);
      }
      this.reports.sort(function (a, b) {
        if (a._id > b._id) {
          return 1;
        }
        if (a._id < b._id) {
          return -1;
        }
        return 0;
      });
    });
    this.searchReportClosedOpp(-1, 1);
  }

  searchReportClosedOpp(id, page) {
    this.page = page;
    this.id = id;
    let sort = this.query.sort;
    if (this.initialDate > this.finalDate) {
      this.enumsHelper.toast("A data inicial não pode ser maior que a data final.", "warning");
      return;
    }
    this.query = { "page": this.page }

    if (this.initialDate && this.finalDate && this.id != -1) {
      this.oppInitialDateCalc = Date.parse(this.initialDate.toString());
      this.oppFinalDateCalc = Date.parse(this.finalDate.toString())
      var oppInitialDate = this.oppInitialDateCalc - 10800000;
      var oppFinalDate = this.oppFinalDateCalc + 75599999;
      this.query = { "initialDate": oppInitialDate, "finalDate": oppFinalDate, "userName": this.id, "validation": this.validationSearchByDate, "page": page }

    } else if (this.initialDate && this.finalDate) {

      this.oppInitialDateCalc = Date.parse(this.initialDate.toString());
      this.oppFinalDateCalc = Date.parse(this.finalDate.toString())
      var oppInitialDate = this.oppInitialDateCalc - 10800000;
      var oppFinalDate = this.oppFinalDateCalc + 75599999;
      this.query = { "initialDate": oppInitialDate, "finalDate": oppFinalDate, "validation": this.validationSearchByDate, "page": this.page }

    } else if (this.initialDate && this.id != -1) {
      this.oppInitialDateCalc = Date.parse(this.initialDate.toString());
      var oppInitialDate = this.oppInitialDateCalc - 10800000;
      this.query = { "userName": this.id, "initialDate": oppInitialDate, "validation": this.validationSearchByDate, "page": this.page }

    } else if (this.finalDate && this.id != -1) {
      this.oppFinalDateCalc = Date.parse(this.finalDate.toString())
      var oppFinalDate = this.oppFinalDateCalc + 75599999;
      this.query = { "userName": this.id, "finalDate": oppFinalDate, "validation": this.validationSearchByDate, "page": this.page }

    } else if (this.initialDate) {
      this.oppInitialDateCalc = Date.parse(this.initialDate.toString());
      var oppInitialDate = this.oppInitialDateCalc - 10800000;
      this.query = { "initialDate": oppInitialDate, "validation": this.validationSearchByDate, "page": this.page }

    } else if (this.finalDate) {

      this.oppFinalDateCalc = Date.parse(this.finalDate.toString());
      var oppFinalDate = this.oppFinalDateCalc + 75599999;
      this.query = { "finalDate": oppFinalDate, "validation": this.validationSearchByDate, "page": this.page }

    } else if (this.id != -1) {

      this.query = { "userName": this.id, "page": this.page }

    }
    if (sort) {
      this.query.sort = sort;
    }
    this.opportunityService.searchReportOpportunityClosed(this.query).subscribe(r => {
      this.result = [];
      for (let cr of r.result) {
        let c = cr;
        this.result.push(c);
      }
      this.totalItems = r.count;
      this.exportListXlsx = r.export;
    });
  }

  selectDateValidation(value) {

    if (value == 0) {
      this.initialDate = undefined;
      this.finalDate = undefined;
    }
    this.validationSearchByDate = value;
  }

  clearInitialDate() {
    this.initialDate = undefined;
  }

  clearFinalDate() {
    this.finalDate = undefined;
  }

  formatDate(registrationDate: Date) {
    return moment(registrationDate).format('L');
  }

  formatTime(registrationDate: Date) {
    return moment(registrationDate).format('LT');
  }

  exportList() {
    this.export = true;
    if (this.totalItems > 0) {
      const ws: XLSX.WorkSheet = XLSX.utils.aoa_to_sheet(this.exportListXlsx);

      /* generate workbook and add the worksheet */
      const wb: XLSX.WorkBook = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');

      /* save to file */
      XLSX.writeFile(wb, 'Vagas-Fechadas.xlsx');
      this.export = false;
    } else {
      this.enumsHelper.toast("Não há resultados para exportar", "warning")
      this.export = false;
    }
  }

  onSort(event) {
    // event was triggered, start sort sequence
    switch (this.statusSort[event]) {
      case 0:
        switch (event) {
          case 0:
            this.statusSort[event] = 1;
            this.statusSort[1] = 0;
            this.statusSort[2] = 0;
            this.statusSort[3] = 0;
            this.statusSort[4] = 0;
            this.query.sort = { "query": { "customerName": 1 } }
            break;
          case 1:
            this.statusSort[event] = 1;
            this.statusSort[0] = 0;
            this.statusSort[2] = 0;
            this.statusSort[3] = 0;
            this.statusSort[4] = 0;
            this.query.sort = { "query": { "name": 1 } }
            break;
          case 2:
            this.statusSort[event] = 1;
            this.statusSort[0] = 0;
            this.statusSort[1] = 0;
            this.statusSort[3] = 0;
            this.statusSort[4] = 0;
            this.query.sort = { "query": { "registrationDate": 1 } }
            break;
          case 3:
            this.statusSort[event] = 1;
            this.statusSort[0] = 0;
            this.statusSort[1] = 0;
            this.statusSort[2] = 0;
            this.statusSort[4] = 0;
            this.query.sort = { "query": { "interaction.registrationDate": 1 } }
            break;
          case 4:
            this.statusSort[event] = 1;
            this.statusSort[0] = 0;
            this.statusSort[1] = 0;
            this.statusSort[2] = 0;
            this.statusSort[3] = 0;
            this.query.sort = { "query": { "slaApproval": 1 } }
            break;
        }
        break;
      case 1:
        switch (event) {
          case 0:
            this.statusSort[event] = 2;
            this.statusSort[1] = 0;
            this.statusSort[2] = 0;
            this.statusSort[3] = 0;
            this.statusSort[4] = 0;
            this.query.sort = { "query": { "customerName": -1 } }
            break;
          case 1:
            this.statusSort[event] = 2;
            this.statusSort[0] = 0;
            this.statusSort[2] = 0;
            this.statusSort[3] = 0;
            this.statusSort[4] = 0;
            this.query.sort = { "query": { "name": -1 } }
            break;
          case 2:
            this.statusSort[event] = 2;
            this.statusSort[0] = 0;
            this.statusSort[1] = 0;
            this.statusSort[3] = 0;
            this.statusSort[4] = 0;
            this.query.sort = { "query": { "registrationDate": -1 } }
            break;
          case 3:
            this.statusSort[event] = 2;
            this.statusSort[0] = 0;
            this.statusSort[1] = 0;
            this.statusSort[2] = 0;
            this.statusSort[4] = 0;
            this.query.sort = { "query": { "interaction.registrationDate": -1 } }
            break;
          case 4:
            this.statusSort[event] = 2;
            this.statusSort[0] = 0;
            this.statusSort[1] = 0;
            this.statusSort[2] = 0;
            this.statusSort[3] = 0;
            this.query.sort = { "query": { "slaApproval": -1 } }
            break;
        }
        break;
      case 2:
        this.query.sort = undefined;
        this.statusSort[event] = 0;
        break;
    }
    this.searchReportClosedOpp(this.id, this.page);
  }
}
