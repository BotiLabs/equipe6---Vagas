import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from '../../shared/shared.module';
import { RatingModule } from "ngx-rating";

export const ReportsRoutes: Routes = [
    {
      path: '',
      children: [
        {
          path: 'selection',
          loadChildren: './selection/reports.selection.module#ReportSelectionModule',
          data:{
            heading:"selection"
          }
        },
        {
          path: 'media',
          loadChildren: './media/media.module#ReportMediaModule',
          data:{
            heading:"media"
          }
        },
        {
          path: 'opportunities-closed',
          loadChildren: './opportunities-closed/opportunities-closed.module#ReportOpportunitiesClosedModule',
          data:{
            heading:"opportunities-closed"
          }
        },
        {
          path: 'actions',
          loadChildren: './actions/actions.module#ActionsModule',
          data:{
            heading:"actions"
          }
        },
        {
          path: 'opportunities-closed-match',
          loadChildren: './opportunities-closed-match/opportunities-closed-match.module#OpportunitiesClosedMatchModule',
          data:{
            heading:"opportunities-closed-match"
          }
        },
        {
          path: 'candidate-report',
          loadChildren: './candidate-report/candidate-report.module#CandidateReportsModule',
          data:{
            heading:"candidate-report"
          }
        }       
      ]
    }
  ];
  
  @NgModule({
    imports: [
      CommonModule,
      RouterModule.forChild(ReportsRoutes)
    ],
    declarations: []
  })
export class ReportsModule { }
