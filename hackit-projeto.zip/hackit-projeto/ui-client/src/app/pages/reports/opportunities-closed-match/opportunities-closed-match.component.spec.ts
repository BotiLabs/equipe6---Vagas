import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OpportunitiesClosedMatchComponent } from './opportunities-closed-match.component';

describe('OpportunitiesClosedMatchComponent', () => {
  let component: OpportunitiesClosedMatchComponent;
  let fixture: ComponentFixture<OpportunitiesClosedMatchComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OpportunitiesClosedMatchComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OpportunitiesClosedMatchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
