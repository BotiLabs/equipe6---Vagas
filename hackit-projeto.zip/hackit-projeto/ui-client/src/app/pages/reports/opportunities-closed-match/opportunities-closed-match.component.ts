import { ActionInteraction } from './../../../common/action-interaction';
import { Component, OnInit } from '@angular/core';
import { OpportunityModel } from '../../../models/opportunity.model';
import { OpportunityService } from '../../../../../_services/opportunity.service';
import { InteractionService } from '../../../../../_services/interaction.service';
import * as moment from 'moment';
import { EnumsHelper } from '../../../common/enums-helper';
import { PersistenceService } from 'angular-persistence';
import { StatusOfCandidateModel } from '../../../models/statusOfCandidate.model';
import { InteractionModel } from '../../../models/interaction.model';
import { OpportunitiesRequest } from '../../../common/opportunities.request';
import { CustomerModel } from '../../../models/customerModel';
import { ReportHiredRequest } from '../../../common/reportHired.request';
import { PriorityOpportunity } from '../../../common/priority';
import * as XLSX from 'xlsx';
import { AuthService } from '../../../../../_services/auth.service';
import { UserModel } from '../../../models/user.model';

declare var $: any;
moment.locale('pt-BR');
@Component({
  selector: 'app-opportunities-closed-match',
  templateUrl: './opportunities-closed-match.component.html',
  styleUrls: ['./opportunities-closed-match.component.css']
})
export class OpportunitiesClosedMatchComponent implements OnInit {
  opportunityModel: OpportunityModel = new OpportunityModel();
  initialDate: Date;
  finalDate: Date;
  validationSearchByDate: number = 0;
  oppInitialDateCalc: number;
  oppFinalDateCalc: number;
  result: any;
  totalItems: number;
  page: number;
  enumsHelper: EnumsHelper = new EnumsHelper();
  selectedItems = [];
  selectedItemsCargo = [];
  reportHiredRequest: ReportHiredRequest = new ReportHiredRequest();
  interactionModel: InteractionModel = new InteractionModel();
  interactions: InteractionModel[];
  candidatesLoaded: boolean = false;
  limit: number = 15;
  reportsWithDate: any;
  reports: any;
  statusOfCandidateArray: StatusOfCandidateModel[];
  priorityOpportunity: PriorityOpportunity[];
  statusSort: [number, number, number, number, number, number, number, number, number] = [0, 0, 0, 0, 0, 0, 0, 0, 0];
  query: any;
  opportunitiesRequest: OpportunitiesRequest = new OpportunitiesRequest();
  selectedCustomer: CustomerModel = new CustomerModel();
  locationFilter = [];
  customer: any[];
  location: any[];
  users: any;
  export: boolean = false



  constructor(
    private opportunityService: OpportunityService,
    private interactionService: InteractionService,
    private persistenceService: PersistenceService,
    private authService: AuthService,
  ) {
    this.getUsers();
    (<any>window).ga('set', 'page', 'Relatório de contratações');
    (<any>window).ga('send', 'pageview');
  }


  ngOnInit() {
    this.priorityOpportunity = this.enumsHelper.getEnumPrioritOpportunity();
    this.getCostumerName()
    this.reportOpportunityClosedMatch(1);
  }

  reportOpportunityClosedMatch(page) {
    this.reportHiredRequest.page = page;
    this.interactionService.searchHiredRequest(this.reportHiredRequest).subscribe(r => {
      this.result = [];
      this.result = r.result;
      this.totalItems = r.count;
    });

  }

  loadStatus(status: number) {
    let obj = this.statusOfCandidateArray.find(x => x.number == status);
    if (obj)
      return obj;
  }

  actionConverter(action: number) {
    let stat = this.enumsHelper.getDescriptionActionInteraction(action);
    return stat;
  }


  // search(page) {
  //   this.reportHiredRequest.page = page;

  //   this.interactionService.searchHiredRequest(this.reportHiredRequest).subscribe(r => {
  //     this.interactions = r.result;
  //     this.totalItems = r.count;
  //   });
  // }

  dateConverter(date: string) {
    var dateToConvert = new Date(date)
    var convertedDate = dateToConvert.toLocaleDateString()
    return convertedDate
  }

  clearInitialDate() {
    this.reportHiredRequest.initialDate = undefined;
  }
  clearFinalDate() {
    this.reportHiredRequest.finalDate = undefined;
  }
  formatDate(registrationDate: Date) {
    return moment(registrationDate).format('L');
  }
  formatTime(registrationDate: Date) {
    return moment(registrationDate).format('LT');
  }

  getCostumerName() {
    this.customer = [];
    this.opportunityService.getCustomer().subscribe(r => {
      for (let cr of r.result) {
        let cN = new CustomerModel;
        cN.loadFromServer(cr)
        this.customer.push(cN);
      }
      //sorting dropdowns
      this.customer.sort(function (a, b) {
        if (a.name > b.name) {
          return 1;
        }
        if (a.name < b.name) {
          return -1;
        }
        return 0;
      });
    });
  }

  exportContratationList() {
    this.export = true;
    this.interactionService.exportContratationList(this.reportHiredRequest).subscribe(r => {
      this.export = false;
      if (r.length > 0) {
        const ws: XLSX.WorkSheet = XLSX.utils.aoa_to_sheet(r);

        /* generate workbook and add the worksheet */
        const wb: XLSX.WorkBook = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');

        /* save to file */
        XLSX.writeFile(wb, 'Contratações.xlsx');
      } else {
        this.enumsHelper.toast("Não há dados para exportar.", "warning")
      }
    }, err => {
      this.export = false;
      this.enumsHelper.toast(err.Errors.message, "warning")
    })
  }

  getUsers() {
    this.users = []
    this.authService.getUsers().subscribe(r => {
      for (let u of r.result) {
        let user = new UserModel();
        user.loadUserModel(u);
        this.users.push(user)
      }

      this.users.sort((a, b) => {
        if (a.firstName > b.firstName) {
          return 1;
        }
        if (a.firstName < b.firstName) {
          return -1;
        }
        return 0;
      })


    })
  }

  onSort(event) {
    // event was triggered, start sort sequence
    switch (this.statusSort[event]) {
      case 0:
        switch (event) {
          case 0:
            this.statusSort[event] = 1;
            this.statusSort[1] = 0;
            this.statusSort[2] = 0;
            this.statusSort[3] = 0;
            this.statusSort[4] = 0;
            this.statusSort[5] = 0;
            this.statusSort[6] = 0;
            this.reportHiredRequest.sort = { "query": { "userFirstName": 1 } }
            break;
          case 1:
            this.statusSort[event] = 1;
            this.statusSort[0] = 0;
            this.statusSort[2] = 0;
            this.statusSort[3] = 0;
            this.statusSort[4] = 0;
            this.statusSort[5] = 0;
            this.statusSort[6] = 0;
            this.reportHiredRequest.sort = { "query": { "customerName": 1 } }
            break;
          case 2:
            this.statusSort[event] = 1;
            this.statusSort[0] = 0;
            this.statusSort[1] = 0;
            this.statusSort[3] = 0;
            this.statusSort[4] = 0;
            this.statusSort[5] = 0;
            this.statusSort[6] = 0;
            this.reportHiredRequest.sort = { "query": { "id": 1 } }
            break;
          case 3:
            this.statusSort[event] = 1;
            this.statusSort[0] = 0;
            this.statusSort[1] = 0;
            this.statusSort[2] = 0;
            this.statusSort[4] = 0;
            this.statusSort[5] = 0;
            this.statusSort[6] = 0;
            this.reportHiredRequest.sort = { "query": { "opportunity": 1 } }
            break;
          case 4:
            this.statusSort[event] = 1;
            this.statusSort[0] = 0;
            this.statusSort[1] = 0;
            this.statusSort[2] = 0;
            this.statusSort[3] = 0;
            this.statusSort[5] = 0;
            this.statusSort[6] = 0;
            this.reportHiredRequest.sort = { "query": { "priority": 1 } }
            break;
          case 5:
            this.statusSort[event] = 1;
            this.statusSort[0] = 0;
            this.statusSort[1] = 0;
            this.statusSort[2] = 0;
            this.statusSort[3] = 0;
            this.statusSort[4] = 0;
            this.statusSort[6] = 0;
            this.reportHiredRequest.sort = { "query": { "candidate": 1 } }
            break;
          case 6:
            this.statusSort[event] = 1;
            this.statusSort[0] = 0;
            this.statusSort[1] = 0;
            this.statusSort[2] = 0;
            this.statusSort[3] = 0;
            this.statusSort[4] = 0;
            this.statusSort[5] = 0;
            this.reportHiredRequest.sort = { "query": { "registrationDate": 1 } }
            break;
        }
        break;
      case 1:
        switch (event) {
          case 0:
            this.statusSort[event] = 2;
            this.statusSort[1] = 0;
            this.statusSort[2] = 0;
            this.statusSort[3] = 0;
            this.statusSort[4] = 0;
            this.statusSort[5] = 0;
            this.statusSort[6] = 0;
            this.reportHiredRequest.sort = { "query": { "userFirstName": -1 } }
            break;
          case 1:
            this.statusSort[event] = 2;
            this.statusSort[0] = 0;
            this.statusSort[2] = 0;
            this.statusSort[3] = 0;
            this.statusSort[4] = 0;
            this.statusSort[5] = 0;
            this.statusSort[6] = 0;
            this.reportHiredRequest.sort = { "query": { "customerName": -1 } }
            break;
          case 2:
            this.statusSort[event] = 2;
            this.statusSort[0] = 0;
            this.statusSort[1] = 0;
            this.statusSort[3] = 0;
            this.statusSort[4] = 0;
            this.statusSort[5] = 0;
            this.statusSort[6] = 0;
            this.reportHiredRequest.sort = { "query": { "id": -1 } }
            break;
          case 3:
            this.statusSort[event] = 2;
            this.statusSort[0] = 0;
            this.statusSort[1] = 0;
            this.statusSort[2] = 0;
            this.statusSort[4] = 0;
            this.statusSort[5] = 0;
            this.statusSort[6] = 0;
            this.reportHiredRequest.sort = { "query": { "opportunity": -1 } }
            break;
          case 4:
            this.statusSort[event] = 2;
            this.statusSort[0] = 0;
            this.statusSort[1] = 0;
            this.statusSort[2] = 0;
            this.statusSort[3] = 0;
            this.statusSort[5] = 0;
            this.statusSort[6] = 0;
            this.reportHiredRequest.sort = { "query": { "priority": -1 } }
            break;
          case 5:
            this.statusSort[event] = 2;
            this.statusSort[0] = 0;
            this.statusSort[1] = 0;
            this.statusSort[2] = 0;
            this.statusSort[3] = 0;
            this.statusSort[4] = 0;
            this.statusSort[6] = 0;
            this.reportHiredRequest.sort = { "query": { "candidate": -1 } }
            break;
          case 6:
            this.statusSort[event] = 2;
            this.statusSort[0] = 0;
            this.statusSort[1] = 0;
            this.statusSort[2] = 0;
            this.statusSort[3] = 0;
            this.statusSort[4] = 0;
            this.statusSort[5] = 0;
            this.reportHiredRequest.sort = { "query": { "registrationDate": -1 } }
            break;
        }
        break;
      case 2:
        this.reportHiredRequest.sort = undefined;
        this.statusSort[event] = 0;
        break;
    }
    this.reportOpportunityClosedMatch(this.reportHiredRequest.page);
  }

}
