import { TagsComponent } from './tags.component';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from '../../shared/shared.module';
import { InputTrimModule } from 'ng2-trim-directive';
import { InfiniteScrollModule } from 'ngx-infinite-scroll';

export const LogsRoutes: Routes = [
    {
    path:'',
    component: TagsComponent,
    data: {
        heading: 'Tags'
        }
    }
];

@NgModule({
    imports: [
      CommonModule,
      InputTrimModule,
      RouterModule.forChild(LogsRoutes),
      SharedModule,
      InfiniteScrollModule
    ],
    declarations: [TagsComponent]
})
export class TagsModule { }