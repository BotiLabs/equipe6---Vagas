import { NgxPaginationModule } from 'ngx-pagination';
import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Router } from '@angular/router';
import { TagModel } from '../../models/tag.model';
import { TagService } from '../../../../_services/tag.service';
import { TagsRequest } from '../../common/tags.request';
import { InteractionListenService } from '../../../../_services/interaction-listen.service';
import { NotificationService } from '../../../../_services/notification.service';
import { LogsComponent } from '../logs/logs.component';
import '../../../assets/plugins/toast-master/js/jquery.toast.js';
import { EnumsHelper } from '../../common/enums-helper';
declare var $: any;


@Component({
  selector: 'app-tags',
  templateUrl: './tags.component.html',
  styleUrls: ['./tags.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class TagsComponent implements OnInit {
  title: string = "";
  subtitle: string = "";
  // itemsPerPage: number[] = [30, 60, 120, 240, 480];
  limit: number = 48;
  page: number;
  totalItems: number = -1;
  statusTag: string = "";
  modal: boolean = false;
  tagsRequest: TagsRequest = new TagsRequest();
  tags: TagModel[];
  tagToSave: TagModel = new TagModel();
  tagToInsertOrSave: TagModel = new TagModel();
  valores: string;
  tagsRequestArr: TagsRequest[];
  tagModel: TagModel = new TagModel();
  tagValidator: string;
  i: any;
  p: number = 1;
  searchSaveStatus: number = -1;
  enumsHelper: EnumsHelper = new EnumsHelper();
  msg: string = ""

  constructor(
    private router: Router,
    private tagService: TagService,
    private notificationService: NotificationService,
    private logs: LogsComponent
  ) {
    this.title = "Buscar Tags";
    this.subtitle = "Encontre as tags cadastradas.";
    (<any>window).ga('set', 'page', 'Tela de tags');
    (<any>window).ga('send', 'pageview');
  }

  ngOnInit() {
    this.tags = new Array<TagModel>();
    this.searchTags(1, false);
    this.getAllTags();
    // $('.tst3').on('click', () => {
    //   setTimeout(() => {
    //     switch (this.searchSaveStatus) {
    //       case 0:
    //         this.enumsHelper.toast("Tag cadastrada com sucesso!", "success");
    //         break;
    //       case 1:
    //         this.enumsHelper.toast("Digite o nome da Tag.", "warning");
    //         break;
    //       case 2:
    //         this.enumsHelper.toast("A pesquisa deve ter um nome.", "warning");
    //         break;
    //       case 3:
    //         this.enumsHelper.toast(this.msg, "error");
    //         break;
    //       case 4:
    //         this.enumsHelper.toast('Tag atualizada com sucesso!', "success");
    //         break;
    //       case 5:
    //         this.enumsHelper.toast('A tag não pode começar ou terminar com um espaço em branco', "warning");
    //         break;
    //       // default:
    //       //   $.toast({
    //       //     heading: "Alerta",
    //       //     text: 'Tente novamente',
    //       //     position: 'top-right',
    //       //     loaderBg: '#ff6849',
    //       //     icon: "warning",
    //       //     hideAfter: 4500,
    //       //     stack: 6
    //       //   });
    //       //   break;
    //     }
    //   }, 1000);
    // });
  }



  searchTags(page: number, scroll: boolean) {
    this.page = page;
    this.tagsRequest.name = this.tagToSave.name.trim();
    this.tagsRequest.page = page;
    this.tagsRequest.limit = this.limit;

    if (!scroll) {
      this.tags = [];
    }

    this.tagService.search(this.tagsRequest).subscribe(res => {
      console.log(res)
      this.totalItems = res.count;
      for (let tr of res.result) {
        let t = new TagModel();
        t.loadTag(tr);
        this.tags.push(t);
        // console.log(tr)
      }
      if (this.tags.length <= 0){
        this.statusTag = "Não encontramos esta tag. Deseja criar uma nova?";
      }
    }
  
  
  ); 
  
  }


  setTagToEdit(id: string) {
    this.abrirModal();
    this.tagModel = this.tags.find(x => x._id === id);
  }

  
ifExists(name) {
  // this.tagsRequest.name = name.inputTextValue;
  this.tagService.searchIfExists(this.tagsRequest).subscribe(r => {
      if (r == "Não encontramos esta tag. Deseja criar uma nova?" && this.tagsRequest.name != "") {
          this.statusTag = r
      } else {
          this.statusTag = "";
      }
  });
}

  saveTag() {
    // this.fecharModal();
    this.searchSaveStatus = -1;
    console.log(this.tagToSave);
    if (this.tagToSave.name.substring(0, 1) != " "
      && this.tagToSave.name.substring(this.tagToSave.name.length - 1, this.tagToSave.name.length) != " ") {
      if (this.tagToSave.name == "" && this.tags.length < 0) {
        this.enumsHelper.toast("Digite o nome da Tag.", "warning");
        return;
      }
      if (this.tagToSave._id === undefined) {

        this.tagService.add(this.tagToSave).subscribe(r => {
          this.statusTag = "";
          var descricao = "Criou a tag " + this.tagToSave.name.toUpperCase();
          this.tagToSave = new TagModel();
          this.logs.create(descricao);
          this.searchTags(1, false);
          this.enumsHelper.toast("Tag cadastrada com sucesso!", "success");

          return;
        }, (err) => {

          this.enumsHelper.toast(this.msg, 'error');
        });
      } 
      // else {
      //   this.tagService.updateToDelete(this.tagToSave).subscribe(r => {

      //     this.searchSaveStatus = 4;
      //     this.tagToSave = new TagModel();
      //     this.searchTags(1, false);
      //     var descricao = "Alterou uma tag ";
      //     this.logs.create(descricao);
      //   }, err => {
      //     var error = JSON.parse(err._body);
      //     this.enumsHelper.toast(error.message, "warning");
      //   });
      // }
      return;
    } else {
      this.enumsHelper.toast('A tag não pode começar ou terminar com um espaço em branco', "warning");
    }
  }


  getAllTags() {
    this.tagService.getAll().subscribe(tg => {
      this.tags.push(tg);
        for (let t of tg) {
            var tag = new TagModel();
            tag.loadTag(t);
        }
    })
}

// getAllTags() {
//   this.tagService.getAll().subscribe(tg => {
//       for (let t of tg) {
//           var tag = new TagModel();
//           tag.loadTag(t);
//           this.tags.push(tag);
//       }
//   })
//   console.log(this.tags);
// }

editTag(){
  if (this.tagModel._id === undefined) {
    this.createTag();
} else {
  this.tagService.updateToDelete(this.tagModel).subscribe(r => {

    this.searchSaveStatus = 4;
    this.tagModel = new TagModel();
    this.searchTags(1, false);
    var descricao = "Alterou uma tag ";
    this.logs.create(descricao);
  }, err => {
    var error = JSON.parse(err._body);
    this.enumsHelper.toast(error.message, "warning");
  });
  this.fecharModal();
}
}


createTag() {
  // this.tagModel.name = this.tagsRequest.name;
  console.log(this.tagModel);
  this.tagService.add(this.tagModel).subscribe(r => {
      this.statusTag = "";
      this.tagModel = new TagModel();
      this.getAllTags();
      var descricao = "Criou a tag " + this.tagModel.name.toUpperCase();
      this.logs.create(descricao);
          this.searchTags(1, false);
          this.enumsHelper.toast("Tag cadastrada com sucesso!", "success");
      return;
  }, (err) => {
      console.log(err);
      this.enumsHelper.toast("Digite o nome da Tag.", "warning");
  });
  this.fecharModal();
}

// createTag() {
//   // this.tagModel.name = this.tagsRequest.name;
//   console.log(this.tagModel);
//   this.tagService.add(this.tagModel).subscribe(r => {
//       this.statusTag = "";
//       this.tagModel = new TagModel();
//       this.getAllTags();
//       var descricao = "Criou a tag " + this.tagModel.name.toUpperCase();
//       this.logs.create(descricao);
//           this.searchTags(1, false);
//           this.enumsHelper.toast("Tag cadastrada com sucesso!", "success");
//       return;
//   }, (err) => {
//       console.log(err);
//   });
//   this.fecharModal();
// }


  no(name) {
    this.statusTag = "";
    // name.inputTextValue = "";
  }

  abrirModal(){
    this.modal = true;
  }

  fecharModal(){
    this.modal = false;
  }


  deleteTag(tag: TagModel) {
    var descricao = "Deletou a tag " + tag.name;
    this.logs.create(descricao);
    tag.visible = false;
    this.tagService.update(tag).subscribe(r => {

      this.searchTags(1, false);
      this.searchSaveStatus = 6;
      this.enumsHelper.toast("Tag deletada com sucesso", "error");
      return;
    });

  }

  onScroll() {
    if (this.tags.length > 0) {
      this.page++;
      this.searchTags(this.page, true);
    }
  }



// editTag(){

//   if (this.tagModel._id === undefined) {
//     this.createTag();
// } else {
//   this.tagService.updateToDelete(this.tagModel).subscribe(r => {

//     this.searchSaveStatus = 4;
//     this.tagModel = new TagModel();
//     this.searchTags(1, false);
//     var descricao = "Alterou uma tag ";
//     this.logs.create(descricao);
//   }, err => {
//     var error = JSON.parse(err._body);
//     this.enumsHelper.toast(error.message, "warning");
//   });
//   this.fecharModal();
// }
// }




}


