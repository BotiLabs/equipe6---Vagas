import { NgModule } from '@angular/core';

import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from './../../../shared/shared.module';

import { ProfileComponent } from './profile.component';
import { ChartsModule } from 'ng2-charts';
import { AngularMultiSelectModule } from 'angular2-multiselect-dropdown/angular2-multiselect-dropdown';


export const ProfileRoutes: Routes = [ 
    {
        path: '',
        component: ProfileComponent,
        data:{
            heading: 'Perfil do Candidato'
        }
    }
];

@NgModule({
    imports: [
        CommonModule,
        RouterModule.forChild(ProfileRoutes),
        SharedModule,
        ChartsModule,
        AngularMultiSelectModule
    ],
    declarations: [
        ProfileComponent,
    ]
})
export class ProfileModule {}