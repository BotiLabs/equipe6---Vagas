import { PersonalityService } from './../../../../../_services/personality.service';
import { EvaluationModel } from './../../../models/evaluation.model';
import { CandidateModel } from './../../../models/candidate.model';
import { HiringCandidate } from './../../../common/hiring-candidate';
import { CandidateService } from './../../../../../_services/candidate.service';
import { Component, OnInit, Input, ApplicationRef, EventEmitter, Output, HostListener, ElementRef } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { IOption } from 'ng-select';
import { StatusCandidate } from '../../../common/status-candidate';
import { ProfileCandidate } from '../../../common/profile-candidate';
import { EnumsHelper } from '../../../common/enums-helper';
import { CandidatesRequest } from '../../../common/candidates.request';
import { PersistenceService } from 'angular-persistence';
import { Location } from '@angular/common';
import { EvaluationService } from '../../../../../_services/evaluation.service';
import { InteractionService } from '../../../../../_services/interaction.service';
import { InteractionModel } from '../../../models/interaction.model';
import { StatusModel } from '../../../models/status.model';
import { StatusOfCandidateModel } from '../../../models/statusOfCandidate.model';
import { StatusOfCandidateService } from '../../../../../_services/statusCandidate.service';
import { ActionInteraction } from '../../../common/action-interaction';
import { ProfileInteraction } from '../../../common/profile-interaction';
import { OpportunityService } from '../../../../../_services/opportunity.service';
import { OpportunityModel } from '../../../models/opportunity.model';
import { ManagementService } from '../../../../../_services/service-management.service';
import { ServiceManagementModel } from '../../../models/service-management.model';
import { AuthService } from '../../../../../_services/auth.service';
import { InteractionType } from '../../../common/interaction-type';
import { NotificationModel } from '../../../models/notification.model';
import { LogsComponent } from '../../logs/logs.component';
import { CandidateHistoricModel } from '../../../models/candidateHistoric.model';
import { NotificationService } from '../../../../../_services/notification.service';
import { OpportunityHistoricModel } from '../../../models/opportunityHistoric.model';
import { EmailModel } from '../../../models/email.model';
import { TemplateEmail } from '../interaction/templateEmailInteraction';
import { environment } from '../../../../environments/environment';
import { EmailService } from '../../../../../_services/email.service';
import { NotificationServ } from '../../../../../_services/notificationSoquet.service';
import { AppComponent } from '../../../app.component';
import { StatusOfOpportunityModel } from '../../../models/statusOfOpportunity.model';
import { InteractionListenService } from '../../../../../_services/interaction-listen.service';

declare var $: any;
declare var Morris: any;

@Component({
    selector: 'app-profile',
    templateUrl: './profile.component.html',
    styleUrls: ['./profile.component.css']
})



export class ProfileComponent implements OnInit {

    // @Input() candidateModel: CandidateModel;
    @Output() created = new EventEmitter();

    candidateId: string;
    candidateModel = new CandidateModel();
    candidate: CandidateModel = new CandidateModel();
    c: CandidateModel = new CandidateModel();
    enumsHelper: EnumsHelper = new EnumsHelper();
    interactionsLoaded: boolean = false;
    interactions: InteractionModel[] = [];
    status: StatusModel = new StatusModel();
    statusOfCandidateArray: StatusOfCandidateModel[] = new Array<StatusOfCandidateModel>();
    ddlStatus: StatusCandidate[];
    ddlActions: ActionInteraction[];
    ddlProfiles: ProfileInteraction[];
    opportunities: OpportunityModel[] = [];
    dropdownItem2: {};
    dropdownList2: any = [];
    success: boolean = false;
    opportunityModel: OpportunityModel = new OpportunityModel();
    configs: ServiceManagementModel;
    selectedItems2: any;
    interactionModel: InteractionModel = new InteractionModel();
    dropdownSettingsSingle: {};
    notificationModel: NotificationModel = new NotificationModel();
    candidateHistoric: CandidateHistoricModel = new CandidateHistoricModel();
    opportunityHistoric: OpportunityHistoricModel = new OpportunityHistoricModel();
    emailModel: EmailModel = new EmailModel();
    emailModel2: EmailModel = new EmailModel();
    notificationModel2: NotificationModel = new NotificationModel();
    interactionBlock: boolean = false;
    statusOfOpportunityArray: StatusOfOpportunityModel[] = [];
    opportunitiesLoaded: boolean = false;
    candidateOpportunities: OpportunityModel[] = [];
    blocked: boolean = false;
    modalToInteraction: boolean = false;
    likeIcon: number = 0;
    dislikeIcon: number = 0;
    sk: number;
    ssk: number;
    expandEssay: boolean = true;
    expandVideo: boolean = true;
    modalVideo: boolean = false;
    evaluationResult = [];
    evaluation_SL: EvaluationModel = new EvaluationModel();
    evaluation_HP: EvaluationModel = new EvaluationModel();
    date_sl: Date;
    date_hp: Date;
    expand: boolean = true;
    modal: boolean;
    hiringType: number;
    desiredHiring = [];




    constructor(
        private persistenceService: PersistenceService,
        private _route: ActivatedRoute,
        private candidateService: CandidateService,
        private router: Router,
        private activatedRoute: ActivatedRoute,
        private interactionService: InteractionService,
        private statusOfCandidate: StatusOfCandidateService,
        private opportunityService: OpportunityService,
        private serviceManagement: ManagementService,
        private authService: AuthService,
        private logs: LogsComponent,
        private notificationService: NotificationService,
        private app: ApplicationRef,
        private templateEmail: TemplateEmail,
        private sendEmailService: EmailService,
        private notification: NotificationServ,
        private notificationAdmin: AppComponent,
        private interactionListenService: InteractionListenService,
        private evaluationService: EvaluationService,
        private eRef: ElementRef,

    ) {
        this.dropdownSettingsSingle = {
            singleSelection: true,
            text: "Selecione...",
            selectAllText: 'Marcar todos',
            unSelectAllText: 'Desmarcar todos',
            enableSearchFilter: true,
            classes: "myclass custom-class",
            badgeShowLimit: 3,
            searchBy: ["itemName"]
        };
        this.getAllStatus();
        (<any>window).ga('set', 'page', 'Perfil de candidato');
        (<any>window).ga('send', 'pageview');
    }



    ngOnInit() {

        if (this.activatedRoute.snapshot.params['id'] != undefined) {
            this.candidateId = this.activatedRoute.snapshot.params['id'].split('id')[1];
        }

        this.candidateService.getById(this.candidateId).subscribe(
            res => {
                this.hiringType = res.hiringType;

                this.desiredHiring = res.desiredHiring
                // for (let item of res.desiredHiring) {
                //     parseInt(item);
                //     console.log(item);
                //     this.desiredHiring.push(item);              
                // }

                let o = res.name.toUpperCase();
                this.candidate = res;
                this.verifySilver()
                let c = res.desiredHiring[0]
                this.sk = this.candidate.skills.length;
                this.ssk = this.candidate.softSkills.length;

                this.evaluationService.getByEmail(this.candidate.email).subscribe(
                    res => {
                        if (res.count != 0) {
                            this.evaluation_SL = res.result[0];
                            this.evaluation_HP = res.result[1];

                            this.date_sl = this.evaluation_SL.date;
                            this.date_hp = this.evaluation_HP.date;

                            this.evaluationService.getSum(this.evaluation_SL._id).subscribe(response => {

                                this.evaluationResult = response;

                            }), error => console.log(error);
                        }

                    }, err => {
                        console.log(err);
                    }
                );

            }, err => {
                console.log(err);
            });
        this.loadSource();

        this.ddlStatus = this.enumsHelper.getEnumStatusCandidateArray();
        this.ddlActions = this.enumsHelper.getEnumActionInteractionArray();
        this.ddlProfiles = this.enumsHelper.getProfileInteractionArray();

        this.opportunityService.getOpportunitiesForInteraction().subscribe(res => {
            (res.sort(function (a, b) {
                return a.number - b.number;
            }));
            for (let item of res) {
                var opportunity = new OpportunityModel();
                opportunity.loadModelFromServer(item);
                if (opportunity.isActive)
                    this.opportunities.push(opportunity);

                this.dropdownItem2 = {
                    id: JSON.stringify(opportunity), itemName: opportunity.number.toString() + " - " + opportunity.name + " - Cliente: " + opportunity.customerName
                };
                this.dropdownList2.push(this.dropdownItem2);
            }
        });

        $('.tst3').on('click', () => {
            setTimeout(() => {
                if (this.success == true) {
                    this.enumsHelper.toast("Interação criada com sucesso.", "success");
                } else {
                    this.enumsHelper.toast("Erro na Criação da Interação", "warning");
                }
            }, 1500);
        });

        this.candidate.historic == undefined ? this.candidate.historic = [] : this.candidate.historic = this.candidate.historic;
        this.opportunityModel.historic == undefined ? this.opportunityModel.historic = [] : this.opportunityModel.historic = this.opportunityModel.historic;


        this.serviceManagement.getAll().subscribe(tg => {
            this.configs = tg;
        })

    }

    create() {
        let userInfo = this.authService.getUserInfoModel();
        let opportunity = this.opportunities.find(x => x._id === this.interactionModel.opportunityId);
        this.interactionModel.opportunityName = typeof (opportunity) !== "undefined" ? opportunity.name : "";
        this.interactionModel.userFirstName = userInfo.firstName + " " + userInfo.lastName;
        this.interactionModel.userEmail = userInfo.email;
        this.interactionModel.candidateId = this.candidate._id;
        this.interactionModel.interactionType = InteractionType.RS;
        this.notificationModel.userEmail = userInfo.email;
        this.notificationModel.originNotification = "Interação";


        this.notificationModel.userFirstName = userInfo.firstName + " " + userInfo.lastName;
        this.notificationModel.typeOfNotification = 0;
        this.notificationModel.candidateId = this.interactionModel.candidateId;
        if (typeof (opportunity) !== "undefined") {
            this.interactionModel.opportunityNumber = opportunity.number;
            this.notificationModel.discriptionNotification = "Criou uma interação de " + this.enumsHelper.getDescriptionActionInteraction(this.interactionModel.action) + " da vaga " + opportunity.number + " cujo você é responsável ";
            this.interactionModel.opportunity = opportunity;
            if (this.interactionModel.status != 5) {
                if (this.candidate.opportunities.find(x => x._id === this.interactionModel.opportunityId) === undefined) {
                    this.candidate.opportunities.push(opportunity);
                }

            }
        } else {
            this.notificationModel.discriptionNotification = "Criou uma interação de " + this.enumsHelper.getDescriptionActionInteraction(this.interactionModel.action);
        }

        var acao = this.enumsHelper.getDescriptionActionInteraction(this.interactionModel.action);

        if (!this.interactionModel.opportunity._id) {
            this.interactionModel.opportunity = undefined;
        }
        console.log("aaa")
        console.log(this.interactionModel.status)
        // Validate status of candidate
        if (this.interactionModel.status != -1) {
            if (this.interactionModel.status == 3 || this.interactionModel.status == 2) {
                this.interactionService.findToDisapprove(this.interactionModel).subscribe(r => {
                    if (r.length == 0) {
                        this.candidate.status = this.interactionModel.status;
                    }
                }, err => {
                    console.log(err)
                });

            } else {
                this.candidate.status = this.interactionModel.status;
            }
        }

        this.interactionService.add(this.interactionModel).subscribe(r => {
            var message = "Criou interação de " + acao;
            this.logs.create(message);

            // this.interactionModel.status == 3 ? this.notifyReprovedCandidate() : "";

            //Populate historic of candidate

            if (typeof (opportunity) !== "undefined") {
                this.candidateHistoric.opportunityId = opportunity._id;
                this.candidateHistoric.opportunityName = opportunity.name;
                this.candidateHistoric.opportunityNumber = opportunity.number;
                this.candidateHistoric.opportunityCustomer = opportunity.customerName;
                this.candidateHistoric.registrationDate = new Date();
                this.candidateHistoric.interactions.push(r);

                if (this.candidate.historic.find(x => x.opportunityId === this.interactionModel.opportunityId) != undefined) {
                    this.candidate.historic.forEach(his => {
                        if (his.opportunityId == opportunity._id) {
                            his.interactions.push(r);
                        }
                    });
                }
                if (this.candidate.historic.length > 0) {
                    if (this.candidate.historic.find(x => x.opportunityId == this.interactionModel.opportunityId) == undefined) {
                        this.candidate.historic.push(this.candidateHistoric);
                    }
                } else {
                    this.candidate.historic.push(this.candidateHistoric);
                }
                let opp = this.candidate.opportunities.find(x => x._id == opportunity._id)
                this.candidate.opportunities.indexOf(opp) > -1 && (this.interactionModel.status == 3 || this.interactionModel.status == 2 || this.interactionModel.status == 6) ? this.candidate.opportunities.splice(this.candidate.opportunities.indexOf(opp), 1) : this.candidate;
            }

            this.candidateService.update(this.candidate).subscribe(c => {
                // this.notificationService.notify('Interação inserida com sucesso!');
                this.interactionModel = new InteractionModel();
                this.app.tick();
                this.created.emit();
            });

            if (typeof (opportunity) !== "undefined") {

                if (opportunity.candidates.find(x => x === this.interactionModel.candidateId) === undefined)
                    for (var i = 0; i <= opportunity.candidates.length; i++) {
                        if (opportunity.candidates[i] == this.interactionModel.candidateId) {
                            console.log("quebrou");
                            // return;
                        }
                    }
                if (this.interactionModel.status != 5) {
                    if (typeof (opportunity) !== "undefined") {
                        if (this.interactionModel.status == 4) {
                            if (opportunity.qtdOpportunities) {
                                if (opportunity.qtdOpportunities > 0) {
                                    opportunity.qtdOpportunities = opportunity.qtdOpportunities - 1;
                                }
                                if (opportunity.qtdOpportunities == 0) {
                                    opportunity.status = 1;
                                }
                            }
                        }
                        if (opportunity.candidates.find(x => x === this.interactionModel.candidateId) === undefined) {
                            opportunity.candidates.push(this.interactionModel.candidateId);
                        }
                        //Populate historic opportunity 

                        this.opportunityHistoric.candidateId = this.candidate._id;
                        this.opportunityHistoric.candidateName = this.candidate.name;
                        this.opportunityHistoric.candidateEmail = this.candidate.email;
                        this.opportunityHistoric.registrationDate = new Date();
                        this.opportunityHistoric.interactions.push(r);

                        if (opportunity.historic.find(x => x.candidateId == this.interactionModel.candidateId) != undefined) {
                            opportunity.historic.forEach(his => {
                                if (his.candidateId == this.candidate._id) {
                                    his.interactions.push(r);
                                }
                            });
                        }

                        if (opportunity.historic.length > 0) {
                            if (opportunity.historic.find(x => x.candidateId == this.interactionModel.candidateId) == undefined) {
                                opportunity.historic.push(this.opportunityHistoric);
                            }
                        } else {
                            opportunity.historic.push(this.opportunityHistoric);
                        }
                        opportunity.candidates.indexOf(this.interactionModel.candidateId) && (this.interactionModel.status == 3 || this.interactionModel.status == 2 || this.interactionModel.status == 6) ? opportunity.candidates.splice(opportunity.candidates.indexOf(this.candidate._id), 1) : opportunity;
                        this.opportunityService.update(opportunity).subscribe(r => {
                        });
                    }
                }



            }
            this.notifyRecruiter(opportunity);
        });
        this.success = true
        if (this.interactionModel.status == 4 && typeof (opportunity) !== "undefined") {

            this.updateOpportunities(this.candidate, opportunity);
        }

        if (this.interactionModel.status != -1) {
            if (this.interactionModel.status == 4) {
                this.interactionService.addHired(this.interactionModel).subscribe(r => {

                }, err => {
                    console.log(err)
                });
            }
        }
    }

    validation(c: CandidateModel) {
        c.isBlocked = !c.isBlocked;
        this.candidateService.update(c).subscribe(r => {
        })
    }

    notifyRecruiter(opportunity) {
        if (opportunity != undefined) {
            let email = [];
            if (this.interactionModel.opportunity.involvedPeople.length > 0) {
                opportunity.involvedPeople.forEach(inv => {
                    if (inv.email) {
                        email.push(inv.email);
                    }
                });
                if (email.length > 0) {
                    this.emailModel.to = email.toString();
                } else {
                    this.emailModel.to = this.interactionModel.userEmail;
                }
            } else {
                this.notificationModel.responsibleEmail = "";
                this.emailModel.to = this.interactionModel.userEmail;
            }
        } else {
            this.notificationModel.responsibleEmail = "";
            this.emailModel.to = this.interactionModel.userEmail;
        }


        if (this.interactionModel.opportunity != undefined) {
            if (this.interactionModel.opportunity.emailResponsible == this.interactionModel.userEmail) {
                this.emailModel.subject = "Nova interação de " + this.candidate.name;
                this.emailModel.text = this.templateEmail.createTemplateEmail(this.interactionModel.userFirstName, this.candidate.name, `${environment.frontUrlApi}/candidate/edit/id${this.interactionModel.candidateId}`, this.enumsHelper.getDescriptionActionInteraction(this.interactionModel.action), `${environment.frontUrlApi}`, opportunity);
            } else {
                this.emailModel.subject = "Nova interação de " + this.candidate.name;
                this.emailModel.text = this.templateEmail.createTemplateEmail(this.interactionModel.userFirstName, this.candidate.name, `${environment.frontUrlApi}/candidate/edit/id${this.interactionModel.candidateId}`, this.enumsHelper.getDescriptionActionInteraction(this.interactionModel.action), `${environment.frontUrlApi}`, opportunity);
            }
        } else {
            this.emailModel.subject = "Nova interação de " + this.candidate.name;
            this.emailModel.text = this.templateEmail.createTemplateEmail(this.interactionModel.userFirstName, this.candidate.name, `${environment.frontUrlApi}/candidate/edit/id${this.interactionModel.candidateId}`, this.enumsHelper.getDescriptionActionInteraction(this.interactionModel.action), `${environment.frontUrlApi}`, opportunity);
        }

        if (this.configs.interactionEmail == true) {
            this.sendEmailService.send(this.emailModel)
                .subscribe(res => {
                    // console.log(res);
                }, error => {
                    // console.log(error);
                })
            if (opportunity) {
                if (opportunity.emailWatching != undefined) {
                    for (let i = 0; i < opportunity.emailWatching.length; i++) {
                        this.emailModel2.to = opportunity.emailWatching[i];
                        this.emailModel2.subject = "Nova interação de " + this.candidate.name;
                        this.emailModel2.text = this.templateEmail.createTemplateEmail(this.interactionModel.userFirstName, this.candidate.name, `${environment.frontUrlApi}/candidate/edit/id${this.interactionModel.candidateId}`, this.enumsHelper.getDescriptionActionInteraction(this.interactionModel.action), `${environment.frontUrlApi}`, opportunity);

                        this.sendEmailService.send(this.emailModel2)
                            .subscribe(res => {
                            }, error => {
                                console.log(error);
                            })
                        let userInfo = this.authService.getUserInfoModel();

                        this.notificationModel2.userEmail = userInfo.email;
                        this.notificationModel2.originNotification = "Interação";
                        this.notificationModel2.userFirstName = userInfo.firstName + " " + userInfo.lastName;
                        this.notificationModel2.typeOfNotification = 0;
                        this.notificationModel2.candidateId = this.interactionModel.candidateId;
                        this.notificationModel2.discriptionNotification = "Criou uma interação de " + this.enumsHelper.getDescriptionActionInteraction(this.interactionModel.action) + " da vaga " + opportunity.number + " cujo você é responsável ";
                        this.notificationModel2.responsibleEmail = opportunity.emailWatching[i];

                        this.notification.insert(this.notificationModel2).subscribe(l => {
                            this.notificationAdmin.sendMessage(this.notificationModel2);
                        });

                    }
                } else {
                    console.log("ninguém vigiando a vaga")
                }
            }
        } else {
            console.log("Configuração do envio de e-mail para interações desligada.")
        }

        this.notification.insert(this.notificationModel).subscribe(r => {
            this.notificationAdmin.sendMessage(this.notificationModel);
        });
    }

    updateOpportunities(candidate: CandidateModel, opp) {
        candidate.opportunities = []
        candidate.opportunities.push(opp)
        this.opportunityService.getAll().subscribe(r => {

            for (var i = 0; i < r.length; i++) {
                if (r[i].candidates) {
                    if (r[i].candidates.length > 0) {
                        for (var y = 0; y < r[i].candidates.length; y++) {
                            if (r[i].candidates[y] == candidate._id) {
                                if (r[i]._id != opp._id) {
                                    r[i].candidates.splice(y, 1);
                                    this.opportunityService.update(r[i]).subscribe(r => {
                                    });
                                }
                            }
                        }
                    }
                }
            }
        });
    }

    populateOpportunity() {
        if (this.selectedItems2.length > 0) {
            let selected = JSON.parse(this.selectedItems2[0].id)
            this.interactionModel.opportunityId = selected._id;
            this.interactionModel.opportunityName = selected.name;
        }
    }

    loadStatus(status: number) {
      
        if (this.statusOfCandidateArray) {
            let obj = this.statusOfCandidateArray.find(x => x.number == status);
            if (obj) {
                return obj;
            }
        }
    }


    loadSource() {
        this.interactionsLoaded = false;

        if (this.candidateId) {
            this.interactionService.getByCandidateId(this.candidateId).subscribe(interactionsRes => {
                console.log(interactionsRes);
                this.interactions = [];
                for (let i of interactionsRes) {
                    let interactionLoaded = new InteractionModel();
                    interactionLoaded.loadFromServer(i);
                    this.interactions.push(interactionLoaded);
                }
                //Converting Observation to html
                this.interactionsLoaded = true;
            });
        }
        this.candidateService.getById(this.candidateId).subscribe(
            res => {
                this.candidate = res;
            });
    }

    selectStatusAndColor(status: number) {
        switch (status) {
            case 0:
                this.status.color = "#1a446e";
                this.status.icon = "icon-hourglass";
                break;

            case 1:
                this.status.color = "#e3ac26";
                this.status.icon = "icon-bubble";
                break;

            case 2:
                this.status.color = "#1a446e";
                this.status.icon = "icon-hourglass";
                break;

            case 3:
                this.status.color = " #c4534f";
                this.status.icon = "icon-hourglass";
                break;

            case 4:
                this.status.color = "#7fb16c";
                this.status.icon = "icon-flag ";
                break;

            case 5:
                this.status.color = "#1a446e";
                this.status.icon = "icon-hourglass";
                break;

            case 6:
                this.status.color = "#1a446e";
                this.status.icon = "icon-hourglass";
                break;

            case 7:
                this.status.color = "#e3ac26";
                this.status.icon = "icon-bubble";
                break;

            case 8:
                this.status.color = "#7fb16c";
                this.status.icon = "icon-flag ";
                break;

            case 9:
                this.status.color = "#1a446e";
                this.status.icon = "icon-hourglass";
                break;

            case 11:
                this.status.color = "#f00";
                this.status.icon = "icon-lock";
                break;

            default:
                this.status.color = "#1a446e";
                this.status.icon = "icon-hourglass";
                break;
        }
        return this.status;
    }

    getAllStatus() {
        this.statusOfCandidate.getAll().subscribe(status => {
            this.statusOfCandidateArray = [];
            for (let statusC of status) {
                let statusLoaded = new StatusOfCandidateModel();
                statusLoaded.loadModelFromServer(statusC);
                this.statusOfCandidateArray.push(statusLoaded);
            }
        })
    }

    openIteraction() {
        this.interactionBlock = !this.interactionBlock;
    }

    modalToBlock(c: CandidateModel) {
        this.candidateModel = new CandidateModel()
        this.candidateModel = c;
        this.modalToInteraction = !this.modalToInteraction;
        this.interactionModel = new InteractionModel();
    }


    modalclose() {
        this.modalToInteraction = !this.modalToInteraction;
        this.interactionModel = new InteractionModel();
    }

    loadStatusOpportunity(status: number) {
        let obj = this.statusOfOpportunityArray.find(x => x.number == status);
        if (obj)
            return obj;
    }
    loadCandidateOpportunities() {
        this.opportunitiesLoaded = false;
        this.candidateOpportunities = [];
        for (let opp of this.c.opportunities) {
            let opportunityLoaded = new OpportunityModel;
            opportunityLoaded.loadModelFromServer(opp);
            //Somente exibir as vagas que possuem status aberta ou congelada.
            if (opportunityLoaded.status == 0 || opportunityLoaded.status == 2) {
                this.candidateOpportunities.push(opportunityLoaded);
            }
        }
        this.opportunitiesLoaded = true;
    }

    setInit() {
        this.loadSource();
        this.loadCandidateOpportunities();
    }

    publishCandidate(candidate) {
        this.interactionListenService.publish(candidate);
    }

    async deleteOpportunity(opportunity) {
        console.log('ANTES DE TUDO', opportunity)
        for (var i = 0; i < this.candidate.opportunities.length; i++) {

            if (opportunity._id === this.candidate.opportunities[i]._id) {

                this.candidate.opportunities.splice(i, 1);

            };
        }


        this.candidateService.update(this.candidate).subscribe(r => {

            // this.notificationService.notify('Candidato atualizado com sucesso!');

            for (var i = 0; i < opportunity.candidates.length; i++) {
                console.log(opportunity.candidates[i])
                if (opportunity.candidates[i] == this.candidate._id) {

                    console.log("1", opportunity)
                    opportunity.candidates.splice(i, 1);
                    console.log("2", opportunity)

                    this.candidate.opportunities = [opportunity];

                    this.opportunityService.update(opportunity).subscribe(res => {

                        var message = "Deletou a opportunidade " + opportunity.name + "do candidato " + this.candidate.name;
                        this.logs.create(message);
                        this.loadCandidateOpportunities();
                        this.interactionListenService.notifier.subscribe(candidate => {
                            this.loadSource();
                            this.setInit();
                        });
                        this.candidateService.getById(this.candidate._id).subscribe(r => {
                            this.c.loadCandidate(r);
                            this.publishCandidate(this.candidate);
                        });
                    });
                }
            }
        });
    }

    blockCandidate() {
        this.modalToInteraction = !this.modalToInteraction;

        let i = localStorage.getItem('userInfo');
        let y = JSON.parse(i)
        this.interactionModel.userEmail = y.email;
        this.interactionModel.userFirstName = y.firstName;
        let x: object
        this.interactionModel.opportunity = x;
        this.interactionModel.candidateId = this.candidateModel._id;

        this.candidateModel.isBlocked = !this.candidateModel.isBlocked;
        if (this.candidateModel.isBlocked == true) {
            this.interactionModel.status = 11;
            this.interactionModel.action = 8;
            this.candidateModel.status = 11;
        } else {
            this.interactionModel.action = 9;
            this.interactionModel.status = 5;
            this.candidateModel.status = 5;
        }

        this.candidateService.update(this.candidateModel).subscribe(r => {
            //Analytcs event, Não delete esta linha
            if (this.candidateModel.isBlocked == true)
                this.enumsHelper.sendEventAnalytcs("Bloquear candidato", this.c.name, "Um candidato foi bloqueado")
        })

        this.interactionService.add(this.interactionModel).subscribe(r => {
        })
    }

    verifySilver(){
        let button : HTMLElement = document.getElementById("trophy");
        if(this.candidate.silver){
            button.classList.remove('btn-silver-off');
            button.classList.add('btn-silver');
        }else{
            button.classList.remove('btn-silver');
            button.classList.add('btn-silver-off');
        }
    }

    async silver() {
        let button : HTMLElement = document.getElementById("trophy");
        if(!this.candidate.silver){
            button.classList.remove('btn-silver-off');
            button.classList.add('btn-silver');
            this.candidate.silver = true;
            this.candidateService.update(this.candidate).subscribe(res => {
                console.log(res);
            }, err => {
                console.log(err);
            });;
        }else{
            button.classList.remove('btn-silver');
            button.classList.add('btn-silver-off');
            this.candidate.silver = false;
            this.candidateService.update(this.candidate).subscribe(res => {
                console.log(res);
            }, err => {
                console.log(err);
            });;
        }
    }

    like() {
        this.dislikeIcon = 1;


        let l = window.localStorage.getItem('like');

        if (l == "undefined") {
            this.candidate.like++;

            this.candidateService.update(this.candidate).subscribe(res => {
                window.localStorage.setItem('like', 'like');
            }, err => {
                console.log(err);
            });
        } else {
            if (l == "dislike") {
                this.likeIcon = 0;
                this.candidate.dislike--;
                this.candidate.like++;
                this.candidateService.update(this.candidate).subscribe(res => {
                    window.localStorage.setItem('like', 'like');
                }, err => {
                    console.log(err);
                });
            }
        }

    }

    dislike() {
        this.likeIcon = 1;
        let l = window.localStorage.getItem('like');

        if (l == "undefined") {

            this.candidate.dislike++;

            this.candidateService.update(this.candidate).subscribe(res => {
                window.localStorage.setItem('like', 'dislike');
            }, err => {
                console.log(err);
            });
        } else {
            if (l == "like") {
                this.dislikeIcon = 0;
                this.candidate.dislike++;
                this.candidate.like--;
                this.candidateService.update(this.candidate).subscribe(res => {
                    window.localStorage.setItem('like', 'dislike');
                }, err => {
                    console.log(err);
                });
            }
        }
    }

    expandessay() {
        this.expandEssay = !this.expandEssay;
    }

    expandvideo() {
        this.expandVideo = !this.expandVideo;
    }

    expandCard() {
        this.expand = !this.expand;
    }

    openModal() {
        this.modal = !this.modal;
        this.loadSource()
    }

    openVideo()  {
        this.modalVideo = !this.modalVideo
    }
}