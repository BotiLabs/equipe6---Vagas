import { Component, OnInit, Input } from '@angular/core';
import { CandidateModel } from '../../../../models/candidate.model';
import { EnumsHelper } from '../../../../common/enums-helper';
import { StatusOfCandidateModel } from '../../../../models/statusOfCandidate.model';
import { StatusOfCandidateService } from '../../../../../../_services/statusCandidate.service';
import html2canvas from 'html2canvas';
import * as jspdf from 'jspdf';
@Component({
  selector: 'app-export-candidate',
  templateUrl: './export-candidate.component.html',
  styleUrls: ['./export-candidate.component.css']
})
export class ExportCandidateComponent implements OnInit {
  @Input() candidateModel: CandidateModel;
  @Input() interactions: any;
  enumsHelper: EnumsHelper = new EnumsHelper();
  statusOfCandidateArray: StatusOfCandidateModel[] = new Array<StatusOfCandidateModel>();
  constructor(private statusOfCandidate: StatusOfCandidateService) {
    this.getAllStatus();
  }

  ngOnInit() {
  }

  loadStatus(status: number) {

    if (this.statusOfCandidateArray) {
      let obj = this.statusOfCandidateArray.find(x => x.number == status);
      if (obj)
        return obj;
    }
  }

  getAllStatus() {
    this.statusOfCandidate.getAll().subscribe(status => {
      this.statusOfCandidateArray = [];
      for (let statusC of status) {
        let statusLoaded = new StatusOfCandidateModel();
        statusLoaded.loadModelFromServer(statusC);
        this.statusOfCandidateArray.push(statusLoaded);
      }
    })
  }


  public captureScreen() {
    var data = document.getElementById('content');
    var footer = document.getElementById('footer');
    var header = document.getElementById('header');

    html2canvas(data).then(async canvas => {

      let pdf = new jspdf('p', 'mm', 'a4'); // A4 size page of PDF  

      //first page
      var cropPosition = 0;
      var cropImgHeight = 0
      if (canvas.height >= 1000) {
        cropImgHeight = 1000
      } else {
        cropImgHeight = canvas.height;
      }
      var cropLeft = canvas.height;

      //first page
      var crop = this.crop(canvas, 0, cropPosition, canvas.width, cropImgHeight);

      // Few necessary setting options  
      var imgWidth = 208;
      var pageHeight = 295;
      var imgHeight = crop.height * imgWidth / crop.width;
      var position = 10;
      cropLeft -= cropImgHeight;
      let contentDataURL = crop.toDataURL('image/png')

      // footer canvas
      var croopFooter = await html2canvas(footer).then(canvas => {
        return canvas;
      })

      var croopHeader = await html2canvas(header).then(canvas => {
        return canvas;
      })
      var footerImage = croopFooter.toDataURL('image/png')

      var headerImage = croopHeader.toDataURL('image/png');

      var croopHeight = croopFooter.height * imgWidth / croopFooter.width;

      var croopHeaderHeight = croopHeader.height * imgWidth / croopHeader.width;

      //header
      pdf.addImage(headerImage, 'PNG', 1, position - 5, imgWidth, croopHeaderHeight);
      //BODY
      pdf.addImage(contentDataURL, 'PNG', 3, position + 10, imgWidth, imgHeight);
      //footer
      pdf.addImage(footerImage, 'PNG', 1, position + 270, imgWidth, croopHeight);
      //paginate
      while (cropLeft > 0) {
        cropPosition += cropImgHeight;
        if (cropLeft < 1000 && cropLeft > 0) {
          cropImgHeight = cropLeft
        }
        crop = this.crop(canvas, 0, cropPosition, canvas.width, cropImgHeight);
        contentDataURL = crop.toDataURL('image/png')
        imgHeight = crop.height * imgWidth / crop.width;
        pdf.addPage();
        pdf.addImage(headerImage, 'PNG', 1, position - 5, imgWidth, croopHeaderHeight);
        pdf.addImage(contentDataURL, 'PNG', 3, position + 10, imgWidth, imgHeight);
        pdf.addImage(footerImage, 'PNG', 1, position + 270, imgWidth, croopHeight);
        cropLeft -= cropImgHeight;
      }

      // header page information
      var pdf_pages = pdf.internal.pages
      for (var i = 1; i < pdf_pages.length; i++) {
        // We are telling our pdfObject that we are now working on this page
        pdf.setPage(i)
        pdf.setFontSize(10)

        // The 10,200 value is only for A4 landscape. You need to define your own for other page sizes
        pdf.text(180, 10, "Página " + pdf.internal.getCurrentPageInfo().pageNumber + " de " + (pdf_pages.length - 1));
      }

      pdf.save(`${this.candidateModel.name}.pdf`); // Generated PDF   
      this.enumsHelper.sendEventAnalytcs("Exportação de CV Candidato", this.candidateModel.name, "Exportou o CV de um candidato");
    });
  }




  crop(canvas, offsetX, offsetY, width, height) {
    // create an in-memory canvas
    var buffer = document.createElement('canvas');
    var b_ctx = buffer.getContext('2d');
    // set its width/height to the required ones
    buffer.width = width;
    buffer.height = height;
    // draw the main canvas on our buffer one
    // drawImage(source, source_X, source_Y, source_Width, source_Height, 
    //  dest_X, dest_Y, dest_Width, dest_Height)
    b_ctx.drawImage(canvas, offsetX, offsetY, width, height,
      0, 0, buffer.width, buffer.height);
    // now call the callback with the dataURL of our buffer canvas
    return buffer;
  }
}
