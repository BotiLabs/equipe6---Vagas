import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HistoricCAndidateComponent } from './historic-candidate.component';

describe('HistoricCAndidateComponent', () => {
  let component: HistoricCAndidateComponent;
  let fixture: ComponentFixture<HistoricCAndidateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HistoricCAndidateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HistoricCAndidateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
