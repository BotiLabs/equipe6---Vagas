import { ApproachService } from './../../../../../_services/approach.server';
import { Component, OnInit, ViewEncapsulation, ViewChild, ElementRef, HostListener } from '@angular/core';
import { Location } from '@angular/common';
import { StatusCandidate } from '../../../common/status-candidate';
import { EnumsHelper } from '../../../common/enums-helper';
import { IOption } from 'ng-select';
import { CandidateModel } from '../../../models/candidate.model'
import { TagService } from '../../../../../_services/tag.service';
import { PositionService } from '../../../../../_services/position.service';
import { ActivatedRoute, Router } from '@angular/router';
import { CandidateService } from '../../../../../_services/candidate.service';
import { LogsComponent } from '../../logs/logs.component';
declare var $: any;
import '../../../../assets/plugins/toast-master/js/jquery.toast.js';
import { ProfileCandidate } from '../../../common/profile-candidate';
import { HiringCandidate } from '../../../common/hiring-candidate';
import { TagsRequest } from '../../../common/tags.request';
import { TagModel } from '../../../models/tag.model';
import { InteractionService } from '../../../../../_services/interaction.service';
import { InteractionModel } from '../../../models/interaction.model';
import { InteractionListenService } from '../../../../../_services/interaction-listen.service';
import { NotificationService } from '../../../../../_services/notification.service';
import { OpportunityService } from '../../../../../_services/opportunity.service';
import { OpportunityModel } from '../../../models/opportunity.model';
import { Observable } from 'rxjs/Rx';
import * as moment from 'moment';
import { StatusOfCandidateService } from '../../../../../_services/statusCandidate.service';
import { StatusOfCandidateModel } from '../../../models/statusOfCandidate.model';
import { CepModule } from '../../../shared/cep/cep.module';
import { AuthService } from '../../../../../_services/auth.service';
import { StatusModel } from '../../../models/status.model';
import { StatusOfOpportunityModel } from '../../../models/statusOfOpportunity.model';
import { StatusOfOpportunityService } from '../../../../../_services/statusOpportuniry.service';
import { OriginService } from '../../../../../_services/origin.service';
import { PositionsService } from '../../../../../_services/positions.service';
import { PositionsModel } from '../../../models/positions.model';
import { ActionService } from '../../../../../_services/action.service';
import { SoftSkillsRequest } from '../../../common/softskill.request';
import { SoftSkillModel } from '../../../models/softskill.model';
import { SoftSkillService } from '../../../../../_services/softskill.service';
moment.locale('pt-BR');

@Component({
    selector: 'cand-edit',
    templateUrl: './edit.component.html',
    styleUrls: ['./edit.component.css'],
    encapsulation: ViewEncapsulation.None
})

export class EditComponent implements OnInit {
    c: CandidateModel = new CandidateModel();
    ddlStatus: StatusCandidate[];
    states: String[] = ["AC", "AL", "AM", "AP", "BA", "CE", "DF", "ES", "GO", "MA", "MT", "MS", "MG", "PA", "PB", "PR", "PE", "PI", "RJ", "RN", "RO", "RS", "RR", "SC", "SE", "SP", "TO"];
    ddlProfile: ProfileCandidate[];
    ddlHiring: HiringCandidate[];
    enumsHelper: EnumsHelper = new EnumsHelper();
    dropdownItem: IOption;
    dropdownList: Array<IOption> = [];
    dropdownItem2: IOption;
    dropDownItemDesiredHiring: {};
    dropdownList2: Array<IOption> = [];
    dropdownListDesiredHiring: any = [];
    selectedItems: any;
    selectedItems2: any;
    selectedItemsDesiredHiring: any = [];
    success: boolean = false;
    statusTag: string = "";
    statusSoftskill: string = "";
    tagRequest: TagsRequest = new TagsRequest();
    softskillRequest: SoftSkillsRequest = new SoftSkillsRequest();
    tagModel: TagModel = new TagModel();
    softskillModel: SoftSkillModel = new SoftSkillModel();
    files;
    delete: number;
    ddlOrigin: any[] = [];
    interactionsLoaded: boolean = false;
    formIsVisible: boolean = false;
    interact: InteractionModel[];
    int: InteractionModel = new InteractionModel();
    interactions: InteractionModel[] = [];
    opportunitiesLoaded: boolean = false;
    candidateOpportunities: OpportunityModel[] = [];
    statusC: boolean;
    showHistoric: boolean = false;
    dropDownItemSkill: IOption;
    dropdownListSkills: Array<IOption> = [];
    selectedItemsSkills = [];
    dropdownListSoftSkills: Array<IOption> = [];
    selectedItemsSoftSkills = [];
    tags: TagModel[] = [];
    softskills: SoftSkillModel[] = [];
    dropdownSettings = {};
    statusOfCandidateArray: StatusOfCandidateModel[] = new Array<StatusOfCandidateModel>();
    canShowTimeLine: boolean = false;
    modal: boolean = false;
    candidateId: string;
    status: StatusModel = new StatusModel();
    statusOfOpportunityArray: StatusOfOpportunityModel[] = [];
    uploading: boolean = false;
    dateCandidate: string;
    btnBlock: string;
    origins: any[];
    approaches: any[];
    positions: any[];
    positionsArray = [];
    actionsArray: any = [];
    candidateModel: CandidateModel = new CandidateModel();
    modalToInteraction: boolean = false;
    isClear: boolean = true;
    fillPercentage: number;

    @ViewChild('file') fileInput: any;
    public model: any = undefined;

    constructor(
        private opportunityService: OpportunityService,
        private notificationService: NotificationService,
        private logs: LogsComponent,
        private candidateService: CandidateService,
        private router: Router,
        private _location: Location,
        public tagService: TagService,
        public softSkillService: SoftSkillService,
        private positionService: PositionService,
        private activatedRoute: ActivatedRoute,
        private interactionListenService: InteractionListenService,
        private interactionService: InteractionService,
        private statusOfCandidate: StatusOfCandidateService,
        private cepModule: CepModule,
        private authService: AuthService,
        private statusOfOpportunityService: StatusOfOpportunityService,
        private originService: OriginService,
        private approachService: ApproachService,
        private position: PositionsService,
        private actionService: ActionService
    ) {
        this.dropdownSettings = {
            singleSelection: false,
            text: "Selecione...",
            // selectAllText: 'Marcar todos',
            // unSelectAllText: 'Desmarcar todos',
            enableSearchFilter: true,
            classes: "myclass custom-class",
            badgeShowLimit: 3,
            searchBy: ["itemName"]
        };
        this.getAllStatus();
        this.getAllStatusOpportunity();
        this.getAllOrigins();
        this.getAllApproaches();
        this.getAllActions();
    }

    ngOnInit() {
        this.contFieldsAnswered()
        this.getAllPositions();
        this.getAllTags();
        this.getAllSoftskills();
        this.statusC = true;
        this.interactionListenService.notifier.subscribe(candidate => {
            this.loadSource();
            this.setInit();
        });


        this.ddlProfile = this.enumsHelper.getEnumProfileCandidateArray();
        this.ddlHiring = this.enumsHelper.getEnumHiringCandidateArray();
        this.ddlStatus = this.enumsHelper.getEnumStatusCandidateArray();
        this.populateDropDowns();

        if (this.activatedRoute.snapshot.params['id'] != undefined) {
            this.loadSource();
            this.setInit();
            this.candidateId = this.activatedRoute.snapshot.params['id'].split('id')[1];
        }
        if (this.candidateId) {
            (<any>window).ga('set', 'page', 'Edição de candidatos');
            (<any>window).ga('send', 'pageview');
            this.candidateService.getById(this.candidateId).subscribe(candidate => {
                this.c.loadCandidate(candidate);
                this.validateColorButton();
                this.loadCandidateOpportunities();
                this.selectedItemsSkills = this.c.skills;
                this.selectedItemsSoftSkills = this.c.softSkills;
                var arr = []
                this.c.desiredHiring.map(desiredHiring => {
                    arr.push({ "id": desiredHiring.toString(), "itemName": this.enumsHelper.getHiringType(parseInt(desiredHiring)) });
                });
                this.setInit();
                this.selectedItemsDesiredHiring = arr;

                if (this.c.dateOfBirth) {
                    let day = this.c.dateOfBirth.getDate();
                    let year = this.c.dateOfBirth.getFullYear();
                    let month = this.c.dateOfBirth.getMonth() + 1;
                    this.model = { date: { year: year, month: month, day: day } }
                    let monthDate = "";
                    let dayDate = "";
                    if (month < 10) {
                        monthDate = "0" + month;
                    } else {
                        monthDate = month.toString();
                    }
                    if (day < 10) {
                        dayDate = "0" + day;
                    } else {
                        dayDate = day.toString();
                    }
                    this.dateCandidate = "" + dayDate + monthDate + year;
                }

            });
            this.publishCandidate(this.c);
        } else {
            (<any>window).ga('set', 'page', 'Criação de candidatos');
            (<any>window).ga('send', 'pageview');
        }
    }

    @HostListener('window:scroll', [])
    onWindowScroll() {
        var checkScroll = document.getElementById("checkScroll").getBoundingClientRect();
        if (
            checkScroll.top >= 0 &&
            checkScroll.left >= 0 &&
            checkScroll.right <= (window.innerWidth || document.documentElement.clientWidth) &&
            checkScroll.bottom <= (window.innerHeight || document.documentElement.clientHeight)
        ) {
            if (document.getElementsByClassName("fillPercentage").length == 1) {
                let i = document.getElementsByClassName("fillPercentage")
                i[0].className = "afterScroll";
            }
        } else {
            if (document.getElementsByClassName("afterScroll").length == 1) {
                let i = document.getElementsByClassName("afterScroll")
                i[0].className = "fillPercentage";
            }
        }

        fixedMessagePosition();

        $(window).resize(() => {
            fixedMessagePosition();
        });

        function fixedMessagePosition() {
            let boxWhiteEl = $('.white-box');
            let boxWhiteElWidth = boxWhiteEl.width() + 15;
            let boxWhiteElLeftValue = boxWhiteEl.offset().left + 15;
            $('.fillPercentage').css({
                'width': boxWhiteElWidth + 'px',
                'left': boxWhiteElLeftValue + "px"
            });
        }
    }







    onBlurCep() {
        this.cepModule.buscar(String(this.c.cep))
            .then(cep => {
                //this.c.district = cep.logradouro;
                //this.c.district = cep.complemento;
                this.c.district = cep.bairro;
                this.c.city = cep.localidade;
                this.c.state = cep.uf;
                console.log(cep);
            });
    }

    getAllOrigins() {
        this.origins = [];
        this.originService.getAllOrigins().subscribe(r => {
            for (let o of r) {
                this.origins.push(o);
            }
        })

    }

    getAllApproaches() {
        this.approaches = [];
        this.approachService.getAllApproaches().subscribe(r => {
            for (let a of r) {
                this.approaches.push(a);
            }
        })

    }

    populateDropDowns() {
        this.dropdownList.sort(function (a, b) {
            if (a.label > b.label) {
                return 1;
            }
            if (a.label < b.label) {
                return -1;
            }
            return 0;
        });

        this.ddlStatus = this.enumsHelper.getEnumStatusCandidateArray();

        if (this.ddlStatus) {
            for (var i = 0; i < this.ddlStatus.length; i++) {

                this.dropdownItem = {
                    value: this.enumsHelper.getDescriptionStatusCandidate(i), label: this.enumsHelper.getDescriptionStatusCandidate(i)
                }
                this.dropdownList.push(this.dropdownItem);
            }
        }

        if (this.ddlHiring) {
            for (var i = 0; i < this.ddlHiring.length; i++) {
                this.dropDownItemDesiredHiring = {
                    id: i.toString(), itemName: this.enumsHelper.getHiringType(i)
                }
                this.dropdownListDesiredHiring.push(this.dropDownItemDesiredHiring);
            }
        }

        this.dropdownList.sort(function (a, b) {
            if (a.label > b.label) {
                return 1;
            }
            if (a.label < b.label) {
                return -1;
            }
            return 0;
        });
    }

    isItOdd(pos: number): boolean {
        if (pos % 2 == 0) return false;
        return true;
    }

    loadSource() {
        this.interactionsLoaded = false;

        if (this.candidateId) {
            this.interactionService.getByCandidateId(this.candidateId).subscribe(interactionsRes => {
                this.interactions = [];
                for (let i of interactionsRes) {
                    let interactionLoaded = new InteractionModel();
                    interactionLoaded.loadFromServer(i);
                    this.interactions.push(interactionLoaded);
                }
                //Converting Observation to html
                this.interactionsLoaded = true;
            });
        }
    }

    // deleteInteraction(cand: c, interaction: InteractionModel) {
    //     this.delete = 1;
    //     interaction.visible = false;
    //     this.interactionService.update(interaction).subscribe(r => {
    //         this.loadSource();
    //     });

    //     if (this.delete == 1) {

    //         $.toast({
    //         heading: "Interação deletada.",
    //         text: '',
    //         position: 'top-right',
    //         loaderBg: '#ff6849',
    //         icon: "error",
    //         hideAfter: 2500,
    //         stack: 6
    //     });

    // }
    // }

    deleteOpportunity(opportunity) {
        // delete interaction
        // this.interactionService.getAll().subscribe(res => {
        //   this.interact = new Array<InteractionModel>();
        //   this.interact = [];

        //   for (let cr of res) {
        //     let i = new InteractionModel();
        //     i.loadFromServer(cr);
        //     this.interact.push(i);
        //   }
        //   for (var i = 0; i < this.interact.length; i++) {
        //     if (opportunity._id == this.interact[i].opportunityId && this.c._id == this.interact[i].candidateId) {
        //       var interaction = this.interact[i];
        //       this.interactionService.update(interaction).subscribe(r => { });
        //     }
        //   }
        // });

        // update c
        for (var i = 0; i < this.c.opportunities.length; i++) {

            if (opportunity._id === this.c.opportunities[i]._id) {

                this.c.opportunities.splice(i, 1);

            };
        }

        this.candidateService.update(this.c).subscribe(r => {

            this.notificationService.notify('Candidato atualizado com sucesso!');

            // update opportunity
            for (var i = 0; i < opportunity.candidates.length; i++) {
                if (opportunity.candidates[i] == this.c._id) {

                    opportunity.candidates.splice(i, 1);

                    this.c.opportunities = opportunity;
                    this.opportunityService.update(opportunity).subscribe(res => {
                        var message = "Deletou a opportunidade " + opportunity.name + "do candidato " + this.c.name;
                        this.logs.create(message);
                        this.loadCandidateOpportunities();
                        this.interactionListenService.notifier.subscribe(candidate => {
                            this.loadSource();
                            this.setInit();
                        });
                        this.candidateService.getById(this.c._id).subscribe(r => {
                            this.c.loadCandidate(r);
                            this.publishCandidate(this.c);
                        });
                    });
                }
            }
        });
    }

    deleteCandidate() {
        this.c.visible = false;
        this.candidateService.update(this.c).subscribe(r => {
            this.notificationService.notify("Vaga deletada com sucesso");
        });
        this.interactionService.getByCandidateId(this.c._id).subscribe(r => {
            for (let i = 0; i < r.length; i++) {
                this.interactionService.update(r[i]._id);
            }
        });
        this.opportunityService.getAll().subscribe(r => {
            for (let i = 0; i < r.length; i++) {
                if (r[i].candidates == this.c._id) {
                    r.splice(i, 1);
                }
            }
            this.redirectLastPage()
        });
    }

    loadCandidateOpportunities() {
        this.opportunitiesLoaded = false;
        this.candidateOpportunities = [];
        for (let opp of this.c.opportunities) {
            let opportunityLoaded = new OpportunityModel;
            opportunityLoaded.loadModelFromServer(opp);
            //Somente exibir as vagas que possuem status aberta ou congelada.
            if (opportunityLoaded.status == 0 || opportunityLoaded.status == 2) {
                this.candidateOpportunities.push(opportunityLoaded);
            }
        }
        this.opportunitiesLoaded = true;
    }

    setInit() {
        this.loadSource();
        this.loadCandidateOpportunities();
    }



    close() {
        this.interactions = [];
        this.c = new CandidateModel();
    }


    publishCandidate(candidate) {
        this.interactionListenService.publish(candidate);
    }

    ifExists(name) {
        this.tagRequest.name = name.inputTextValue;
        this.tagService.searchIfExists(this.tagRequest).subscribe(r => {
            if (r == "Não encontramos esta tag. Deseja criar uma nova?" && name.inputTextValue != "") {
                this.statusTag = r
            } else {
                this.statusTag = "";
            }
        });
    }

    ifExistsSoft(name) {
        this.softskillRequest.softskill = name.inputTextValue;
        this.softSkillService.searchIfExists(this.softskillRequest).subscribe(r => {
            if (r == "Não encontramos esta competência. Deseja criar uma nova?" && name.inputTextValue != "") {
                this.statusSoftskill = r
            } else {
                this.statusSoftskill = "";
            }
        });
    }


    createTag() {
        this.tagModel.name = this.tagRequest.name;
        this.tagService.add(this.tagModel).subscribe(r => {
            this.statusTag = "";
            this.getAllTags();
            return;
        }, (err) => {
            console.log(err);
        });
    }


    createSoftskill() {
        this.softskillModel.softskill = this.softskillRequest.softskill;
        this.softSkillService.add(this.softskillModel).subscribe(r => {
            this.statusSoftskill = "";
            this.getAllSoftskills();
            return;
        }, (err) => {
            console.log(err);
        });
    }

    no(name) {
        this.statusTag = "";
        name.inputTextValue = "";
    }

    noSoft(name) {
        this.statusSoftskill = "";
        name.inputTextValue = "";
    }

    formatDate() {
        if (this.c.registrationDate != undefined) {
            let data: string = moment(this.c.registrationDate).format('L');
            return "Candidato cadastrado em " + data;
        }
        else {
            return "Não temos data de cadastro do candidato"
        }
    }

    redirectLastPage() {
        if (this.activatedRoute.snapshot.params['ref'] == "refprofile") {
            this.router.navigateByUrl('/candidate/profile/' + this.activatedRoute.snapshot.params['id']);
        } else {
            this.router.navigateByUrl('/candidate');
        }
    }


    populateOrigin() {
        this.c.origin = this.enumsHelper.getOriginCandidate(this.selectedItems2);
    }

    populateStatus() {
        if (this.c.status != 0 && this.selectedItems == 0) {
            this.enumsHelper.toast('O status não pode deve ser diferente de Candidato Cadastrado!', "warning");
            return;
        } else {
            this.c.status = this.selectedItems;
        }
    }

    populateDesiredHiring() {

        if (this.candidateId)
            this.isClear = false;
        if (this.selectedItemsDesiredHiring.length > 0) {
            let arr = []
            for (let desiredHiring of this.selectedItemsDesiredHiring) {
                arr.push(desiredHiring.id);
            }
            this.c.desiredHiring = arr;
        }
        if (this.selectedItemsDesiredHiring.length == 0) {
            this.c.desiredHiring = ["-1"]
        }
    }

    editCandidate() {
        this.isClear = true;
        this.c.noAscentName = this.enumsHelper.validateAscentClientname(this.c.name);
        if (this.files) {
            this.c['file'] = this.files;
        }
        if (this.dateCandidate) {
            let year = parseInt(this.dateCandidate.substring(4, 8));
            let month = parseInt(this.dateCandidate.substring(2, 4)) - 1;
            let day = parseInt(this.dateCandidate.substring(0, 2));

            if (this.dateCandidate)
                this.c.dateOfBirth = new Date(year, month, day);
        }

        if (this.candidateId) {
            this.updateCandidate();
        } else {
            this.createCandidate();
        }


    }

    updateCandidate() {
        this.candidateService.update(this.c).subscribe(r => {
            this.success = true;
            let message = "Alterou o candidato de Nome " + this.c.name;
            this.logs.create(message);
            this.enumsHelper.toast("Candidato editado com sucesso.", "success");
        }, (err) => {
            this.enumsHelper.toast("Erro na edição", "warning");
        });
        if (this.activatedRoute.snapshot.params['ref'] == "reflist") {
            this.router.navigateByUrl('/candidate');
        } else {
            this.router.navigateByUrl('/candidate/profile/' + this.activatedRoute.snapshot.params['id']);
        }
    }

    createCandidate() {
        if (this.c.origin == "") {
            this.c.origin = "Outro"
        }
        if (this.c.position == "") {
            this.c.position = "";
        }
        this.c.noAscentName = this.enumsHelper.validateAscentClientname(this.c.name);
        this.c.phone = this.c.phone.replace("(", "");
        this.c.phone = this.c.phone.replace(")", "");
        this.c.phone = this.c.phone.replace("-", "");
        this.c.phone = this.c.phone.replace(" ", "");
        let userInfo = this.authService.getUserInfoModel();
        this.c.userEmail = userInfo.email;

        this.candidateService.add(this.c).subscribe(r => {
            this.success = true;
            this.router.navigate(['/candidate/profile/', "id" + r._id]);
            var message = "Criou o candidato " + this.c.name;
            this.logs.create(message);
            this.enumsHelper.sendEventAnalytcs("Campos cadastrados - Candidatos", this.contFieldsAnswered(), `Cadastrou o candidato com ${this.contFieldsAnswered()}% de preenchimento do campos`);
            this.enumsHelper.sendEventAnalytcs("Cadastrar candidato", this.c.name, "Cadastrou candidato via cadastro comum");
            this.enumsHelper.toast("Candidato criado com sucesso.", "success");
        }, (err) => {
            this.enumsHelper.toast(err.Errors.message, "warning");
        });
    }

    turnHisroricTrue() {
        switch (this.showHistoric) {
            case true:
                this.showHistoric = false;
                break;
            case false:
                this.showHistoric = true;
                break
            default:

                break;
        }
    }

    getAllTags() {
        this.tagService.getAll().subscribe(tg => {
            for (let t of tg) {
                var tag = new TagModel();
                tag.loadTag(t);
                this.tags.push(tag);
            }
        })
    }

    getAllSoftskills() {
        this.softSkillService.getAll().subscribe(tg => {
            for (let t of tg) {
                var softskill = new SoftSkillModel();
                softskill.loadSoftSkill(t);
                this.softskills.push(softskill);
            }
        })
    }

    getAllStatus() {
        this.statusOfCandidate.getAll().subscribe(status => {
            this.statusOfCandidateArray = [];
            for (let statusC of status) {
                let statusLoaded = new StatusOfCandidateModel();
                statusLoaded.loadModelFromServer(statusC);
                this.statusOfCandidateArray.push(statusLoaded);
            }
        })
    }

    populateSkill() {
        if (this.selectedItemsSkills.length > 0) {
            this.c.skills = this.selectedItemsSkills;
        }
        if (this.selectedItemsSkills.length == 0) {
            this.c.skills = [];
        }
        if (this.selectedItemsSoftSkills.length > 0) {
            this.c.softSkills = this.selectedItemsSoftSkills;
        }
        if (this.selectedItemsSoftSkills.length == 0) {
            this.c.softSkills = [];
        }
    }

    itemsRequest = (text: string): Observable<Array<string>> => {
        let tags = new Array<string>();
        var obs = new Observable<Array<string>>(observer => {
            let request = new TagsRequest();
            request.name = text;

            this.tags.forEach(tag => {
                if (tag.name.match(new RegExp(text, "gi"))) {
                    tags.push(tag.name);
                }
            });

            observer.next(tags);
        });

        return obs;
    }

    itemsRequestSoft = (text: string): Observable<Array<string>> => {
        let softTags = new Array<string>();
        var obs = new Observable<Array<string>>(observer => {
            let request = new SoftSkillsRequest();
            request.softskill = text;

            this.softskills.forEach(softTag => {
                if (softTag.softskill.match(new RegExp(text, "gi"))) {
                    softTags.push(softTag.softskill);
                }
            });

            observer.next(softTags);
        });

        return obs;
    }

    clearRequest() {
        this.statusTag = "";
    }

    clearRequestSoftskill() {
        this.statusSoftskill = "";
    }

    loadStatus(status: number) {

        if (this.statusOfCandidateArray) {
            let obj = this.statusOfCandidateArray.find(x => x.number == status);
            if (obj)
                return obj;
        }
    }

    showTimeLine() {
        this.canShowTimeLine = !this.canShowTimeLine;
        // Comentei o log abaixo abaixo @matheus
        // console.log(this.canShowTimeLine);
    }

    onDateChanged(event) {
        this.c.dateOfBirth = undefined;
        if (event.jsdate)
            this.c.dateOfBirth = new Date(event.jsdate);
    }

    openModal() {
        this.modal = !this.modal;
        this.loadSource()
    }

    changeCandidateStatus(c: CandidateModel) {
        this.c = c;
    }

    getAllStatusOpportunity() {
        this.statusOfOpportunityService.getAll().subscribe(status => {
            this.statusOfOpportunityArray = [];
            for (let statuOpp of status) {
                let statusLoaded = new StatusOfOpportunityModel();
                statusLoaded.loadModelFromServer(statuOpp);
                this.statusOfOpportunityArray.push(statusLoaded);
            }
        })
    }

    selectStatusAndColor(status: number) {
        switch (status) {
            case 0:
                this.status.color = "#1a446e";
                this.status.icon = "icon-hourglass";
                break;

            case 1:
                this.status.color = "#e3ac26";
                this.status.icon = "icon-bubble";
                break;

            case 2:
                this.status.color = "#1a446e";
                this.status.icon = "icon-hourglass";
                break;

            case 3:
                this.status.color = " #c4534f";
                this.status.icon = "icon-hourglass";
                break;

            case 4:
                this.status.color = "#7fb16c";
                this.status.icon = "icon-flag ";
                break;

            case 5:
                this.status.color = "#1a446e";
                this.status.icon = "icon-hourglass";
                break;

            case 6:
                this.status.color = "#1a446e";
                this.status.icon = "icon-hourglass";
                break;

            case 7:
                this.status.color = "#e3ac26";
                this.status.icon = "icon-bubble";
                break;

            case 8:
                this.status.color = "#7fb16c";
                this.status.icon = "icon-flag ";
                break;

            case 9:
                this.status.color = "#1a446e";
                this.status.icon = "icon-hourglass";
                break;

            case 11:
                this.status.color = "#f00";
                this.status.icon = "icon-lock";
                break;

            default:
                this.status.color = "#1a446e";
                this.status.icon = "icon-hourglass";
                break;
        }
        return this.status;
    }

    loadStatusOpportunity(status: number) {
        let obj = this.statusOfOpportunityArray.find(x => x.number == status);
        if (obj)
            return obj;
    }


    onChange(files: FileList) {
        if (files.length > 0) {
            this.files = files;
            this.uploadCurriculum();
        }
        else {
            this.files = undefined;
        }
    }

    uploadCurriculum() {
        this.uploading = true;
        let candidate = new CandidateModel()
        if (this.files) {
            candidate['file'] = this.files;
        }
        this.candidateService.uploadCurriculum(candidate).subscribe(r => {
            if (r.secondarySkills)
                if (r.secondarySkills.length > 0) {

                    r.secondarySkills.forEach(skill => {
                        if (this.c.skills.find(x => x == skill) == undefined) {
                            this.c.skills.push(skill)
                        }
                    });

                }
            if (!this.c.curriculum)
                this.enumsHelper.sendEventAnalytcs('Upload de currículo', this.c.name, 'Um currículo foi adicionado');
            else
                this.enumsHelper.sendEventAnalytcs('Atualização de currículo', this.c.name, 'Um currículo foi atualizado');
            this.c.curriculum = r.curriculum;
            this.uploading = false;
            this.enumsHelper.toast("Currículo importado com sucesso!", "success");

        }, err => {
            this.enumsHelper.toast(err.Errors.message, "warning");
            this.uploading = false;
        })
    }

    validateColorButton() {
        if (this.c.isBlocked) {
            this.btnBlock = "btn-grey"
        } else {
            this.btnBlock = "btn-unlock"
        }
    }

    blockCandidate2() {
        this.c.isBlocked = !this.c.isBlocked;
        this.updateCandidate()
        this.validateColorButton();
    }

    blockCandidate() {
        this.modalToInteraction = !this.modalToInteraction;
        this.c.isBlocked = !this.c.isBlocked;
        let i = localStorage.getItem('userInfo');
        let y = JSON.parse(i)
        this.int.userEmail = y.email;
        this.int.userFirstName = `${y.firstName} ${y.lastName}`;
        let x: object
        this.int.opportunity = x;
        this.int.candidateId = this.c._id;

        if (this.c.isBlocked == true) {
            this.int.status = 11;
            this.int.action = 8;
            this.c.status = 11;
        } else {
            this.int.action = 9;
            this.int.status = 5;
            this.c.status = 5;
        }
        this.candidateService.update(this.c).subscribe(r => {
            //Analytcs event, Não delete esta linha
            if (this.c.isBlocked == true)
                this.enumsHelper.sendEventAnalytcs("Bloquear candidato", this.c.name, "Um candidato foi bloqueado")
        });

        this.interactionService.add(this.int).subscribe(r => {
        });
        this.updateCandidate();
        this.validateColorButton();
    }

    deleteCurriculum() {
        this.c.curriculum = "";
        this.files = undefined;
        this.fileInput.nativeElement.value = "";
        this.enumsHelper.sendEventAnalytcs("Deletou curriculo", this.c.name, "Deletou curriculo de um candidato");
    }

    getAllPositions() {
        this.position.getAll().subscribe(r => {
            for (let position of r) {
                let postionsLoaded = new PositionsModel();
                postionsLoaded.loadFromServer(position);
                this.positionsArray.push(postionsLoaded);
            }
        })
    }

    getAllActions = async () => {
        await this.actionService.getAllActions().subscribe(actions => {
            this.actionsArray = [];
            for (let action of actions) {
                this.actionsArray.push(action);
            }
        })
    }

    loadAction(number) {
        let action = this.actionsArray.find(x => x.number == number);
        if (action)
            return action.name;
        else
            return "";
    }

    // getallDepartaments() {

    //     this.departament.getAll().subscribe(data => {
    //       for (let dept of data) {
    //         let dpt = new DepartamentModel;
    //         dpt.loadFromServer(dept);
    //         this.business.push(dpt);
    //       }
    //       console.log(this.business);
    //     }, err => {
    //       console.log(err);
    //     });

    //   }
    // generatePdf() {
    modalToBlock(c: CandidateModel) {
        c = new CandidateModel()
        c = this.c;
        this.modalToInteraction = !this.modalToInteraction;
    }

    contFieldsAnswered() {
        this.c.fillPercentage = 0;
        let count = 0;

        if (!this.dateCandidate) {
            this.dateCandidate = "";
        }



        if (this.c.name) {
            this.c.fillPercentage += 5;
            count++;
        }

        if (this.c.email) {
            this.c.fillPercentage += 5;
            count++;
        }

        if (this.c.actualValue) {
            this.c.fillPercentage += 5;
            count++;
        }

        if (this.c.approachRs) {
            count++;
        }

        if (this.c.cep) {
            this.c.fillPercentage += 5;
            count++;
        }

        if (this.c.city) {
            this.c.fillPercentage += 5;
            count++;
        }

        if (this.c.curriculum) {
            this.c.fillPercentage += 5;
            count++;
        }

        if (this.c.desiredHiring.length > 1) {
            this.c.fillPercentage += 5;
            count++;
        }

        if (this.c.desiredValue) {
            this.c.fillPercentage += 5;
            count++;
        }

        if (this.c.discription) {
            count++;
        }

        if (this.c.district) {
            this.c.fillPercentage += 5;
            count++;
        }

        if (this.c.githubUrl) {
            this.c.fillPercentage += 5;
        }

        if (this.c.linkedinUrl) {
            this.c.fillPercentage += 5;
            count++;
        }

        if (this.c.hiringType > -1) {
            this.c.fillPercentage += 5;
            count++;
        }

        if (this.c.origin) {
            this.c.fillPercentage += 5;
            count++;
        }

        if (this.c.phone) {
            this.c.fillPercentage += 5;
            count++;
        }

        if (this.c.position) {
            this.c.fillPercentage += 5;
            count++;
        }

        if (this.c.profile > -1) {
            this.c.fillPercentage += 5;
            count++;
        }

        if (this.c.skills)
            if (this.c.skills.length > 0) {
                this.c.fillPercentage += 3;
            }


        if (this.c.softSkills)
            if (this.c.softSkills.length > 0) {
                this.c.fillPercentage += 2;
                count++;
            }

        if (this.c.state) {
            this.c.fillPercentage += 5;
            count++;
        }

        if (this.c.status > -1) {
            count++;
        }

        if (this.c.yearsOfExperience > 0) {
            this.c.fillPercentage += 5;
            count++;
        }

        if (this.dateCandidate) {
            this.c.fillPercentage += 5;
        }


        let percent = count / 21;
        let percentage = Number.parseFloat(percent.toFixed(2)) * 100;
        return percentage;
    }

    @HostListener('window:beforeunload', ['$event'])
    beforeUnloadHander(event) {
        return false;
    }

    formChanged(form) {
        if (this.candidateId)
            if (form.form.dirty) {
                this.isClear = false;
            } else {
                this.isClear = true;
            }
    }

    turnDirty() {
        this.isClear = false;
    }




}
