import { EnumsHelper } from './../../../../common/enums-helper';
import { Component, OnInit, Input } from '@angular/core';
import { CandidateModel } from '../../../../models/candidate.model';
import * as moment from 'moment';
import { StatusOfCandidateModel } from '../../../../models/statusOfCandidate.model';
import { StatusOfCandidateService } from '../../../../../../_services/statusCandidate.service';
moment.locale('pt-BR');
declare var $: any;
@Component({
  selector: 'app-historic-candidate',
  templateUrl: './historic-candidate.component.html',
  styleUrls: ['./historic-candidate.component.css']
})


export class HistoricCAndidateComponent implements OnInit {
  @Input() candidateModel: CandidateModel
  enumsHelper: EnumsHelper = new EnumsHelper();
  statusOfCandidateArrayHistoric: StatusOfCandidateModel[] = new Array<StatusOfCandidateModel>();
  constructor(private statusOfCandidate: StatusOfCandidateService) { }


  ngOnInit() {
    this.getAllStatusHistoric();
  }

  formatDate(date) {
    if (date) {
      let data: string = moment(date).format('L');
      return data;
    }
    else {
      return "Sem data"
    }
  }

  getAllStatusHistoric() {
    this.statusOfCandidate.getAll().subscribe(status => {
        this.statusOfCandidateArrayHistoric = [];
        for (let statusC of status) {
            let statusLoaded = new StatusOfCandidateModel();
            statusLoaded.loadModelFromServer(statusC);
            this.statusOfCandidateArrayHistoric.push(statusLoaded);
        }
    })
}

  loadStatus(status: number) {

    if (this.statusOfCandidateArrayHistoric) {
      let obj = this.statusOfCandidateArrayHistoric.find(x => x.number == status);
      if (obj)
        return obj;
    }
  }


}
