import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EditComponent } from './edit.component';
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from '../../../shared/shared.module';
import { CurrencyMaskModule } from "ng2-currency-mask";
import { HistoricCAndidateComponent } from './historic-candidate/historic-candidate.component';
import { CKEditorModule } from 'ng2-ckeditor';
import { AngularMultiSelectModule } from 'angular2-multiselect-dropdown/angular2-multiselect-dropdown';
import { ExportCandidateComponent } from './export-candidate/export-candidate.component';
import { CanDeactivateService } from '../../../../../_services/canDeactivate.service';

export const EditRoutes: Routes = [
  {
    path: '',
    component: EditComponent,
    data: {
      heading: 'Editar um Candidato'
    },
    canDeactivate: [CanDeactivateService]
  }
];

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(EditRoutes),
    SharedModule,
    CurrencyMaskModule,
    CKEditorModule,
    AngularMultiSelectModule
  ],
  declarations: [EditComponent, HistoricCAndidateComponent, ExportCandidateComponent]
})

export class EditModule { }
