import { OpportunitiesHapinComponent } from './../../../../../../ui-client-external/src/app/pages/opportunities-hapin/opportunities-hapin.component';
import { Component, OnInit, Input, Output, EventEmitter, ApplicationRef, ViewEncapsulation } from '@angular/core';
import { InteractionModel } from '../../../models/interaction.model';
import { OpportunityModel } from '../../../models/opportunity.model';
import { InteractionService } from '../../../../../_services/interaction.service';
import { CandidateService } from '../../../../../_services/candidate.service';
import { OpportunityService } from '../../../../../_services/opportunity.service';
import { EnumsHelper } from '../../../common/enums-helper';
import { StatusCandidate } from '../../../common/status-candidate';
import { ActionInteraction } from '../../../common/action-interaction';
import { ProfileInteraction } from '../../../common/profile-interaction';
import { AuthService } from '../../../../../_services/auth.service';
import { CandidateModel } from '../../../models/candidate.model';
import { NotificationService } from '../../../../../_services/notification.service';
import { InteractionType } from '../../../common/interaction-type';
import { LogsComponent } from '../../logs/logs.component';
import { EmailService } from '../../../../../_services/email.service';
import { EmailModel } from '../../../models/email.model';
import { EvaluationService } from '../../../../../_services/evaluation.service'
import { EvaluationModel } from '../../../models/evaluation.model';
import { ListComponent } from '../../candidate/list/list.component'
import { NotificationModel } from '../../../models/notification.model';
import { AppComponent } from '../../../app.component';
import { IOption } from 'ng-select';
import { NotificationServ } from '../../../../../_services/notificationSoquet.service';
import { AdminLayoutComponent } from '../../../layout/admin/admin-layout.component';
import { EditComponent } from '../edit/edit.component';
import { environment } from '../../../../environments/environment';
import { TemplateEmail } from './templateEmailInteraction';
import { CandidateHistoricModel } from '../../../models/candidateHistoric.model';
import { OpportunityHistoricModel } from '../../../models/opportunityHistoric.model';
declare var $: any;
import '../../../../assets/plugins/toast-master/js/jquery.toast.js';
import { StatusOfCandidateModel } from '../../../models/statusOfCandidate.model';
import { StatusOfCandidateService } from '../../../../../_services/statusCandidate.service';
import { ActionService } from '../../../../../_services/action.service';
import { ManagementService } from '../../../../../_services/service-management.service';
import { ServiceManagementModel } from '../../../models/service-management.model';
import { CompanyService } from '../../../../../_services/company.service';
import { CompanyModel } from '../../../models/company.model';
import { promise } from 'protractor';
@Component({
	selector: 'app-create-interaction',
	templateUrl: './createInteraction.component.html',
	styleUrls: ['./createInteraction.component.css'],
	encapsulation: ViewEncapsulation.None
})

export class CreateInteractionComponent implements OnInit {

	@Input() candidateModel: CandidateModel
	@Output() cancel = new EventEmitter();
	@Output() created = new EventEmitter();
	selectedItems: any;
	dropdownSettingsSingle = {};
	opportunities: OpportunityModel[] = [];
	interactionModel: InteractionModel = new InteractionModel();
	enumsHelper: EnumsHelper = new EnumsHelper();
	ddlStatus: StatusCandidate[];
	ddlActions: ActionInteraction[];
	ddlProfiles: ProfileInteraction[];
	interactions: InteractionModel[];
	opportunityModel: OpportunityModel = new OpportunityModel();
	emailModel: EmailModel = new EmailModel();
	emailModel2: EmailModel = new EmailModel();
	emailModelReproved: EmailModel = new EmailModel();
	evaluation: EvaluationModel = new EvaluationModel();
	itemStatus: any;
	notificationModel: NotificationModel = new NotificationModel();
	notificationModel2: NotificationModel = new NotificationModel();
	success: boolean = false;
	opportunity;
	statusOfCandidateArray: StatusOfCandidateModel[] = new Array<StatusOfCandidateModel>();
	dropdownItem2: {};
	dropdownList2: any = [];
	selectedItems2: any;
	opportunityHistoric: OpportunityHistoricModel = new OpportunityHistoricModel();
	candidateHistoric: CandidateHistoricModel = new CandidateHistoricModel();
	actionsArray: any;
	configs: ServiceManagementModel;
	company: CompanyModel = new CompanyModel();
	hiredConfirmation: boolean = false;

	constructor(
		private serviceManagement: ManagementService,
		private app: ApplicationRef,
		private interactionService: InteractionService,
		private opportunityService: OpportunityService,
		private authService: AuthService,
		private notificationService: NotificationService,
		private candidateService: CandidateService,
		private logs: LogsComponent,
		private sendEmailService: EmailService,
		private evaluationService: EvaluationService,
		private candidates: ListComponent,
		private appComponent: AppComponent,
		private listComponent: ListComponent,
		private notification: NotificationServ,
		private notificationAdmin: AppComponent,
		private editCandidate: EditComponent,
		private templateEmail: TemplateEmail,
		private statusOfCandidate: StatusOfCandidateService,
		private actionService: ActionService,
		private companyService: CompanyService) {
		this.dropdownSettingsSingle = {
			singleSelection: true,
			text: "Selecione...",
			selectAllText: 'Marcar todos',
			unSelectAllText: 'Desmarcar todos',
			enableSearchFilter: true,
			classes: "myclass custom-class",
			badgeShowLimit: 3,
			searchBy: ["itemName"]
		};
		this.getAllStatus();
		this.getAllActions();
		this.companyService.getById(JSON.parse(localStorage.getItem('userInfo')).company_id).subscribe(company => {
			this.company = company;
		});
		(<any>window).ga('set', 'page', 'Página de interações');
		(<any>window).ga('send', 'pageview');
	}

	ngOnInit() {
		this.ddlStatus = this.enumsHelper.getEnumStatusCandidateArray();
		this.ddlActions = this.enumsHelper.getEnumActionInteractionArray();
		this.ddlProfiles = this.enumsHelper.getProfileInteractionArray();
		this.opportunityService.getOpportunitiesForInteraction().subscribe(res => {
			(res.sort(function (a, b) {
				return a.number - b.number;
			}));
			for (let item of res) {
				var opportunity = new OpportunityModel();
				opportunity.loadModelFromServer(item);
				if (opportunity.isActive)
					this.opportunities.push(opportunity);

				this.dropdownItem2 = {
					id: JSON.stringify(opportunity), itemName: opportunity.number.toString() + " - " + opportunity.name + " - Cliente: " + opportunity.customerName
				};
				this.dropdownList2.push(this.dropdownItem2);
			}
		});

		$('.tst3').on('click', () => {
			setTimeout(() => {
				if (this.success == true) {
					this.enumsHelper.toast("Interação criada com sucesso.", "success");
				} else {
					this.enumsHelper.toast("Erro na Criação da Interação", "warning");
				}
			}, 1500);
		});

		this.candidateModel.historic == undefined ? this.candidateModel.historic = [] : this.candidateModel.historic = this.candidateModel.historic;
		this.opportunityModel.historic == undefined ? this.opportunityModel.historic = [] : this.opportunityModel.historic = this.opportunityModel.historic;


		this.serviceManagement.getAll().subscribe(tg => {
			this.configs = tg;
		})


	}

	async hiredInteraction() {
		await this.interactionService.getByCandidateId(this.interactionModel.candidateId).map(res => {
			this.interactions = new Array<InteractionModel>();
			this.interactions = [];
			for (let cr of res) {
				let i = new InteractionModel();
				i.loadFromServer(cr);
				this.interactions.push(i);

				if (cr.status == 4 && cr.opportunityId == this.interactionModel.opportunityId) {
					this.hiredConfirmation = true;
				}
			}
		}).toPromise();
	}

	async create() {
		let userInfo = this.authService.getUserInfoModel();
		let opportunity = this.opportunities.find(x => x._id === this.interactionModel.opportunityId);
		this.interactionModel.opportunityName = typeof (opportunity) !== "undefined" ? opportunity.name : "";
		this.interactionModel.userFirstName = userInfo.firstName + " " + userInfo.lastName;
		this.interactionModel.userEmail = userInfo.email;
		this.interactionModel.candidateId = this.candidateModel._id;
		this.interactionModel.interactionType = InteractionType.RS;
		this.notificationModel.userEmail = userInfo.email;
		this.notificationModel.originNotification = "Interação";


		this.notificationModel.userFirstName = userInfo.firstName + " " + userInfo.lastName;
		this.notificationModel.typeOfNotification = 0;
		this.notificationModel.candidateId = this.interactionModel.candidateId;

		if (this.interactionModel.status == 4) {
			await this.hiredInteraction();
			if (this.hiredConfirmation == true) {
				this.enumsHelper.toast("Candidato já está contratado para essa vaga.", "warning")
				this.cancelEvent()
				return null;
			}
		}


		if (typeof (opportunity) !== "undefined") {
			this.interactionModel.opportunityNumber = opportunity.number;
			this.notificationModel.discriptionNotification = "Criou uma interação de " + this.enumsHelper.getDescriptionActionInteraction(this.interactionModel.action) + " da vaga " + opportunity.number + " cujo você é responsável ";
			this.interactionModel.opportunity = opportunity;
			if (this.interactionModel.status != 5) {
				if (this.candidateModel.opportunities.find(x => x._id === this.interactionModel.opportunityId) === undefined) {
					this.candidateModel.opportunities.push(opportunity);
				}

			}
		} else {
			this.notificationModel.discriptionNotification = "Criou uma interação de " + this.enumsHelper.getDescriptionActionInteraction(this.interactionModel.action);
		}

		var acao = this.enumsHelper.getDescriptionActionInteraction(this.interactionModel.action);

		if (!this.interactionModel.opportunity._id) {
			this.interactionModel.opportunity = undefined;
		}

		// Validate status of candidate
		if (this.company.tag == 'fcamara') {
			if (this.interactionModel.status != -1) {
				if (this.interactionModel.status == 3 || this.interactionModel.status == 2) {
					this.interactionService.findToDisapprove(this.interactionModel).subscribe(r => {
						if (r.length == 0) {
							this.candidateModel.status = this.interactionModel.status;
							this.candidateService.update(this.candidateModel).subscribe(c => {
							}, err => {
								return this.enumsHelper.toast(err.Errors.message, "error")
							})
						}
					}, err => {
						console.log(err)
					});
				} else {
					this.candidateModel.status = this.interactionModel.status;
				}
			}
		} else {
			this.candidateModel.status = this.interactionModel.status;
		}

		this.interactionService.add(this.interactionModel).subscribe(r => {
			var message = "Criou interação de " + acao;
			this.logs.create(message);

			// this.interactionModel.status == 3 ? this.notifyReprovedCandidate() : "";

			//Populate historic of candidate

			if (typeof (opportunity) !== "undefined") {
				this.candidateHistoric.opportunityId = opportunity._id;
				this.candidateHistoric.opportunityName = opportunity.name;
				this.candidateHistoric.opportunityNumber = opportunity.number;
				this.candidateHistoric.opportunityCustomer = opportunity.customerName;
				this.candidateHistoric.registrationDate = new Date();
				this.candidateHistoric.interactions.push(r);

				if (this.candidateModel.historic.find(x => x.opportunityId === this.interactionModel.opportunityId) != undefined) {
					this.candidateModel.historic.forEach(his => {
						if (his.opportunityId == opportunity._id) {
							his.interactions.push(r);
						}
					});
				}
				if (this.candidateModel.historic.length > 0) {
					if (this.candidateModel.historic.find(x => x.opportunityId == this.interactionModel.opportunityId) == undefined) {
						this.candidateModel.historic.push(this.candidateHistoric);
					}
				} else {
					this.candidateModel.historic.push(this.candidateHistoric);
				}
				let opp = this.candidateModel.opportunities.find(x => x._id == opportunity._id)
				this.candidateModel.opportunities.indexOf(opp) > -1 && (this.interactionModel.status == 3 || this.interactionModel.status == 2 || this.interactionModel.status == 6) ? this.candidateModel.opportunities.splice(this.candidateModel.opportunities.indexOf(opp), 1) : this.candidateModel;
			}
			this.candidateService.update(this.candidateModel).subscribe(c => {
				this.notificationService.notify('Interação inserida com sucesso!');
				this.interactionModel = new InteractionModel();
				this.app.tick();
				this.created.emit();
			});

			if (typeof (opportunity) !== "undefined") {

				if (opportunity.candidates.find(x => x === this.interactionModel.candidateId) === undefined)
					for (var i = 0; i <= opportunity.candidates.length; i++) {
						if (opportunity.candidates[i] == this.interactionModel.candidateId) {
							// console.log("quebrou");
							// return;
						}
					}
				if (this.interactionModel.status != 5) {
					if (typeof (opportunity) !== "undefined") {
						if (this.interactionModel.status == 4) {
							if (opportunity.qtdOpportunities) {
								if (opportunity.qtdOpportunities > 0) {
									opportunity.qtdOpportunities = opportunity.qtdOpportunities - 1;
								}
								if (opportunity.qtdOpportunities == 0) {
									opportunity.status = 1;
								}
							}
						}
						if (opportunity.candidates.find(x => x === this.interactionModel.candidateId) === undefined) {
							opportunity.candidates.push(this.interactionModel.candidateId);
						}
						//Populate historic opportunity 

						this.opportunityHistoric.candidateId = this.candidateModel._id;
						this.opportunityHistoric.candidateName = this.candidateModel.name;
						this.opportunityHistoric.candidateEmail = this.candidateModel.email;
						this.opportunityHistoric.registrationDate = new Date();
						this.opportunityHistoric.interactions.push(r);

						if (opportunity.historic.find(x => x.candidateId == this.interactionModel.candidateId) != undefined) {
							opportunity.historic.forEach(his => {
								if (his.candidateId == this.candidateModel._id) {
									his.interactions.push(r);
								}
							});
						}

						if (opportunity.historic.length > 0) {
							if (opportunity.historic.find(x => x.candidateId == this.interactionModel.candidateId) == undefined) {
								opportunity.historic.push(this.opportunityHistoric);
							}
						} else {
							opportunity.historic.push(this.opportunityHistoric);
						}
						opportunity.candidates.indexOf(this.interactionModel.candidateId) && (this.interactionModel.status == 3 || this.interactionModel.status == 2 || this.interactionModel.status == 6) ? opportunity.candidates.splice(opportunity.candidates.indexOf(this.candidateModel._id), 1) : opportunity;
						this.opportunityService.update(opportunity).subscribe(r => {
						})
					}
				}



			}
			this.notifyRecruiter(opportunity);
		});
		this.success = true
		if (this.interactionModel.status == 4 && typeof (opportunity) !== "undefined") {

			this.updateOpportunities(this.candidateModel, opportunity);
		}

		if (this.interactionModel.status != -1) {
			if (this.interactionModel.status == 4) {
				this.interactionService.addHired(this.interactionModel).subscribe(r => {

				}, err => {
					console.log(err)
				});
			}
		}

		if (this.interactionModel.status == 11) {
			this.candidateModel.isBlocked = !this.candidateModel.isBlocked;
			this.candidateService.update(this.candidateModel).subscribe(r => {
			})
		}
		// 	});
		// }
	}

	populateOpportunity() {
		if (this.selectedItems2.length > 0) {
			let selected = JSON.parse(this.selectedItems2[0].id)
			this.interactionModel.opportunityId = selected._id;
			this.interactionModel.opportunityName = selected.name;
		}
	}

	getAllInteractions() {
		this.interactionService.getAll().subscribe(res => {
			this.interactions = new Array<InteractionModel>();
			this.interactions = [];

			for (let cr of res) {
				let i = new InteractionModel();
				i.loadFromServer(cr);
				this.interactions.push(i);
			}
		});
	}

	updateOpportunities(candidate: CandidateModel, opp) {
		candidate.opportunities = []
		candidate.opportunities.push(opp)
		this.opportunityService.getAll().subscribe(r => {

			for (var i = 0; i < r.length; i++) {
				if (r[i].candidates) {
					if (r[i].candidates.length > 0) {
						for (var y = 0; y < r[i].candidates.length; y++) {
							if (r[i].candidates[y] == candidate._id) {
								if (r[i]._id != opp._id) {
									r[i].candidates.splice(y, 1);
									this.opportunityService.update(r[i]).subscribe(r => {
									});
								}
							}
						}
					}
				}
			}
		});
	}

	// deleteInteraction(i) {
	// 	this.interactionService.delete(i).subscribe(r => {

	// 	});
	// 	var message = "Deletou interação de " + this.interactionModel.action;
	// 	this.logs.create(message);

	// }

	cancelEvent() {
		this.interactionModel = new InteractionModel();
		this.cancel.emit();
	}


	notifyRecruiter(opportunity) {
		if (opportunity != undefined) {
			let email = [];
			if (this.interactionModel.opportunity.involvedPeople.length > 0) {
				opportunity.involvedPeople.forEach(inv => {
					if (inv.email) {
						email.push(inv.email);
					}
				});
				if (email.length > 0) {
					this.emailModel.to = email.toString();
				} else {
					this.emailModel.to = this.interactionModel.userEmail;
				}
			} else {
				this.notificationModel.responsibleEmail = "";
				this.emailModel.to = this.interactionModel.userEmail;
			}
		} else {
			this.notificationModel.responsibleEmail = "";
			this.emailModel.to = this.interactionModel.userEmail;
		}


		if (this.interactionModel.opportunity != undefined) {
			if (this.interactionModel.opportunity.emailResponsible == this.interactionModel.userEmail) {
				this.emailModel.subject = "Nova interação de " + this.candidateModel.name;
				this.emailModel.text = this.templateEmail.createTemplateEmail(this.interactionModel.userFirstName, this.candidateModel.name, `${environment.frontUrlApi}/candidate/edit/id${this.interactionModel.candidateId}`, this.enumsHelper.getDescriptionActionInteraction(this.interactionModel.action), `${environment.frontUrlApi}`, opportunity);
			} else {
				this.emailModel.subject = "Nova interação de " + this.candidateModel.name;
				this.emailModel.text = this.templateEmail.createTemplateEmail(this.interactionModel.userFirstName, this.candidateModel.name, `${environment.frontUrlApi}/candidate/edit/id${this.interactionModel.candidateId}`, this.enumsHelper.getDescriptionActionInteraction(this.interactionModel.action), `${environment.frontUrlApi}`, opportunity);
			}
		} else {
			this.emailModel.subject = "Nova interação de " + this.candidateModel.name;
			this.emailModel.text = this.templateEmail.createTemplateEmail(this.interactionModel.userFirstName, this.candidateModel.name, `${environment.frontUrlApi}/candidate/edit/id${this.interactionModel.candidateId}`, this.enumsHelper.getDescriptionActionInteraction(this.interactionModel.action), `${environment.frontUrlApi}`, opportunity);
		}

		// if (this.configs.interactionEmail == true) {
		this.sendEmailService.send(this.emailModel)
			.subscribe(res => {
				// console.log(res);
			}, error => {
				// console.log(error);
			})
		if (opportunity) {
			if (opportunity.emailWatching != undefined) {
				for (let i = 0; i < opportunity.emailWatching.length; i++) {
					this.emailModel2.to = opportunity.emailWatching[i];
					this.emailModel2.subject = "Nova interação de " + this.candidateModel.name;
					this.emailModel2.text = this.templateEmail.createTemplateEmail(this.interactionModel.userFirstName, this.candidateModel.name, `${environment.frontUrlApi}/candidate/edit/id${this.interactionModel.candidateId}`, this.enumsHelper.getDescriptionActionInteraction(this.interactionModel.action), `${environment.frontUrlApi}`, opportunity);

					this.sendEmailService.send(this.emailModel2)
						.subscribe(res => {
						}, error => {
							console.log(error);
						})
					let userInfo = this.authService.getUserInfoModel();

					this.notificationModel2.userEmail = userInfo.email;
					this.notificationModel2.originNotification = "Interação";
					this.notificationModel2.userFirstName = userInfo.firstName + " " + userInfo.lastName;
					this.notificationModel2.typeOfNotification = 0;
					this.notificationModel2.candidateId = this.interactionModel.candidateId;
					this.notificationModel2.discriptionNotification = "Criou uma interação de " + this.enumsHelper.getDescriptionActionInteraction(this.interactionModel.action) + " da vaga " + opportunity.number + " cujo você é responsável ";
					this.notificationModel2.responsibleEmail = opportunity.emailWatching[i];

					this.notification.insert(this.notificationModel2).subscribe(l => {
						this.notificationAdmin.sendMessage(this.notificationModel2);
					});

				}
			} else {
				console.log("ninguém vigiando a vaga")
			}
		}
		// } else {
		// 	console.log("Configuração do envio de e-mail para interações desligada.")
		// }

		this.notification.insert(this.notificationModel).subscribe(r => {
			this.notificationAdmin.sendMessage(this.notificationModel);
		});
	}


	// notifyReprovedCandidate() {
	// 	if (this.configs.reprovalEmail == true) {
	// 		this.emailModel = new EmailModel();
	// 		this.emailModelReproved.to = this.candidateModel.email;
	// 		this.emailModelReproved.subject = "Reprovado";
	// 		this.emailModelReproved.text = "Reprovado";

	// 		this.sendEmailService.sendReproved(this.emailModelReproved).subscribe(r => { })
	// 	} else {
	// 		console.log("Configuração do envio de e-mail para reprovação desligada.")
	// 	}
	// }

	createEvaluation = () => {
		this.evaluation.email = this.candidateModel.email
		this.evaluation.name = this.candidateModel.name
		this.evaluation.type = ["HP", "SL"]
		this.evaluationService.add(this.evaluation).subscribe(res => {
			// this.notificationService.notify('Foi criada uma avaliação para ' + this.candidateModel.name)
			this.enumsHelper.toast('Foi criada uma avaliação para ' + this.candidateModel.name, "success");
		})
	}

	getAllStatus() {
		this.statusOfCandidate.getAll().subscribe(status => {
			this.statusOfCandidateArray = [];
			for (let statusC of status) {
				let statusLoaded = new StatusOfCandidateModel();
				statusLoaded.loadModelFromServer(statusC);
				this.statusOfCandidateArray.push(statusLoaded);
			}
		})
	}

	getAllActions() {
		this.actionService.getAllActions().subscribe(actions => {
			this.actionsArray = [];
			for (let action of actions) {
				this.actionsArray.push(action);
			}
		})
	}
}

