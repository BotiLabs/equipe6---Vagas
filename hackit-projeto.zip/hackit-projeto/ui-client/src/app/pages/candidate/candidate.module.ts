import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from '../../shared/shared.module';
import { RatingModule } from 'ngx-rating';
import { EditComponent } from './edit/edit.component';
export const CandidateRoutes: Routes = [
    {
        path: '',
        children: [
            {
                path: '',
                loadChildren: './list/list.module#ListModule',
                data: {
                    heading: 'Lista dos Candidatos',
                    status: false
                }
            },
            {
                path: 'edit',
                loadChildren: './edit/edit.module#EditModule',
                data: {
                    heading: 'Cadastrar um Candidato'
                }
            },
            {
                path: 'edit/:id/:ref',
                loadChildren: './edit/edit.module#EditModule',
                data: {
                    heading: 'Editar um Candidato'
                }
            },
            {
                path: 'profile/:id',
                loadChildren: './profile/profile.module#ProfileModule',
                data: {
                    heading: 'Perfil do Candidato'
                }
            }
        ]
    }
];

@NgModule({
    imports: [
        CommonModule,
        RouterModule.forChild(CandidateRoutes),
        SharedModule,
        RatingModule
    ],
    declarations: [],
    providers: [EditComponent]
})

export class CandidateModule { }
