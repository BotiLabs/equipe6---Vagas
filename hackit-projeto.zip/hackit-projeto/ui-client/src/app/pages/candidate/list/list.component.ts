import { state } from '@angular/animations';
import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { CandidateModel } from '../../../models/candidate.model';
import { CandidateService } from '../../../../../_services/candidate.service';
import { StatusCandidate } from '../../../common/status-candidate';
import { EnumsHelper } from '../../../common/enums-helper';
import { CandidatesRequest } from '../../../common/candidates.request';
import { TagService } from '../../../../../_services/tag.service';
import { PersistenceService } from 'angular-persistence';
import { AuthService } from '../../../../../_services/auth.service';
import '../../../../assets/plugins/toast-master/js/jquery.toast.js';
import { OpportunityModel } from '../../../models/opportunity.model';
import { OpportunityService } from '../../../../../_services/opportunity.service';
import { TagModel } from '../../../models/tag.model';
import { Observable } from 'rxjs/Rx';
import { StatusOfCandidateService } from '../../../../../_services/statusCandidate.service';
import { StatusOfCandidateModel } from '../../../models/statusOfCandidate.model';
import { PositionsService } from '../../../../../_services/positions.service';
import * as XLSX from 'xlsx';
import * as moment from 'moment';
import { PositionsModel } from '../../../models/positions.model';
import { InteractionService } from '../../../../../_services/interaction.service';
import { InteractionModel } from '../../../models/interaction.model';
import { UserModel } from '../../../models/user.model';

moment.locale('pt-BR');
declare var $: any;

@Component({
    selector: 'app-list',
    templateUrl: './list.component.html',
    styleUrls: ['./list.component.css'],
    encapsulation: ViewEncapsulation.None
})

export class ListComponent implements OnInit {
    down = [];
    positionData = [];
    dropdownItem: {};
    dropdownItemCargo: any = [];
    dropdownListCargo: any = [];
    dropdownList = []
    dropdownListRec = [];
    dropdownItemRec: any = [];
    selectedItems = [];
    selectedItems2: number
    selectedItemsCargo = [];
    selectedItemsRec = [];
    dropdownSettings = {};
    itemsPerPage: number[] = [10, 50, 100];
    limit: number = 20;
    opportunity: OpportunityModel;
    opportunityLocation: string;
    totalItems: number;
    candidatesRequest: CandidatesRequest = new CandidatesRequest();
    enumsHelper: EnumsHelper = new EnumsHelper();
    candidates: CandidateModel[];
    ddlStatus: StatusCandidate[];
    title: string = "";
    subtitle: string = "";
    candidateModel: CandidateModel = new CandidateModel();
    advancedSearch: boolean = false;
    searchSaveStatus: number = -1;
    searchs = [];
    candidatesLoaded: boolean = false;
    page: number;
    statusSort: [number, number, number, number, number, number, number] = [0, 0, 0, 0, 0, 0, 0];
    tags: TagModel[] = [];
    statusOfCandidateArray: StatusOfCandidateModel[];
    positionsArray: PositionsModel[];
    modal: boolean = false;
    dropdownSettingsSingle: {};
    opportunities: OpportunityModel[] = [];
    userEmail;
    dropdownItemOpp: {};
    dropdownListOpp: any = [];
    selectedItemsOpp: any = [];
    exportItensArr: any[][] = [];
    disable: string = "disabled";
    users: any;
    nameOp: String = '';
    candidateId: string;
    recrutador;
    interactions: InteractionModel[] = [];
    modalToInteraction: boolean = false;
    interactionModel: InteractionModel = new InteractionModel()

    constructor(
        private opportunityService: OpportunityService,
        public authService: AuthService,
        private candidateService: CandidateService,
        public tagService: TagService,
        private persistenceService: PersistenceService,
        private statusOfCandidate: StatusOfCandidateService,
        private positions: PositionsService,
        private interactionService: InteractionService,
    ) {
        this.dropdownSettings = {
            singleSelection: false,
            text: "Selecione...",
            selectAllText: 'Marcar todos',
            unSelectAllText: 'Desmarcar todos',
            enableSearchFilter: true,
            classes: "myclass custom-class",
            badgeShowLimit: 1,
            searchBy: ["itemName"]
        };
        this.dropdownSettingsSingle = {
            singleSelection: true,
            text: "Selecione...",
            selectAllText: 'Marcar todos',
            unSelectAllText: 'Desmarcar todos',
            enableSearchFilter: true,
            classes: "myclass custom-class",
            badgeShowLimit: 3,
            searchBy: ["itemName"]
        };
        (<any>window).ga('set', 'page', 'Grid de candidatos');
        (<any>window).ga('send', 'pageview');
        this.getUsers();
    }

    async ngOnInit() {
        this.candidates = [];
        this.getAllTags();
        this.getAllOpportunities();
        this.populateDropDowns();
        this.getCache();
        this.searchCandidates(1, false);
        this.getAllStatus();
    }

    getUsers() {
        this.users = []
        this.authService.getUsers().subscribe(r => {
            for (let u of r.result) {
                let user = new UserModel();
                user.loadUserModel(u);
                this.users.push(user)
            }
        })
    }

    //search candidate method
    searchCandidates(page: number, scroll: boolean) {
        this.disable = "disabled"
        //Cache of search
        this.persistenceService.set('nameCandidate', this.candidatesRequest.name);
        this.persistenceService.set('statusCandidate', this.candidatesRequest.status);
        this.persistenceService.set('selectedItems', this.selectedItems);
        this.persistenceService.set('positionCandidate', this.candidatesRequest.position);
        this.persistenceService.set('selectedItemsCargo', this.selectedItemsCargo);
        this.persistenceService.set('userEmail', this.candidatesRequest.userEmail);
        if (this.candidatesRequest.skills != undefined) {
            for (var i = 0; i <= this.candidatesRequest.skills.length; i++) {
                this.persistenceService.set(this.candidateModel.skills[i], this.candidatesRequest.skills);
            }
        }

        if (!scroll) {
            this.candidates = [];
        }
        this.candidatesRequest.name = this.candidateModel.name;
        this.page = page;
        this.candidatesLoaded = false;
        this.candidatesRequest.page = page;
        this.candidatesRequest.limit = this.limit;
        this.candidatesRequest.name ? this.candidatesRequest.name = this.enumsHelper.validateAscentClientname(this.candidatesRequest.name) : this.candidatesRequest.name;
        //Analytcs event
        this.enumsHelper.sendEventAnalytcs("Buscar candidato", "grid candidatos", "Buscou candidato" + `(${this.candidatesRequest.name})`)
        this.candidateService.search(this.candidatesRequest).subscribe(res => {
            this.totalItems = 0;
            this.candidatesLoaded = true;
            this.totalItems = res.count;
            for (let cr of res.result) {
                let c = new CandidateModel();
                c.loadCandidate(cr);
                this.candidates.push(c);
            }
            this.candidates.forEach(async c => {
                c.distance = await this.getDistance(c)
            })
            if (this.candidates.length > 0) {
                this.disable = ""
            }
        });
    }

    populateOrigin() {
        this.candidatesRequest.origin = this.enumsHelper.getOriginCandidate(this.selectedItems2);
    }

    populateCargo() {
        if (this.selectedItemsCargo.length > 0) {
            let arr = []
            for (let position of this.selectedItemsCargo) {
                arr.push(position.itemName);
            }
            this.candidatesRequest.position = arr;

        }
        if (this.selectedItemsCargo.length == 0) {
            this.candidatesRequest.position = undefined
        }
    }

    //Ajustar para multi-empresa
    populateDropDowns() {
        //Status
        this.getAllCandidateStatus();

        //Cargo
        this.getAllPositions();

        //Recrutadores
        // this.getAllRecrutadores();
    }

    getCache() {
        // Persistance
        this.candidatesRequest.name = this.persistenceService.get('nameCandidate');
        if (this.persistenceService.get(this.candidateModel.skills[0]) != undefined) {
            this.candidatesRequest.skills = this.persistenceService.get(this.candidateModel.skills[0]);
        } else {
            this.candidatesRequest.skills = [];
        }
        if (this.persistenceService.get('positionCandidate') != undefined) {
            this.candidatesRequest.position = this.persistenceService.get('positionCandidate');
            this.selectedItemsCargo = this.persistenceService.get('selectedItemsCargo');
        }
        if (this.persistenceService.get('statusCandidate') != undefined) {
            this.candidatesRequest.status = this.persistenceService.get('statusCandidate');
            this.selectedItems = this.persistenceService.get('selectedItems');
        }
        this.candidatesRequest.userEmail = this.persistenceService.get('userEmail');

    }

    populateStatus() {
        if (this.selectedItems.length > 0) {
            let arrStatus = []
            for (let status of this.selectedItems) {
                arrStatus.push(parseInt(status.id));
            }
            this.candidatesRequest.status = arrStatus;
        }
        if (this.selectedItems.length == 0) {
            this.candidatesRequest.status = -1;
        }
    }

    onSort(event) {
        // event was triggered, start sort sequence
        switch (this.statusSort[event]) {
            case 0:
                switch (event) {
                    case 0:
                        this.statusSort[event] = 1;
                        this.statusSort[1] = 0;
                        this.statusSort[2] = 0;
                        this.statusSort[3] = 0;
                        this.candidatesRequest.sort = { "query": { "noAscentName": 1 } }
                        break;
                    case 1:
                        this.statusSort[event] = 1;
                        this.statusSort[0] = 0;
                        this.statusSort[2] = 0;
                        this.statusSort[3] = 0;
                        this.candidatesRequest.sort = { "query": { "position": 1 } }
                        break;
                    case 2:
                        this.statusSort[event] = 1;
                        this.statusSort[0] = 0;
                        this.statusSort[1] = 0;
                        this.statusSort[3] = 0;
                        this.candidatesRequest.sort = { "query": { "statusJoin.name": 1 } }
                        break;
                    case 3:
                        this.statusSort[event] = 1;
                        this.statusSort[0] = 0;
                        this.statusSort[1] = 0;
                        this.statusSort[2] = 0;
                        this.candidatesRequest.sort = { "query": { "relevance": 1 } }
                        break;
                }
                break;
            case 1:
                switch (event) {
                    case 0:
                        this.statusSort[event] = 2;
                        this.statusSort[1] = 0;
                        this.statusSort[2] = 0;
                        this.statusSort[3] = 0;
                        this.candidatesRequest.sort = { "query": { "noAscentName": -1 } }
                        break;
                    case 1:
                        this.statusSort[event] = 2;
                        this.statusSort[0] = 0;
                        this.statusSort[2] = 0;
                        this.statusSort[3] = 0;
                        this.candidatesRequest.sort = { "query": { "position": -1 } }
                        break;
                    case 2:
                        this.statusSort[event] = 2;
                        this.statusSort[0] = 0;
                        this.statusSort[1] = 0;
                        this.statusSort[3] = 0;
                        this.candidatesRequest.sort = { "query": { "statusJoin.name": -1 } }
                        break;
                    case 3:
                        this.statusSort[event] = 2;
                        this.statusSort[0] = 0;
                        this.statusSort[1] = 0;
                        this.statusSort[2] = 0;
                        this.candidatesRequest.sort = { "query": { "relevance": -1 } }
                        break;
                }
                break;
            case 2:
                this.candidatesRequest.sort = undefined;
                this.statusSort[event] = 0;
                break;
        }
        this.searchCandidates(1, false);
    }

    getAllTags() {
        this.tagService.getAll().subscribe(tg => {
            for (let t of tg) {
                var tag = new TagModel();
                tag.loadTag(t);
                this.tags.push(tag);
            }
        })
    }

    async getAllStatus() {
        this.statusOfCandidate.getAll().subscribe(status => {
            this.statusOfCandidateArray = [];
            let drop = {};

            for (let statusC of status) {
                let statusLoaded = new StatusOfCandidateModel();
                statusLoaded.loadModelFromServer(statusC);
                this.statusOfCandidateArray.push(statusLoaded);
                drop = {
                    id: statusC.number.toString(), itemName: statusC.name
                };
                this.down.push(drop);
            }
        })
    }

    getAllPositions() {
        this.positions.getAll().subscribe(r => {
            this.positionsArray = [];
            for (let position of r) {
                let postionsLoaded = new PositionsModel();
                postionsLoaded.loadFromServer(position);
                this.positionsArray.push(postionsLoaded);
                this.dropdownItemCargo = {
                    id: position.name, itemName: position.name
                };
                this.dropdownListCargo.push(this.dropdownItemCargo);
            }
        })

    }
    itemsRequest = (text: String): Observable<Array<String>> => {
        let tags = new Array<String>();
        var obs = new Observable<Array<String>>(observer => {

            this.tags.forEach(tag => {
                if (text)
                    if (tag.name.indexOf(text.toUpperCase()) > -1) {
                        tags.push(tag.name)
                    }
            });

            observer.next(tags);
        });
        return obs;
    }

    loadStatus(status: number) {
        if (this.statusOfCandidateArray) {
            let obj = this.statusOfCandidateArray.find(x => x.number == status);
            if (obj)
                return obj;
        }
    }

    openModal() {
        this.nameOp = "";
        this.modal = true;
    }

    closeModal() {
        let opportunity = JSON.parse(this.selectedItemsOpp[0].id);
        let location = `${opportunity.opportunityLocation.district} ${opportunity.opportunityLocation.streetAddress} ${opportunity.opportunityLocation.state}`
        this.getDataLocation(location);
        this.nameOp = `${opportunity.number} ${opportunity.name}`;
        this.modal = false;

    }

    closeModalAndClean() {
        this.selectedItemsOpp = [];
        this.candidatesRequest.skills = [];
        this.modal = false;
    }

    getAllOpportunities() {
        this.opportunities = [];
        let st = {
            "status": 0
        };
        this.opportunityService.getByStatus(st).subscribe(r => {
            for (let item of r) {
                var opportunity = new OpportunityModel();
                opportunity.loadModelFromServer(item);
                this.dropdownItemOpp = {
                    id: JSON.stringify(opportunity), itemName: opportunity.number.toString() + " - " + opportunity.name + " - Cliente: " + opportunity.customerName
                };
                this.dropdownListOpp.push(this.dropdownItemOpp);
            }
        })
    }

    async getDistance(candidate: CandidateModel){
        if(!candidate.cep || !candidate.district  || !candidate.city || !this.opportunityLocation) return '-'

        const origin = await this.candidateService.getLatLon(this.opportunityLocation);
        const destination = await this.candidateService.getLatLonCep({cep: candidate.cep, district: candidate.district, city: candidate.city})
        const distance = await this.candidateService.getDistance({origin, destination});

        if(typeof distance === 'string') return distance;
        return null;
    }

    async populateTags() {
        this.opportunity = JSON.parse(this.selectedItemsOpp[0].id);
        this.enumsHelper.sendEventAnalytcs("Selecionar vaga no grid de candidatos", "vaga: " + this.selectedItemsOpp[0].number, "Selecionou a vaga " + this.selectedItemsOpp[0].number + " no grid de candidatos.");
        this.opportunityLocation = `${this.opportunity.opportunityLocation.streetAddress}, ${this.opportunity.opportunityLocation.state}`;
        this.candidatesRequest.skills = this.opportunity.specialities;
    }

    unpopulateTags() {
        this.candidatesRequest.skills = [];
        this.opportunityLocation = null;
    }

    blockCandidate() {
        this.modalToInteraction = !this.modalToInteraction;

        let i = localStorage.getItem('userInfo');
        let y = JSON.parse(i)
        this.interactionModel.userEmail = y.email;
        this.interactionModel.userFirstName = `${y.firstName} ${y.lastName}`;
        let x: object
        this.interactionModel.opportunity = x;
        this.interactionModel.candidateId = this.candidateModel._id;

        this.candidateModel.isBlocked = !this.candidateModel.isBlocked;
        if (this.candidateModel.isBlocked == true) {
            this.interactionModel.status = 11;
            this.interactionModel.action = 8;
            this.candidateModel.status = 11;
        } else {
            this.interactionModel.action = 9;
            this.interactionModel.status = 5;
            this.candidateModel.status = 5;
        }
        this.candidateService.update(this.candidateModel).subscribe(r => {
            this.searchCandidates(1, false);
            this.enumsHelper.sendEventAnalytcs("Bloquear candidato", this.candidateModel.name, "Um candidato foi bloqueado")
        })

        this.interactionService.add(this.interactionModel).subscribe(r => {
        })
    }

    modalToBlock(c: CandidateModel) {
        this.candidateModel = new CandidateModel();
        this.candidateModel = c;
        this.modalToInteraction = !this.modalToInteraction;
        this.interactionModel = new InteractionModel();
    }

    modalclose() {
        this.modalToInteraction = !this.modalToInteraction;
        this.interactionModel = new InteractionModel();
    }


    exportList() {
        this.candidateService.exportList(this.candidatesRequest).subscribe(r => {
            if (r.length > 0) {
                const ws: XLSX.WorkSheet = XLSX.utils.aoa_to_sheet(r);

                /* generate workbook and add the worksheet */
                const wb: XLSX.WorkBook = XLSX.utils.book_new();
                XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');

                /* save to file */
                XLSX.writeFile(wb, 'Candidatos.xlsx');
            } else {
                this.enumsHelper.toast("Não há dados para exportar.", "warning")
            }
        }, err => {
            this.enumsHelper.toast(err.Errors.message, "warning")
        })
    }

    onScroll() {
        if (this.candidates.length > 0) {
            this.page++;
            this.searchCandidates(this.page, true);
        }
    }

    getAllCandidateStatus() {

        this.statusOfCandidate.getAll().subscribe(status => {
            for (let s of status) {
                this.dropdownItem = {
                    id: s.number, itemName: s.name
                };
                this.dropdownList.push(this.dropdownItem);
            }

            this.dropdownList.sort(function (a, b) {
                if (a.itemName > b.itemName) {
                    return 1;
                }
                if (a.itemName < b.itemName) {
                    return -1;
                }
                return 0;
            });

        }, err => {
            this.enumsHelper.toast(err.Errors.message, "warning");
        })
    }


    getDataLocation(data: string) {
        // console.log(data);
        // this.candidateService.getLatLon(data).subscribe(r => {
        //     console.log(r);
        // }, err => {
        //     console.log(err);
        // })
    }

    cacalculatesDistancece() {

        // let points =
        // {
        //     "p1": {
        //         "lat": "-23.55196",
        //         "lon": "-46.65459"
        //     },

        //     "p2": {
        //         "lat": "-23.966736",
        //         "lon": "-46.311809"
        //     }
        // }

        // this.candidateService.getDistance(points).subscribe(r => {
        //     console.log(r);
        // }, err => {
        //     console.log(err);
        // });
    }
}
