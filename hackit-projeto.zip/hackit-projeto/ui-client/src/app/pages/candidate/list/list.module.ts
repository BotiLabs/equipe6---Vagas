import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ListComponent } from './list.component';
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from '../../../shared/shared.module';
import { InputTrimModule } from 'ng2-trim-directive';
import { AngularMultiSelectModule } from 'angular2-multiselect-dropdown/angular2-multiselect-dropdown';
import { InfiniteScrollModule } from 'ngx-infinite-scroll';
export const ListRoutes: Routes = [
  {
    path: '',
    component: ListComponent,
    data: {
      heading: 'Lista de Candidatos',
      status: false
    }
  }
];
@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(ListRoutes),
    SharedModule,
    InputTrimModule,
    AngularMultiSelectModule,
    InfiniteScrollModule
  ],
  declarations: [ListComponent]
})

export class ListModule { }



