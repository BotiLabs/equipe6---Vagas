import { EnumsHelper } from './../../common/enums-helper';
import { Router } from '@angular/router';
import { Component, OnInit, Input } from '@angular/core';
import { OpportunityService } from '../../../../_services/opportunity.service';
import { InteractionService } from '../../../../_services/interaction.service';
import { CandidateService } from '../../../../_services/candidate.service';
import { CandidateModel } from '../../models/candidate.model';
// import { Angular2Txt } from 'angular2-txt/Angular2-txt';
import * as moment from 'moment';
import { UserModel } from '../../models/user.model';
import { AuthService } from '../../../../_services/auth.service';
moment.locale('pt-BR');

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})

export class DashboardComponent implements OnInit {
  candidateSourceChart: any[];
  candidates: CandidateModel[];
  reports: any = [];
  reportsWithDate: any;
  reportsByStatus: any;
  report1: any;
  report2: any;
  report3: any;
  report4: any;
  report5: any;
  report6: any;
  reportStatus1: number = 0;
  reportStatus2: number = 0;
  reportStatus3: number = 0;
  reportStatus4: number = 0;
  initialDate: Date;
  initialDateCalc: number;
  finalDate: Date;
  finalDateCalc: number;
  c: any;
  users: any;
  id: any;
  candidateOrigin: any[] = [];
  cand: any[] = [];
  enumsHelper: EnumsHelper = new EnumsHelper();
  objProcess: any = {}
  priorityOpp: any = [0, 0, 0];
  processOpportunities: any = [];
  data: any;
  options: any;
  msgs: any;
  showHTML: boolean = false;
  labels = []
  dataLabels = [];
  percentCandidates: number;
  percentInteractions: number;
  sla: number;
  modal: boolean = false;
  constructor(private opportunityService: OpportunityService,
    private candidateService: CandidateService,
    private interactionService: InteractionService,
    private authService: AuthService,
    private router: Router,
  ) {
    var date = new Date();
    var days = this.daysInMonth(date.getUTCMonth() + 1, date.getUTCFullYear());
    this.data = {
      labels: [],
      datasets: [
        {
          label: 'Candidatos',
          data: [],
          fill: false,
          borderColor: '#1b7c8c'
        },
        {
          label: 'Entrevistas',
          data: [],
          fill: false,
          borderColor: '#df8d0e'
        }
      ]
    }

    for (var i = 0; i <= days; i++) {
      if (i > 0)
        this.data.labels.push("" + i + "")

      if (i < days) {
        this.data.datasets[0].data.push(0)
        this.data.datasets[1].data.push(0)
      }
    }
    this.getCandidateAndInterviews();
    this.getUsers();
    (<any>window).ga('set', 'page', 'Dashboard');
    (<any>window).ga('send', 'pageview');
  }


  ngOnInit() {
    this.getSla();
    this.getPriorityCount();
    this.getCountCandidates();
    this.getProcessCandidate()
    this.interactionService.getReports().subscribe(r => {
      this.reports = [];
      for (let cr of r) {
        let c = cr;
        this.reports.push(c);
      }
      this.reports.sort(function (a, b) {
        if (new RegExp(a._id, "i") > new RegExp(b._id, "i")) {
          return 1;
        }
        if (new RegExp(a._id, "i") < new RegExp(b._id, "i")) {
          return -1;
        }
        return 0;
      });
    });
    this.searchReports(-1);
    this.searchReportsByStatus();
    this.candidateSourceChart = [];
  }

  searchReportsByStatus() {
    this.opportunityService.getOpportunitiesByStatus().subscribe(res => {
      this.reportsByStatus = [];

      for (let cr of res) {
        let c = cr;
        this.reportsByStatus.push(c);
      }
      for (var i = 0; i < this.reportsByStatus.length; i++) {
        if (this.reportsByStatus[i]) {
          if (this.reportsByStatus[i]._id == 0) {
            this.reportStatus1 = this.reportsByStatus[i].count;
          }
          if (this.reportsByStatus[i]._id == 1) {
            this.reportStatus2 = this.reportsByStatus[i].count;
          }
          if (this.reportsByStatus[i]._id == 2) {
            this.reportStatus3 = this.reportsByStatus[i].count;
          }
          if (this.reportsByStatus[i]._id == 3) {
            this.reportStatus4 = this.reportsByStatus[i].count;
          }
        }
      }

    });
  }


  getUsers() {
    this.users = []
    this.authService.getUsers().subscribe(r => {
      for (let u of r.result) {
        let user = new UserModel();
        user.loadUserModel(u);
        this.users.push(user)
      }
    })
  }


  /*pesquisar(){
    //this.reportStatus4
    this.router.navigate(['/candidate'], 
    {Params: this.reportStatus4});
  }*/

  getProcessCandidate() {
    this.candidateService.getProcessCandidates().subscribe(res => {
      this.objProcess = res;
    })
  }

  async searchReports(id) {
    this.reportsWithDate = [];
    this.report1 = 0;
    this.report2 = 0;
    this.report3 = 0;
    this.report4 = 0;
    this.report5 = 0;
    this.report6 = 0;
    this.id = id;

    var query = {};
    if (this.initialDate && this.finalDate && this.id != -1) {

      if (this.initialDate > this.finalDate) {
        this.enumsHelper.toast("A data inicial não pode ser maior que a data final.", "warning");
        return;
      }
      this.initialDateCalc = Date.parse(this.initialDate.toString());
      this.finalDateCalc = Date.parse(this.finalDate.toString())
      var initialDate = this.initialDateCalc;
      var finalDate = this.finalDateCalc + 86400000;
      query = { "initialDate": initialDate, "finalDate": finalDate, "userEmail": this.id }
    } else if (this.initialDate && this.finalDate) {
      if (this.initialDate > this.finalDate) {
        this.enumsHelper.toast("A data inicial não pode ser maior que a data final.", "warning");
        return;
      }
      this.initialDateCalc = Date.parse(this.initialDate.toString());
      this.finalDateCalc = Date.parse(this.finalDate.toString())
      var initialDate = this.initialDateCalc - 10800000;
      var finalDate = this.finalDateCalc + 75599999;
      query = { "initialDate": initialDate, "finalDate": finalDate }
    }
    else if (this.initialDate && this.id != -1) {
      this.initialDateCalc = Date.parse(this.initialDate.toString());
      var initialDate = this.initialDateCalc - 10800000;
      query = { "initialDate": initialDate, "userEmail": this.id }
    }
    else if (this.initialDate) {
      this.initialDateCalc = Date.parse(this.initialDate.toString());
      var initialDate = this.initialDateCalc - 10800000;
      query = { "initialDate": initialDate }

    } else if (this.finalDate && this.id != -1) {
      this.finalDateCalc = Date.parse(this.finalDate.toString())
      var finalDate = this.finalDateCalc + 75599999;
      query = { "finalDate": finalDate, "userEmail": this.id }

    } else if (this.finalDate) {
      this.finalDateCalc = Date.parse(this.finalDate.toString())
      var finalDate = this.finalDateCalc + 75599999;
      query = { "finalDate": finalDate }
    } else if (this.id != -1) {
      query = { "userEmail": this.id }
    }

    await this.interactionService.searchReports(query).subscribe(r => {
      this.reportsWithDate = [];
      this.report1 = 0;
      this.report2 = 0;
      this.report3 = 0;
      this.report4 = 0;
      this.report5 = 0;
      this.report6 = 0;
      for (let cr of r) {
        let c = cr;
        if (c) {
          if (c._id == 4) {
            this.report1 = c.count;
          }
          if (c._id == 1) {
            this.report2 = c.count;
          }
          if (c.status == 4) {
            this.report3 = c.count;
          }
          if (c._id == 3) {
            this.report4 = c.count;
          }
          if (c._id == 7) {
            this.report5 = c.count;
          }
          if (c._id == 6) {
            this.report6 = c.count;
          }
          this.reportsWithDate.push(c);
        }
      }
    });
  }


  clearInitialDate() {
    this.initialDate = undefined;
    this.searchReports(this.id)
  }

  clearFinalDate() {
    this.finalDate = undefined;
    this.searchReports(this.id)
  }

  getPriorityCount() {
    this.opportunityService.getPriorityOpportunity().subscribe(r => {
      r.forEach(i => {
        switch (i._id) {
          case 0:
            this.priorityOpp[0] = i.count;
            break;

          case 1:
            this.priorityOpp[1] = i.count;
            break;

          case 2:
            this.priorityOpp[2] = i.count;
            break;

          default:
            break;
        }
      });
    })
  }

  getCountCandidates() {
    this.opportunityService.getProcessOpportunities().subscribe(r => {
      this.processOpportunities[0] = r.withCandidateCount;
      this.processOpportunities[1] = r.withoutCandidateCount;
    });
  }

  getCandidateAndInterviews() {
    this.candidateService.getCandidatesAndInterviews().subscribe(r => {
      this.showHTML = true;
      if (r.percentCandidates) {
        this.percentCandidates = r.percentCandidates.toFixed(1);
      } else {
        this.percentCandidates = 0;
      }
      if (r.percentInteractions) {
        this.percentInteractions = r.percentInteractions.toFixed(1);
      } else {
        this.percentInteractions = 0;
      }

      r.candidates.forEach(candidates => {
        this.data.datasets[0].data[candidates.day - 1] = candidates.count;
      });

      r.interactions.forEach(interactions => {
        this.data.datasets[1].data[interactions.day - 1] = interactions.count;
      });
    })
  }

  daysInMonth(month, year) {
    return new Date(year, month, 0).getDate();
  }

  getSla() {
    this.opportunityService.getSla().subscribe(r => {
      this.sla = r;
    })
  }

  turnModal() {
    this.modal = !this.modal;
  }
}
