import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from '../../shared/shared.module';
import { ChartModule } from 'primeng/primeng';

export const CleanRoutes: Routes = [
  {
    path: '',
    data: {
      heading: 'Dashboard'
    }
  }
];

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(CleanRoutes),
    SharedModule,
    ChartModule,
  ],
  declarations: []
})
export class DashboardCleanModule { }
