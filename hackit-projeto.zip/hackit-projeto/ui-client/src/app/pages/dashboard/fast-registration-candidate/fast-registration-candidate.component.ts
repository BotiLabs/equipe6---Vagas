import { Component, OnInit, Output, EventEmitter, ViewChild } from '@angular/core';
import { CandidateModel } from '../../../models/candidate.model';
import { EnumsHelper } from '../../../common/enums-helper';
import { CandidateService } from '../../../../../_services/candidate.service';
import { PositionService } from '../../../../../_services/position.service';

@Component({
  selector: 'app-fast-registration-candidate',
  templateUrl: './fast-registration-candidate.component.html',
  styleUrls: ['./fast-registration-candidate.component.css']
})

export class FastRegistrationCandidateComponent implements OnInit {
  candidateModel: CandidateModel = new CandidateModel();
  files;
  uploading: boolean = false;
  enumsHelper: EnumsHelper = new EnumsHelper();
  @ViewChild('file') fileInput: any;
  @Output() closeModal = new EventEmitter;
  ddlpositions: any;
  constructor(
    private candidateService: CandidateService,
    private positionService: PositionService
  ) {
    this.ddlpositions = this.positionService.getPositions();
  }

  ngOnInit() {
  }

  close() {
    this.closeModal.emit();
  }

  onChange(files: FileList) {
    if (files.length > 0) {
      this.files = files;
      this.uploadCurriculum();
    }
    else {
      this.files = undefined;
    }
  }

  uploadCurriculum() {
    this.uploading = true;
    let candidate = new CandidateModel()
    if (this.files) {
      candidate['file'] = this.files;
    }
    this.candidateService.uploadCurriculum(candidate).subscribe(r => {
      this.candidateModel.skills = [];
      if (r.secondarySkills)
        if (r.secondarySkills.length > 0) {

          r.secondarySkills.forEach(skill => {
            if (this.candidateModel.skills.find(x => x == skill) == undefined) {
              this.candidateModel.skills.push(skill)
            }
          });

        }

      this.candidateModel.email = r.email;
      this.candidateModel.linkedinUrl = r.linkedinUrl;
      this.candidateModel.curriculum = r.curriculum;
      this.uploading = false;
      this.enumsHelper.toast("Currículo importado com sucesso!", "success");
    }, err => {
      this.enumsHelper.toast(err.Errors.message, "warning");
      this.uploading = false;
    })
  }

  deleteCurriculum() {
    this.candidateModel.curriculum = "";
    this.files = undefined;
    this.fileInput.nativeElement.value = "";
    this.candidateModel.skills = [];
    this.candidateModel.email = "";
    this.candidateModel.linkedinUrl = "";
  }

  saveCandidate() {
    this.candidateService.add(this.candidateModel).subscribe(r => {
      this.enumsHelper.toast("Candidato cadastrado com sucesso!", "success");
      this.candidateModel = new CandidateModel();
      //Analytcs event
      this.enumsHelper.sendEventAnalytcs("Cadastrar candidato", this.candidateModel.name, "Cadastrou candidato via cadastro rápido");
      this.closeModal.emit();
    }, err => {
      this.enumsHelper.toast(err.Errors.message, "warning")
    })
  }
}
