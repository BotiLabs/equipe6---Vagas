import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FastRegistrationCandidateComponent } from './fast-registration-candidate.component';

describe('FastRegistrationCandidateComponent', () => {
  let component: FastRegistrationCandidateComponent;
  let fixture: ComponentFixture<FastRegistrationCandidateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FastRegistrationCandidateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FastRegistrationCandidateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
