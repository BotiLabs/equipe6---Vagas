import { StatusOfOpportunityModel } from './../../../models/statusOfOpportunity.model';
import { StatusOfOpportunityService } from './../../../../../_services/statusOpportuniry.service';
import { PriorityOpportunity } from './../../../common/priority';
import { Component, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { OpportunityService } from '../../../../../_services/opportunity.service';
import { SearchOp } from '../../../../../_services/searchOp.service';
import { OpportunitiesRequest } from '../../../common/opportunities.request';
import { StatusOpportunity } from '../../../common/status-opportunity';
import { EnumsHelper } from '../../../common/enums-helper';
import { OpportunityModel } from '../../../models/opportunity.model';
import { TagService } from '../../../../../_services/tag.service';
import { BusinessUnit } from '../../../common/business-unit';
import { NotificationService } from '../../../../../_services/notification.service';
import { MatchService } from '../../../../../_services/match.service';
import { PersistenceService } from 'angular-persistence';
import { SearchOpModel } from '../../../models/searchOp.model';
import { AuthService } from '../../../../../_services/auth.service';
import { SearchOpRequest } from '../../../common/search-opp.request';
import { LogsComponent } from '../../logs/logs.component';
import * as moment from 'moment';
import '../../../../assets/plugins/toast-master/js/jquery.toast.js';
import { LocationModel } from './../../../models/location.model';
import { CustomerModel } from './../../../models/customerModel';
import { UserModel } from '../../../models/user.model';
import { TagModel } from '../../../models/tag.model';
import { Observable } from 'rxjs/Rx';
import * as XLSX from 'xlsx';
import { DpartamentService } from '../../../../../_services/dpartament.service';
import { DepartamentModel } from './../../../models/departament.model';
moment.locale('pt-BR');
declare var $: any;
@Component({
    selector: 'app-opportunities',
    templateUrl: './opportunities.component.html',
    styleUrls: ['./opportunities.component.css'],
    encapsulation: ViewEncapsulation.None
})

export class OpportunitiesComponent implements OnInit {
    @ViewChild('myTable') myTable: any;
    ativo: boolean = false;
    tamanhoFonte: number = 10;
    table: any;
    rows: any[] = [];
    expanded: any = {};
    timeout: any;
    title: string;
    subtitle: string;
    opportunitiesRequest: OpportunitiesRequest = new OpportunitiesRequest();
    statusList: StatusOpportunity[];
    enumsHelper: EnumsHelper = new EnumsHelper();
    opportunities: OpportunityModel[];
    opportunitiesModal: OpportunityModel[];
    showFeedBack: boolean;
    ddlBusinessUnit: BusinessUnit[];
    cache: boolean;
    limit: number = 20;
    totalItems: number;
    totalItemsModal: number;
    searchOpRequest: SearchOpRequest = new SearchOpRequest;
    searchs: SearchOpModel[];
    searchOpModel: SearchOpModel = new SearchOpModel();
    itemsPerPage: number[] = [10, 50, 100];
    itemsPerPageModal: number[] = [10, 50, 100];
    opportunitiesBystatus;
    opportunitiesBystatusModal2;
    validation: boolean = false;
    statusSort: [number, number, number, number, number, number, number, number, number] = [0, 0, 0, 0, -1, 0, 0, 0, 0];
    opportunitiesSort: any;
    advancedSearch: boolean = false;
    ddlProfile: any;
    initialDate: Date;
    query: any;
    validatorSort: number;
    ddlPriority: PriorityOpportunity[];
    custumerName: any;
    sortOpportunity: boolean = false;
    idSort: number;
    sortValid: boolean = false;
    rotationE: boolean = false;
    statusNotification: number = -1;
    opportunitiesLoaded: boolean = false;
    opportunitiesLoadedModal: boolean = false;
    count: number;
    countModal: number = 0;
    statusParam: number = -1;
    page: number;
    customerN: String;
    customer: any[];
    location: any[];
    finalDate: Date;
    watchEmail: string;
    users: UserModel[] = [];
    user = new UserModel();
    assistir = " Acompanhar vaga";
    tags: TagModel[] = [];
    statusOfOpportunityArray: StatusOfOpportunityModel[] = [];
    selectedCustomer: CustomerModel = new CustomerModel();
    locationFilter = [];
    disable: string = "disabled";
    involvedPeopleItem: {}
    involvedPeopleItems = [];
    involvedPeopleList = [];
    involvedPeopleDropdownSettings: {};
    business = [];

    constructor(private opportunityService: OpportunityService,
        private router: Router,
        private route: ActivatedRoute,
        public tagService: TagService,
        private notificationService: NotificationService,
        private matchService: MatchService,
        private persistenceService: PersistenceService,
        private searchOp: SearchOp,
        private authService: AuthService,
        private logs: LogsComponent,
        private departament: DpartamentService,
        private statusOfOpportunityService: StatusOfOpportunityService) {
        this.title = "Pesquisar Vagas";
        this.subtitle = "Encontre vagas por Skills, Unidade de Negócio, Localização, Clientes etc.";
        this.involvedPeopleDropdownSettings = {
            singleSelection: false,
            text: "Selecione...",
            selectAllText: 'Marcar todos',
            unSelectAllText: 'Desmarcar todos',
            enableSearchFilter: true,
            classes: "myclass custom-class",
            badgeShowLimit: 1,
            searchBy: ["itemName"]
        };
        (<any>window).ga('set', 'page', 'Grid de vagas');
        (<any>window).ga('send', 'pageview');
    }

    ngOnInit() {
        this.getallDepartaments();
        this.getAllStatus();
        this.getAllTags();
        this.getUsers();
        this.statusParam = parseInt(this.route.snapshot.params['status']);
        this.table = true;
        this.ddlProfile = this.enumsHelper.getEnumProfileCandidateArray();
        this.ddlPriority = this.enumsHelper.getEnumPrioritOpportunity();
        this.ddlBusinessUnit = this.enumsHelper.getBusinessUnitArray();
        this.validation = false;
        this.showFeedBack = false;
        this.opportunities = new Array<OpportunityModel>();
        this.statusList = this.enumsHelper.getEnumStatusOpportunityArray();
        this.enumsHelper.getDescriptionStatusOpportunity;

        //Cache
        if (this.persistenceService.get('nameOpportunity')) {
            this.opportunitiesRequest.name = this.persistenceService.get('nameOpportunity');
        }
        if (this.persistenceService.get('customerName')) {
            this.opportunitiesRequest.customerName = this.persistenceService.get('customerName');
        }

        if (this.persistenceService.get('location')) {
            this.opportunitiesRequest.location = this.persistenceService.get('location');
        }

        if (this.persistenceService.get('responsible')) {
            this.opportunitiesRequest.responsible = this.persistenceService.get('responsible');
        }
        if (localStorage.getItem('email')) {
            this.watchEmail = localStorage.getItem('email');
        }
        if (this.persistenceService.get('businessUnit') != null) {
            this.opportunitiesRequest.businessUnit = this.persistenceService.get('businessUnit');
        }
        if (this.persistenceService.get('statusOpportunity') != null) {
            this.opportunitiesRequest.status = this.persistenceService.get('statusOpportunity');
        }
        this.opportunitiesRequest.number = this.persistenceService.get('number');
        if (this.opportunitiesRequest.location == "") {
            this.opportunitiesRequest.status == undefined;
        }
        this.opportunitiesRequest.specialities = this.persistenceService.get('specialites'[0]);
        if (this.statusParam > -1) {
            this.opportunitiesRequest.status = this.statusParam;
        }
        this.searchOpportunities(1, false);

        $('.tst1').on('click', () => {
            setTimeout(() => {
                switch (this.statusNotification) {
                    case 0:
                        this.enumsHelper.toast("Pesquisa cadastrada com sucesso!", "success");
                        break;
                    case 1:
                        this.enumsHelper.toast("Já existe uma pesquisa com este nome, Digite outro nome", "warning");
                        break;
                    case 2:
                        this.enumsHelper.toast("O nome da pesquisa não pode começar com caracteres especiais e não pode terminar com espaço em branco", "warning");
                        break;
                    case 3:
                        this.enumsHelper.toast("A pesquisa deve ter um nome", "warning");
                        break;
                    case 4:
                        this.enumsHelper.toast("Pelo menos um campo deve ser preenchido", "warning");
                        break;
                }
            }, 1500);
        });
        this.getLocation();
        this.getCostumerName();
    }




    getUsers() {
        this.authService.getUsersDrop().subscribe(r => {
            for (let u of r) {
                let user = new UserModel();
                user.loadUserModel(u);
                this.involvedPeopleItem = {
                    id: user.fullName, itemName: user.fullName
                }
                this.involvedPeopleList.push(this.involvedPeopleItem)
            }
        }, err => {
            this.enumsHelper.toast(err.Errors.message, "warning")
        })
    }

    getLocation() {
        this.location = [];
        this.opportunityService.getLocation().subscribe(r => {
            for (let cr of r) {
                let cN = new LocationModel;
                cN.loadFromServer(cr)
                this.location.push(cN);
            }
            this.location.sort(function (a, b) {
                if (a.discription > b.discription) {
                    return 1;
                }
                if (a.discription < b.discription) {
                    return -1;
                }
                return 0;
            });
            this.locationFilter = this.location;
            if (this.persistenceService.get('customerId')) {
                let arr = this.location.filter(x => x.clientLocation == this.persistenceService.get('customerId'));
                this.locationFilter = arr;
            }
        });
    }


    getAllStatus() {
        this.statusOfOpportunityService.getAll().subscribe(status => {
            this.statusOfOpportunityArray = [];
            for (let statuOpp of status) {
                let statusLoaded = new StatusOfOpportunityModel();
                statusLoaded.loadModelFromServer(statuOpp);
                this.statusOfOpportunityArray.push(statusLoaded);
            }
        })
    }

    searchOpportunities(page, scroll: boolean) {
        this.opportunitiesLoaded = false;
        this.disable = "disabled"
        this.page = page;
        if (this.initialDate && this.opportunitiesRequest.registrationDate) {
            if (this.initialDate > this.opportunitiesRequest.registrationDate) {
                this.enumsHelper.toast("A data inicial não pode ser maior que a data final.", "warning");
                return;
            }
        }
        if (!this.opportunitiesRequest.value) {
            this.opportunitiesRequest.value = undefined;
        }

        //Cache of search opportunity
        if (this.opportunitiesRequest.number == null) {
            this.opportunitiesRequest.number = undefined;
        }

        this.showFeedBack = false;
        this.opportunitiesRequest.page = page;

        if (this.finalDate) {
            var dateCalc = Date.parse(this.finalDate.toString())
            var finalDate = dateCalc + 75599999;
            this.opportunitiesRequest.registrationDate = finalDate;
        }
        this.setCache();
        if (this.initialDate) {
            var initialDateCalc = Date.parse(this.initialDate.toString());
            var initialDate = initialDateCalc - 10800000;
            this.opportunitiesRequest['initialDate'] = this.initialDate;
        }

        if (!scroll) {
            this.opportunities = [];
        }

        this.opportunitiesRequest.limit = this.limit;

        this.opportunityService.search(this.opportunitiesRequest).subscribe(r => {
            this.opportunitiesLoaded = true;
            this.enumsHelper.sendEventAnalytcs("Busca de vaga", this.opportunitiesRequest.name, "Buscou uma vaga");
            this.totalItems = r.count;
            for (let item of r.result) {
                let opp = new OpportunityModel();
                opp.loadModelFromServer(item);

                if (opp.priority == undefined) {
                    opp.priority = 0;
                }
                this.opportunities.push(opp);

            }
            //this.opportunities = this.opportunities.sort((one, two) => (one.statusName < two.statusName ? -1 : 1));
            this.count = r.count;
            this.opportunitiesLoaded = true;
            if (this.opportunities.length > 0)
                this.disable = "";
        }, err => {
            this.enumsHelper.toast(err.Errors.message, "warning");
        });

    }

    setCache() {
        this.cache = true;
        this.persistenceService.set('nameOpportunity', this.opportunitiesRequest.name);
        this.persistenceService.set('customerName', this.opportunitiesRequest.customerName);
        this.persistenceService.set('location', this.opportunitiesRequest.location);
        this.persistenceService.set('businessUnit', this.opportunitiesRequest.businessUnit);
        this.persistenceService.set('statusOpportunity', this.opportunitiesRequest.status);
        this.persistenceService.set('cache', this.cache);
        this.persistenceService.set('responsible', this.opportunitiesRequest.responsible);

        if (this.selectedCustomer._id) {
            this.persistenceService.set('customerId', this.selectedCustomer._id);
        }
        if (this.opportunitiesRequest.specialities != undefined) {
            for (var i = 0; i <= this.opportunitiesRequest.specialities.length; i++) {
                this.persistenceService.set('specialites'[i], this.opportunitiesRequest.specialities);

            }
        }
        this.persistenceService.set('number', this.opportunitiesRequest.number);
    }

    clearInitialDate() {
        this.initialDate = undefined;
        this.opportunitiesRequest['initialDate'] = undefined;
    }
    clearFinalDate() {
        this.finalDate = undefined;
        this.opportunitiesRequest.registrationDate = undefined;
    }

    formatDate(registrationDate: Date) {
        return moment(registrationDate).format('L');
    }

    formatTime(registrationDate: Date) {
        return moment(registrationDate).format('LT');
    }

    filterOpportunities(statusOpportunity: StatusOpportunity) {
        return this.opportunities.filter(x => x.status == statusOpportunity);
    }

    onSort(event) {
        this.opportunitiesRequest.priority = -1;
        // event was triggered, start sort sequence
        switch (this.statusSort[event]) {
            case 0:
                switch (event) {
                    case 0:
                        this.statusSort[event] = 1;
                        this.statusSort[1] = 0;
                        this.statusSort[2] = 0;
                        this.statusSort[3] = 0;
                        this.statusSort[4] = -1;
                        this.statusSort[6] = 0;
                        this.opportunitiesRequest.sort = { "query": { "name": 1 } }
                        break;
                    case 1:
                        this.statusSort[event] = 1;
                        this.statusSort[0] = 0;
                        this.statusSort[2] = 0;
                        this.statusSort[3] = 0;
                        this.statusSort[4] = -1;
                        this.statusSort[5] = 0;
                        this.statusSort[6] = 0;
                        this.opportunitiesRequest.sort = { "query": { "customerName": 1 } }
                        break;
                    case 2:
                        this.statusSort[event] = 2;
                        this.statusSort[0] = 0;
                        this.statusSort[1] = 0;
                        this.statusSort[3] = 0;
                        this.statusSort[4] = -1;
                        this.statusSort[5] = 0;
                        this.statusSort[6] = 0;
                        this.opportunitiesRequest.sort = { "query": { "opportunityLocation.district": 1 } }
                        break;
                    case 3:
                        this.statusSort[event] = 1;
                        this.statusSort[0] = 0;
                        this.statusSort[1] = 0;
                        this.statusSort[2] = 0;
                        this.statusSort[4] = -1;
                        this.statusSort[5] = 0;
                        this.statusSort[6] = 0;
                        this.opportunitiesRequest.sort = { "query": { "statusJoin.name": 1 } }
                        break;
                    case 5:
                        this.statusSort[event] = 1;
                        this.statusSort[0] = 0;
                        this.statusSort[1] = 0;
                        this.statusSort[2] = 0;
                        this.statusSort[4] = -1;
                        this.statusSort[6] = 0;
                        this.opportunitiesRequest.sort = { "query": { "number": 1 } }
                        break;
                    case 6:
                        this.statusSort[event] = 1;
                        this.statusSort[0] = 0;
                        this.statusSort[1] = 0;
                        this.statusSort[2] = 0;
                        this.statusSort[4] = -1;
                        this.statusSort[5] = 0;
                        this.opportunitiesRequest.sort = { "query": { "candidatesLength": 1 } }
                        break;
                }
                break;
            case 1:
                switch (event) {
                    case 0:
                        this.statusSort[event] = 2;
                        this.statusSort[1] = 0;
                        this.statusSort[2] = 0;
                        this.statusSort[3] = 0;
                        this.statusSort[4] = -1;
                        this.statusSort[6] = 0;
                        this.opportunitiesRequest.sort = { "query": { "name": -1 } }
                        break;
                    case 1:
                        this.statusSort[event] = 2;
                        this.statusSort[0] = 0;
                        this.statusSort[2] = 0;
                        this.statusSort[3] = 0;
                        this.statusSort[4] = -1;
                        this.statusSort[5] = 0;
                        this.statusSort[6] = 0;
                        this.opportunitiesRequest.sort = { "query": { "customerName": -1 } }
                        break;
                    case 2:
                        this.statusSort[event] = 2;
                        this.statusSort[0] = 0;
                        this.statusSort[1] = 0;
                        this.statusSort[3] = 0;
                        this.statusSort[4] = -1;
                        this.statusSort[5] = 0;
                        this.statusSort[6] = 0;
                        this.opportunitiesRequest.sort = { "query": { "opportunityLocation.district": -1 } }
                        break;
                    case 3:
                        this.statusSort[event] = 2;
                        this.statusSort[0] = 0;
                        this.statusSort[1] = 0;
                        this.statusSort[2] = 0;
                        this.statusSort[4] = -1;
                        this.statusSort[5] = 0;
                        this.statusSort[6] = 0;
                        this.opportunitiesRequest.sort = { "query": { "statusJoin.name": -1 } }
                        break;
                    case 5:
                        this.statusSort[event] = 2;
                        this.statusSort[0] = 0;
                        this.statusSort[1] = 0;
                        this.statusSort[2] = 0;
                        this.statusSort[4] = -1;
                        this.statusSort[6] = 0;
                        this.opportunitiesRequest.sort = { "query": { "number": -1 } }
                        break;
                    case 6:
                        this.statusSort[event] = 2;
                        this.statusSort[0] = 0;
                        this.statusSort[1] = 0;
                        this.statusSort[2] = 0;
                        this.statusSort[4] = -1;
                        this.statusSort[5] = 0;
                        this.opportunitiesRequest.sort = { "query": { "candidatesLength": -1 } }
                        break;
                }
                break;
            case 2:
                this.opportunitiesRequest.sort = undefined;
                this.statusSort[event] = 0;
                break;
        }
        this.searchOpportunities(1, false);
    }

    filterPriority(event) {
        this.opportunitiesRequest.priority = -1;
        switch (this.statusSort[event]) {
            case -1:
                this.statusSort[event] = 0;
                this.statusSort[0] = 0;
                this.statusSort[1] = 0;
                this.statusSort[2] = 0;
                this.statusSort[3] = 0;
                this.statusSort[5] = 0;
                this.opportunitiesRequest.priority = 0
                break;
            case 0:
                this.statusSort[event] = 1;
                this.statusSort[0] = 0;
                this.statusSort[1] = 0;
                this.statusSort[2] = 0;
                this.statusSort[3] = 0;
                this.statusSort[5] = 0;
                this.opportunitiesRequest.priority = 1
                break;
            case 1:
                this.statusSort[event] = 2;
                this.statusSort[0] = 0;
                this.statusSort[1] = 0;
                this.statusSort[2] = 0;
                this.statusSort[3] = 0;
                this.statusSort[5] = 0;
                this.opportunitiesRequest.priority = 2
                break;
            case 2:
                this.statusSort[event] = -1;
                this.statusSort[0] = 0;
                this.statusSort[1] = 0;
                this.statusSort[2] = 0;
                this.statusSort[3] = 0;
                this.statusSort[5] = 0;
                this.opportunitiesRequest.priority = -1
                break;
            default:
                break;
        }
        this.searchOpportunities(1, false);
    }

    modalOp(row) {
        if (row.specialities != "") {
            this.opportunityService.searchOpSkills(row).subscribe(r => {

                this.totalItemsModal = r.count;
                this.opportunitiesModal = [];
                // this.opportunitiesRequest.limit = this.limitModal
                for (let item of r.result) {
                    let opp = new OpportunityModel();
                    opp.loadModelFromServer(item);
                    if (opp.priority == undefined) {
                        opp.priority = 0;
                    }
                    this.opportunitiesModal.push(opp);

                }
                this.countModal = r.result.length;
                this.opportunitiesBystatusModal2 = this.opportunitiesModal;
                this.opportunitiesLoadedModal = true;
            });
        } else {
            console.log("vazio");
        }
    }


    watch(opportunity) {
        this.ativo = !this.ativo;

        this.users = [];
        this.authService.getUsers().subscribe(r => {
            for (let u of r.result) {
                // var user = new UserModel();
                // user = u;  
                this.users.push(u);
            }


            for (let i = 0; i < this.users.length; i++) {
                if (this.users[i].email == this.watchEmail) {
                    this.user = this.users[i];

                    var l = this.user.watch.indexOf(opportunity._id);

                    if (l <= -1) {
                        opportunity.emailWatching.push(this.watchEmail);

                        this.opportunityService.update(opportunity).subscribe(op => {
                            var message = "Alterou a Vaga de numero " + opportunity.number + " do cliente " + opportunity.customerName;
                            this.logs.create(message);
                        });

                        this.user.watch.push(opportunity._id);
                        this.authService.updateUser2(this.user).subscribe(res => {
                        })
                        this.assistir = " Acompanhando"
                    } else {

                        var n = opportunity.emailWatching.indexOf(this.watchEmail);
                        if (n >= 0) {
                            opportunity.emailWatching.splice(n, 1);

                            this.opportunityService.update(opportunity).subscribe(op => {
                                var message = "Alterou a Vaga de numero " + opportunity.number + " do cliente " +
                                    this.logs.create(message);
                            });
                        }

                        var m = this.user.watch.indexOf(opportunity._id);
                        if (m >= 0) {
                            this.user.watch.splice(m, 1);
                        }

                        this.authService.updateUser2(this.user).subscribe(res => {
                        })

                        this.assistir = " Acompanhar vaga"
                    }
                }
            }
        })
    }

    isWatching(row) {
        if (row.emailWatching && row.emailWatching.indexOf(this.watchEmail) >= 0) return "Acompanhando"; else return "Acompanhar vaga";
    }

    getAllTags() {
        this.tagService.getAll().subscribe(tg => {
            for (let t of tg) {
                var tag = new TagModel();
                tag.loadTag(t);
                this.tags.push(tag);
            }
        })
    }

    itemsRequest = (text: string): Observable<Array<string>> => {
        let tags = new Array<string>();

        var obs = new Observable<Array<string>>(observer => {

            this.tags.forEach(tag => {
                if (tag.name.indexOf(text)) {
                    tags.push(tag.name)
                }
            });

            observer.next(tags);
        });

        return obs;
    }

    populateCustomer(customer) {

        if (!customer) {
            this.selectedCustomer = new CustomerModel();
            this.locationFilter = this.location;
        } else {
            this.opportunitiesRequest.location = "";
            let customerObj = this.customer.find(x => x.name == customer);
            this.selectedCustomer.loadFromServer(customerObj);
            let arr = this.location.filter(x => x.clientLocation == customerObj._id);
            this.locationFilter = arr;
        }
    }

    loadStatus(status: number) {
        let obj = this.statusOfOpportunityArray.find(x => x.number == status);
        if (obj)
            return obj;
    }

    exportList() {
        this.opportunityService.exportList(this.opportunitiesRequest).subscribe(r => {
            if (r.length > 0) {
                const ws: XLSX.WorkSheet = XLSX.utils.aoa_to_sheet(r);

                /* generate workbook and add the worksheet */
                const wb: XLSX.WorkBook = XLSX.utils.book_new();
                XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');

                /* save to file */
                XLSX.writeFile(wb, 'Vagas.xlsx');
                this.enumsHelper.sendEventAnalytcs("Exportar lista de vagas", this.opportunitiesRequest.name, "Exportou lista de vagas");
            } else {
                this.enumsHelper.toast("Não há dados para exportar.", "warning")
            }
        }, err => {
            this.enumsHelper.toast(err.Errors.message, "warning")
        })

    }

    //Involved People methods

    populateInvolvedPeople() {
        if (this.involvedPeopleItems.length > 0) {
            this.involvedPeopleItems.forEach(i => {
                this.opportunitiesRequest.involvedPeople.push(i.itemName)
            })
        } else {
            this.opportunitiesRequest.involvedPeople = [];
        }
    }

    unpopulateInvolvedPeople() {
        this.opportunitiesRequest.involvedPeople = [];
        if (this.involvedPeopleItems.length > 0) {
            this.involvedPeopleItems.forEach(i => {
                this.opportunitiesRequest.involvedPeople.push(i.itemName)
            })
        } else {
            this.opportunitiesRequest.involvedPeople = [];
        }
    }

    populateInvolvedPeopleAll(event) {
        this.opportunitiesRequest.involvedPeople = [];
        if (this.involvedPeopleItems.length > 0) {
            event.forEach(e => {
                this.opportunitiesRequest.involvedPeople.push(e.itemName);
            });
        } else {
            this.opportunitiesRequest.involvedPeople = [];
        }
    }

    getallDepartaments() {
        this.departament.getAll().subscribe(data => {
            for (let dept of data) {
                let dpt = new DepartamentModel;
                dpt.loadFromServer(dept);
                this.business.push(dpt);
            }

            this.business.sort(function (a, b) {
                if (a.name > b.name) {
                    return 1;
                }
                if (a.name < b.name) {
                    return -1;
                }
                return 0;
            });
        }, err => {
            console.log(err);
        });
    }

    getCostumerName() {
        this.customer = [];
        this.opportunityService.getCustomer().subscribe(r => {
            for (let cr of r.result) {
                let cN = new CustomerModel;
                cN.loadFromServer(cr)
                this.customer.push(cN);
            }
            //sorting dropdowns
            this.customer.sort(function (a, b) {
                if (a.name > b.name) {
                    return 1;
                }
                if (a.name < b.name) {
                    return -1;
                }
                return 0;
            });
        });

    }
    onScroll() {
        if (this.opportunities.length > 0) {
            this.page++;
            this.searchOpportunities(this.page, true);
        }
    }
}