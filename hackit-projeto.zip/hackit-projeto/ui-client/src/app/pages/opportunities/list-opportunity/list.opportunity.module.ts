import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { OpportunitiesComponent } from './opportunities.component';
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from '../../../shared/shared.module';
import { CurrencyMaskModule } from "ng2-currency-mask";
import { InputTrimModule } from 'ng2-trim-directive';
import { AngularMultiSelectModule } from 'angular2-multiselect-dropdown/angular2-multiselect-dropdown';
import { InfiniteScrollModule } from 'ngx-infinite-scroll';

export const ListOpportunitiesRoutes: Routes = [
  {
    path: '',
    component: OpportunitiesComponent,
    data: {
      heading: 'Listagem de vagas',
      status: false
    }
  }
];

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(ListOpportunitiesRoutes),
    SharedModule,
    CurrencyMaskModule,
    InputTrimModule,
    AngularMultiSelectModule,
    InfiniteScrollModule
  ],
  declarations: [OpportunitiesComponent]
})
export class ListOpportunityModule { }
