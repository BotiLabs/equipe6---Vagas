import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { OpportunitiesComponent } from './list-opportunity/opportunities.component';
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from '../../shared/shared.module';



export const OpportunitiesRoutes: Routes = [
  {
    path: '',
    children: [
      {
        path: 'edit-opportunity',
        loadChildren: './edit-opportunity/edit-opportunity.module#EditOpportunityModule',
        data:{
          heading:"Criar uma vaga"
        }
      },
      {
        path: 'edit-opportunity/:id',
        loadChildren: './edit-opportunity/edit-opportunity.module#EditOpportunityModule',
        data:{
          heading:"Editar uma vaga"
        }
      },
      {
        path: 'duplicate/:id',
        loadChildren: './duplicate-opportunity/duplicateOpportunity.module#DuplicateOpportunityModule',
        data:{
          heading:"Duplicar vaga"
        }
      },
      {
        path: '',
        loadChildren: './list-opportunity/list.opportunity.module#ListOpportunityModule',
        data:{
          heading:"Listagem de vagas"
        }
      },
      {
        path: 'profile-opportunity/:id',
        loadChildren: './profile-opportunity/profile-opportunity.module#ProfileOpportunityModule',
        data:{
          heading:"Perfil de vagas"
        }
      },
    ]

  }
];

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(OpportunitiesRoutes)

  ],
  declarations: []
})
export class OpportunitiesModule { }
