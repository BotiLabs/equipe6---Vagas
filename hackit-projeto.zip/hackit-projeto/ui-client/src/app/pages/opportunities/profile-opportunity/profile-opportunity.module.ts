import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ProfileOpportunityComponent } from './profile-opportunity.component';
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from '../../../shared/shared.module';
import { ChartsModule } from 'ng2-charts';
import { AngularMultiSelectModule } from 'angular2-multiselect-dropdown/multiselect.component';
import { OpportunitiesComponent } from '../list-opportunity/opportunities.component';


export const ProfileOpportunityRoutes: Routes = [ 
  {
      path: '',
      component: ProfileOpportunityComponent,
      data:{
          heading: 'Perfil do Candidato'
      }
  }
];

@NgModule({
  imports: [
      CommonModule,
      RouterModule.forChild(ProfileOpportunityRoutes),
      SharedModule,
      ChartsModule,
      AngularMultiSelectModule
  ],
  declarations: [
    ProfileOpportunityComponent,
  ]
})
export class ProfileOpportunityModule {}
