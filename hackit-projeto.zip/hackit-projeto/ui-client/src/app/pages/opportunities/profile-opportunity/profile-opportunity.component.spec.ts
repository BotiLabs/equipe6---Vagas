import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProfileOpportunityComponent } from './profile-opportunity.component';

describe('ProfileOpportunityComponent', () => {
  let component: ProfileOpportunityComponent;
  let fixture: ComponentFixture<ProfileOpportunityComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProfileOpportunityComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProfileOpportunityComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
