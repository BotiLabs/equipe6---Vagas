import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { OpportunityService } from '../../../../../_services/opportunity.service';
import { map } from 'rxjs/operators';
import { EnumsHelper } from '../../../common/enums-helper';
import { StatusOfOpportunityService } from '../../../../../_services/statusOpportuniry.service';
import { CandidateModel } from '../../../models/candidate.model';
import { CandidatesRequest } from '../../../common/candidates.request';
import { PersistenceService } from 'angular-persistence';
import { OpportunityModel } from '../../../models/opportunity.model';
import { CandidateService } from '../../../../../_services/candidate.service';
import { StatusOfCandidateModel } from '../../../models/statusOfCandidate.model';
import { StatusOfCandidateService } from '../../../../../_services/statusCandidate.service';
import { AuthService } from '../../../../../_services/auth.service';


@Component({
  selector: 'app-profile-opportunity',
  templateUrl: './profile-opportunity.component.html',
  styleUrls: ['./profile-opportunity.component.css']
})
export class ProfileOpportunityComponent implements OnInit {
  opportunityId: string;
  fullOpportunity: any;
  enumsHelper: EnumsHelper = new EnumsHelper();
  candidates: CandidateModel[];
  statusSort: [number, number, number, number, number, number, number] = [0, 0, 0, 0, 0, 0, 0];
  candidatesRequest: CandidatesRequest = new CandidatesRequest();
  candidateModel: CandidateModel = new CandidateModel();
  page: number;
  candidatesLoaded: boolean = false;
  limit: number = 15;
  totalItems: number;
  opportunityModel: OpportunityModel = new OpportunityModel();
  canShowFeedback: boolean;
  statusOfCandidateArray: StatusOfCandidateModel[];
  userEmail: string;
  userName: string;
  noCandidates: boolean = true;
  opportunityStatus: any;
  opportunityPriority: any;
  opportunityPriorityColor: any;

  constructor(
    private route: ActivatedRoute,
    private opportunityService: OpportunityService,
    private statusOfOpportunityService: StatusOfOpportunityService,
    private persistenceService: PersistenceService,
    private candidateService: CandidateService,
    private statusOfCandidate: StatusOfCandidateService,
    private authService: AuthService,
  ) {
    this.find();
    this.getAllStatus();
  }


  ngOnInit() {


  }

  async find() {
    if (this.route.snapshot.params['id'] != undefined) {
      this.opportunityId = this.route.snapshot.params['id'];
    }
    await this.opportunityService.getById(this.opportunityId).map(r => {
      return this.fullOpportunity = r;
    }).toPromise();
    this.opportunityModel = this.fullOpportunity;
    this.opportunityPriority = this.enumsHelper.getPriority(this.fullOpportunity.priority)
    if (this.fullOpportunity.priority == 2) {
      this.opportunityPriorityColor = "#da0000";
    }

    if (this.fullOpportunity.priority == 1) {
      this.opportunityPriorityColor = "#f7ad01";
    }

    if (this.fullOpportunity.priority == 0) {
      this.opportunityPriorityColor = "#7fb16c";
    }


    this.statusOfOpportunityService.getAll().subscribe(res => {
      for (let i of res) {
        if (i.number == this.fullOpportunity.status) {
          this.opportunityStatus = i;
        }
      }
    });

    this.searchCandidates(1)
  }

  onSort(event) {
    // event was triggered, start sort sequence
    switch (this.statusSort[event]) {
      case 0:
        switch (event) {
          case 0:
            this.statusSort[event] = 1;
            this.statusSort[1] = 0;
            this.statusSort[2] = 0;
            this.statusSort[3] = 0;
            this.candidatesRequest.sort = { "query": { "noAscentName": 1 } }
            break;
          case 1:
            this.statusSort[event] = 1;
            this.statusSort[0] = 0;
            this.statusSort[2] = 0;
            this.statusSort[3] = 0;
            this.candidatesRequest.sort = { "query": { "phone": 1 } }
            break;
          case 2:
            this.statusSort[event] = 1;
            this.statusSort[0] = 0;
            this.statusSort[1] = 0;
            this.statusSort[3] = 0;
            this.candidatesRequest.sort = { "query": { "status": 1 } }
            break;
        }
        break;
      case 1:
        switch (event) {
          case 0:
            this.statusSort[event] = 2;
            this.statusSort[1] = 0;
            this.statusSort[2] = 0;
            this.statusSort[3] = 0;
            this.candidatesRequest.sort = { "query": { "noAscentName": -1 } }
            break;
          case 1:
            this.statusSort[event] = 2;
            this.statusSort[0] = 0;
            this.statusSort[2] = 0;
            this.statusSort[3] = 0;
            this.candidatesRequest.sort = { "query": { "phone": -1 } }
            break;
          case 2:
            this.statusSort[event] = 2;
            this.statusSort[0] = 0;
            this.statusSort[1] = 0;
            this.statusSort[3] = 0;
            this.candidatesRequest.sort = { "query": { "status": -1 } }
            break;
        }
        break;
      case 2:
        this.candidatesRequest.sort = undefined;
        this.statusSort[event] = 0;
        break;
    }
    this.searchCandidates(this.page);
  }

  searchCandidates(page: number) {
    //Cache of search
    this.persistenceService.set('name', this.candidatesRequest.name);
    this.persistenceService.set('statusCandidate', this.candidatesRequest.status);
    this.persistenceService.set('phone', this.candidatesRequest.phone);
    if (this.candidatesRequest.skills != undefined) {
      for (var i = 0; i <= this.candidatesRequest.skills.length; i++) {
        this.persistenceService.set(this.candidateModel.skills[i], this.candidatesRequest.skills);
      }
    }

    this.candidates = [];
    this.page = page;
    this.candidatesLoaded = false;
    this.candidatesRequest.page = page;
    this.candidatesRequest.limit = this.limit;
    this.candidatesRequest.name ? this.candidatesRequest.name = this.enumsHelper.validateAscentClientname(this.candidatesRequest.name) : this.candidatesRequest.name;
    this.candidatesLoaded = true;
    this.candidates = [];
    this.totalItems = this.opportunityModel.candidates.length;
    for (let i = 0; i < this.opportunityModel.candidates.length; i++) {
      let candidateId = this.opportunityModel.candidates[i];

      this.candidateService.getById(candidateId).subscribe(can => {
        let candidate = new CandidateModel();
          candidate = can;
        this.candidateService.searchRecruiter(can._id).subscribe(c => {

          this.noCandidates = false;
          if (c.length != 0) {
            let fullname = c[0].user.firstName + " " + c[0].user.lastName;
            candidate.userEmail = fullname;
          } else {
            candidate.userEmail = "Sem Recrutador";
          }
          this.candidates.push(candidate);

        })
      })

    }

    this.canShowFeedback = true;
  }

  loadStatus(status: number) {

    if (this.statusOfCandidateArray) {
      let obj = this.statusOfCandidateArray.find(x => x.number == status);
      if (obj)
        return obj;
    }
  }

  getAllStatus() {
    this.statusOfCandidate.getAll().subscribe(status => {
      this.statusOfCandidateArray = [];
      for (let statusC of status) {
        let statusLoaded = new StatusOfCandidateModel();
        statusLoaded.loadModelFromServer(statusC);
        this.statusOfCandidateArray.push(statusLoaded);
      }
    })
  }

  // getUserByEmail(){
  //   console.log("ENTROU")
  //   this.authService.findUserByEmail(this.userEmail).pipe(map(res => {
  //     console.log(res)
  //   }));
  // }

}
