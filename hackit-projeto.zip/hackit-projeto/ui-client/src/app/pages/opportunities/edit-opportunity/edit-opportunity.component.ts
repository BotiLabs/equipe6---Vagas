import { SelectedPeopleModel } from './../../../models/selectedPeople.model';
import { PriorityOpportunity } from './../../../common/priority';
import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

import { StatusOpportunity } from '../../../common/status-opportunity';
import { EnumsHelper } from '../../../common/enums-helper';
import { OpportunityModel } from '../../../models/opportunity.model';
import { CandidateModel } from '../../../models/candidate.model';
import { OpportunityService } from '../../../../../_services/opportunity.service';
import { CandidateService } from '../../../../../_services/candidate.service';
import { NotificationService } from '../../../../../_services/notification.service';
import { TagService } from '../../../../../_services/tag.service';
import { ProfileCandidate } from '../../../common/profile-candidate';
import { BusinessUnit } from '../../../common/business-unit';
import { LogsComponent } from '../../logs/logs.component';
import { TagsRequest } from '../../../common/tags.request';
import { TagModel } from '../../../models/tag.model';
import { Location } from '@angular/common';
import { LocationModel } from './../../../models/location.model';
import { Observable } from 'rxjs/Rx';
import { CustomerModel } from './../../../models/customerModel';
import { StatusOfCandidateService } from '../../../../../_services/statusCandidate.service';
import * as moment from 'moment';
import '../../../../assets/plugins/toast-master/js/jquery.toast.js';
import { IOption } from 'ng-select';
import { PersistenceService } from 'angular-persistence';
import { CandidatesRequest } from '../../../common/candidates.request';
import { StatusOfCandidateModel } from '../../../models/statusOfCandidate.model';
import { InvolvedPeople } from '../../../models/involvedPeople';
import { AuthService } from '../../../../../_services/auth.service';
import { PositionOpportunityService } from '../../../../../_services/position-opportunity.service';
import { UserModel } from '../../../models/user.model';
import { DpartamentService } from '../../../../../_services/dpartament.service';
import { DepartamentModel } from './../../../models/departament.model';
import { FunctionService } from '../../../../../_services/function.service';
import { FunctionModel } from '../../../models/function.model';
import { OpportunitiesRequest } from '../../../common/opportunities.request';
import { InteractionService } from '../../../../../_services/interaction.service';
import { InteractionModel } from '../../../models/interaction.model';
import { StatusCandidate } from '../../../common/status-candidate';



moment.locale('pt-BR');
declare var $: any;
@Component({
  selector: 'app-edit-opportunity',
  templateUrl: './edit-opportunity.component.html',
  styleUrls: ['./edit-opportunity.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class EditOpportunityComponent implements OnInit {
  states: String[] = ["AC", "AL", "AM", "AP", "BA", "CE", "DF", "ES", "GO", "MA", "MT", "MS", "MG", "PA", "PB", "PR", "PE", "PI", "RJ", "RN", "RO", "RS", "RR", "SC", "SE", "SP", "TO"];
  enumsHelper: EnumsHelper = new EnumsHelper();
  statusOpportunity: StatusOpportunity;
  ddlStatus: StatusOpportunity[];
  ddlProfile: ProfileCandidate[];
  opportunityModel: OpportunityModel = new OpportunityModel();
  canShowFeedback: boolean;
  ddlBusinessUnit: BusinessUnit[];
  candidateModel: CandidateModel = new CandidateModel();
  opportunitieCandidates: CandidateModel[] = [];
  nameDiscription: string;
  ddlPriority: PriorityOpportunity[];
  tagRequest: TagsRequest = new TagsRequest();
  statusTag: string = "";
  tagModel: TagModel = new TagModel();
  searchSaveStatus: number = -1;
  data
  valueOpp: boolean = false;
  customerN: String;
  customer: any[];
  customerModel: CustomerModel = new CustomerModel();
  location: any[];
  locationModel: LocationModel = new LocationModel();
  qtdOpp: number;
  qtdOppInit: number;
  showHistoric: boolean = false;
  dropDownItemSpecialitie: IOption;
  dropdownListSpecialities: Array<IOption> = [];
  selectedItemsSpecialities: any = [];
  tags: TagModel[] = [];
  selectedCustomer: any;
  locationFilter = [];
  opportunityId: string;
  itemsPerPage: number[] = [10, 50, 100];
  limit: number = 15;
  totalItems: number;
  candidatesRequest: CandidatesRequest = new CandidatesRequest();
  candidatesLoaded: boolean = false;
  candidates: CandidateModel[];
  page: number;
  statusSort: [number, number, number, number, number, number, number] = [0, 0, 0, 0, 0, 0, 0];
  statusOfCandidateArray: StatusOfCandidateModel[];
  involvedPerson: InvolvedPeople = new InvolvedPeople();
  listPositionCreate: string[] = [];
  users: any[] = [];
  dropdownSettingsSingle = {};
  selectedPeople: SelectedPeopleModel = new SelectedPeopleModel;
  selectedItemsPeople: SelectedPeopleModel[] = [];
  dropdownListPeople: any = [];
  dropdownItemPeople = {};
  expandedDiscription: boolean = false;
  business = [];
  valor: number = 10;
  functions: FunctionModel[] = new Array<FunctionModel>();
  opportunitiesRequest: OpportunitiesRequest = new OpportunitiesRequest();
  constructor(
    private departament: DpartamentService,
    private router: Router,
    private opportunityService: OpportunityService,
    private route: ActivatedRoute,
    private persistenceService: PersistenceService,
    private notificationService: NotificationService,
    public tagService: TagService,
    private candidateService: CandidateService,
    private logs: LogsComponent,
    private _location: Location,
    private statusOfCandidate: StatusOfCandidateService,
    private authService: AuthService,
    private positionOpportunityService: PositionOpportunityService,
    private interactionService: InteractionService,
    private functionService: FunctionService) {
    this.ddlStatus = this.enumsHelper.getEnumStatusOpportunityArray();
    this.ddlProfile = this.enumsHelper.getEnumProfileCandidateArray();
    this.ddlBusinessUnit = this.enumsHelper.getBusinessUnitArray();
    this.ddlPriority = this.enumsHelper.getEnumPrioritOpportunity();
    this.getAllTags();
    this.getAllStatus();
    this.getUsers();
    this.getAllFunctions();
    this.dropdownSettingsSingle = {
      singleSelection: true,
      text: "Selecione...",
      selectAllText: 'Marcar todos',
      unSelectAllText: 'Desmarcar todos',
      enableSearchFilter: true,
      classes: "myclass custom-class",
      badgeShowLimit: 3,
      searchBy: ["itemName"]
    };
  }

  ngOnInit() {
    this.getallDepartaments();
    this.customer = []
    if (this.opportunityModel.value == "") {
      this.valueOpp = true;
    }

    if (this.route.snapshot.params['id'] != undefined)
      this.opportunityId = this.route.snapshot.params['id'];

    if (this.opportunityId) {
      (<any>window).ga('set', 'page', 'Edição de vagas');
      (<any>window).ga('send', 'pageview');

      this.opportunityService.getById(this.opportunityId).subscribe(r => {
        this.opportunityModel.loadModelFromServer(r);
        this.loadOpportunitieCandidates();
        this.qtdOpp = this.opportunityModel.qtdOpportunities;
        this.qtdOppInit = this.opportunityModel.initialQtd;
        this.selectedItemsSpecialities = this.opportunityModel.specialities;
        this.opportunityService.getCustomer().subscribe(r => {
          for (let cr of r.result) {
            let cN = new CustomerModel;
            cN.loadFromServer(cr)
            this.customer.push(cN);
          }
          if (this.customer.find(c => c.name == this.opportunityModel.customerName)) {
            this.selectedCustomer = this.customer.find(c => c.name == this.opportunityModel.customerName)
          }

          this.location = [];
          this.opportunityService.getLocation().subscribe(r => {
            for (let cr of r) {
              let cN = new LocationModel;
              cN.loadFromServer(cr)
              this.location.push(cN);
            }

            let arr = this.location.filter(x => x.clientLocation == this.selectedCustomer._id);
            this.locationFilter = arr;
          });
        });

      });
    } else {
      (<any>window).ga('set', 'page', 'Criação de vagas');
      (<any>window).ga('send', 'pageview');
    }
    this.getLocation();
    this.getCustomerName();
  }

  showValue(value) {
    if (isNaN(value)) {
      this.valueOpp = true;
    } else {
      this.valueOpp = false;
    }
  }

  editOpportunity(ngForm) {

    if (parseInt(this.opportunityModel.value) < 1) {
      this.enumsHelper.toast("O valor da vaga não pode ser menor que 1", "warning");
      return;
    }

    // if (this.opportunityModel.customerName == undefined || this.opportunityModel.customerName == "") {
    //   this.enumsHelper.toast("O cliente não foi selecionado", "warning");
    //   return;
    // }


    // if (this.opportunityModel.location == undefined || this.opportunityModel.location == "") {
    //   this.enumsHelper.toast("A unidade não foi selecionada", "warning");
    //   return;
    // }

    if (!this.opportunityModel.specialities && this.opportunityModel.specialities.length == 0) {
      this.enumsHelper.toast("Não foram inseridas as habilidades da vaga", "warning");
      return;
    }

    var message = "Alterou a Vaga de numero " + this.opportunityModel.number + " do cliente " + this.opportunityModel.customerName;
    this.logs.create(message);
    this.opportunityModel.isActive = this.opportunityModel.status != StatusOpportunity.Fechada;

    if (this.opportunityId) {
      this.updateOpportunity();
    } else {
      this.createOpportunity();
    }
  }

  updateOpportunity() {
    this.opportunityService.update(this.opportunityModel).subscribe(r => {

      this.enumsHelper.toast("Vaga atualizada com sucesso", "success");
      this.enumsHelper.sendEventAnalytcs("Editar vaga", this.opportunityModel.name, "Editou uma vaga");
    }, (err) => {

      let textErr = err;
      this.enumsHelper.toast("Não foi possível editar a vaga", "warning");

    });
  }

  createOpportunity() {

    if (!this.opportunityModel.qtdOpportunities || this.opportunityModel.qtdOpportunities <= 0) {
      this.enumsHelper.toast("O total de posições deve ser maior que zero", "warning");
      return;
    }

    let userInfo = this.authService.getUserInfoModel();

    let userCreate: InvolvedPeople = new InvolvedPeople();
    userCreate.name = userInfo.firstName + " " + userInfo.lastName;
    userCreate.position = "Criador da vaga";
    userCreate.email = userInfo.email;
    this.opportunityModel.involvedPeople.push(userCreate);

    this.opportunityModel.registrationDate = new Date();
    this.opportunityModel.initialQtd = this.opportunityModel.qtdOpportunities;
    this.opportunityService.save(this.opportunityModel).subscribe(r => {
      this.enumsHelper.toast("Vaga criada com sucesso", "success");
      var message = "Criou nova Vaga do cliente " + this.opportunityModel.customerName;
      this.logs.create(message);
      this.enumsHelper.sendEventAnalytcs("Cadastro de vaga", this.opportunityModel.number, "Cadastrou nova vaga");
      this.notificationService.notify(`${(this.opportunityModel.qtdOpportunities > 1 ? 'Vagas cadastradas' : 'Vaga cadastrada')} com sucesso!`);
      this.router.navigate(['opportunities/edit-opportunity/', r._id]);
    });
  }

  deleteCandidateOfOpportunity(candidate) {

    var index = this.opportunityModel.candidates.indexOf(candidate._id);

    this.opportunityModel.candidates.splice(index, 1);
    //TODO Validar o porque pegava o nome de candidatesJoin
    //var message = "Deletou o candidato " + this.opportunityModel.candidatesJoin[index].name + " da vaga " + this.opportunityModel.customerName;
    var message = "Deletou o candidato " + candidate.name + " da vaga " + this.opportunityModel.customerName;
    this.logs.create(message);

    var query = {
      "_id": this.opportunityModel._id,
      "candidateId": candidate._id
    }

    this.opportunityService.deleteCandidateOpportunity(query).subscribe(r => {
      candidate.opportunities.splice(this.opportunityModel._id, 1);
      this.candidateService.update(candidate).subscribe(res => {
      });
    });
    this.loadOpportunitieCandidates();
  }

  getCustomerName() {
    this.customer = [];

    this.opportunityService.getCustomer().subscribe(r => {
      this.customer = [];
      for (let cr of r.result) {
        let cN = new CustomerModel;
        cN.loadFromServer(cr)
        this.customer.push(cN);
      }
      this.customer.sort(function (a, b) {
        if (a.name > b.name) {
          return 1;
        }
        if (a.name < b.name) {
          return -1;
        }
        return 0;
      });
    });
    if (this.customer.find(c => c.name == this.opportunityModel.customerName)) {
      this.selectedCustomer = this.customer.find(c => c.name == this.opportunityModel.customerName)
    }
  }

  getLocation() {
    this.location = [];
    this.opportunityService.getLocation().subscribe(r => {
      for (let cr of r) {
        let cN = new LocationModel;
        cN.loadFromServer(cr)
        this.location.push(cN);
      }
      this.location.sort(function (a, b) {
        if (a.discription > b.discription) {
          return 1;
        }
        if (a.discription < b.discription) {
          return -1;
        }
        return 0;
      });

      if (this.selectedCustomer) {
        let arr = this.location.filter(x => x.clientLocation == this.selectedCustomer._id);
        this.locationFilter = arr;
      }
    });
  }

  validateDropDown(discription) {
    let locationModel = new LocationModel();
    for (var i = 0; i < this.location.length; i++) {
      if (this.location[i]) {
        if (this.location[i].discription == discription) {
          locationModel = this.location[i];
        }
      }
    }
    this.opportunityModel.location = locationModel.discription;
    this.opportunityModel.opportunityLocation = locationModel;
  }

  expandTextarea() {
    // document.getElementById("description").addEventListener('keyup', function () {
    // this.style.overflow = 'hidden';
    // this.style.height = '0';
    // this.style.height = this.scrollHeight + 'px';
    // }, false);
  }

  loadOpportunitieCandidates() {

    // this.canShowFeedback = false;
    // this.opportunityModel.candidatesJoin = [];
    // if (this.opportunityModel.status != 3) {
    //   for (let candidateId of this.opportunityModel.candidates) {
    //     this.candidateService.getById(candidateId).subscribe(c => {
    //       let candidate = new CandidateModel();
    //       candidate.loadCandidate(c);
    //       this.opportunityModel.candidatesJoin.push(candidate);
    //     })
    //   }
    // }
    // this.opportunitieCandidates = [];
    // for (let i of this.opportunityModel.candidatesJoin) {
    //   let cand = new CandidateModel();
    //   cand.loadCandidate(i);
    //   this.opportunitieCandidates.push(cand);
    // }
    this.canShowFeedback = false;

    this.searchCandidates(1);
  }

  formatDate() {
    if (this.opportunityModel.registrationDate != undefined) {
      let data: string = moment(this.opportunityModel.registrationDate).format('L');
      return "Vaga cadastrada em " + data;
    }
    else {
      return "Não temos data de cadastro da vaga"
    }
  }

  onSort(event) {
    // event was triggered, start sort sequence
    switch (this.statusSort[event]) {
      case 0:
        switch (event) {
          case 0:
            this.statusSort[event] = 1;
            this.statusSort[1] = 0;
            this.statusSort[2] = 0;
            this.statusSort[3] = 0;
            this.candidatesRequest.sort = { "query": { "noAscentName": 1 } }
            break;
          case 1:
            this.statusSort[event] = 1;
            this.statusSort[0] = 0;
            this.statusSort[2] = 0;
            this.statusSort[3] = 0;
            this.candidatesRequest.sort = { "query": { "phone": 1 } }
            break;
          case 2:
            this.statusSort[event] = 1;
            this.statusSort[0] = 0;
            this.statusSort[1] = 0;
            this.statusSort[3] = 0;
            this.candidatesRequest.sort = { "query": { "status": 1 } }
            break;
        }
        break;
      case 1:
        switch (event) {
          case 0:
            this.statusSort[event] = 2;
            this.statusSort[1] = 0;
            this.statusSort[2] = 0;
            this.statusSort[3] = 0;
            this.candidatesRequest.sort = { "query": { "noAscentName": -1 } }
            break;
          case 1:
            this.statusSort[event] = 2;
            this.statusSort[0] = 0;
            this.statusSort[2] = 0;
            this.statusSort[3] = 0;
            this.candidatesRequest.sort = { "query": { "phone": -1 } }
            break;
          case 2:
            this.statusSort[event] = 2;
            this.statusSort[0] = 0;
            this.statusSort[1] = 0;
            this.statusSort[3] = 0;
            this.candidatesRequest.sort = { "query": { "status": -1 } }
            break;
        }
        break;
      case 2:
        this.candidatesRequest.sort = undefined;
        this.statusSort[event] = 0;
        break;
    }
    this.searchCandidates(this.page);
  }

  searchCandidates(page: number) {
    //Cache of search
    this.persistenceService.set('name', this.candidatesRequest.name);
    this.persistenceService.set('statusCandidate', this.candidatesRequest.status);
    this.persistenceService.set('phone', this.candidatesRequest.phone);
    if (this.candidatesRequest.skills != undefined) {
      for (var i = 0; i <= this.candidatesRequest.skills.length; i++) {
        this.persistenceService.set(this.candidateModel.skills[i], this.candidatesRequest.skills);
      }
    }

    this.candidates = [];
    this.page = page;
    this.candidatesLoaded = false;
    this.candidatesRequest.page = page;
    this.candidatesRequest.limit = this.limit;
    this.candidatesRequest.name ? this.candidatesRequest.name = this.enumsHelper.validateAscentClientname(this.candidatesRequest.name) : this.candidatesRequest.name;
    this.candidatesLoaded = true;
    this.candidates = [];
    this.totalItems = this.opportunityModel.candidates.length;
    for (let candidateId of this.opportunityModel.candidates) {
      this.candidateService.getById(candidateId).subscribe(c => {
        let candidate = new CandidateModel();
        candidate.loadCandidate(c);
        this.candidates.push(candidate);
      })
    }

    this.canShowFeedback = true;
  }

  loadStatus(status: number) {

    if (this.statusOfCandidateArray) {
      let obj = this.statusOfCandidateArray.find(x => x.number == status);
      if (obj)
        return obj;
    }
  }
  getAllStatus() {
    this.statusOfCandidate.getAll().subscribe(status => {
      this.statusOfCandidateArray = [];
      for (let statusC of status) {
        let statusLoaded = new StatusOfCandidateModel();
        statusLoaded.loadModelFromServer(statusC);
        this.statusOfCandidateArray.push(statusLoaded);
      }
    })
  }
  ifExists(name) {
    this.tagRequest.name = name.inputTextValue;
    this.tagService.searchIfExists(this.tagRequest).subscribe(r => {
      if (r == "Não encontramos esta tag. Deseja criar uma nova?" && name.inputTextValue != "") {
        this.statusTag = r
      } else {
        this.statusTag = "";
      }
    });
  }

  clearRequest() {
    console.log(this.opportunityModel.specialities);
    if (this.opportunityModel.specialities.length >= 3) {
      this.valor = this.valor + 5;
    }
    this.statusTag = "";
  }

  createTag() {
    this.tagModel.name = this.tagRequest.name;
    this.tagService.add(this.tagModel).subscribe(r => {
      this.notificationService.notify('Tag cadastrada com sucesso!');
      this.statusTag = "";
      this.getAllTags();
      return;
    }, (err) => {
      this.notificationService.notify(err.Errors.message);
    });
  }

  no(name) {
    this.statusTag = "";
    name.inputTextValue = "";
  }

  redirectLastPage() {
    this._location.back();
  }


  createCustomer() {
    var name = this.enumsHelper.validateAscentClientname(this.customerModel.name);
    for (let c of this.customer) {
      if (name.toUpperCase() == this.enumsHelper.validateAscentClientname(c.name.toLowerCase()).toUpperCase()) {
        this.enumsHelper.toast("Já existe um cliente com este nome!", "warning");
        return;
      }
    }

    var barra = "\\";
    if (this.customerModel.name.substring(0, 1) == " "
      || this.customerModel.name.substring(0, 1) == "@"
      || this.customerModel.name.substring(0, 1) == "#"
      || this.customerModel.name.substring(0, 1) == "!"
      || this.customerModel.name.substring(0, 1) == "$"
      || this.customerModel.name.substring(0, 1) == "*"
      || this.customerModel.name.substring(0, 1) == "("
      || this.customerModel.name.substring(0, 1) == ")"
      || this.customerModel.name.substring(0, 1) == "`"
      || this.customerModel.name.substring(0, 1) == "´"
      || this.customerModel.name.substring(0, 1) == "~"
      || this.customerModel.name.substring(0, 1) == "^"
      || this.customerModel.name.substring(0, 1) == ";"
      || this.customerModel.name.substring(0, 1) == ":"
      || this.customerModel.name.substring(0, 1) == ","
      || this.customerModel.name.substring(0, 1) == "."
      || this.customerModel.name.substring(0, 1) == "<"
      || this.customerModel.name.substring(0, 1) == ">"
      || this.customerModel.name.substring(0, 1) == "?"
      || this.customerModel.name.substring(0, 1) == "{"
      || this.customerModel.name.substring(0, 1) == "/"
      || this.customerModel.name.substring(0, 1) == "}"
      || this.customerModel.name.substring(0, 1) == "'"
      || this.customerModel.name.substring(0, 1) == '"'
      || this.customerModel.name.substring(0, 1) == "+"
      || this.customerModel.name.substring(0, 1) == "-"
      || this.customerModel.name.substring(0, 1) == "_"
      || this.customerModel.name.substring(0, 1) == "="
      || this.customerModel.name.substring(0, 1) == "§"
      || this.customerModel.name.substring(0, 1) == '|'
      || this.customerModel.name.substring(0, 1) == '¨'
      || this.customerModel.name.substring(0, 1) == '"'
      || this.customerModel.name.substring(0, 1) == "'"
      || this.customerModel.name.substring(0, 1) == "["
      || this.customerModel.name.substring(0, 1) == "]"
      || this.customerModel.name.substring(0, 1) == barra.substring(0, 1)
      || this.customerModel.name.substring(this.customerModel.name.length - 1, this.customerModel.name.length) == " ") {
      this.enumsHelper.toast("O nome não do cliente não pode começar e/ou terminar em branco ou começar com caracteres especiais", "warning");
      return;
    }

    this.customerModel.unity.push(this.locationModel);
    this.opportunityService.createCustomer(this.customerModel).subscribe(r => {
      this.opportunityModel.customerName = r.name;
      this.selectedCustomer = r;
      this.opportunityService.getLocation().subscribe(res => {
        this.location = [];
        for (let cr of res) {
          let cN = new LocationModel;
          cN.loadFromServer(cr)
          this.location.push(cN);
        }
        let arr = this.location.filter(x => x.clientLocation == this.selectedCustomer._id);
        this.locationFilter = arr;
        this.opportunityModel.location = this.locationFilter[0].discription;
        this.locationModel = new LocationModel();
      });
      this.getCustomerName();
      this.enumsHelper.toast("Cliente cadastrado com sucesso!", "success");
      var message = "Criou o cliente " + this.customerModel.name;
      this.logs.create(message);
    }, (err) => {
      this.enumsHelper.toast(err.Errors.message, "success");
    })
  }

  alterQtd() {
    this.opportunityModel.qtdOpportunities = this.qtdOpp;

    if (this.opportunityModel.initialQtd < 0) {
      this.opportunityModel.initialQtd = 0;
    }

    if (this.qtdOppInit < this.opportunityModel.initialQtd) {
      this.opportunityModel.qtdOpportunities = this.opportunityModel.qtdOpportunities + (this.opportunityModel.initialQtd - this.qtdOppInit);
    }

    if (this.qtdOppInit > this.opportunityModel.initialQtd) {
      this.opportunityModel.qtdOpportunities = this.opportunityModel.qtdOpportunities + (this.opportunityModel.initialQtd - this.qtdOppInit);

      if (this.opportunityModel.qtdOpportunities < 0) {
        this.opportunityModel.qtdOpportunities = 0;
      }
    }
  }

  turnHisroricTrue() {
    switch (this.showHistoric) {
      case true:
        this.showHistoric = false;
        break;
      case false:
        this.showHistoric = true;
        break
      default:

        break;
    }
  }

  getAllTags() {
    this.tagService.getAll().subscribe(tg => {
      for (let t of tg) {
        var tag = new TagModel();
        tag.loadTag(t);
        this.tags.push(tag);
      }
    })
  }

  populateSpecialities() {
    if (this.selectedItemsSpecialities.length > 0) {
      this.opportunityModel.specialities = this.selectedItemsSpecialities;
    }
    if (this.selectedItemsSpecialities.length == 0) {
      this.opportunityModel.specialities = [];
    }
  }

  populateCustomer(customer) {
    this.opportunityModel.location = "";
    this.opportunityModel.opportunityLocation = new LocationModel();
    if (!customer) {
      this.selectedCustomer = {};
    } else {
      let customerObj = this.customer.find(x => x.name == customer);
      this.selectedCustomer = customerObj;
      let arr = this.location.filter(x => x.clientLocation == customerObj._id);
      this.locationFilter = arr;
    }
  }

  itemsRequest = (text: string): Observable<Array<string>> => {
    let tags = new Array<string>();
    var obs = new Observable<Array<string>>(observer => {
      let request = new TagsRequest();
      request.name = text;

      this.tags.forEach(tag => {
        if (tag.name.match(new RegExp(text, "gi"))) {
          tags.push(tag.name);
        }
      });

      observer.next(tags);
    });

    return obs;
  }


  updateLocationCustomer() {
    this.locationModel.clientLocation = this.selectedCustomer._id;
    this.selectedCustomer.unity.push(this.locationModel);
    this.opportunityService.updateLocationCustomer(this.selectedCustomer).subscribe(r => {
      this.enumsHelper.toast("Localização inserida com sucesso!", "success");
      this.getLocation();
      this.locationModel = new LocationModel();
    }, err => {
      let error = JSON.parse(err._body)
      this.enumsHelper.toast(error.message, "warning")
    })
  }

  addInvolvedPeople(form) {
    let name = this.involvedPerson.name.trim();
    let position = this.involvedPerson.position.trim();

    if (name.length == 0 || name == "") {
      this.enumsHelper.toast("Nome da pessoa envolvida não foi preenchido!", "error");
      return;
    }

    if (position.length == 0 || position == "") {
      this.enumsHelper.toast("Função da pessoa envolvida não foi escolhida!", "error");
      return;
    }

    if (form.valid) {

      if (this.opportunityModel.involvedPeople.find(x => x.name == this.involvedPerson.name) == undefined) {
        this.opportunityModel.involvedPeople.push(this.involvedPerson);
        this.enumsHelper.toast("Adicionado com sucesso!", "success")
        this.selectedItemsPeople = [];
      } else {
        this.enumsHelper.toast("Esta pessoa já foi adicionada abaixo!", "warning")
        return;
      }

      this.involvedPerson = new InvolvedPeople();

      if (this.opportunityId) {
        this.opportunityService.updateInvolvedPeople(this.opportunityModel.involvedPeople, this.opportunityId)
          .subscribe(response => {
            this.selectedItemsPeople = [];
          });
      }
    }
  }

  editInvolvedPeople(item) {
    if (item.position == "Criador da vaga") {
      this.enumsHelper.toast("O criador da vaga não pode ser editado!", "error");
      return;
    }

    this.involvedPerson.name = item.name;
    let peopleModel = new SelectedPeopleModel();
    peopleModel.id = item.name;
    peopleModel.itemName = item.name;
    this.selectedItemsPeople[0] = peopleModel;
    this.involvedPerson.position = item.position;


    let index = this.opportunityModel.involvedPeople.indexOf(item);
    this.opportunityModel.involvedPeople.splice(index, 1);
  }

  removeInvolvedPeople(item) {

    let index = this.opportunityModel.involvedPeople.indexOf(item);

    if (this.opportunityModel.involvedPeople[index].position == "Criador da vaga") {
      this.enumsHelper.toast("O criador da vaga não pode ser removido!", "error");
      return;
    }

    this.opportunityModel.involvedPeople.splice(index, 1);

    if (this.opportunityId) {
      this.opportunityService.updateInvolvedPeople(this.opportunityModel.involvedPeople, this.opportunityId)
        .subscribe(response => {

        });
    }
  }

  getUsers() {
    this.users = []
    this.authService.getUsers().subscribe(r => {
      for (let u of r.result) {
        let user = new UserModel();
        user.loadUserModel(u);
        if (user.approved == true) {
          this.dropdownItemPeople = {
            id: user, itemName: user.firstName.toString() + " " + user.lastName
          };
          this.dropdownListPeople.push(this.dropdownItemPeople);
        }
      }
    })
  }

  async time(op: OpportunityModel) {


    // this.opportunitiesRequest.specialities = op.specialities;
    // this.opportunitiesRequest.status = 1;

    // let resul:any = await this.opportunityService.searchOp(this.opportunitiesRequest);

    //   console.log(resul);

    //   let i: any = [];
    //   for (let item of resul.result) {
    //     let a: Date = item.registrationDate;
    //     let id: any = item._id;
    //     let rOp = {
    //       "id": id,
    //       "DataC": a
    //     }
    //     i.push(rOp);
    //   }

    //   console.log(i);



    //   let int: any = [];
    //   for (let o of i) {
    //     let r:any = await this.interactionService.search(o.id);

    //       for (let y of r) {
    //         let g: Date = y.registrationDate;
    //         let id_int: any = y.opportunityId;
    //         let tInt = {
    //           "id": id_int,
    //           "DataI": g
    //         }
    //         int.push(tInt);
    //       }    
    //   }
    //   console.log(int);
    // let d = [];

    // for (let l = 0; l < i.length; l++) {
    //   if (i[l].id == int[l].id) {
    //     let datas = {
    //       "dataC": i.DataC,
    //       "datain": int.DataI
    //     }
    //     d.push(datas);
    //   }
    // }

    // console.log(d);


    // var a = moment(i);
    // var b = moment(data);

    // let d:any = a.diff(b, 'days');
    // // let d:any = i - data
    // console.log(d);

  }



  populatePerson() {
    let person = this.selectedItemsPeople[0].id;
    this.involvedPerson.name = person.firstName.toString() + " " + person.lastName.toString();
    this.involvedPerson.email = person.email;
  }

  unpopulatePerson() {
    this.involvedPerson.name = "";
    this.involvedPerson.email = "";
  }

  expandDiscription() {
    this.expandedDiscription = !this.expandedDiscription;
  }

  getallDepartaments() {

    this.departament.getAll().subscribe(data => {
      for (let dept of data) {
        let dpt = new DepartamentModel;
        dpt.loadFromServer(dept);
        this.business.push(dpt);
      }
    }, err => {
      this.enumsHelper.toast(err.Errors.message, "warning");
    });

  }

  getAllFunctions() {
    this.functionService.getAllFunctions().subscribe(r => {
      for (let f of r) {
        let func = new FunctionModel();
        func.loadFunction(f);
        this.functions.push(func);
      }
    }, err => {
      this.enumsHelper.toast(err.Errors.message, "warning")
    })
  }

}
