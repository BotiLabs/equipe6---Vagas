import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HistoricOpportunityComponent } from './historic-opportunity.component';

describe('HistoricOpportunityComponent', () => {
  let component: HistoricOpportunityComponent;
  let fixture: ComponentFixture<HistoricOpportunityComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HistoricOpportunityComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HistoricOpportunityComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
