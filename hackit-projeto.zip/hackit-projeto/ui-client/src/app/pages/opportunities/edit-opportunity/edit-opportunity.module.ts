import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EditOpportunityComponent } from './edit-opportunity.component';
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from '../../../shared/shared.module';
import { CurrencyMaskModule } from "ng2-currency-mask";
import { HistoricOpportunityComponent } from './historic-opportunity/historic-opportunity.component';
import { AngularMultiSelectModule } from 'angular2-multiselect-dropdown/angular2-multiselect-dropdown';


export const EditOpportunityRoutes: Routes = [
    {
        path: '',
        component: EditOpportunityComponent,
        data: {
          heading: 'Edição de vaga',
          status:false
        }
      }
    ];
    
    @NgModule({
      imports: [
        CommonModule,
        RouterModule.forChild(EditOpportunityRoutes),
        SharedModule,
        CurrencyMaskModule,
        AngularMultiSelectModule
      ],
      declarations: [EditOpportunityComponent,  HistoricOpportunityComponent]
    })
export class EditOpportunityModule { }
