import { Component, OnInit, Input } from '@angular/core';
import { OpportunityModel } from '../../../../models/opportunity.model';
import * as moment from 'moment';
import { EnumsHelper } from '../../../../common/enums-helper';
import { StatusOfCandidateModel } from '../../../../models/statusOfCandidate.model';
import { StatusOfCandidateService } from '../../../../../../_services/statusCandidate.service';
moment.locale('pt-BR');
declare var $:any;

@Component({
  selector: 'app-historic-opportunity',
  templateUrl: './historic-opportunity.component.html',
  styleUrls: ['./historic-opportunity.component.css']
})
export class HistoricOpportunityComponent implements OnInit {
@Input() opportunityModel:OpportunityModel;
enumsHelper:EnumsHelper = new EnumsHelper();
statusOfCandidateArrayHistoric: StatusOfCandidateModel[] = new Array<StatusOfCandidateModel>();
  constructor(private statusOfCandidate: StatusOfCandidateService) { }

  ngOnInit() {
    this.getAllStatusHistoric();
  }

  formatDate(date) {
    if (date) {
      let data: string = moment(date).format('L');
      return data;
    }
    else {
      return "Sem data"
    }
}


getAllStatusHistoric() {
  this.statusOfCandidate.getAll().subscribe(status => {
      this.statusOfCandidateArrayHistoric = [];
      for (let statusC of status) {
          let statusLoaded = new StatusOfCandidateModel();
          statusLoaded.loadModelFromServer(statusC);
          this.statusOfCandidateArrayHistoric.push(statusLoaded);
      }
  })
}

loadStatus(status: number) {

  if (this.statusOfCandidateArrayHistoric) {
    let obj = this.statusOfCandidateArrayHistoric.find(x => x.number == status);
    if (obj)
      return obj;
  }
}

}
