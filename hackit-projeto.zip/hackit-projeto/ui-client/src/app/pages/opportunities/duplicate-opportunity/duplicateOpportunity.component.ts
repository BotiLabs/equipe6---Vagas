import { Observable } from 'rxjs/Rx';
import { PriorityOpportunity } from './../../../common/priority';
import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { OpportunityService } from '../../../../../_services/opportunity.service';
import { StatusOpportunity } from '../../../common/status-opportunity';
import { EnumsHelper } from '../../../common/enums-helper';
import { OpportunityModel } from '../../../models/opportunity.model';
import { TagService } from '../../../../../_services/tag.service';
import { BusinessUnit } from '../../../common/business-unit';
import { NotificationService } from '../../../../../_services/notification.service';
import { MatchService } from '../../../../../_services/match.service';
import { CandidateService } from '../../../../../_services/candidate.service';
import { LogsComponent } from '../../logs/logs.component';
import { ProfileCandidate } from '../../../common/profile-candidate';
import { TagsRequest } from '../../../common/tags.request';
import { TagModel } from '../../../models/tag.model';
import { Location } from '@angular/common';
import '../../../../assets/plugins/toast-master/js/jquery.toast.js';
import { LocationModel } from './../../../models/location.model';
import { CustomerModel } from './../../../models/customerModel';
import { InvolvedPeople } from '../../../models/involvedPeople';
import { SelectedPeopleModel } from '../../../models/selectedPeople.model';
import { AuthService } from '../../../../../_services/auth.service';
import { UserModel } from '../../../models/user.model';
import { PositionOpportunityService } from '../../../../../_services/position-opportunity.service';

declare var $: any;
@Component({
  selector: 'app-duplicateOpportunity',
  templateUrl: './duplicateOpportunity.component.html',
  styleUrls: ['./duplicateOpportunity.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class DuplicateOpportunityComponent implements OnInit {
  opportunityModel: OpportunityModel = new OpportunityModel();
  enumsHelper: EnumsHelper = new EnumsHelper();
  ddlStatus: StatusOpportunity[];
  ddlProfile: ProfileCandidate[];
  ddlBusinessUnit: BusinessUnit[];
  ddlPriority: PriorityOpportunity[];
  tagRequest: TagsRequest = new TagsRequest();
  statusTag: string = "";
  tagModel: TagModel = new TagModel();
  searchSaveStatus: number = -1;
  customerModel: CustomerModel = new CustomerModel();
  locationModel: LocationModel = new LocationModel();
  customerN: string;
  customer: any[];
  location: any[];
  tags: TagModel[] = [];
  states: String[] = ["AC", "AL", "AM", "AP", "BA", "CE", "DF", "ES", "GO", "MA", "MT", "MS", "MG", "PA", "PB", "PR", "PE", "PI", "RJ", "RN", "RO", "RS", "RR", "SC", "SE", "SP", "TO"];
  selectedCustomer: any;
  locationFilter = [];
  involvedPerson: InvolvedPeople = new InvolvedPeople();
  selectedItemsPeople: SelectedPeopleModel[] = [];
  opportunityId: string;
  users: any[] = [];
  dropdownItemPeople = {};
  dropdownListPeople: any = [];
  dropdownSettingsSingle = {};
  positions: any[];
  expandedDiscription: boolean;


  constructor(private opportunityService: OpportunityService,
    private router: Router,
    private route: ActivatedRoute,
    private notificationService: NotificationService,
    private matchService: MatchService,
    public tagService: TagService,
    private candidateService: CandidateService,
    private logs: LogsComponent,
    private authService: AuthService,
    private _location: Location,
    private positionOpportunityService: PositionOpportunityService,
  ) {
    this.getUsers();
    this.positions = this.positionOpportunityService.getPositionsOpportunity();
    this.dropdownSettingsSingle = {
      singleSelection: true,
      text: "Selecione...",
      selectAllText: 'Marcar todos',
      unSelectAllText: 'Desmarcar todos',
      enableSearchFilter: true,
      classes: "myclass custom-class",
      badgeShowLimit: 3,
      searchBy: ["itemName"]
    };
    (<any>window).ga('set', 'page', 'Duplicação de vagas');
    (<any>window).ga('send', 'pageview');
  }

  ngOnInit() {
    this.getAllTags();
    this.opportunityService.getById(this.route.snapshot.params['id']).subscribe(r => {
      r.status = 0;
      this.ddlStatus = this.enumsHelper.getEnumStatusOpportunityArray();
      this.ddlProfile = this.enumsHelper.getEnumProfileCandidateArray();
      this.opportunityModel.loadModelFromServer(r);
      this.opportunityModel.status = 0;
      this.opportunityModel.involvedPeople = [];
      this.ddlBusinessUnit = this.enumsHelper.getBusinessUnitArray();
      this.ddlPriority = this.enumsHelper.getEnumPrioritOpportunity();
      this.opportunityService.getCustomer().subscribe(r => {
        this.customer = []
        for (let cr of r.result) {
          let cN = new CustomerModel;
          cN.loadFromServer(cr)
          this.customer.push(cN);
        }

        if (this.customer.find(c => c.name == this.opportunityModel.customerName)) {
          this.selectedCustomer = this.customer.find(c => c.name == this.opportunityModel.customerName)
        }
        this.location = [];
        this.opportunityService.getLocation().subscribe(r => {
          for (let cr of r) {
            let cN = new LocationModel;
            cN.loadFromServer(cr)
            this.location.push(cN);
          }

          let arr = this.location.filter(x => x.clientLocation == this.selectedCustomer._id);
          this.locationFilter = arr;
        });
      });
    });

    this.getCustomerName();
    this.getLocation();
  }

  addInvolvedPeople(form) {
    let name = this.involvedPerson.name.trim();
    let position = this.involvedPerson.position.trim();

    if (name.length == 0 || name == "") {
      this.enumsHelper.toast("Nome da pessoa envolvida não foi preenchido!", "error");
      return;
    }

    if (position.length == 0 || position == "") {
      this.enumsHelper.toast("Função da pessoa envolvida não foi escolhida!", "error");
      return;
    }

    if (form.valid) {

      if (this.opportunityModel.involvedPeople.find(x => x.name == this.involvedPerson.name) == undefined) {
        this.opportunityModel.involvedPeople.push(this.involvedPerson);
        this.enumsHelper.toast("Adicionado com sucesso!", "success")
        this.selectedItemsPeople = [];
      } else {
        this.enumsHelper.toast("Esta pessoa já foi adicionada abaixo!", "warning")
        return;
      }

      this.involvedPerson = new InvolvedPeople();

      if (this.opportunityId) {
        this.opportunityService.updateInvolvedPeople(this.opportunityModel.involvedPeople, this.opportunityId)
          .subscribe(response => {
            this.selectedItemsPeople = [];
          });
      }
    }
  }

  duplicateOpportunity(opportunity) {
    delete opportunity._id;
    delete opportunity.candidates;
    delete opportunity.candidatesJoin;
    delete opportunity.number;
    delete opportunity.historic;
    var message = "Fez uma copia da vaga numero " + this.opportunityModel.number;
    this.logs.create(message);

    this.opportunityModel = opportunity;
    this.opportunityModel.qtdOpportunities = opportunity.qtdOpportunities;
    this.opportunityModel.initialQtd = opportunity.qtdOpportunities;
    this.opportunityModel.registrationDate = new Date();
    this.opportunityModel.status = 0;
    /// Linha abaixo é IMPORTANTE

    if (parseInt(this.opportunityModel.value) < 1) {
      this.enumsHelper.toast("O valor da vaga não pode ser menor que 1", "warning");
    } else {
      let userInfo = this.authService.getUserInfoModel();

      let userCreate: InvolvedPeople = new InvolvedPeople();
      userCreate.name = userInfo.firstName + " " + userInfo.lastName;
      userCreate.position = "Criador da vaga";
      userCreate.email = userInfo.email;
      this.opportunityModel.involvedPeople.push(userCreate);

      this.opportunityService.save(this.opportunityModel).subscribe(r => {
        this.enumsHelper.toast(`${(this.opportunityModel.qtdOpportunities > 1 ? 'Vagas duplicadas' : 'Vaga duplicada')} com sucesso!`, "success");
        this.router.navigate(['opportunities/edit-opportunity', r._id]);
        this.enumsHelper.sendEventAnalytcs("Duplicar vaga", this.opportunityModel.name, "Duplicou uma vaga");
      });
      this.searchSaveStatus = 0;

    }
  }

  expandTextarea() {
    document.getElementById("discription").addEventListener('keyup', function () {
      this.style.overflow = 'hidden';
      this.style.height = '0';
      this.style.height = this.scrollHeight + 'px';
    }, false);
  }
  ifExists(name) {
    this.tagRequest.name = name.inputTextValue;
    this.tagService.searchIfExists(this.tagRequest).subscribe(r => {
      if (r == "Não encontramos esta tag. Deseja criar uma nova?" && name.inputTextValue != "") {
        this.statusTag = r
      } else {
        this.statusTag = "";
      }
    });
  }

  clearRequest() {
    this.statusTag = "";
  }

  createTag() {
    this.tagModel.name = this.tagRequest.name;
    this.tagService.add(this.tagModel).subscribe(r => {
      this.enumsHelper.toast('Tag cadastrada com sucesso!', "success");
      this.statusTag = "";
      this.getAllTags();
      return;
    }, (err) => {
      this.enumsHelper.toast(err.Errors.message, "warning");
    });
  }

  no(name) {
    this.statusTag = "";
    name.inputTextValue = "";
  }

  redirectLastPage() {
    this._location.back();
  }

  createCustomer() {
    var name = this.enumsHelper.validateAscentClientname(this.customerModel.name);

    for (let c of this.customer) {
      if (name.toUpperCase() == this.enumsHelper.validateAscentClientname(c.name.toLowerCase()).toUpperCase()) {
        this.enumsHelper.toast("Já existe um cliente com este nome!", "warning");
        return;
      }
    }

    var barra = "\\";
    if (this.customerModel.name.substring(0, 1) == " "
      || this.customerModel.name.substring(0, 1) == "@"
      || this.customerModel.name.substring(0, 1) == "#"
      || this.customerModel.name.substring(0, 1) == "!"
      || this.customerModel.name.substring(0, 1) == "$"
      || this.customerModel.name.substring(0, 1) == "*"
      || this.customerModel.name.substring(0, 1) == "("
      || this.customerModel.name.substring(0, 1) == ")"
      || this.customerModel.name.substring(0, 1) == "`"
      || this.customerModel.name.substring(0, 1) == "´"
      || this.customerModel.name.substring(0, 1) == "~"
      || this.customerModel.name.substring(0, 1) == "^"
      || this.customerModel.name.substring(0, 1) == ";"
      || this.customerModel.name.substring(0, 1) == ":"
      || this.customerModel.name.substring(0, 1) == ","
      || this.customerModel.name.substring(0, 1) == "."
      || this.customerModel.name.substring(0, 1) == "<"
      || this.customerModel.name.substring(0, 1) == ">"
      || this.customerModel.name.substring(0, 1) == "?"
      || this.customerModel.name.substring(0, 1) == "{"
      || this.customerModel.name.substring(0, 1) == "/"
      || this.customerModel.name.substring(0, 1) == "}"
      || this.customerModel.name.substring(0, 1) == "'"
      || this.customerModel.name.substring(0, 1) == '"'
      || this.customerModel.name.substring(0, 1) == "+"
      || this.customerModel.name.substring(0, 1) == "-"
      || this.customerModel.name.substring(0, 1) == "_"
      || this.customerModel.name.substring(0, 1) == "="
      || this.customerModel.name.substring(0, 1) == "§"
      || this.customerModel.name.substring(0, 1) == '|'
      || this.customerModel.name.substring(0, 1) == '¨'
      || this.customerModel.name.substring(0, 1) == '"'
      || this.customerModel.name.substring(0, 1) == "'"
      || this.customerModel.name.substring(0, 1) == "["
      || this.customerModel.name.substring(0, 1) == "]"
      || this.customerModel.name.substring(0, 1) == barra.substring(0, 1)
      || this.customerModel.name.substring(this.customerModel.name.length - 1, this.customerModel.name.length) == " ") {
      this.enumsHelper.toast("O nome não do cliente não pode começar e/ou terminar em branco ou começar com caracteres especiais", "warning");
      return;
    }

    this.customerModel.unity.push(this.locationModel);
    this.opportunityService.createCustomer(this.customerModel).subscribe(r => {
      this.opportunityModel.customerName = r.name;
      this.selectedCustomer = r;
      this.location = [];
      this.opportunityService.getLocation().subscribe(res => {
        for (let cr of res) {
          let cN = new LocationModel;
          cN.loadFromServer(cr)
          this.location.push(cN);
        }
        let arr = this.location.filter(x => x.clientLocation == this.selectedCustomer._id);
        this.locationFilter = arr;
        this.opportunityModel.location = this.locationFilter[0].discription;
        this.locationModel = new LocationModel();
      });

      this.customer.push(r);
      this.enumsHelper.toast("Cliente cadastrado com sucesso!", "success");
      var message = "Criou o cliente " + this.customerModel.name;
      this.logs.create(message);
    }, (err) => {
      this.enumsHelper.toast(err.Errors.message, "warning");
    })
  }

  getCustomerName() {
    this.customer = [];

    this.opportunityService.getCustomer().subscribe(r => {

      for (let cr of r.result) {
        let cN = new CustomerModel;
        cN.loadFromServer(cr)
        this.customer.push(cN);
      }
      this.customer.sort(function (a, b) {
        if (a.name > b.name) {
          return 1;
        }
        if (a.name < b.name) {
          return -1;
        }
        return 0;
      });
    });

  }

  getLocation() {
    this.location = [];
    this.opportunityService.getLocation().subscribe(r => {
      for (let cr of r) {
        let cN = new LocationModel;
        cN.loadFromServer(cr)
        this.location.push(cN);
      }
      this.location.sort(function (a, b) {
        if (a.discription > b.discription) {
          return 1;
        }
        if (a.discription < b.discription) {
          return -1;
        }
        return 0;
      });


      let arr = this.location.filter(x => x.clientLocation == this.selectedCustomer._id);
      this.locationFilter = arr;
    });
  }


  validateDropDown(discription) {
    let locationModel = new LocationModel();
    for (var i = 0; i < this.location.length; i++) {
      if (this.location[i]) {
        if (this.location[i].discription == discription) {
          locationModel = this.location[i];
        }
      }
    }

    this.opportunityModel.location = locationModel.discription;
    this.opportunityModel.opportunityLocation = locationModel;
  }

  getAllTags() {
    this.tagService.getAll().subscribe(tg => {
      for (let t of tg) {
        var tag = new TagModel();
        tag.loadTag(t);
        this.tags.push(tag);
      }
    })
  }

  itemsRequest = (text: string): Observable<Array<string>> => {
    let tags = new Array<string>();
    var obs = new Observable<Array<string>>(observer => {

      this.tags.forEach(tag => {
        if (tag.name.match(new RegExp(text, "gi"))) {
          tags.push(tag.name);
        }
      });

      observer.next(tags);
    });
    return obs;
  }

  updateLocationCustomer() {
    this.locationModel.clientLocation = this.selectedCustomer._id;
    this.selectedCustomer.unity.push(this.locationModel);
    this.opportunityService.updateLocationCustomer(this.selectedCustomer).subscribe(r => {
      this.enumsHelper.toast("Localização inserida com sucesso!", "success");
      this.getLocation();
      this.locationModel = new LocationModel();
    }, err => {
      let error = JSON.parse(err._body)
      this.enumsHelper.toast(error.message, "warning")
    })
  }

  populateCustomer(customer) {
    this.opportunityModel.location = "";
    this.opportunityModel.opportunityLocation = new LocationModel();
    if (!customer) {
      this.selectedCustomer = {};
    } else {
      let c = this.customer;
      let customerObj = c.find(x => x.name == customer);
      this.selectedCustomer = customerObj;
      let arr = this.location.filter(x => x.clientLocation == customerObj._id);
      this.locationFilter = arr;
    }
  }

  editInvolvedPeople(item) {
    if (item.position == "Criador da vaga") {
      this.enumsHelper.toast("O criador da vaga não pode ser editado!", "error");
      return;
    }

    this.involvedPerson.name = item.name;
    let peopleModel = new SelectedPeopleModel();
    peopleModel.id = item.name;
    peopleModel.itemName = item.name;
    this.selectedItemsPeople[0] = peopleModel;
    this.involvedPerson.position = item.position;


    let index = this.opportunityModel.involvedPeople.indexOf(item);
    this.opportunityModel.involvedPeople.splice(index, 1);
  }

  removeInvolvedPeople(item) {

    let index = this.opportunityModel.involvedPeople.indexOf(item);

    if (this.opportunityModel.involvedPeople[index].position == "Criador da vaga") {
      this.enumsHelper.toast("O criador da vaga não pode ser removido!", "error");
      return;
    }

    this.opportunityModel.involvedPeople.splice(index, 1);

    if (this.opportunityId) {
      this.opportunityService.updateInvolvedPeople(this.opportunityModel.involvedPeople, this.opportunityId)
        .subscribe(response => {

        });
    }
  }

  populatePerson() {
    let person = this.selectedItemsPeople[0].id;
    this.involvedPerson.name = person.firstName.toString() + " " + person.lastName.toString();
    this.involvedPerson.email = person.email;
  }

  unpopulatePerson() {
    this.involvedPerson.name = "";
    this.involvedPerson.email = "";
  }

  getUsers() {
    this.users = [];
    this.authService.getUsers().subscribe(r => {
      for (let u of r.result) {
        let user = new UserModel();
        user.loadUserModel(u);
        if (user.approved == true) {
          this.dropdownItemPeople = {
            id: user, itemName: user.firstName.toString() + ' ' + user.lastName
          };
          this.dropdownListPeople.push(this.dropdownItemPeople);
        }
      }
    });
  }

  expandDiscription() {
    this.expandedDiscription = !this.expandedDiscription;
  }
}

