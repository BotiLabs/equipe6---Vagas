import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '../../../../node_modules/@angular/router';
import { LoadingComponent } from './loading.component';
import { SharedModule } from '../../shared/shared.module';
import { ChartModule } from '../../../../node_modules/primeng/primeng';

export const LoadingRoutes: Routes = [
  {
    path: '',
    component: LoadingComponent,
    data: {
      heading: 'Loading'
    }
  }
];
@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(LoadingRoutes),
    SharedModule,
    ChartModule,
  ],
  declarations: [LoadingComponent]
})
export class LoadingModule { }
