import { Component, OnInit } from '@angular/core';
import { UserInfoModel } from '../../models/user-info.model';
// import { Adal4Service } from '../../../../node_modules/adal-angular4';
import { Router, ActivatedRoute } from '../../../../node_modules/@angular/router';
import { AuthService } from '../../../../_services/auth.service';
import { EnumsHelper } from '../../common/enums-helper';

@Component({
  selector: 'app-loading',
  templateUrl: './loading.component.html',
  styleUrls: ['./loading.component.css']
})
export class LoadingComponent implements OnInit {
  enumsHelper: EnumsHelper = new EnumsHelper();
  constructor(
    private authService: AuthService,
    private router: Router,
    private route: ActivatedRoute
  ) {
    this.route.queryParams.subscribe(params => {
      if (params['office365']) {
        let userInfo = new UserInfoModel();
        var token = params['token'];
        userInfo.loadInfoOffice365(params);
        this.authService.storeUserData(token, userInfo);
        this.authService.updateUserLoginCount(userInfo).subscribe(r => {
          console.log(r)
        }, err => {
          console.log(err)
        })
      }
    })
  }

  ngOnInit() {
    setTimeout(r => {
      if (localStorage.getItem('locationToRedirect')) {
        this.router.navigate([localStorage.getItem('locationToRedirect')]);
      } else {
        this.router.navigate(['/dashboard']);
      }
    }, 2000)
  }


}
