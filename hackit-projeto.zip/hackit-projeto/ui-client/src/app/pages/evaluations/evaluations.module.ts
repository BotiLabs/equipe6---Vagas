import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from '../../shared/shared.module';
export const EvaluationRoutes: Routes = [
    {
        path: '',
        children: [
            {
                path: '',
                loadChildren: './list-evaluations.module#ListEvaluationsModule',
                data: {
                    heading: 'Lista das AValiações'
                }
            },
            {
                path: 'view-evaluation/:id',
                loadChildren: './view-evaluation/view.module#ViewModule',
                data: {
                    heading: 'Ver uma Avaliação'
                }
            },
            {
                path: 'create-evaluation',
                loadChildren: './create-evaluation/create-evaluation.module#CreateEvaluationModule',
                data: {
                    heading: 'Criar uma Avaliação'
                }
            },
            {
                path: 'edit-evaluation/:id',
                loadChildren: './edit-evaluation/edit-evaluation.module#EditEvaluationModule',
                data: {
                    heading: 'Editar uma Avaliação'
                }
            }
        ]
    }
];

@NgModule({
    imports: [
        CommonModule,
        RouterModule.forChild(EvaluationRoutes),
        SharedModule
    ],
    declarations: []
})
export class EvaluationModule { }