import { EvaluationModule } from './evaluations.module';
import { EvaluationsComponent } from './evaluations.component';
import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from '../../shared/shared.module';
import { InputTrimModule } from 'ng2-trim-directive';
import { InfiniteScrollModule } from 'ngx-infinite-scroll';
export const ListEvaluationRoutes: Routes = [
    {
        path: '',
        component: EvaluationsComponent,
        data: {
            heading: 'Lista das Avaliações'
        }
    }
];

@NgModule({
    imports: [
        CommonModule,
        RouterModule.forChild(ListEvaluationRoutes),
        SharedModule,
        InputTrimModule,
        InfiniteScrollModule
    ],
    declarations: [EvaluationsComponent]
})
export class ListEvaluationsModule { }