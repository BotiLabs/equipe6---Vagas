import { CreateEvaluationComponent } from './create-evaluation.component';
import { SharedModule } from './../../../shared/shared.module';
import { RouterModule, Routes } from '@angular/router'; 
import { CommonModule } from '@angular/common';
import { NgModule, Component } from '@angular/core';

export const CreateRoutes: Routes = [
    {
        path: '',
        component: CreateEvaluationComponent,
        data: {
            heading: 'Criar uma Avaliação'
        }
    }
];
@NgModule({
    imports: [
        CommonModule,
        RouterModule.forChild(CreateRoutes),
        SharedModule,
    ],
    declarations: [CreateEvaluationComponent]
})
export class CreateEvaluationModule { }