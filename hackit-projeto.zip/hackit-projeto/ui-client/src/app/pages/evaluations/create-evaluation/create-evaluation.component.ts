import { Component, OnInit, ViewEncapsulation } from "@angular/core";
import { EvaluationModel } from '../../../models/evaluation.model';
import { EvaluationService } from '../../../../../_services/evaluation.service';
import { NotificationService } from "../../../../../_services/notification.service";
import { Router } from "@angular/router";
import { EnumsHelper } from "../../../common/enums-helper";
import { ProfileCandidate } from "../../../common/profile-candidate";
import { TypeModel } from "../../../models/type.model";
import { FormControl, FormGroup, Validators, FormBuilder } from '@angular/forms';
import { CandidateService } from "../../../../../_services/candidate.service";
import { CandidateModel } from "../../../models/candidate.model";
import { CandidatesRequest } from '../../../common/candidates.request';
import { InteractionModel } from '../../../models/interaction.model';
import { InteractionService } from '../../../../../_services/interaction.service';
import { ActionInteraction } from '../../../common/action-interaction';
import { StatusCandidate } from '../../../common/status-candidate';
import { OpportunityModel } from "../../../models/opportunity.model";
import { OpportunityService } from "../../../../../_services/opportunity.service";
import { InteractionType } from '../../../common/interaction-type';
import '../../../../assets/plugins/toast-master/js/jquery.toast.js';
import { TypeService } from "../../../../../_services/type.service";
declare var $: any;

@Component({
    selector: 'app-create-evaluation',
    templateUrl: './create-evaluation.component.html',
    styleUrls: ['./create-evaluation.component.css'],
    encapsulation: ViewEncapsulation.None
})

export class CreateEvaluationComponent implements OnInit {
    candidateModel: CandidateModel;
    evaluationModel: EvaluationModel = new EvaluationModel();
    typeModel: TypeModel = new TypeModel();
    form;
    boolSl: boolean;
    boolHp: boolean;
    candidate: CandidatesRequest = new CandidatesRequest();
    interaction: InteractionModel = new InteractionModel();
    enumsHelper: EnumsHelper = new EnumsHelper();
    ddlActions: ActionInteraction[];
    opportunities: OpportunityModel[] = [];
    ddlStatus: StatusCandidate[];
    actions = [];
    result;
    status: number = -1;
    errorType: boolean = false;
    types: any = [];
    constructor(private router: Router,
        private evaluationService: EvaluationService,
        private notificationService: NotificationService,
        private candidateService: CandidateService,
        private opportunityService: OpportunityService,
        private interactionService: InteractionService,
        private typeService: TypeService,
        fb: FormBuilder) {
        (<any>window).ga('set', 'page', 'Criação de avaliações');
        (<any>window).ga('send', 'pageview');
        typeService.getAllTypes().subscribe(r => {
            console.log(r)
            this.types = r;
        })
    }

    ngOnInit() {
        this.evaluationModel = new EvaluationModel;
        this.ddlActions = this.enumsHelper.getEnumActionInteractionArray();
        this.ddlStatus = this.enumsHelper.getEnumStatusCandidateArray();
        this.candidateModel = new CandidateModel();
        this.opportunityService.getAll().subscribe(res => {
            for (let item of res) {
                var opportunity = new OpportunityModel();
                opportunity.loadModelFromServer(item);
                if (opportunity.isActive)
                    this.opportunities.push(opportunity);
            }
        });
    }

    isChecked(status, type) {
        switch (status.currentTarget.checked) {
            case true:
                this.evaluationModel.type.push(type.id)
                break;

            case false:
                this.evaluationModel.type.splice(this.evaluationModel.type.indexOf(type.id), 1)
                break;

            default:
                break;
        }
    }

    create(email) {
        this.candidate.email = email;
        this.errorType = false;
        this.evaluationService.getByEmail(email).subscribe(res => {
            let evs = []
            res.result.forEach(evaluation => {
                if (this.evaluationModel.type.find(x => x == evaluation.type[0])) {
                    this.errorType = true;
                    evs.push(evaluation.type[0])
                }
            });


            if (this.errorType) {
                this.enumsHelper.toast("Já existe uma avaliação deste(s) tipo(s) " + "'" + evs.toString() + "'", "warning");
                return;
            }


            this.candidateService.getByEmail(this.candidate.email).subscribe(candidate => {
                this.candidateModel = candidate;


                if (!candidate) {
                    this.enumsHelper.toast("Informe um e-mail de um candidato cadastrado", "warning");
                    return;
                } else {

                    if (this.candidateModel) {
                        if (this.candidateModel.isBlocked) {
                            this.status = 1;
                            this.enumsHelper.toast('Candidato Bloqueado ' + this.candidateModel.name, "error");
                            return;
                        }
                    }
                    if (this.evaluationModel.type.length == 0) {
                        this.enumsHelper.toast("Selecione ao menos um tipo de avaliação", "warning")
                        return;
                    }

                    this.evaluationModel.name = this.candidateModel.name;
                    let userEmail = JSON.parse(localStorage.getItem('userInfo')).email;
                    console.log(userEmail)
                    this.evaluationModel.userEmail = userEmail; 

                    this.evaluationService.add(this.evaluationModel).subscribe(r => {
                        this.enumsHelper.toast("Avaliação cadastrada com sucesso ", "success");
                        this.router.navigate(['/evaluation']);
                    }), error => { console.log(error) };
                }
            }, error => {
                this.enumsHelper.toast('Digite um email', 'warning');
                this.status = 2;
            });
        }, err => console.log)

    }

    createInteraction() {
        let opportunity = this.opportunities.find(x => x._id === this.interaction.opportunityId);

        this.interaction.userFirstName = this.candidateModel.name;
        this.interaction.userEmail = this.candidateModel.email;
        this.interaction.candidateId = this.candidateModel._id;
        this.interaction.action = 3;
        this.interaction.status = 1;
        this.interaction.interactionType = InteractionType.RS;
        this.interaction.opportunity = opportunity;

        this.interactionService.add(this.interaction).subscribe(r => {

            this.candidateModel.status = this.interaction.status;
            this.candidateService.update(this.candidateModel).subscribe(c => { });
        });
    }
}



