import { SharedModule } from './../../../shared/shared.module';
import { RouterModule, Routes } from '@angular/router';
import { ViewEvaluationComponent, SafeHtmlPipe } from './view-evaluation.component';
import { CommonModule } from '@angular/common';
import { NgModule, Component } from '@angular/core';
import { ChartsModule } from 'ng2-charts';

export const ViewRoutes: Routes = [
    {
        path: '',
        component: ViewEvaluationComponent,
        data: {
            heading: 'Lista de Avaliações'
        }
    }
];
@NgModule({
    imports: [
        CommonModule,
        RouterModule.forChild(ViewRoutes),
        SharedModule,
        ChartsModule
    ],
    declarations: [ViewEvaluationComponent,SafeHtmlPipe]
})
export class ViewModule { }