import { Pipe, PipeTransform, Component, OnInit, ViewEncapsulation } from '@angular/core';
import { EvaluationService } from '../../../../../_services/evaluation.service';
import { ActivatedRoute } from '@angular/router';
import { EvaluationModel } from '../../../models/evaluation.model';
import { CandidatesRequest } from '../../../common/candidates.request';
import { CandidateService } from '../../../../../_services/candidate.service';
import { CandidateModel } from '../../../models/candidate.model';
import { TestingModel } from '../../../models/testing.model';
import { DomSanitizer } from "@angular/platform-browser";
declare var $: any;
@Component({
    selector: 'app-view-evaluation',
    templateUrl: './view-evaluation.component.html',
    styleUrls: ['./view-evaluation.component.css'],
    encapsulation: ViewEncapsulation.None,
})

export class ViewEvaluationComponent implements OnInit {
    evaluation: EvaluationModel = new EvaluationModel();
    sum: any;
    total: any[];
    text: string;
    wording = null;
    theme = null;
    traducao = [];
    candidateModel: CandidatesRequest = new CandidatesRequest();
    candidate: CandidateModel = new CandidateModel();
    skills = "";
    sumtotal = 0;
    testings: TestingModel[];
    testing = [];
    checkhp = false;
    checksl = false;
    qtdeRespondidas = 0;
    personality;
    colors;
    date;
    types;
    editorAvailable: boolean = false;
    public barChartOptions: any = {
        scaleShowVerticalLines: true,
        responsive: true,
        scales: {
            yAxes: [{ id: 'y-axis-1', type: 'linear', position: 'left', ticks: { min: 0, max: 9 } }]
        }
    };

    public barChartLabels: string[] = [];
    public barChartType: string = 'bar';
    public barChartLegend: boolean = true;
    public barChartData: any[] = [{ data: [], label: '' }];
    public barChartColors: any[] = [{ backgroundColor: ['#0283cc', '#0283cc', '#0283cc', '#0283cc'] }];

    constructor(
        private _evaluationService: EvaluationService,
        private _route: ActivatedRoute,
        private _candidateService: CandidateService
    ) {
        this.total = new Array<any>();
        this.text = "";
        this.testing = new Array<any>()
        this.colors = ["#f62d51", "#009efb", "#55ce63", "#7460ee", "#ffbc34"];
        (<any>window).ga('set', 'page', 'Tela informações da avaliação');
        (<any>window).ga('send', 'pageview');
    }

    ngOnInit() {
        this.loadEvaluation();
        this.loadBarChartData();
    }

    loadEvaluation() {
        this.total = [];
        this._evaluationService.getById(this._route.snapshot.params['id']).subscribe(response => {
            this.evaluation = response;
            this.date = this.evaluation.date;

            this.evaluation.type.map((item, i) =>
                item == "HP" ?
                    this.evaluation.type[i] = " Hapin " :
                    (item == "SL" ? this.evaluation.type[i] = " Sangue Laranja " : ""))

            this.types = this.evaluation.type;
            if (this.evaluation.type.includes("HP"))
                this.checkhp = true

            else if (this.evaluation.type.includes("SL"))
                this.checksl = true



            this.evaluation.testing.map(
                item => item.theme == "Redação" ? this.wording = item.answer : "")

            if (response.personality.length != 0) {
                this.traduzir(response.personality);

                for (let item in this.traducao) {
                    response.personality[item].name = this.traducao[item].traducao;
                    response.personality[item].descricao = this.traducao[item].descricao;
                }
            }


            this.getCandidate(this.evaluation.email);
        }, error => console.log(error));
    }
    loadBarChartData() {
        this.barChartLabels = [];
        this.barChartData = [{ data: [], label: '' }];
        this._evaluationService.getSum(this._route.snapshot.params['id']).subscribe(response => {
            this.sum = response;
            for (let key of this.sum) {
                if (key.theme != "Redação") {
                    this.barChartLabels.push(key.theme);
                    this.sumtotal = this.sumtotal + key.total;
                    this.total.push(key.total);
                }

            }

            this.barChartData = [
                { data: this.total, label: "Pontuação" }
            ];
        }), error => console.log(error);
    }
    getCandidate(email) {
        this.skills = "";
        this.candidateModel.email = email;
        this._candidateService.search(this.candidateModel).subscribe(candidate => {

            this.candidate = candidate.result[0];
            let end = this.candidate.skills.length - 1;
            for (let item in this.candidate.skills) {
                if (parseFloat(item) == end) {
                    this.skills += this.candidate.skills[item];
                } else {
                    this.skills += this.candidate.skills[item] + ", ";
                }
            }
        }, error => console.log(error));
    }

    onChange(event) {
        this.wording = event.html;

    }

    traduzir(items) {
        for (let item of items) {
            switch (item.name) {
                case "Openness": {
                    this.traducao.push({
                        traducao: "Aceitação",
                        descricao: "A medida em que uma pessoa está aberta a experimentar uma variedade de atividades."
                    });
                    break;
                }
                case "Conscientiousness": {
                    this.traducao.push({
                        traducao: "Conscienciosidade",
                        descricao: "A tendência de uma pessoa em agir de forma organizada ou pensativa."
                    });
                    break;
                }
                case "Extraversion": {
                    this.traducao.push({
                        traducao: "Extroversão",
                        descricao: "A tendência de uma pessoa em buscar incentivo na companhia dos outros"
                    });
                    break;
                }
                case "Agreeableness": {
                    this.traducao.push({
                        traducao: "Aceitabilidade",
                        descricao: "A tendência de uma pessoa em ser compassiva e cooperar com os outros."
                    });
                    break;
                }
                case "Emotional range": {
                    this.traducao.push({
                        traducao: "Faixa emocional",
                        descricao: "É a medida em que as emoções de uma pessoa são sensíveis ao ambiente."
                    });
                    break;
                }
            }
        }
    }

    editWording() {
        this.editorAvailable = true;
    }

    trowEditorFalse() {
        this.editorAvailable = false;
    }

}
@Pipe({ name: 'safeHtml' })
export class SafeHtmlPipe implements PipeTransform {
    constructor(private sanitized: DomSanitizer) {
    }
    transform(value: string) {
        return this.sanitized.bypassSecurityTrustHtml(value);
    }
}

