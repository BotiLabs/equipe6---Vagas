import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EditEvaluationComponent } from './edit-evaluation.component';
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from '../../../shared/shared.module';

export const EditEvaluationRoutes: Routes = [
    {
        path: '',
        component: EditEvaluationComponent,
        data: {
            heading: 'Editar uma Avaliação'
        }
    }
];
@NgModule({
    imports: [
        CommonModule,
        RouterModule.forChild(EditEvaluationRoutes),
        SharedModule    
    ],
    declarations: [EditEvaluationComponent]
})

export class EditEvaluationModule {}