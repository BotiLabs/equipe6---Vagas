import { Component, OnInit } from '@angular/core';
import { EvaluationService } from '../../../../../_services/evaluation.service';
import { Router, ActivatedRoute } from '@angular/router';
import { EvaluationModel } from '../../../models/evaluation.model';
import { NotificationService } from '../../../../../_services/notification.service';


@Component({
    selector: 'app-edit-evaluation',
    templateUrl: './edit-evaluation.component.html',
    styleUrls: ['./edit-evaluation.component.css']
})

export class EditEvaluationComponent implements OnInit {

    evaluationModel: EvaluationModel = new EvaluationModel();
    boolSl: boolean = false;
    boolHp: boolean = false;

    constructor(
        private evaluationService: EvaluationService,
        private router: Router,
        private route: ActivatedRoute,
        private notificationService: NotificationService
    ) {
        (<any>window).ga('set', 'page', 'Tela de informações da avaliação');
        (<any>window).ga('send', 'pageview');
    }

    ngOnInit() {

        this.evaluationService.getById(this.route.snapshot.params['id']).subscribe(response => {

            this.evaluationModel = response;

            if (this.evaluationModel.type.indexOf("HP") > -1)
                this.boolHp = true;

            if (this.evaluationModel.type.indexOf("SL") > -1)
                this.boolSl = true;

            console.log('SL ' + this.boolSl + ' HP ' + this.boolHp);
        });
    }

    update() {

        this.evaluationModel.type = [];

        if (this.boolSl)
            this.evaluationModel.type.push("SL");

        if (this.boolHp)
            this.evaluationModel.type.push("HP");

        if (!this.boolSl && !this.boolHp) {
            this.notificationService.notify('É necessário escolher um tipo de avaliação!')
            return;
        }

        this.evaluationService.update(this.evaluationModel).subscribe(r => {
            this.notificationService.notify('Avaliação atualizada com sucesso!');
            this.router.navigate(['/evaluation']);
        });
    }

}