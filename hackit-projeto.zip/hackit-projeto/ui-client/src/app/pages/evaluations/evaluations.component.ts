import { Component, OnInit } from "@angular/core";
import { EvaluationsRequest } from "../../common/evaluations.request";
import { EvaluationModel } from "../../models/evaluation.model";
import { EvaluationService } from '../../../../_services/evaluation.service';
import { BOOL_TYPE } from "@angular/compiler/src/output/output_ast";
import { EnumsHelper } from "../../common/enums-helper";
declare var $: any;
@Component({
    selector: 'app-evaluations',
    templateUrl: './evaluations.component.html',
    styleUrls: ['./evaluations.component.css']
})

export class EvaluationsComponent implements OnInit {
    title: string = "";
    subtitle: string = "";
    evaluationsRequest: EvaluationsRequest = new EvaluationsRequest();
    evaluations: EvaluationModel[];
    feedBackVisible: boolean;
    totalItems: number = -1;
    limit: number = 20;
    itemsPerPage: number[] = [10, 50, 100];
    initialDate: Date;
    page: number;
    withDate: any = undefined;
    evaluationModel: EvaluationModel = new EvaluationModel();
    verify;
    statusSort: [number, number, number, number, number, number, number, number, number] = [0, 0, 0, 0, -1, 0, 0, 0, 0];
    aviso = "";
    description = "";
    enumsHelper: EnumsHelper = new EnumsHelper();

    constructor(private evaluationService: EvaluationService) {
        this.title = "Pesquisar Avaliações";
        this.subtitle = "Encontre as avaliações por Nome e E-mail.";
        (<any>window).ga('set', 'page', 'Grid de avaliações');
        (<any>window).ga('send', 'pageview');
    }

    ngOnInit() {
        this.evaluations = new Array<EvaluationModel>();
        this.searchEvaluations(1, true);
    }

    searchEvaluations(page: number, newSearch: boolean) {
        this.page = page;
        this.aviso = ""
        this.description = "";
        this.evaluationsRequest.name = this.evaluationModel.name;
        this.evaluationsRequest.email = this.evaluationModel.email;
        if (this.initialDate) {
            var initialDateCalc = Date.parse(this.initialDate.toString());
            var initialDate = initialDateCalc - 10800000;
            this.evaluationsRequest['initialDate'] = initialDate;
        }

        if (this.evaluationModel.date) {
            var dateCalc = Date.parse(this.evaluationModel.date.toString())
            var finalDate = dateCalc + 75599999;
            this.evaluationsRequest.date = finalDate;
        }
        this.evaluationsRequest.page = page;
        this.evaluationsRequest.limit = this.limit;
        if (this.initialDate > this.evaluationsRequest.date) {
            this.enumsHelper.toast("A data inicial não pode ser maior que a data final.", 'warning');
            return;
        }
        if (this.withDate == true) {
            this.evaluationsRequest.dateValidator = {
                $ne: null
            }
        }
        if (this.withDate == false) {
            this.evaluationsRequest.dateValidator = null;
        }
        if (this.withDate == undefined) {
            this.evaluationsRequest.dateValidator = undefined;
        }

        this.evaluationService.search(this.evaluationsRequest).subscribe(res => {
            this.totalItems = res.count;
            if (newSearch)
                this.evaluations = [];
            this.verify = res.verify;
            for (let er of res.result) {
                let e = new EvaluationModel();
                e.loadEvaluation(er);
                this.evaluations.push(e);
            }
            console.log(this.evaluations)
            this.feedBackVisible = true;
        });

    }

    filtertable(withDate) {
        this.withDate = withDate;
        this.searchEvaluations(1, true);
    }

    turnUndefined() {
        this.withDate = undefined;
        this.evaluationsRequest.date = undefined;
    }


    clearInitialDate() {
        this.initialDate = undefined;
        this.evaluationsRequest['initialDate'] = undefined;
    }
    clearFinalDate() {
        this.evaluationModel.date = undefined;
    }

    onSort(event) {
        switch (this.statusSort[event]) {
            case 0:
                switch (event) {
                    case 0:
                        this.statusSort[event] = 1;
                        this.statusSort[1] = 0;
                        this.statusSort[2] = 0;
                        this.statusSort[3] = 0;
                        this.statusSort[4] = -1;
                        this.evaluationsRequest.sort = { "query": { "name": 1 } }
                        break;
                    case 1:
                        this.statusSort[event] = 1;
                        this.statusSort[0] = 0;
                        this.statusSort[2] = 0;
                        this.statusSort[3] = 0;
                        this.statusSort[4] = -1;
                        this.statusSort[5] = 0;
                        this.evaluationsRequest.sort = { "query": { "email": 1 } }
                        break;
                    case 2:
                        this.statusSort[event] = 1;
                        this.statusSort[0] = 0;
                        this.statusSort[1] = 0;
                        this.statusSort[3] = 0;
                        this.statusSort[4] = -1;
                        this.statusSort[5] = 0;
                        this.evaluationsRequest.sort = { "query": { "discription": 1 } }
                        break;
                    case 3:
                        this.statusSort[event] = 1;
                        this.statusSort[0] = 0;
                        this.statusSort[1] = 0;
                        this.statusSort[2] = 0;
                        this.statusSort[4] = -1;
                        this.statusSort[5] = 0;
                        this.evaluationsRequest.sort = { "query": { "date": 1 } }
                        break;
                }
                break;
            case 1:
                switch (event) {
                    case 0:
                        this.statusSort[event] = 2;
                        this.statusSort[1] = 0;
                        this.statusSort[2] = 0;
                        this.statusSort[3] = 0;
                        this.statusSort[4] = -1;
                        this.evaluationsRequest.sort = { "query": { "name": -1 } }
                        break;
                    case 1:
                        this.statusSort[event] = 2;
                        this.statusSort[0] = 0;
                        this.statusSort[2] = 0;
                        this.statusSort[3] = 0;
                        this.statusSort[4] = -1;
                        this.statusSort[5] = 0;
                        this.evaluationsRequest.sort = { "query": { "email": -1 } }
                        break;
                    case 2:
                        this.statusSort[event] = 2;
                        this.statusSort[0] = 0;
                        this.statusSort[1] = 0;
                        this.statusSort[3] = 0;
                        this.statusSort[4] = -1;
                        this.statusSort[5] = 0;
                        this.evaluationsRequest.sort = { "query": { "discription": -1 } }
                        break;
                    case 3:
                        this.statusSort[event] = 2;
                        this.statusSort[0] = 0;
                        this.statusSort[1] = 0;
                        this.statusSort[2] = 0;
                        this.statusSort[4] = -1;
                        this.statusSort[5] = 0;
                        this.evaluationsRequest.sort = { "query": { "date": -1 } }
                        break;
                }
                break;
            case 2:
                this.evaluationsRequest.sort = undefined;
                this.statusSort[event] = 0;
                break;
        }
        this.searchEvaluations(1, true);
    }

    onScroll() {
        if (this.evaluations.length > 0) {
            this.page++;
            this.searchEvaluations(this.page, false);
        }
    }
}
