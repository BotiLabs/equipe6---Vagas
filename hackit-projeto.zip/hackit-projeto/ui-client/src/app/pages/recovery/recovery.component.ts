import { Router, ActivatedRouteSnapshot, ActivatedRoute } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { trigger, state, style, AUTO_STYLE, transition, animate } from '@angular/animations';
import { UserModel } from '../../models/user.model';
import { AuthService } from '../../../../_services/auth.service';
import { EnumsHelper } from '../../common/enums-helper';

@Component({
  selector: 'app-recovery',
  templateUrl: './recovery.component.html',
  styleUrls: ['./recovery.component.css'],
  animations: [
    trigger('cardToggle', [
      state('collapsed, void',
        style({
          overflow: 'hidden',
          height: '0px',
        })
      ),
      state('expanded',
        style({
          height: AUTO_STYLE,
        })
      ),
      transition('collapsed <=> expanded', [
        animate('500ms ease-in-out')
      ])
    ]),
    trigger('cardToggleInverse', [
      state('collapsed, void',
        style({
          overflow: 'hidden',
          height: '0px',
        })
      ),
      state('expanded',
        style({
          height: AUTO_STYLE,
        })
      ),
      transition('collapsed <=> expanded', [
        animate('50ms ease-in-out')
      ])
    ])
  ]
})
export class RecoveryComponent implements OnInit {
  id: string;
  jsonError: string;
  confirmation: string = "";
  userModel: UserModel = new UserModel();
  login: boolean = true;
  emailRecovery: string = "";
  changed: boolean = false;
  showForm: boolean = false;
  enumsHelper: EnumsHelper = new EnumsHelper();
  public menuType: string;
  public headerType: string;
  public sidebarType: string;
  public themeType: string;
  public toggledArrow: string;
  public windowHeight: number;
  public windowWidth: number;
  public settingToggle: string;
  public cardToggle = 'collapsed';
  message: string = "";
  constructor(
    private activatedRoute: ActivatedRoute,
    private authService: AuthService,
    private router: Router
  ) {
    this.userModel['confirmation'] = "";
    this.activatedRoute.queryParams
      .subscribe(params => {
        this.id = params['id'];
        if (this.id) {
          this.authService.getUserById(this.id).subscribe(r => {
            this.showForm = true;
            if (r.changeValidated) {
              this.showForm = false;
              this.message = "Você já alterou sua senha, solicite novamente caso deseje alterar";
              setTimeout(r => {
                this.router.navigate(['/login']);
              }, 3000)
            }
          })
        } else {
          this.message = "Página não encontrada :(";
          setTimeout(r => {
            this.router.navigate(['/login']);
          }, 3000)
        }
      });
    this.themeType = 'default';
    this.toggledArrow = 'icon-arrow-left-circle';
    this.settingToggle = 'off';
    this.windowHeight = window.innerHeight - 60;
    this.windowWidth = window.innerWidth;
    if (this.windowWidth < 1170) {
      this.menuType = 'mini-sidebar';
    }
    if (this.windowWidth < 768) {
      this.toggledArrow = 'fa fa-bars';
    }
    (<any>window).ga('set', 'page', 'Tela de recuperação de senha');
    (<any>window).ga('send', 'pageview');
  }

  ngOnInit() {
  }

  onResize(event) {
    this.windowHeight = event.target.innerHeight - 60;
    this.windowWidth = window.innerWidth;
    if (this.windowWidth < 1170) {
      this.menuType = 'mini-sidebar';
    } else {
      this.menuType = '';
    }

    if (this.windowWidth < 768) {
      this.toggledArrow = this.menuType === 'mini-sidebar show-sidebar' ? 'fa fa-close' : 'fa fa-bars';
    } else {
      this.toggledArrow = this.menuType === 'mini-sidebar' ? 'fa fa-bars' : 'icon-arrow-left-circle';
    }
  }

  toggleCard() {
    this.cardToggle = this.cardToggle === 'collapsed' ? 'expanded' : 'collapsed';
  }

  changePassword() {
    let obj = {
      password: "",
      _id: "",
      changeValidated: undefined
    };
    obj._id = this.id;
    obj.password = this.userModel.password;
    obj.changeValidated = true;

    this.authService.chagePassword(obj).subscribe(user => {
      this.enumsHelper.toast("Senha alterada com sucesso!", "success");
      setTimeout(r => {
        this.router.navigate(['/login']);
      }, 2000);
    }, err => {
      this.enumsHelper.toast(err.Errors.message, "warning");
    })
  }

}
