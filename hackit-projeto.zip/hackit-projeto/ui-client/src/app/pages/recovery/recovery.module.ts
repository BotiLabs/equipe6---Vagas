import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RecoveryComponent } from './recovery.component';
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from './../../shared/shared.module';
import { InputTrimModule } from 'ng2-trim-directive';

export const RecoveryRoutes: Routes = [
    {
        path: '',
        component: RecoveryComponent,
        data: {
            heading: 'Recovery'
        }
    }
];

@NgModule({
    imports: [
        CommonModule,
        RouterModule.forChild(RecoveryRoutes),
        SharedModule,
        InputTrimModule
    ],
    declarations: [RecoveryComponent]
})
export class RecoveryModule { }
