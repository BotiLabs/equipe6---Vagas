import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CompanyComponent } from './company.component';
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from '../../../shared/shared.module';
import { CurrencyMaskModule } from "ng2-currency-mask"; 
import { InputTrimModule } from 'ng2-trim-directive';
export const CompanyRoutes: Routes = [
  {
    path: '',
    component: CompanyComponent,
    data: {
      heading: '',
      status:false
    }
  }
];

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(CompanyRoutes),
    SharedModule,
    CurrencyMaskModule,
    InputTrimModule
  ],
  declarations: [CompanyComponent]
})
export class CompanyModule { }
