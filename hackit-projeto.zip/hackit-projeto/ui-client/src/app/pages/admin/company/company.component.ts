import { Component, OnInit } from '@angular/core';
import { PriorityOpportunity } from './../../../common/priority';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { OpportunityService } from '../../../../../_services/opportunity.service';
import { SearchOp } from '../../../../../_services/searchOp.service';
import { CompanyRequest } from '../../../common/company.request';
import { StatusOpportunity } from '../../../common/status-opportunity';
import { EnumsHelper } from '../../../common/enums-helper';
import { OpportunityModel } from '../../../models/opportunity.model';
import { TagService } from '../../../../../_services/tag.service';
import { BusinessUnit } from '../../../common/business-unit';
import { NotificationService } from '../../../../../_services/notification.service';
import { MatchService } from '../../../../../_services/match.service';
import { AuthService } from '../../../../../_services/auth.service';
import { LogsComponent } from '../../logs/logs.component';
import * as moment from 'moment';
import '../../../../assets/plugins/toast-master/js/jquery.toast.js';
import { CompanyModel } from './../../../models/company.model';
import { CompanyService } from '../../../../../_services/company.service';
@Component({
  selector: 'app-company',
  templateUrl: './company.component.html',
  styleUrls: ['./company.component.css']
})
export class CompanyComponent implements OnInit {
companyModel:CompanyModel = new CompanyModel();
companies:CompanyModel[] = [];
companiesLoaded:any;
companiesInit:CompanyModel[] = [];
totalItems:number;
companyRequest:CompanyRequest = new CompanyRequest();
  constructor(
    private companyService:CompanyService) { }

  ngOnInit() {
    this.searchCompanies(1);
  }

  searchCompanies(page){
    this.companies=[];
    this.companyRequest.page = page;
    this.companiesLoaded = undefined;
    this.companyService.search(this.companyRequest).subscribe(r=>{
      for(let l of r.result){
        var company = new CompanyModel();
        company.loadFromServer(l);
        this.companies.push(company)        
      }
      this.totalItems = r.count;
      this.companiesLoaded = true;
    })
  }


}

