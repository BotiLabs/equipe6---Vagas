import { Component, OnInit, Input, Output, EventEmitter, Injectable, ViewChild } from '@angular/core';
import { LogService } from '../../../../../_services/log.service';
import { LogModel } from '../../../models/log.model';
import { EnumsHelper } from '../../../common/enums-helper';
import { StatusCandidate } from '../../../common/status-candidate';
import { AuthService } from '../../../../../_services/auth.service';
import { NotificationService } from '../../../../../_services/notification.service';
import { PersistenceService } from 'angular-persistence';
import { LogsRequest } from '../../../common/logs.request';
import * as moment from 'moment';
moment.locale('pt-BR');

@Component({
    selector: 'app-component',
    templateUrl: './logs.component.html',
    styleUrls: ['./logs.component.css'],
})

export class LogsComponent implements OnInit {
    @ViewChild('myTable') table: any;
    logModel: LogModel = new LogModel();
    selectedItems = [];
    logs: LogModel[];
    logsRequest: LogsRequest = new LogsRequest();
    itemsPerPage: number[] = [10, 50, 100];
    limit: number = 10;
    totalItems: number;
    feedBackVisible: boolean;
    advancedSearch: boolean = false;
    initialDate: Date;
    withDate: any = undefined;
    searchSaveStatus: number = -1;
    logToSearch: string;
    validation: boolean;
    rows: any[] = [];
    expanded: any = {};
    timeout: any;
    page: number;
    statusSort: [number, number, number, number, number, number, number] = [0, 0, 0, 0, 0, 0, 0];
    logsLoaded: boolean = false;
    enumsHelper: EnumsHelper = new EnumsHelper();
    constructor(
        private logService: LogService,
        private persistenceService: PersistenceService,
        private authService: AuthService
    ) {
        (<any>window).ga('set', 'page', 'Página de logs');
        (<any>window).ga('send', 'pageview');
     }

    ngOnInit() {

        this.searchOnInit(1);
        this.logs = new Array<LogModel>();


    }

    create(descricao) {
        let userInfo = this.authService.getUserInfoModel();

        this.logModel.userEmail = userInfo.email;
        this.logModel.userFirstName = userInfo.firstName + " " + userInfo.lastName;
        this.logModel.discriptionLog = descricao;

        this.logService.add(this.logModel).subscribe(r => {
            this.logModel = new LogModel();
        }, (err) => {
            console.log(err.Errors.message);
        });
        return;
    }

    searchLogs(page: number) {
        this.validation = true;
        this.logsRequest.userEmail = this.logToSearch;
        this.logsRequest.userFirstName = this.logToSearch;
        this.logsRequest.discriptionLog = this.logToSearch;
        this.logsRequest.limit = this.limit;
        if (this.initialDate) {
            var initialDateCalc = Date.parse(this.initialDate.toString());
            var initialDate = initialDateCalc - 10800000;
            this.logsRequest['initialDate'] = initialDate;
        }
        if (this.logModel.registrationDate) {
            var dateCalc = Date.parse(this.logModel.registrationDate.toString())
            var finalDate = dateCalc + 75599999;
            this.logsRequest.registrationDate = finalDate;
        }
        if (this.initialDate > this.logsRequest.registrationDate) {
            this.enumsHelper.toast("A data inicial não pode ser maior que a data final.", 'warning');
            return;
        }
        // if (this.withDate == true) {
        //     this.logsRequest.dateValidator = {
        //         $ne: null
        //     }
        // }
        // if (this.withDate == false) {
        //     this.logsRequest.dateValidator = null;
        // }
        // if (this.withDate == undefined) {
        //     this.logsRequest.dateValidator = undefined;
        // }
        this.logsRequest.page = page;
        
        this.logService.search(this.logsRequest).subscribe(res => {
            this.totalItems = res.count;
            this.logs = [];
            for (let tr of res.result) {
                let l = new LogModel();
                l.loadFromServer(tr);
                this.logs.push(l);
            }

        });
        this.feedBackVisible = true;
    }
    clearInitialDate() {
        this.initialDate = undefined;
        this.logsRequest['initialDate'] = undefined;
    }
    clearFinalDate() {
        this.logModel.registrationDate = undefined;
    }
    searchOnInit(page: number) {
        this.persistenceService.set('userFirstName', this.logsRequest.userFirstName);
        this.persistenceService.set('discriptionLog', this.logsRequest.discriptionLog);
        this.persistenceService.set('registrationDate', this.logsRequest.registrationDate);
        this.persistenceService.set('selectedItems', this.selectedItems);


        this.page = page;
        this.logsLoaded = false;
        this.logsRequest.page = page;
        this.logsRequest.limit = this.limit;
        this.logService.search(this.logsRequest).subscribe(res => {
            this.logsLoaded = true;
            this.totalItems = res.count;
            this.logs = [];
            for (let cr of res.result) {
                let c = new LogModel();
                c.loadFromServer(cr);
                this.logs.push(c);
            }
        });
    }
    formatDate(registrationDate: Date) {
        return moment(registrationDate).format('L');
    }
    formatTime(registrationDate: Date) {
        return moment(registrationDate).format('LT');
    }

    onPage(event) {
        clearTimeout(this.timeout);
        this.timeout = setTimeout(() => {
            console.log('paged!', event);
        }, 100);
        this.searchLogs(event)
    }

    fetch(cb) {
        const req = new XMLHttpRequest();
        req.open('GET', `assets/data/candidates.json`);

        req.onload = () => {
            cb(JSON.parse(req.response));
        };

        req.send();
    }

    toggleExpandRow(row) {
        this.table.rowDetail.toggleExpandRow(row);
        this.expanded = true;
    }

    onSort(event) {
        // event was triggered, start sort sequence
        switch (this.statusSort[event]) {
            case 0:
                switch (event) {
                    case 0:
                        this.statusSort[event] = 1;
                        this.statusSort[1] = 0;
                        this.statusSort[2] = 0;
                        this.statusSort[3] = 0;
                        this.logsRequest.sort = { "query": { "userFirstName": 1 } }
                        break;
                    case 1:
                        this.statusSort[event] = 1;
                        this.statusSort[0] = 0;
                        this.statusSort[2] = 0;
                        this.statusSort[3] = 0;
                        this.logsRequest.sort = { "query": { "discriptionLog": 1 } }
                        break;
                    case 2:
                        this.statusSort[event] = 1;
                        this.statusSort[0] = 0;
                        this.statusSort[1] = 0;
                        this.statusSort[3] = 0;
                        this.logsRequest.sort = { "query": { "registrationDate": 1 } }
                        break;
                }
                break;
            case 1:
                switch (event) {
                    case 0:
                        this.statusSort[event] = 2;
                        this.statusSort[1] = 0;
                        this.statusSort[2] = 0;
                        this.statusSort[3] = 0;
                        this.logsRequest.sort = { "query": { "userFirstName": -1 } }
                        break;
                    case 1:
                        this.statusSort[event] = 2;
                        this.statusSort[0] = 0;
                        this.statusSort[2] = 0;
                        this.statusSort[3] = 0;
                        this.logsRequest.sort = { "query": { "discriptionLog": -1 } }
                        break;
                    case 2:
                        this.statusSort[event] = 2;
                        this.statusSort[0] = 0;
                        this.statusSort[1] = 0;
                        this.statusSort[3] = 0;
                        this.logsRequest.sort = { "query": { "registrationDate": -1 } }
                        break;
                }
                break;
            case 2:
                this.logsRequest.sort = undefined;
                this.statusSort[event] = 0;
                break;
        }
        this.searchLogs(this.page);
    }
    
    onDetailToggle(event) { }
}

