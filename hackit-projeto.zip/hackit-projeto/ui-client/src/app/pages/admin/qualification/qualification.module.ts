import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { QualificationComponent } from './qualification.component';
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from '../../../shared/shared.module';
import { CurrencyMaskModule } from "ng2-currency-mask"; 
import { InputTrimModule } from 'ng2-trim-directive';
export const QualificationRoutes: Routes = [
  {
    path: '',
    component: QualificationComponent,
    data: {
      heading: '',
      status:false
    }
  }
];

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(QualificationRoutes),
    SharedModule,
    CurrencyMaskModule,
    InputTrimModule
  ],
  declarations: [QualificationComponent]
})
export class QualificationModule { }
