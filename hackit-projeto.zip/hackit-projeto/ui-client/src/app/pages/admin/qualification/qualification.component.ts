import { QualificationModel } from './../../../models/quelification.model';
import { Component, OnInit } from '@angular/core';
import * as XLSX from 'xlsx';
import { QualificationService } from '../../../../../_services/qualification.service';
import { EnumsHelper } from '../../../common/enums-helper';

declare var $: any;
@Component({
  selector: 'app-qualification',
  templateUrl: './qualification.component.html',
  styleUrls: ['./qualification.component.css']
})

export class QualificationComponent implements OnInit {
  files: any;
  data: any;
  qualificationModel: QualificationModel = new QualificationModel();
  skillsQualification: any[][] = [[], [], [], [], [], [], [], [], [], []];
  qualifications: QualificationModel[] = [];
  totalItems: number = 0;
  limit: number = 10;
  page: number = 1;
  showTable: boolean = false;
  qualificationLoaded: boolean = true;
  enumsHelper: EnumsHelper = new EnumsHelper();
  constructor(
    private qualificationService: QualificationService
  ) {

  }

  ngOnInit() {

  }

  onFileChange(evt: any) {
    if (evt.target.files[0].type != "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet") {
      this.enumsHelper.toast("Somente aceitamos arquivos do tipo excel (xlsx)", "warning");
      return;
    }
    /* wire up file reader */
    const target: DataTransfer = <DataTransfer>(evt.target);
    if (target.files.length !== 1) throw new Error('Cannot use multiple files');
    const reader: FileReader = new FileReader();
    reader.onload = (e: any) => {
      /* read workbook */
      const bstr: string = e.target.result;
      const wb: XLSX.WorkBook = XLSX.read(bstr, { type: 'binary' });

      /* grab first sheet */
      const wsname: string = wb.SheetNames[0];
      const ws: XLSX.WorkSheet = wb.Sheets[wsname];

      /* save data */
      this.data = <any>(XLSX.utils.sheet_to_json(ws, { header: 1 }));
      this.validateData(this.data);
    };
    reader.readAsBinaryString(target.files[0]);
  }

  validateData(data: any) {
    this.qualifications = [];
    this.skillsData(data[0]);
    for (let lines of data) {
      if (lines.length > 0) {
        let discriptionArray = [];
        this.qualificationModel.discription = discriptionArray.join("<br>");
        this.qualificationModel = new QualificationModel();
        for (var i = 3; i < 9; i++) {
          if (i < 7) {
            let question = data[0][i];
            let answer = lines[i]
            discriptionArray.push("Pergunta: " + question + " Resposta: " + answer);

          }
          if (i == 7) {
            switch (lines[7]) {
              case "CLT":
                this.qualificationModel.desiredHiring.push(0)
                break;
              case "PJ":
                this.qualificationModel.desiredHiring.push(1)
                break;
              case "Ambas as contratações":
                this.qualificationModel.desiredHiring.push(0)
                this.qualificationModel.desiredHiring.push(1)
                break;
            }
          }

        }

        switch (lines[8]) {
          case "Analista de Banco de Dados / DBA":
            for (var i = 271; i < 287; i++) {
              this.reciveSkills(lines[i], i, this.skillsQualification[0])
            }
            this.qualificationModel.date = new Date(lines[0]);
            this.qualificationModel.name = lines[1];
            this.qualificationModel.noAscentName = lines[1];
            this.qualificationModel.email = lines[2];
            this.qualificationModel.position = lines[8];
            break;

          case "Analista de Negócios":
            for (var i = 193; i < 199; i++) {
              if (i != 195)
                this.reciveSkills(lines[i], i, this.skillsQualification[1])
            }
            this.qualificationModel.date = new Date(lines[0]);
            this.qualificationModel.name = lines[1];
            this.qualificationModel.noAscentName = lines[1];
            this.qualificationModel.email = lines[2];
            this.qualificationModel.position = lines[8];
            break;

          case "Analista de Qualidade - QA":
            for (var i = 199; i < 244; i++) {
              if (i != 201 && i != 233)
                this.reciveSkills(lines[i], i, this.skillsQualification[2])
            }
            this.qualificationModel.date = new Date(lines[0]);
            this.qualificationModel.name = lines[1];
            this.qualificationModel.noAscentName = lines[1];
            this.qualificationModel.email = lines[2];
            this.qualificationModel.position = lines[8];
            break;

          case "Arquiteto de Software / Soluções":

            for (var i = 150; i < 193; i++) {
              this.reciveSkills(lines[i], i, this.skillsQualification[3])
            }
            this.qualificationModel.date = new Date(lines[0]);
            this.qualificationModel.name = lines[1];
            this.qualificationModel.noAscentName = lines[1];
            this.qualificationModel.email = lines[2];
            this.qualificationModel.position = lines[8];
            break;

          case "Desenvolvedor (a) Back-End":
            for (var i = 36; i < 86; i++) {
              this.reciveSkills(lines[i], i, this.skillsQualification[4])
            }
            this.qualificationModel.date = new Date(lines[0]);
            this.qualificationModel.name = lines[1];
            this.qualificationModel.noAscentName = lines[1];
            this.qualificationModel.email = lines[2];
            this.qualificationModel.position = lines[8];
            break;

          case "Desenvolvedor (a) Front-End":
            for (var i = 9; i < 36; i++) {
              this.reciveSkills(lines[i], i, this.skillsQualification[5])
            }
            this.qualificationModel.date = new Date(lines[0]);
            this.qualificationModel.name = lines[1];
            this.qualificationModel.noAscentName = lines[1];
            this.qualificationModel.email = lines[2];
            this.qualificationModel.position = lines[8];
            break;

          case "Desenvolvedor (a) Full Stack":
            for (var i = 86; i < 150; i++) {
              this.reciveSkills(lines[i], i, this.skillsQualification[6])
            }
            this.qualificationModel.date = new Date(lines[0]);
            this.qualificationModel.name = lines[1];
            this.qualificationModel.noAscentName = lines[1];
            this.qualificationModel.email = lines[2];
            this.qualificationModel.position = lines[8];
            break;

          case "Desenvolvedor (a) Mobile":
            for (var i = 309; i < 359; i++) {
              this.reciveSkills(lines[i], i, this.skillsQualification[7])
            }
            this.qualificationModel.date = new Date(lines[0]);
            this.qualificationModel.name = lines[1];
            this.qualificationModel.noAscentName = lines[1];
            this.qualificationModel.email = lines[2];
            this.qualificationModel.position = lines[8];
            break;

          case "DevOps":
            for (var i = 287; i < 309; i++) {
              this.reciveSkills(lines[i], i, this.skillsQualification[8])
            }
            this.qualificationModel.date = new Date(lines[0]);
            this.qualificationModel.name = lines[1];
            this.qualificationModel.noAscentName = lines[1];
            this.qualificationModel.email = lines[2];
            this.qualificationModel.position = lines[8];
            break;


          case "Scrum Master / Product Owner":
            for (var i = 244; i < 271; i++) {
              this.reciveSkills(lines[i], i, this.skillsQualification[9])
            }
            this.qualificationModel.date = new Date(lines[0]);
            this.qualificationModel.name = lines[1];
            this.qualificationModel.noAscentName = lines[1];
            this.qualificationModel.email = lines[2];
            this.qualificationModel.position = lines[8];
            break;

          default:
            break;
        }
        if (data.indexOf(lines) != 0)
          this.qualifications.push(this.qualificationModel)

      }
      this.showTable = true;
      setTimeout(() => {
        this.totalItems = this.qualifications.length
        this.showTable = false;
      }, 600);
    }
  }

  reciveSkills(line, i, skillsQualification) {
    switch (line) {
      case "Tenho boa experiência":
        skillsQualification.forEach(obj => {
          if (i == obj.index) {
            this.qualificationModel.mainSkills.push(obj.tag)
          }
        })
        break;
      case "Domino":
        skillsQualification.forEach(obj => {
          if (i == obj.index) {
            this.qualificationModel.mainSkills.push(obj.tag)
          }
        })
        break;

      case "Estudo":
        skillsQualification.forEach(obj => {
          if (i == obj.index) {
            this.qualificationModel.secondarySkills.push(obj.tag)
          }
        })
        break;

      case "Já atuei profissionalmente":
        skillsQualification.forEach(obj => {
          if (i == obj.index) {
            this.qualificationModel.secondarySkills.push(obj.tag)
          }
        })
        break;

      default:
        break;
    }
  }

  skillsData(data) {

    for (var i = 271; i < 287; i++) {
      this.skillsQualification[0].push({ "tag": data[i].substring(data[i].indexOf("[") + 1, data[i].indexOf("]")).toUpperCase(), "index": i });
    }
    for (var i = 193; i < 199; i++) {
      if (i != 195)
        this.skillsQualification[1].push({ "tag": data[i].substring(data[i].indexOf("[") + 1, data[i].indexOf("]")).toUpperCase(), "index": i });
    }

    for (var i = 199; i < 244; i++) {
      if (i != 201 && i != 233)
        this.skillsQualification[2].push({ "tag": data[i].substring(data[i].indexOf("[") + 1, data[i].indexOf("]")).toUpperCase(), "index": i });
    }

    for (var i = 150; i < 193; i++) {
      this.skillsQualification[3].push({ "tag": data[i].substring(data[i].indexOf("[") + 1, data[i].indexOf("]")).toUpperCase(), "index": i });
    }

    for (var i = 36; i < 86; i++) {
      this.skillsQualification[4].push({ "tag": data[i].substring(data[i].indexOf("[") + 1, data[i].indexOf("]")).toUpperCase(), "index": i });
    }

    for (var i = 9; i < 36; i++) {
      this.skillsQualification[5].push({ "tag": data[i].substring(data[i].indexOf("[") + 1, data[i].indexOf("]")).toUpperCase(), "index": i });
    }

    for (var i = 86; i < 150; i++) {
      this.skillsQualification[6].push({ "tag": data[i].substring(data[i].indexOf("[") + 1, data[i].indexOf("]")).toUpperCase(), "index": i });
    }

    for (var i = 309; i < 359; i++) {
      this.skillsQualification[7].push({ "tag": data[i].substring(data[i].indexOf("[") + 1, data[i].indexOf("]")).toUpperCase(), "index": i });
    }

    for (var i = 287; i < 309; i++) {
      this.skillsQualification[8].push({ "tag": data[i].substring(data[i].indexOf("[") + 1, data[i].indexOf("]")).toUpperCase(), "index": i });
    }

    for (var i = 244; i < 271; i++) {
      this.skillsQualification[9].push({ "tag": data[i].substring(data[i].indexOf("[") + 1, data[i].indexOf("]")).toUpperCase(), "index": i });
    }
  }


  paginate(page_size, page_number) {
    this.page = page_number
    return this.qualifications.slice(this.page * page_size, (this.page + 1) * page_size);
  }

  saveQualifications() {
    if (this.qualifications.length > 0) {

      this.qualificationLoaded = false;

      this.qualificationService.create(this.qualifications).subscribe(r => {
        this.enumsHelper.toast(r.insertedMsg + r.duplicatedMsg, "success")
        this.qualificationLoaded = true;
      }, err => {
        this.enumsHelper.toast(err.Errors.message, "warning")
        this.qualificationLoaded = true;
      })
    } else {

      this.enumsHelper.toast("Não há nenhum candidato importado para salvar", "warning");

    }
  }
}