import { InteractionModel } from './../../../models/interaction.model';
import { Component, OnInit } from '@angular/core';
import { ManagementService } from '../../../../../_services/service-management.service';
import { ServiceManagementModel } from '../../../models/service-management.model';

@Component({
  selector: 'app-service-management',
  templateUrl: './service-management.component.html',
  styleUrls: ['./service-management.component.css'],
  providers: [ManagementService],
})

export class ServiceManagementComponent implements OnInit {

  configs: ServiceManagementModel;

  constructor(
    public serviceManagement: ManagementService,
  ) {
    this.getConfig();
    (<any>window).ga('set', 'page', 'Página de configurações');
    (<any>window).ga('send', 'pageview');
  }

  ngOnInit() {
  }


  getConfig() {
    this.serviceManagement.getAll().subscribe(tg => {
      this.configs = tg;
    })
  }

  updateConfig(key) {
    if (!this.configs) {
      return;
    }
    switch (key) {
      case 0:
        this.configs.interactionEmail = !this.configs.interactionEmail;
        break;


      case 1:
        this.configs.reprovalEmail = !this.configs.reprovalEmail;

        break;

      case 2:
        this.configs.statusRobot = !this.configs.statusRobot;

        break;

      default:
        break;
    }

    this.serviceManagement.update(this.configs).subscribe(r => {
      return;
    });
  }


}
