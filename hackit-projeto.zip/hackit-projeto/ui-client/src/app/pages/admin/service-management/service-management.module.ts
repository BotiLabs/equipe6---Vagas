import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '../../../../../node_modules/@angular/router';
import { ServiceManagementComponent } from './service-management.component';
import { UiSwitchModule } from 'ngx-ui-switch';
export const ServiceManagementRoutes: Routes = [
  {
    path: '',
    component: ServiceManagementComponent,
    data: {
      heading: 'ServiceManagement',
      status: false
    }
  }
];
@NgModule({
  imports: [
    UiSwitchModule,
    CommonModule,
    RouterModule.forChild(ServiceManagementRoutes)
  ],
  declarations: [ServiceManagementComponent]
})
export class ServiceManagementModule { }
