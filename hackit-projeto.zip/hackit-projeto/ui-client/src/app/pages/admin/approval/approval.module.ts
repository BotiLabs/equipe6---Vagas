import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from '../../../shared/shared.module';
import { RatingModule } from "ngx-rating";
import { ApprovalComponent } from './approval.component';
export const ApprovalRoutes: Routes = [
{
    path: '',
    component:ApprovalComponent,
    data: {
        heading: 'Users'
      }
}
];

@NgModule({
    imports: [
        CommonModule,
        RouterModule.forChild(ApprovalRoutes),
        SharedModule
    ],
    declarations: [ApprovalComponent]
})

export class ApprovalModule { }

