import { Component, OnInit } from '@angular/core';
import { PriorityOpportunity } from './../../../common/priority';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { OpportunityService } from '../../../../../_services/opportunity.service';
import { SearchOp } from '../../../../../_services/searchOp.service';
import { LocationOpportunityRequest } from '../../../common/location-opportunity.request';
import { StatusOpportunity } from '../../../common/status-opportunity';
import { EnumsHelper } from '../../../common/enums-helper';
import { OpportunityModel } from '../../../models/opportunity.model';
import { TagService } from '../../../../../_services/tag.service';
import { BusinessUnit } from '../../../common/business-unit';
import { NotificationService } from '../../../../../_services/notification.service';
import { MatchService } from '../../../../../_services/match.service';
import { AuthService } from '../../../../../_services/auth.service';
import { LogsComponent } from '../../logs/logs.component';
import * as moment from 'moment';
import '../../../../assets/plugins/toast-master/js/jquery.toast.js';
import { LocationModel } from './../../../models/location.model';
import { UserModel } from '../../../models/user.model';

@Component({
  selector: 'app-approval',
  templateUrl: './approval.component.html',
  styleUrls: ['./approval.component.css']
})
export class ApprovalComponent implements OnInit {
  locationModel: LocationModel = new LocationModel();
  locations: LocationModel[] = [];
  locationsLoaded: any;
  locationsInit: LocationModel[] = [];
  totalItems: number;
  users: UserModel[] = [];
  visible: boolean = false;
  userModel: UserModel = new UserModel();
  locationRequest: LocationOpportunityRequest = new LocationOpportunityRequest();
  limit: number = 10;
  page: number;
  totalUsers: UserModel[] = [];
  constructor(
    private opportunityService: OpportunityService,
    private authService: AuthService) {
    (<any>window).ga('set', 'page', 'Aprovação de usuários');
    (<any>window).ga('send', 'pageview');
  }

  ngOnInit() {
    this.searchUsers(1);
  }

  searchUsers(page) {
    this.page = page
    this.locationsLoaded = undefined;
    this.users = [];
    let userModel = new UserModel();
    if (this.userModel.fullName.indexOf(" ") > 0) {
      userModel.firstName = this.userModel.fullName.substring(0, this.userModel.fullName.indexOf(" "));
      userModel.lastName = this.userModel.fullName.substring(this.userModel.fullName.indexOf(" ") + 1, this.userModel.fullName.length);
    } else {
      userModel.firstName = this.userModel.fullName.substring(0, this.userModel.fullName.length);
    }
    this.authService.searchUsers({ firstName: userModel.firstName, lastName: userModel.lastName, page: this.page, limit: this.limit }).subscribe(r => {
      for (let u of r.result) {
        var user = new UserModel();
        user = u;
        this.users.push(user);
      }
      this.totalUsers = this.users;
      this.totalItems = r.count;
      this.locationsLoaded = true;
    })

  }

  updateUser(user: UserModel) {
    user.approved = true;
    this.authService.updateUser(user).subscribe(res => {
      this.searchUsers(this.page);
    })
  }

}
