import { Component, OnInit } from '@angular/core';
import { OpportunityService } from '../../../../../_services/opportunity.service';
import { CompanyModel } from '../../../models/company.model';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { LogsComponent } from '../../logs/logs.component';
import { CompanyService } from '../../../../../_services/company.service';
declare var $: any;


@Component({
  selector: 'app-edit-company',
  templateUrl: './edit-company.component.html',
  styleUrls: ['./edit-company.component.css']
})
export class EditCompanyComponent implements OnInit {

  company: any[];
  companyModel: CompanyModel = new CompanyModel();
  local: any;
  success: any;
  constructor(
    private companyService: CompanyService,
    private route: ActivatedRoute,
    private log: LogsComponent,
    private router: Router,




  ) { }

  ngOnInit() {
    this.companyService.getById(this.route.snapshot.params['id']).subscribe(r => {
      this.companyModel.loadFromServer(r);
    });
  }


  updateCompany() {
    this.companyService.update(this.companyModel).subscribe(r => {
      this.success = true;
      let message = "Alterou a Empresa " + this.companyModel.name;
      this.log.create(message);
      this.companyModel = new CompanyModel();
      $.toast({
        heading: "Empresa editada com sucesso.",
        text: '',
        position: 'top-right',
        loaderBg: '#ff6849',
        icon: "success",
        hideAfter: 2500,
        stack: 6
      });
    }, (err) => {
      $.toast({
        heading: "Erro na edição",
        text: '',
        position: 'top-right',
        loaderBg: '#ff6849',
        icon: "warning",
        hideAfter: 2500,
        stack: 6
      });
    });

    this.redirectLastPage();

  }

  redirectLastPage() {
    this.router.navigateByUrl('admin/manage-companies');
  }

}
