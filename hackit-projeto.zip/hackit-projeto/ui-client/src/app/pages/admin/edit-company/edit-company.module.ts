import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EditCompanyComponent } from './edit-company.component';
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from '../../../shared/shared.module';
import { CurrencyMaskModule } from "ng2-currency-mask"; 
import { InputTrimModule } from 'ng2-trim-directive';
export const EditCompanyRoutes: Routes = [
  {
    path: '',
    component: EditCompanyComponent,
    data: {
      heading: 'edit-company',
      status:false
    }
  }
];

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(EditCompanyRoutes),
    SharedModule,
    CurrencyMaskModule,
    InputTrimModule
  ],
  declarations: [EditCompanyComponent]
})
export class EditCompanyModule { }
