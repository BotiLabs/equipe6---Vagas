import { SearchCandidate } from './../../../../../_services/search-candidate.service';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CandidateModel } from '../../../models/candidate.model';
import { CandidateService } from '../../../../../_services/candidate.service';
import { StatusCandidate } from '../../../common/status-candidate';
import { EnumsHelper } from '../../../common/enums-helper';
import { CandidatesRequest } from '../../../common/candidates.request';
import { TagService } from '../../../../../_services/tag.service';
import { PersistenceService } from 'angular-persistence';
import { NotificationService } from '../../../../../_services/notification.service';
import { PositionService } from '../../../../../_services/position.service';
import { OriginService } from '../../../../../_services/origin.service';
import { AuthService } from '../../../../../_services/auth.service';
import '../../../../assets/plugins/toast-master/js/jquery.toast.js';
import { LogsComponent } from '../../logs/logs.component';
import { Location } from '@angular/common';
import { OpportunityModel } from '../../../models/opportunity.model';
import { OpportunityService } from '../../../../../_services/opportunity.service';
import * as moment from 'moment';
import { TagModel } from '../../../models/tag.model';
import { Observable } from 'rxjs/Rx';
import { StatusOfCandidateService } from '../../../../../_services/statusCandidate.service';
import { StatusOfCandidateModel } from '../../../models/statusOfCandidate.model';
import { InteractionModel } from '../../../models/interaction.model';
import { InteractionService } from '../../../../../_services/interaction.service';
moment.locale('pt-BR');
declare var $: any;

@Component({
    selector: 'app-blacklist',
    templateUrl: './blacklist.component.html',
    styleUrls: ['./blacklist.component.css']
})
export class BlacklistComponent implements OnInit {
    dropdownItem: {};
    dropdownSettings = {};
    dropdownItemCargo: any = [];
    dropdownListCargo: any = [];
    dropdownList: any = [];
    selectedItems: any = [];
    selectedItemsCargo: any = [];
    itemsPerPage: number[] = [10, 50, 100];
    limit: number = 15;
    totalItems: number;
    candidatesRequest: CandidatesRequest = new CandidatesRequest();
    enumsHelper: EnumsHelper = new EnumsHelper();
    query: any;
    candidates: CandidateModel[];
    ddlStatus: StatusCandidate[];
    title: string = '';
    subtitle: string = '';
    candidateModel: CandidateModel = new CandidateModel();
    advancedSearch: boolean = false;
    searchSaveStatus: number = -1;
    candidatesLoaded: boolean = false;
    page: number;
    statusSort: [number, number, number, number, number, number, number] = [0, 0, 0, 0, 0, 0, 0];
    tags: TagModel[] = [];
    statusOfCandidateArray: StatusOfCandidateModel[];
    modal: boolean = false;
    dropdownSettingsSingle: {};
    opportunities: OpportunityModel[] = [];
    dropdownItemOpp: {};
    dropdownListOpp: any = [];
    selectedItemsOpp: any = [];
    exportItensArr: any[][] = [];
    any: number;
    modalToInteraction: boolean = false;
    interaction: InteractionModel = new InteractionModel();
    success: boolean = false;
    btnBlock: string;


    constructor(
        private opportunityService: OpportunityService,
        public authService: AuthService,
        private candidateService: CandidateService,
        private interactionService: InteractionService,
        public tagService: TagService,
        private persistenceService: PersistenceService,
        private statusOfCandidate: StatusOfCandidateService,
        private logs: LogsComponent

    ) {
        this.getAllStatus();
        this.dropdownSettings = {
            singleSelection: false,
            text: "Selecione...",
            selectAllText: 'Marcar todos',
            unSelectAllText: 'Desmarcar todos',
            enableSearchFilter: true,
            classes: "myclass custom-class",
            badgeShowLimit: 1,
            searchBy: ["itemName"]
        };
        this.dropdownSettingsSingle = {
            singleSelection: true,
            text: "Selecione...",
            selectAllText: 'Marcar todos',
            unSelectAllText: 'Desmarcar todos',
            enableSearchFilter: true,
            classes: "myclass custom-class",
            badgeShowLimit: 3,
            searchBy: ["itemName"]
        };
        (<any>window).ga('set', 'page', 'Candidatos com impedimento');
        (<any>window).ga('send', 'pageview');
    }

    ngOnInit() {
        this.candidates = [];
        this.getAllTags();
        this.getAllOpportunities();
        this.populateDropDowns();
        this.getCache();
        this.searchBlockedCandidates(1);

        this.dropdownItemCargo = new Array<any>();
        this.dropdownListCargo = new Array<any>();
        this.dropdownList = new Array<any>();
        this.selectedItems = new Array<any>();
        this.selectedItemsCargo = new Array<any>();
        this.ddlStatus = new Array<StatusCandidate>();
    }

    searchBlockedCandidates(page: number) {
        this.persistenceService.set('name', this.candidatesRequest.name);
        this.page = page;
        this.candidatesLoaded = false;
        this.candidatesRequest.page = page;
        this.candidatesRequest.limit = this.limit;
        this.candidatesRequest.name ? this.candidatesRequest.name = this.enumsHelper.validateAscentClientname(this.candidatesRequest.name) : this.candidatesRequest.name;
        this.candidateService.findBlockedCandidates(this.candidatesRequest).subscribe(res => {
            this.candidates = [];
            this.candidatesLoaded = true;
            this.totalItems = res.count;
            for (let cr of res.result) {
                let c = new CandidateModel();
                c.loadCandidate(cr);
                this.candidates.push(c);
            }
        });
    }

    //search candidate method
    searchCandidates(page: number) {
        //Cache of search
        this.persistenceService.set('name', this.candidatesRequest.name);
        this.persistenceService.set('statusCandidate', this.candidatesRequest.status);
        this.persistenceService.set('selectedItems', this.selectedItems);
        this.persistenceService.set('positionCandidate', this.candidatesRequest.position);
        this.persistenceService.set('selectedItemsCargo', this.selectedItemsCargo);
        if (this.candidatesRequest.skills !== undefined) {
            // for (var i = 0; i <= this.candidatesRequest.skills.length; i++) {
            //     this.persistenceService.set(this.candidateModel.skills[i], this.candidatesRequest.skills);
            // }
            for (let i of this.candidatesRequest.skills) {
                this.persistenceService.set(i, this.candidatesRequest.skills);
            }
        }

        this.candidates = [];
        this.page = page;
        this.candidatesLoaded = false;
        this.candidatesRequest.page = page;
        this.candidatesRequest.limit = this.limit;
        this.candidatesRequest.name ? this.candidatesRequest.name = this.enumsHelper.validateAscentClientname(this.candidatesRequest.name) : this.candidatesRequest.name;
        this.candidateService.search(this.candidatesRequest).subscribe(res => {
            this.candidatesLoaded = true;
            this.totalItems = res.count;
            this.candidates = [];
            for (let cr of res.result) {
                let c = new CandidateModel();
                if (cr.isBlocked) {
                    c.loadCandidate(cr);
                    this.candidates.push(c);
                }
            }
        });
    }

    populateCargo() {
        if (this.selectedItemsCargo && this.selectedItemsCargo.length !== undefined) {
            if (this.selectedItemsCargo.length > 0) {
                let arr = [];
                for (let position of this.selectedItemsCargo) {
                    arr.push(position.id);
                }
                this.candidatesRequest.position = arr;
            }
            if (this.selectedItemsCargo.length === 0) {
                this.candidatesRequest.position = undefined;
            }
        }
    }

    populateDropDowns() {
        this.ddlStatus = this.enumsHelper.getEnumStatusCandidateArray();

        if (this.ddlStatus && this.ddlStatus.length !== undefined) {
            for (var i = 0; i < this.ddlStatus.length; i++) {
                this.dropdownItem = {
                    id: i.toString(), itemName: this.enumsHelper.getDescriptionStatusCandidate(i)
                };
                this.dropdownList.push(this.dropdownItem);
            }
        }

        this.dropdownList.sort(function (a, b) {
            if (a.itemName > b.itemName) {
                return 1;
            }
            if (a.itemName < b.itemName) {
                return -1;
            }
            return 0;
        });

        for (var k = 1; k < 31; k++) {
            this.dropdownItemCargo = {
                id: this.enumsHelper.getPositionCandidate(k), itemName: this.enumsHelper.getPositionCandidate(k)
            };
            this.dropdownListCargo.push(this.dropdownItemCargo);
        }
    }

    getCache() {
        // Persistance
        this.candidatesRequest.name = this.persistenceService.get('name');
    }

    populateStatus() {
        if (this.selectedItems && this.selectedItems.length !== undefined) {
            if (this.selectedItems.length > 0) {
                let arrStatus = [];
                for (let status of this.selectedItems) {
                    arrStatus.push(status.id);
                }
                this.candidatesRequest.status = arrStatus;
            }
            if (this.selectedItems.length === 0) {
                this.candidatesRequest.status = -1;
            }
        }
    }

    onSort(event) {
        // event was triggered, start sort sequence
        switch (this.statusSort[event]) {
            case 0:
                switch (event) {
                    case 0:
                        this.statusSort[event] = 1;
                        this.statusSort[0] = 1;
                        this.statusSort[1] = 0;
                        this.statusSort[2] = 0;
                        this.statusSort[3] = 0;
                        this.candidatesRequest.sort = { 'query': { 'noAscentName': 1 } }
                        break;
                    case 1:
                        this.statusSort[event] = 1;
                        this.statusSort[0] = 0;
                        this.statusSort[1] = 1;
                        this.statusSort[2] = 0;
                        this.statusSort[3] = 0;
                        this.candidatesRequest.sort = { 'query': { 'position': 1 } }
                        break;
                    case 2:
                        this.statusSort[event] = 1;
                        this.statusSort[0] = 0;
                        this.statusSort[1] = 0;
                        this.statusSort[2] = 1;
                        this.statusSort[3] = 0;
                        this.candidatesRequest.sort = { 'query': { 'statusJoin.name': 1 } }
                        break;
                    case 3:
                        this.statusSort[event] = 1;
                        this.statusSort[0] = 0;
                        this.statusSort[1] = 0;
                        this.statusSort[2] = 0;
                        this.candidatesRequest.sort = { 'query': { 'relevance': 1 } }
                        break;
                }
                break;
            case 1:
                switch (event) {
                    case 0:
                        this.statusSort[event] = 2;
                        this.statusSort[0] = 2;
                        this.statusSort[1] = 0;
                        this.statusSort[2] = 0;
                        this.statusSort[3] = 0;
                        this.candidatesRequest.sort = { 'query': { 'noAscentName': -1 } }
                        break;
                    case 1:
                        this.statusSort[event] = 2;
                        this.statusSort[0] = 0;
                        this.statusSort[1] = 2;
                        this.statusSort[2] = 0;
                        this.statusSort[3] = 0;
                        this.candidatesRequest.sort = { 'query': { 'position': -1 } }
                        break;
                    case 2:
                        this.statusSort[event] = 2;
                        this.statusSort[0] = 0;
                        this.statusSort[1] = 0;
                        this.statusSort[2] = 2;
                        this.statusSort[3] = 0;
                        this.candidatesRequest.sort = { 'query': { 'statusJoin.name': -1 } }
                        break;
                    case 3:
                        this.statusSort[event] = 2;
                        this.statusSort[0] = 0;
                        this.statusSort[1] = 0;
                        this.statusSort[2] = 0;
                        this.candidatesRequest.sort = { 'query': { 'relevance': -1 } }
                        break;
                }
                break;
            case 2:
                this.candidatesRequest.sort = undefined;
                this.statusSort[event] = 0;
                break;
        }
        this.searchBlockedCandidates(this.page);
    }

    getAllTags() {
        this.tagService.getAll().subscribe(tg => {
            for (let t of tg) {
                var tag = new TagModel();
                tag.loadTag(t);
                this.tags.push(tag);
            }
        })
    }

    getAllStatus() {
        this.statusOfCandidate.getAll().subscribe(status => {
            this.statusOfCandidateArray = [];
            for (let statusC of status) {
                let statusLoaded = new StatusOfCandidateModel();
                statusLoaded.loadModelFromServer(statusC);
                this.statusOfCandidateArray.push(statusLoaded);
            }
        })
    }

    itemsRequest = (text: string): Observable<Array<string>> => {
        let tags = new Array<string>();
        var obs = new Observable<Array<string>>(observer => {

            this.tags.forEach(tag => {
                if (tag.name.indexOf(text)) {
                    tags.push(tag.name)
                }
            });

            observer.next(tags);
        });
        return obs;
    }

    loadStatus(status: number) {
        let obj = this.statusOfCandidateArray.find(x => x.number == status);
        if (obj)
            return obj;
    }

    openModal() {
        this.modal = true;
    }
    closeModal() {
        this.modal = false;
    }
    closeModalAndClean() {
        this.selectedItemsOpp = [];
        this.candidatesRequest.skills = [];
        this.modal = false;
    }
    getAllOpportunities() {
        this.opportunities = [];
        this.opportunityService.getAll().subscribe(r => {
            for (let item of r) {
                var opportunity = new OpportunityModel();
                opportunity.loadModelFromServer(item);
                this.dropdownItemOpp = {
                    id: JSON.stringify(opportunity), itemName: opportunity.number.toString() + " - " + opportunity.name + " - Cliente: " + opportunity.customerName
                };
                this.dropdownListOpp.push(this.dropdownItemOpp);
            }
        })
    }

    populateTags() {
        let opportunity = JSON.parse(this.selectedItemsOpp[0].id);
        this.candidatesRequest.skills = opportunity.specialities;
    }

    unpopulateTags() {
        this.candidatesRequest.skills = [];
    }

    exportList() {

        this.candidateService.exportList(this.candidatesRequest).subscribe(r => {
            console.log(r);
        });

        // const ws: XLSX.WorkSheet = XLSX.utils.aoa_to_sheet(this.exportItensArr);

        // /* generate workbook and add the worksheet */
        // const wb: XLSX.WorkBook = XLSX.utils.book_new();
        // XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');

        // /* save to file */
        // XLSX.writeFile(wb, 'SheetJS.xlsx');
    }

    blockCandidate() {
        this.modalToInteraction = !this.modalToInteraction;
        this.candidateModel.isBlocked = !this.candidateModel.isBlocked;
        let i = localStorage.getItem('userInfo');
        let y = JSON.parse(i)
        this.interaction.userEmail = y.email;
        this.interaction.userFirstName = `${y.firstName} ${y.lastName}`;
        let x: object
        this.interaction.opportunity = x;
        this.interaction.candidateId = this.candidateModel._id;

        if (this.candidateModel.isBlocked == true) {
            this.interaction.status = 11;
            this.interaction.action = 8;
            this.candidateModel.status = 11;
        } else {
            this.interaction.action = 9;
            this.interaction.status = 5;
            this.candidateModel.status = 5;
        }
        this.candidateService.update(this.candidateModel).subscribe(r => {
            this.searchBlockedCandidates(1);
        })

        this.interactionService.add(this.interaction).subscribe(r => {
        })
        this.updateCandidate()
        this.validateColorButton();
    }

    validateColorButton() {
        if (this.candidateModel.isBlocked) {
            this.btnBlock = "btn-grey"
        } else {
            this.btnBlock = "btn-unlock"
        }
    }

    updateCandidate() {
        this.candidateService.update(this.candidateModel).subscribe(r => {
            this.success = true;
            let message = "Alterou o candidato de Nome " + this.candidateModel.name;
            this.logs.create(message);
            this.enumsHelper.toast("Candidato editado com sucesso.", "success");
        }, (err) => {
            this.enumsHelper.toast("Erro na edição", "warning");
        });
    }

    modalToBlock(c: CandidateModel) {
        this.candidateModel = new CandidateModel();
        this.candidateModel = c;
        this.modalToInteraction = !this.modalToInteraction;
    }
}