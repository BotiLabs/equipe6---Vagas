import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from '../../../shared/shared.module';
import { CurrencyMaskModule } from "ng2-currency-mask"; 
import { InputTrimModule } from 'ng2-trim-directive';
import { BlacklistComponent } from './blacklist.component';
export const BlackListRoutes: Routes = [
  {
    path: '',
    component: BlacklistComponent,
    data: {
      heading: 'blacklist',
      status:false
    }
  }
];

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(BlackListRoutes),
    SharedModule,
    CurrencyMaskModule,
    InputTrimModule
  ],
  declarations: [BlacklistComponent]
})
export class BlackListModule { }
