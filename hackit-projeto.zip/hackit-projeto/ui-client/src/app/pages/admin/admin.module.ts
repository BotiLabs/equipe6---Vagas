import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from 'primeng/primeng';
import { LogsComponent } from '../../pages/logs/logs.component';
import { UiSwitchModule } from 'ngx-ui-switch';

export const AdminRoutes: Routes = [
  {
    path: '',
    children: [
      {
        path: 'manage-companies',
        loadChildren: './company/company.module#CompanyModule',
        data: {
          heading: "manage-companies"
        }
      },
      {
        path: 'edit-company/:id',
        loadChildren: './edit-company/edit-company.module#EditCompanyModule',
        data: {
          heading: "edit-company"
        }
      },
      {
        path: 'users',
        loadChildren: './approval/approval.module#ApprovalModule',
        data: {
          heading: 'users'
        }
      },
      {
        path: 'logs',
        loadChildren: './logs/logs.module#LogsModule',
        data: {
          heading: 'Logs'
        }
      },
      {
        path: 'qualification',
        loadChildren: './qualification/qualification.module#QualificationModule',
        data: {
          heading: 'users'
        }
      },
      {
        path: 'blacklist',
        loadChildren: './blacklist/blacklist.module#BlackListModule',
        data: {
          heading: 'Blacklist'
        }
      },
      {
        path: 'service-management',
        loadChildren: './service-management/service-management.module#ServiceManagementModule',
        data: {
          heading: 'Configurações'
        }
      },
    ]
  }
];

@NgModule({
  imports: [
    UiSwitchModule,
    CommonModule,
    RouterModule.forChild(AdminRoutes),
    SharedModule
  ],
  declarations: [],
  providers: [
    LogsComponent
  ]
})
export class AdminModule { }
