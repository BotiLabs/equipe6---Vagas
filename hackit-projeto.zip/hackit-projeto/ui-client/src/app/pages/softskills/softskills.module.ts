import { SoftSkillsComponent } from './softskills.component';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from '../../shared/shared.module';
import { InputTrimModule } from 'ng2-trim-directive';
import { InfiniteScrollModule } from 'ngx-infinite-scroll';

export const LogsRoutes: Routes = [
    {
    path:'',
    component: SoftSkillsComponent,
    data: {
        heading: 'SoftSkills'
        }
    }
];

@NgModule({
    imports: [
      CommonModule,
      InputTrimModule,
      RouterModule.forChild(LogsRoutes),
      SharedModule,
      InfiniteScrollModule
    ],
    declarations: [SoftSkillsComponent]
})
export class SoftSkillsModule { }