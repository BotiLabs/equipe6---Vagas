import { NgxPaginationModule } from 'ngx-pagination';
import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Router } from '@angular/router';
import { SoftSkillModel } from '../../models/softskill.model';
import { SoftSkillService } from '../../../../_services/softskill.service';
import { SoftSkillsRequest } from '../../common/softskill.request';
import { InteractionListenService } from '../../../../_services/interaction-listen.service';
import { NotificationService } from '../../../../_services/notification.service';
import { LogsComponent } from '../logs/logs.component';
import '../../../assets/plugins/toast-master/js/jquery.toast.js';
import { EnumsHelper } from '../../common/enums-helper';
declare var $: any;


@Component({
  selector: 'app-softskills',
  templateUrl: './softskills.component.html',
  styleUrls: ['./softskills.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class SoftSkillsComponent implements OnInit {
  title: string = "";
  subtitle: string = "";
  // itemsPerPage: number[] = [30, 60, 120, 240, 480];
  limit: number = 48;
  page: number;
  totalItems: number = -1;
  statusSoftSkill: string = "";
  modal: boolean = false;
  softskillsRequest: SoftSkillsRequest = new SoftSkillsRequest();
  softskills: SoftSkillModel[];
  softskillToSave: SoftSkillModel = new SoftSkillModel();
  softskillToInsertOrSave: SoftSkillModel = new SoftSkillModel();
  valores: string;
  softskillsRequestArr: SoftSkillsRequest[];
  softskillModel: SoftSkillModel = new SoftSkillModel();
  softskillValidator: string;
  i: any;
  p: number = 1;
  searchSaveStatus: number = -1;
  enumsHelper: EnumsHelper = new EnumsHelper();
  msg: string = ""

  constructor(
    private router: Router,
    private softskillService: SoftSkillService,
    private notificationService: NotificationService,
    private logs: LogsComponent
  ) {
    this.title = "Buscar Competências";
    this.subtitle = "Encontre as competências cadastradas.";
    (<any>window).ga('set', 'page', 'Tela de Competências');
    (<any>window).ga('send', 'pageview');
  }

  ngOnInit() {
    this.softskills = new Array<SoftSkillModel>();
    this.searchSoftSkills(1, false);
    this.getAllSoftSkills();
    // $('.tst3').on('click', () => {
    //   setTimeout(() => {
    //     switch (this.searchSaveStatus) {
    //       case 0:
    //         this.enumsHelper.toast("SoftSkill cadastrada com sucesso!", "success");
    //         break;
    //       case 1:
    //         this.enumsHelper.toast("Digite o nome da SoftSkill.", "warning");
    //         break;
    //       case 2:
    //         this.enumsHelper.toast("A pesquisa deve ter um nome.", "warning");
    //         break;
    //       case 3:
    //         this.enumsHelper.toast(this.msg, "error");
    //         break;
    //       case 4:
    //         this.enumsHelper.toast('SoftSkill atualizada com sucesso!', "success");
    //         break;
    //       case 5:
    //         this.enumsHelper.toast('A softskill não pode começar ou terminar com um espaço em branco', "warning");
    //         break;
    //       // default:
    //       //   $.toast({
    //       //     heading: "Alerta",
    //       //     text: 'Tente novamente',
    //       //     position: 'top-right',
    //       //     loaderBg: '#ff6849',
    //       //     icon: "warning",
    //       //     hideAfter: 4500,
    //       //     stack: 6
    //       //   });
    //       //   break;
    //     }
    //   }, 1000);
    // });
  }



  searchSoftSkills(page: number, scroll: boolean) {
    this.page = page;
    this.softskillsRequest.softskill = this.softskillToSave.softskill.trim();
    this.softskillsRequest.page = page;
    this.softskillsRequest.limit = this.limit;

    if (!scroll) {
      this.softskills = [];
    }

    this.softskillService.search(this.softskillsRequest).subscribe(res => {
      console.log(res)
      this.totalItems = res.count;
      for (let tr of res.result) {
        let t = new SoftSkillModel();
        t.loadSoftSkill(tr);
        this.softskills.push(t);
        // console.log(tr)
      }
      if (this.softskills.length <= 0){
        this.statusSoftSkill = "Não encontramos esta competência. Deseja criar uma nova?";
      }
    }
  
  
  ); 
  
  }


  setSoftSkillToEdit(id: string) {
    this.abrirModal();
    this.softskillModel = this.softskills.find(x => x._id === id);
  }

  
ifExists(softskill) {
  // this.softskillsRequest.softskill = softskill.inputTextValue;
  this.softskillService.searchIfExists(this.softskillsRequest).subscribe(r => {
      if (r == "Não encontramos esta softskill. Deseja criar uma nova?" && this.softskillsRequest.softskill != "") {
          this.statusSoftSkill = r
      } else {
          this.statusSoftSkill = "";
      }
  });
}

  saveSoftSkill() {
    // this.fecharModal();
    this.searchSaveStatus = -1;
    console.log(this.softskillToSave);
    if (this.softskillToSave.softskill.substring(0, 1) != " "
      && this.softskillToSave.softskill.substring(this.softskillToSave.softskill.length - 1, this.softskillToSave.softskill.length) != " ") {
      if (this.softskillToSave.softskill == "" && this.softskills.length < 0) {
        this.enumsHelper.toast("Digite o nome da SoftSkill.", "warning");
        return;
      }
      if (this.softskillToSave._id === undefined) {

        this.softskillService.add(this.softskillToSave).subscribe(r => {
          this.statusSoftSkill = "";
          var descricao = "Criou a softskill " + this.softskillToSave.softskill.toUpperCase();
          this.softskillToSave = new SoftSkillModel();
          this.logs.create(descricao);
          this.searchSoftSkills(1, false);
          this.enumsHelper.toast("SoftSkill cadastrada com sucesso!", "success");

          return;
        }, (err) => {

          this.enumsHelper.toast(this.msg, 'error');
        });
      } 
      // else {
      //   this.softskillService.updateToDelete(this.softskillToSave).subscribe(r => {

      //     this.searchSaveStatus = 4;
      //     this.softskillToSave = new SoftSkillModel();
      //     this.searchSoftSkills(1, false);
      //     var descricao = "Alterou uma softskill ";
      //     this.logs.create(descricao);
      //   }, err => {
      //     var error = JSON.parse(err._body);
      //     this.enumsHelper.toast(error.message, "warning");
      //   });
      // }
      return;
    } else {
      this.enumsHelper.toast('A softskill não pode começar ou terminar com um espaço em branco', "warning");
    }
  }


  getAllSoftSkills() {
    this.softskillService.getAll().subscribe(tg => {
      this.softskills.push(tg);
        for (let t of tg) {
            var softskill = new SoftSkillModel();
            softskill.loadSoftSkill(t);
        }
    })
}

// getAllSoftSkills() {
//   this.softskillService.getAll().subscribe(tg => {
//       for (let t of tg) {
//           var softskill = new SoftSkillModel();
//           softskill.loadSoftSkill(t);
//           this.softskills.push(softskill);
//       }
//   })
//   console.log(this.softskills);
// }

editSoftSkill(){
  if (this.softskillModel._id === undefined) {
    this.createSoftSkill();
} else {
  this.softskillService.updateToDelete(this.softskillModel).subscribe(r => {

    this.searchSaveStatus = 4;
    this.softskillModel = new SoftSkillModel();
    this.searchSoftSkills(1, false);
    var descricao = "Alterou uma softskill ";
    this.logs.create(descricao);
  }, err => {
    var error = JSON.parse(err._body);
    this.enumsHelper.toast(error.message, "warning");
  });
  this.fecharModal();
}
}


createSoftSkill() {
  // this.softskillModel.softskill = this.softskillsRequest.softskill;
  console.log(this.softskillModel);
  this.softskillService.add(this.softskillModel).subscribe(r => {
      this.statusSoftSkill = "";
      this.softskillModel = new SoftSkillModel();
      this.getAllSoftSkills();
      var descricao = "Criou a softskill " + this.softskillModel.softskill.toUpperCase();
      this.logs.create(descricao);
          this.searchSoftSkills(1, false);
          this.enumsHelper.toast("SoftSkill cadastrada com sucesso!", "success");
      return;
  }, (err) => {
      console.log(err);
      this.enumsHelper.toast("Digite o nome da SoftSkill.", "warning");
  });
  this.fecharModal();
}

// createSoftSkill() {
//   // this.softskillModel.softskill = this.softskillsRequest.softskill;
//   console.log(this.softskillModel);
//   this.softskillService.add(this.softskillModel).subscribe(r => {
//       this.statusSoftSkill = "";
//       this.softskillModel = new SoftSkillModel();
//       this.getAllSoftSkills();
//       var descricao = "Criou a softskill " + this.softskillModel.softskill.toUpperCase();
//       this.logs.create(descricao);
//           this.searchSoftSkills(1, false);
//           this.enumsHelper.toast("SoftSkill cadastrada com sucesso!", "success");
//       return;
//   }, (err) => {
//       console.log(err);
//   });
//   this.fecharModal();
// }


  no(softskill) {
    this.statusSoftSkill = "";
    // softskill.inputTextValue = "";
  }

  abrirModal(){
    this.modal = true;
  }

  fecharModal(){
    this.modal = false;
  }


  deleteSoftSkill(softskill: SoftSkillModel) {
    var descricao = "Deletou a softskill " + softskill.softskill;
    this.logs.create(descricao);
    softskill.visible = false;
    this.softskillService.update(softskill).subscribe(r => {

      this.searchSoftSkills(1, false);
      this.searchSaveStatus = 6;
      this.enumsHelper.toast("SoftSkill deletada com sucesso", "error");
      return;
    });

  }

  onScroll() {
    if (this.softskills.length > 0) {
      this.page++;
      this.searchSoftSkills(this.page, true);
    }
  }



// editSoftSkill(){

//   if (this.softskillModel._id === undefined) {
//     this.createSoftSkill();
// } else {
//   this.softskillService.updateToDelete(this.softskillModel).subscribe(r => {

//     this.searchSaveStatus = 4;
//     this.softskillModel = new SoftSkillModel();
//     this.searchSoftSkills(1, false);
//     var descricao = "Alterou uma softskill ";
//     this.logs.create(descricao);
//   }, err => {
//     var error = JSON.parse(err._body);
//     this.enumsHelper.toast(error.message, "warning");
//   });
//   this.fecharModal();
// }
// }




}


