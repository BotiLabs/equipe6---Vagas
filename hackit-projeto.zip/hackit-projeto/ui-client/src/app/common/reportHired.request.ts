export class ReportHiredRequest {
    page: number;
    limit: number;
    userFirstName: string;
    initialDate: Date;
    finalDate: Date;
    priority: number;
    sort: any;
    customerName: string;
    registrationDate: Date;
    status: number;
    userEmail: string

    constructor() {
        this.page = 1;
        this.limit = 15;
        this.userFirstName = "";
        this.status = 4;
        this.priority = -1;
        this.customerName = "";
        this.userEmail = "";
    }
}