export class SearchCandidateRequest {
    _id: String;
    number: any;
    name: String;
    userFirstName: String;
    userEmail: String;
    email: String;
    nameSearch: string;
    skills: String[];
    status: number;
    registrationDate: Date;
    position:string;
    company_id: string;

    constructor() {
        this.userFirstName;
        this.userEmail;
        this.nameSearch = "";
        this.number = 0;
        this.skills = [];
        this.registrationDate = new Date();
        this.name = "";
        this.email = "";
        this.status = -1;
        this.position = "";
        this.company_id = "";
    }

}