export enum HiringCandidate{
    CLT = 0,
    PJ = 1,
    Temporário = 2,
}