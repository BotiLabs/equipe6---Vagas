export class CompanyRequest {
    limit: number;
    page: number;
    _id: string;

    constructor() {
        this.page = 1;
        this.limit = 10;
        this._id = "";
    }
}