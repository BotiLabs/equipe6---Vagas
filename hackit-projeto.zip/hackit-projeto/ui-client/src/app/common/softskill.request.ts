
export class SoftSkillsRequest {
    _id: string;
    softskill: string;
    limit: number;
    page: number;
    status: number;
    company_id: string;

    constructor() {
        this._id='';
        this.softskill = '';
        this.page = 1;
        this.limit = 10;
        this.company_id = "";
    }
    public loadSoftSkill(response: any) {
        this._id = response._id;
        this.softskill = response.softskill;
        this.company_id = response.company_id;
    }
}