export class EvaluationsRequest {
    limit: number;
    page: number;
    name: string;
    email: string;
    date: any;
    type: string[];
    withDate: boolean;
    status: number;
    company_id: string;
    sort:any;
    dateValidator:any;
    
    constructor() {
        this.page = 1;
        this.limit = 10;
        this.name = "";
        this.email = "";
        this.date;
        this.type = [];
        this.withDate;
        this.company_id = "";
        this.sort;
        this.dateValidator;
    }
}