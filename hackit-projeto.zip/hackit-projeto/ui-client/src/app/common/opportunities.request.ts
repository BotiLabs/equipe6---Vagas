import { StatusOpportunity } from '../common/status-opportunity';
import { BusinessUnit } from '../common/business-unit';
import { ProfileCandidate } from '../common/profile-candidate';

export class OpportunitiesRequest {
    customerName: string;
    businessUnit: number;
    location: string;
    speciality: string;
    specialities: String[];
    status: StatusOpportunity;
    number: number;
    limit: number;
    page: number;
    name: string;
    profile: ProfileCandidate;
    responsible: string;
    value: number;
    registrationDate: any;
    priority: number;
    sort: any;
    involvedPeople: any;
    company_id: string;
    constructor() {
        this.status = 0;
        this.customerName = "";
        this.businessUnit = -1;
        this.location = "";
        this.speciality = "";
        this.specialities = [];
        this.number;
        this.page = 1;
        this.limit = 10;
        this.name = "";
        this.profile = -1;
        this.responsible = "";
        this.value;
        this.registrationDate;
        this.priority = -1;
        this.sort;
        this.involvedPeople = [];
        this.company_id = "";
    }
}
