export class LocationOpportunityRequest {
    _id: string;
    streetAddress: string;
    district: string;
    state: string;
    discription:string;
    opportunityLocation:string
    clientLocation:string;
    page:number;
    limit:number;
    company_id: string;

    constructor() {
        this.streetAddress = '';
        this.district = '';
        this.state = '';
        this.discription = '';
        this.opportunityLocation = '';
        this.clientLocation = '';
        this.page = 0;
        this.limit = 10;
        this.company_id = "";
    }
}