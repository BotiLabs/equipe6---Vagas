export enum TypeOfOrigin {
    Inbound = 0,
    Outbount = 1
    
}