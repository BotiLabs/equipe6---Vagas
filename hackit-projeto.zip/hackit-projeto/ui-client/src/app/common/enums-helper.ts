import { StatusOpportunity } from './status-opportunity';
import { StatusCandidate } from './status-candidate';
import { ProfileCandidate } from './profile-candidate';
import { ActionInteraction } from './action-interaction';
import { OpportunitiesRequest } from './opportunities.request'
import { BusinessUnit } from './business-unit';
import { ProfileInteraction } from './profile-interaction';
import { HiringCandidate } from './hiring-candidate';
import { PriorityOpportunity } from './priority';
import { TypeOfOrigin } from './typeOriginCandidate';
declare var $: any;
export class EnumsHelper {


    public getDescriptionActionInteraction(actionInteraction: ActionInteraction): string {

        switch (actionInteraction) {
            case ActionInteraction.Contato:
                return "Contato";
            case ActionInteraction.Contratacao:
                return "Contratação";
            case ActionInteraction.Avaliacao:
                return "Avaliação";
            case ActionInteraction.EntrevistaRS:
                return "Entrevista  R&S";
            case ActionInteraction.EntrevistaTecnica:
                return "Entrevista/Teste Técnico";
            case ActionInteraction.EntrevistaCliente:
                return "Entrevista Cliente";
            case ActionInteraction.Analise:
                return "Análise";
            case ActionInteraction.Bloqueio:
                return "Bloqueio";
            case ActionInteraction.Desbloqueio:
                return "Desbloqueio";
            default:
                return "";
        }
    }

    getEnumActionInteractionArray() {
        let actions = [
            ActionInteraction.Avaliacao,
            ActionInteraction.Analise,
            ActionInteraction.Bloqueio,
            ActionInteraction.Contato,
            ActionInteraction.Contratacao,
            ActionInteraction.Desbloqueio,
            ActionInteraction.EntrevistaRS,
            ActionInteraction.EntrevistaTecnica,
            ActionInteraction.EntrevistaCliente
        ];
        return actions;
    }

    public getDescriptionTypeOfOriginCandidate(typeOriginCandidate: TypeOfOrigin): string {

        switch (typeOriginCandidate) {
            case TypeOfOrigin.Inbound:
                return "Inbound";
            case TypeOfOrigin.Outbount:
                return "Outbound";
            default:
                return "";
        }
    }

    getEnumTypeOfOriginCandidate() {
        let types = [
            TypeOfOrigin.Inbound,
            TypeOfOrigin.Outbount
        ];
        return types;
    }
    public getPriority(priorityOpportunity: PriorityOpportunity): string {

        switch (priorityOpportunity) {
            case PriorityOpportunity.Baixa:
                return "Baixa";
            case PriorityOpportunity.Media:
                return "Média";
            case PriorityOpportunity.Alta:
                return "Alta";
            default:
                return "";
        }
    }

    getEnumPrioritOpportunity() {
        let priority = [
            PriorityOpportunity.Baixa,
            PriorityOpportunity.Media,
            PriorityOpportunity.Alta
        ];
        return priority;
    }

    public getDescriptionStatusOpportunity(statusOpportunity: StatusOpportunity): string {

        switch (statusOpportunity) {
            case StatusOpportunity.Aberta:
                return "Aberta";
            case StatusOpportunity.Fechada:
                return "Fechada";
            case StatusOpportunity.Congelada:
                return "Congelada";
            case StatusOpportunity.Cancelada:
                return "Cancelada";
            default:
                return "";
        }
    }

    public getDescriptionStatusOpportunityToExport(number: number): string {

        switch (number) {
            case 0:
                return "Aberta";
            case 1:
                return "Fechada";
            case 2:
                return "Congelada";
            case 3:
                return "Cancelada";
            default:
                return "";
        }
    }

    getEnumStatusOpportunityArray() {
        let status = [
            StatusOpportunity.Aberta,
            StatusOpportunity.Fechada,
            StatusOpportunity.Congelada,
            StatusOpportunity.Cancelada
        ];
        return status;
    }
    //Matar este método TODO
    public getPositionCandidate(positionCandidate: number): string {
        positionCandidate = Number(positionCandidate);

        switch (positionCandidate) {
            case 1:
                return "Agile Coach";
            case 2:
                return "Analista Financeiro";
            case 3:
                return "Analista de Banco de Dados";
            case 4:
                return "Analista de DevOPS";
            case 5:
                return "Analista de Qualidade - Automação";
            case 6:
                return "Analista de Qualidade - Manual";
            case 7:
                return "Analista de Negócio";
            case 8:
                return "Analista de Requisitos";
            case 9:
                return "Arquiteto(a) de Software";
            case 10:
                return "Arquiteto (a) de Soluções";
            case 11:
                return "Desenvolvedor(a) Mobile";
            case 12:
                return "Desenvolvedor(a) Back-End";
            case 13:
                return "Desenvolvedor(a) Back-End Magento";
            case 14:
                return "Desenvolvedor(a) Front-End";
            case 15:
                return "Desenvolvedor(a) Front-End e Designer";
            case 16:
                return "Desenvolvedor(a) Front-End Mobile";
            case 17:
                return "Desenvolvedor(a) Front-End Magento";
            case 18:
                return "Desenvolvedor(a) Full-Stack";
            case 19:
                return "Densenvolvedor(a) Java";
            case 20:
                return "Desenvolvedor(a) NodeJS";
            case 21:
                return "Desenvolvedor(a) Oracle";
            case 22:
                return "Desenvolvedor(a) PHP";
            case 23:
                return "Desenvolvedor(a) PL SQL";
            case 24:
                return "Desenvolvedor(a) Ruby";
            case 25:
                return "Desenvolvedor(a) .NET";
            case 26:
                return "Designer UX/UI";
            case 27:
                return "Gerente de Projeto";
            case 28:
                return "Product Owner";
            case 29:
                return "Scrum Master";
            case 30:
                return "Outro cargo";

            default:
                return "";
        }
    }


    public getDescriptionStatusCandidate(statusCandidate: StatusCandidate): string {

        switch (statusCandidate) {
            case StatusCandidate.Cadastrado:
                return "Cadastrado";
            case StatusCandidate.Reprovado:
                return "Reprovado";
            case StatusCandidate.StandBy:
                return "Stand-by";
            case StatusCandidate.Declinou:
                return "Declinou";
            case StatusCandidate.SemInteresse:
                return "Sem Interesse";
            case StatusCandidate.EmProcesso:
                return "Em Processo";
            case StatusCandidate.EmProcessoCliente:
                return "Em Processo - Cliente";
            case StatusCandidate.Contratado:
                return "Contratado";
            case StatusCandidate.Aprovado:
                return "Aprovado";
            case StatusCandidate.Disponivel:
                return "Disponível";
            case StatusCandidate.PreCandidatado:
                return "Pré Candidatado";
            case StatusCandidate.Bloqueado:
                return "Bloqueado";
            default:
                return "Sem Status";
        }
    }

    getEnumStatusCandidateArray() {
        let status = [StatusCandidate.Cadastrado,
        StatusCandidate.EmProcesso,
        StatusCandidate.EmProcessoCliente,
        StatusCandidate.Declinou,
        StatusCandidate.Reprovado,
        StatusCandidate.Contratado,
        StatusCandidate.Disponivel,
        StatusCandidate.SemInteresse,
        StatusCandidate.Aprovado,
        StatusCandidate.StandBy,
        StatusCandidate.PreCandidatado,
        StatusCandidate.Bloqueado
        ]
        return status;
    }

    public getOriginCandidate(numberOrigin: number): string {
        numberOrigin = Number(numberOrigin);
        switch (numberOrigin) {
            case 1:
                return "ApInfo";
            case 2:
                return "Busca no Google";
            case 3:
                return "Blog FCamara";
            case 4:
                return "Divulgação Mastertech";
            case 5:
                return "Facebook FCamara";
            case 6:
                return "Gama Academy";
            case 7:
                return "Grupos do Facebook";
            case 8:
                return "Grupos do LinkedIn";
            case 9:
                return "Hackathon FCamara";
            case 10:
                return "Indicação";
            case 11:
                return "Instagram FCamara";
            case 12:
                return "LinkedIn FCamara";
            case 13:
                return "Notícias";
            case 14:
                return "Programa Thor";
            case 15:
                return "Publicação no LinkedIn de um(a) Recrutador(a)";
            case 16:
                return "Sangue Laranja";
            case 17:
                return "Um(a) recrutador(a) te abordou";
            case 18:
                return "WhatsApp";
            case 19:
                return "Youtube FCamara";
            case 20:
                return "Chat";
            case 21:
                return "Outro";
            case 22:
                return "Femme IT";
            case 23:
                return "Revelo";

            default:
                return "";
        }
    }


    public getDescriptionProfileCandidate(profileCandidate: ProfileCandidate): string {

        switch (profileCandidate) {
            case ProfileCandidate.Estagio:
                return "Estágio";
            case ProfileCandidate.Junior:
                return "Júnior";
            case ProfileCandidate.Pleno:
                return "Pleno";
            case ProfileCandidate.Senior:
                return "Sênior";
            case ProfileCandidate.Especialista:
                return "Especialista";
            case ProfileCandidate.NaoInformado:
                return "Não informado";
            default:
                return "";
        }
    }

    getEnumProfileCandidateArray() {
        let profiles = [ProfileCandidate.Estagio,
        ProfileCandidate.Junior,
        ProfileCandidate.Pleno,
        ProfileCandidate.Senior,
        ProfileCandidate.Especialista,
        ProfileCandidate.NaoInformado]
        return profiles;
    }

    getEnumHiringCandidateArray() {
        let hirings = [HiringCandidate.CLT,
        HiringCandidate.PJ,
        HiringCandidate.Temporário]
        return hirings;
    }

    public getDescriptionBusinessUnit(businessUnit: BusinessUnit): string {

        switch (businessUnit) {
            case BusinessUnit.OmniCommerce:
                return "Omni Commerce";
            case BusinessUnit.ExponencialBusiness:
                return "Exponential Business";
            default:
                return "";
        }
    }

    getBusinessUnitArray() {
        return [BusinessUnit.OmniCommerce,
        BusinessUnit.ExponencialBusiness]
    }

    public getHiringType(hiringCandidate: HiringCandidate): string {

        switch (hiringCandidate) {
            case HiringCandidate.CLT:
                return "CLT";
            case HiringCandidate.PJ:
                return "PJ";
            case HiringCandidate.Temporário:
                return "Temporário";
            default:
                return "";
        }
    }

    public getProfileInteraction(profileInteraction: ProfileInteraction): string {

        switch (profileInteraction) {
            case ProfileInteraction.Manager:
                return "Gerente"
            case ProfileInteraction.Recruiter:
                return "Recrutador"
            default:
                return "";
        }
    }


    getProfileInteractionArray() {
        let profiles = [ProfileInteraction.Manager,
        ProfileInteraction.Recruiter]
        return profiles;
    }

    public validateAscentClientname(name) {
        var palavra = name;

        var palavraSemAcento = "";
        var caracterComAcento = "ícáàãâäéèêëíìîïóòõôöúùûüçÁÀÃÂÄÉÈÊËÍÌÎÏÓÒÕÖÔÚÙÛÜÇ";
        var caracterSemAcento = "icaaaaaeeeeiiiiooooouuuucAAAAAEEEEIIIIOOOOOUUUUC";

        for (var i = 0; i < palavra.length; i++) {
            var char = palavra.substr(i, 1);
            var indexAcento = caracterComAcento.indexOf(char);
            if (indexAcento != -1) {
                palavraSemAcento += caracterSemAcento.substr(indexAcento, 1);
            } else {
                palavraSemAcento += char;
            }
        }
        return palavraSemAcento;
    }

    toast(msg, type) {
        $.toast({
            heading: msg,
            text: '',
            position: 'top-right',
            loaderBg: '#ff6849',
            icon: type,
            hideAfter: 2500,
            stack: 6
        });
    }

    getStates() {
        let states: String[] = ["AC", "AL", "AM", "AP", "BA", "CE", "DF", "ES", "GO", "MA", "MT", "MS", "MG", "PA", "PB", "PR", "PE", "PI", "RJ", "RN", "RO", "RS", "RR", "SC", "SE", "SP", "TO"];
        return states;
    }

    sendEventAnalytcs(category, label, action) {
        (<any>window).ga('send', 'event', {
            eventCategory: category,
            eventLabel: label,
            eventAction: action,
            eventValue: 10
        });
    }


}

