export enum StatusCandidate {
    Cadastrado = 0,
    EmProcesso = 1, 
    Declinou = 2,
    Reprovado = 3,
    Contratado = 4,
    Disponivel = 5,
    SemInteresse = 6,
    EmProcessoCliente = 7,
    Aprovado = 8,
    StandBy = 9,
    PreCandidatado = 10,
    Bloqueado = 11

    // Cadastrado = 0,
    // EmProcessoSelecao = 1,
    // Declinou = 2,
    // Reprovado = 3,
    // Contratado = 4,
    // Disponivel = 5,
    // SemInteresse = 6,
    // EmProcessoRecrutamento = 7,
    // EmProcessoCliente = 8,
    // Consultor = 9, contratado
    // Aprovado = 10,
    // StandBy = 11
}
