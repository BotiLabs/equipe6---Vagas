import { StatusCandidate } from '../common/status-candidate';
import { ProfileCandidate } from '../common/profile-candidate';

export class CandidatesRequest {
    _id:String;
    count: any;
    skills: string[];
    status: any;
    profile: any;
    name: string;
    email: string;
    limit: number;
    page: number;
    position:string[];
    phone: string;
    yearsOfExperience: number;
    origin: any;
    rank: number;
    userEmail: string;
    company_id: string;
    registrationDate:any;
    sort:any;
    lastInteractionDate:any;

    constructor() {
        this.skills = [];
        this.status = -1;
        this.profile = -1;
        this.name = "";
        this.email = "";
        this.page = 1;
        this.limit = 10;
        this.position = [];
        this.phone= "";
        this.yearsOfExperience;
        this.origin = "";
        this.rank;
        this.userEmail = "";
        this.registrationDate;
        this.company_id = "";
        this.sort;
        this.lastInteractionDate;
    }
}