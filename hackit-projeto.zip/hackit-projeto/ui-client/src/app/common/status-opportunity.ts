export enum StatusOpportunity {
    Aberta = 0,
    Fechada = 1,
    Congelada = 2,
    Cancelada = 3
}
