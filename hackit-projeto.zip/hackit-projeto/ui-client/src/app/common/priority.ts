export enum PriorityOpportunity {
    Baixa = 0,
    Media = 1,
    Alta = 2
    
}