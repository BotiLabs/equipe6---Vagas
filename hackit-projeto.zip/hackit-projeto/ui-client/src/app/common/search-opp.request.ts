import { StatusOpportunity } from '../common/status-opportunity';
import { BusinessUnit } from '../common/business-unit';

export class SearchOpRequest {
    _id:String;
    number: number;
    numberOpp: number;
    customerName: string;
    userEmail: string;
    userFirstName: string;
    registrationDate: Date;
    nameSearch:string;
    businessUnit: BusinessUnit;
    location: string;
    specialities: string[];
    status: StatusOpportunity;
    priority: number;
    page:number;
    limit:number;
    company_id: string;

    constructor() {
        this._id = '';
        this.userFirstName = '';
        this.userEmail = '';
        this.registrationDate;
        this.nameSearch = '';
        this.status = -1;
        this.customerName = "";
        this.businessUnit = -1;
        this.location = "";
        this.specialities = [];
        this.number;  
        this.numberOpp;
        this.priority = -1;
        this.page = 1;
        this.limit = 10;
        this.company_id = "";
    }
}
