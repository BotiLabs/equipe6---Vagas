export enum ActionInteraction {
    Entrevista = 0,
    Contato = 1,
    Contratacao = 2,
    Avaliacao = 3,
    EntrevistaRS = 4, //feedback
    EntrevistaTecnica = 5, // analise
    EntrevistaCliente = 6,
    Analise = 7,
    Bloqueio = 8,
    Desbloqueio = 9
}
