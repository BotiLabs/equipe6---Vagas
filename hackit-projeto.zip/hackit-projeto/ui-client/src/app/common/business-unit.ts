export enum BusinessUnit {
    OmniCommerce = 0,
    ExponencialBusiness = 1,
}
