export enum ProfileCandidate {
    Estagio = 0,
    Junior = 1,
    Pleno = 2,
    Senior = 3,
    Especialista = 4,
    NaoInformado = 5,
   

}
