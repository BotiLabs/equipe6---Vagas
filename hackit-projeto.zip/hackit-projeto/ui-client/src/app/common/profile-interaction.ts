export enum ProfileInteraction{
    Manager = 0,
    Recruiter = 1
}