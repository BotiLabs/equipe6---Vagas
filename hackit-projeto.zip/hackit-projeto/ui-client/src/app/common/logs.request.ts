
export class LogsRequest {
    _id: String;
    userEmail: string;
    userFirstName: string;
    registrationDate: any;
    discriptionLog:String;
    page:number;
    limit:number;
    company_id: string;
    sort:any;
    dateValidator:any;
    constructor() {
        this._id = '';
        this.userEmail = '';
        this.userFirstName = '';
        this.registrationDate;
        this.page = 1;
        this.limit = 10;
        this.company_id = "";
        this.sort;
    }



}