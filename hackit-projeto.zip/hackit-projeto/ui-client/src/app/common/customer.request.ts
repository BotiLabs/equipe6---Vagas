
export class CustomerRequest {
    name: string;
    unity: string;
    location: string;
    limit: number;
    page: number;
    constructor() {
        this.name = "";
        this.unity = "";
        this.location = "";
        this.limit = 12;
        this.page = 1;
    }



}