import { StatusCandidate } from '../common/status-candidate';

export class CandidatesMatchRequest {
    skills: string[];
    status: StatusCandidate[];
    limit: number;
    page: number;
    company_id: string;

    constructor() {
        this.skills = [];
        this.status = [];
        this.page = 1;
        this.limit = 10;
        this.company_id = "";
    }
}