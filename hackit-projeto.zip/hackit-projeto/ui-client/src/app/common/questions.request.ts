export class QuestionsRequest {
    question:string;
    type:string[];
    theme:string;
    answers:string[];

    constructor() {
        this.question = "";
        this.type = [];
        this.theme = "";
        this.answers = [];
    }
}