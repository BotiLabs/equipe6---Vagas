
export class TagsRequest {
    _id: string;
    name: string;
    limit: number;
    page: number;
    status: number;
    company_id: string;

    constructor() {
        this._id='';
        this.name = '';
        this.page = 1;
        this.limit = 10;
        this.company_id = "";
    }
    public loadTag(response: any) {
        this._id = response._id;
        this.name = response.name;
        this.company_id = response.company_id;
    }
}