
export class InteractionsRequest {
    page: number;
    limit: number;
    action: number;
    userFirstName: string;
    initialDate: Date;
    finalDate: Date;
    priority: number;
    sort: any;
    userEmail: string;


    constructor() {
        this.page = 1;
        this.limit = 15;
        this.userFirstName = "";
        this.action = -1;
        this.userEmail = "";
    }
}