export enum InteractionType {
     RS = 0
}