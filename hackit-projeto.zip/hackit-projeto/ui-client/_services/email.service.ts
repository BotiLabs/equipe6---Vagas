import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { environment } from '../src/environments/environment';
import { HttpClient } from './http-client';
import { EmailModel } from '../src/app/models/email.model'
@Injectable()
export class EmailService {

    urlApi: string = `${environment.baseUrlApi}/sendmail`;

    constructor(private httpClient: HttpClient) { }

    send(emailModel: EmailModel) {
        let url = this.urlApi;
        let body = JSON.stringify({ to: emailModel.to, subject: emailModel.subject, text: emailModel.text });

        return this.httpClient.post(url, body);
    }


    sendReproved(emailModel: EmailModel) {
        let url = `${environment.baseUrlApi}/reprovemail`;
        let body = JSON.stringify({ to: emailModel.to, subject: emailModel.subject, text: emailModel.text });

        return this.httpClient.post(url, body);
    }

}