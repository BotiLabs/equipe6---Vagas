import { QuestionsRequest } from '../src/app/common/questions.request';
import { Injectable, Component } from '@angular/core';
import { HttpClient } from './http-client';
import { AuthService } from './auth.service';
import { ErrorHandler } from '../src/app/app.error-handler';
import { environment } from '../src/environments/environment';


import { QuestionModel } from '../src/app/models/questions.model'

@Injectable()
export class QuestionService {
    constructor(
        private authService: AuthService, 
        private httpClient: HttpClient) {
        
    }

    urlApi: string = `${environment.baseUrlApi}`;

    add(question: QuestionModel) {
        let query: string = `${this.urlApi}/testing`;
        return this.httpClient.post(query, JSON.stringify(question), this.authService.createOptions())
        .map((res) => res.json());
    }
    
    search(request: QuestionsRequest) {
        let query: string = `${this.urlApi}/search`;
        
        return this.httpClient.post(query, request, this.authService.createOptions())
        .map((res) => res.json());
    }

    getQuestionsType(){
        let query: string = `${this.urlApi}/testingtype`;
        
        return this.httpClient.get(query, this.authService.createOptions())
        .map((res) => res.json());
    }

    getQuestions(){
        let query: string = `${this.urlApi}/testing`;
        
        return this.httpClient.get(query, this.authService.createOptions())
        .map((res) => res.json());
    }
}