import { Injectable } from '@angular/core';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/catch';
import { Observable } from 'rxjs/Rx';

import { LogModel } from '../src/app/models/log.model';
import { HttpClient } from './http-client';
import { environment } from '../src/environments/environment';
import { LogsRequest } from '../src/app/common/logs.request';
import { AuthService } from './auth.service';

@Injectable()


export class LogService {

  constructor(
    private httpClient: HttpClient,
    private authService: AuthService
  ) { }

  urlApi: string = `${environment.baseUrlApi}/logs`;

  add(logModel: LogModel) {
    logModel.company_id = JSON.parse(localStorage.getItem('userInfo')).company_id;
    return this.httpClient.post(this.urlApi, JSON.stringify(logModel), this.authService.createOptions())
      .map((res) => res.json());
  }

  getAll() {
    return this.httpClient.get(this.urlApi + "/getall/" + localStorage.getItem("company_id"), this.authService.createOptions())
      .map((res) => res.json());
  }

  search(request: LogsRequest) {
    request.company_id = JSON.parse(localStorage.getItem('userInfo')).company_id;
    let query: string = `${this.urlApi}/search`;
    return this.httpClient.post(query, request, this.authService.createOptions())
      .map((res) => res.json());
  }
  searchOnInit(request: LogsRequest) {
    request.company_id = JSON.parse(localStorage.getItem('userInfo')).company_id;
    let query: string = `${this.urlApi}/searchoninit`;
    return this.httpClient.post(query, request, this.authService.createOptions())
      .map((res) => res.json());
  }




}
