import { Injectable } from '@angular/core';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/catch';
import { Observable } from 'rxjs/Rx';
import { HttpClient } from './http-client';
import { environment } from '../src/environments/environment';
import { AuthService } from './auth.service';
@Injectable()
export class ApproachService {


  constructor(private httpClient: HttpClient) { }

  getAllApproaches() {
    let url = `${environment.baseUrlApi}/approach`
    return this.httpClient.get(url)
      .map((res) => res.json())
      .catch(e => {
        console.log(e.status);
        return Observable.throw({ "Errors": e.json(status) });
      });
  }


}
