import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions } from '@angular/http';
import 'rxjs/add/operator/map';
import { Observable } from 'rxjs/Rx';
import { tokenNotExpired, JwtHelper } from 'angular2-jwt';
import { environment } from '../src/environments/environment';
import { UserLoginModel } from "../src/app/models/user-login.model";
import { UserModel } from "../src/app/models/user.model";
import { HttpClient } from './http-client';
import { UserInfoModel } from "../src/app/models/user-info.model";
@Injectable()
export class AuthService {
	authToken: any;
	userInfoModel: UserInfoModel;

	constructor(private httpClient: HttpClient,
		private http: Http) { }

	jwtHelper: JwtHelper = new JwtHelper();


	public dataURItoBlob(dataURI) {
		var byteString = atob(dataURI.split(',')[1]);
		var ab = new ArrayBuffer(byteString.length);
		var ia = new Uint8Array(ab);
		for (var i = 0; i < byteString.length; i++) {
			ia[i] = byteString.charCodeAt(i);
		}
		return new Blob([ab], { type: 'image/jpeg' });
	}


	private toFormData(serverFieldName) {
		var form = new FormData();
		let userInfo = JSON.parse(localStorage.getItem('userInfo'));
		form.append("data", this.dataURItoBlob(serverFieldName), userInfo.email);
		return form
	}

	authenticateUser(user: UserLoginModel) {
		return this.httpClient.post(`${environment.baseUrlApi}/token`, user)
			.map(res => res.json());
	}

	emailAuthentication(user) {
		return this.httpClient.post(`${environment.baseUrlApi}/authentication`, { email: user })
			.map(res => res.json())
			.catch(e => {
				return Observable.throw({ "Errors": e.json(status) });
			});
	}

	registerUser(user: UserModel) {
		return this.httpClient.post(`${environment.baseUrlApi}/signup`, user)
			.map(res => res.json());
	}

	storeUserData(token, userInfoModel: UserInfoModel) {
		let like;
		localStorage.setItem('id_token', token);
		localStorage.setItem('userInfo', JSON.stringify(userInfoModel));
		localStorage.setItem('like', like);
		this.authToken = token;
		this.userInfoModel = userInfoModel;
	}

	loadToken() {
		const token = localStorage.getItem('id_token');
		this.authToken = token;
	}

	loggedIn() {
		return tokenNotExpired('id_token');
	}

	logout() {
		this.authToken = null;
		this.userInfoModel = null;
		localStorage.clear();
	}

	createOptions(): RequestOptions {
		this.loadToken();
		let options = new RequestOptions()
		options.headers = new Headers();
		options.headers.append('Authorization', this.authToken);

		return options;
	}

	getUserInfoModel() {
		let item = JSON.parse(localStorage.getItem('userInfo'));
		let userInfo = new UserInfoModel();
		userInfo.email = item.email;
		userInfo.username = item.username;
		userInfo.firstName = item.firstName;
		userInfo.lastName = item.lastName;
		userInfo.company_id = item.company_id
		userInfo._id = item._id;
		return userInfo;
	}

	getUsers() {
		let company_id = JSON.parse(localStorage.getItem('userInfo')).company_id;
		return this.httpClient.get(`${environment.baseUrlApi}/getuser/${company_id}`)
			.map(res => res.json());
	}

	searchUsers(user) {
		let company_id = JSON.parse(localStorage.getItem('userInfo')).company_id;
		return this.httpClient.post(`${environment.baseUrlApi}/searchuser/${company_id}`, JSON.stringify(user))
			.map(res => res.json());
	}


	updateUser(user: UserModel) {
		return this.httpClient.put(`${environment.baseUrlApi}/user/${user._id}`, user, this.createOptions())
			.map(res => res.json());
	}

	updateUser2(user: UserModel) {
		return this.httpClient.put(`${environment.baseUrlApi}/user2/${user._id}`, user, this.createOptions())
			.map(res => res.json());
	}

	editUser(user: UserModel) {
		return this.httpClient.put(`${environment.baseUrlApi}/user3/${localStorage.getItem("_id")}`, user, this.createOptions())
			.map(res => res.json());
	}

	uploadImageUser(data) {
		let url = `${environment.baseUrlApi}/updateuserimage/${localStorage.getItem('_id')}`
		return this.http.put(`${url}`, this.toFormData(data), this.createOptions())
			.map(res => res.json())
			.catch(e => {
				return Observable.throw({ "Errors": e.json(status) });
			});
	}

	getUsersDrop() {
		let company_id = JSON.parse(localStorage.getItem('userInfo')).company_id;
		return this.httpClient.get(`${environment.baseUrlApi}/getusersmulti/${company_id}`, this.createOptions())
			.map(res => res.json())
			.catch(e => {
				return Observable.throw({ "Errors": e.json(status) });
			});
	}

	recoveryPassword(email) {
		return this.httpClient.post(`${environment.baseUrlApi}/validateifemailexists`, JSON.stringify({ email: email, url: environment.frontUrlApi }))
			.map(res => res.json())
			.catch(e => {
				console.log(e)
				return Observable.throw({ "Errors": e.json(status) });
			});
	}

	chagePassword(obj) {
		return this.httpClient.put(`${environment.baseUrlApi}/updateuserpassword/${obj._id}`, JSON.stringify(obj))
			.map(res => res.json())
			.catch(e => {
				console.log(e)
				return Observable.throw({ "Errors": e.json(status) });
			});
	}

	getUserById(id) {
		return this.httpClient.post(`${environment.baseUrlApi}/userbyid`, JSON.stringify({ _id: id }))
			.map(res => res.json())
			.catch(e => {
				console.log(e)
				return Observable.throw({ "Errors": e.json(status) });
			});
	}

	updateUserLoginCount(user) {
		return this.httpClient.post(`${environment.baseUrlApi}/login/office365`, JSON.stringify({ email: user.email }), this.createOptions())
			.map(res => res.json())
			.catch(e => {
				console.log(e)
				return Observable.throw({ "Errors": e.json(status) });
			});
	}

	findUserByEmail(user: String) {
		return this.httpClient.post(`${environment.baseUrlApi}/user`, JSON.stringify({ email: user }), this.createOptions())
			.map(res => res.json())
			.catch(e => {
				console.log(e)
				return Observable.throw({ "Errors": e.json(status) });
			});
	}
}
