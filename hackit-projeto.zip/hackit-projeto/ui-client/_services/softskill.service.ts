import { Injectable } from '@angular/core';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { Observable } from 'rxjs/Rx';

import { HttpClient } from './http-client';
import { environment } from '../src/environments/environment';
import { AuthService } from './auth.service';
import { SoftSkillModel } from '../src/app/models/softskill.model';
import { SoftSkillsRequest } from '../src/app/common/softskill.request';

@Injectable()
export class SoftSkillService {

  constructor(
    private httpClient: HttpClient,
    private authService: AuthService
  ) { }



  urlApi: string = `${environment.baseUrlApi}/softskills`;

  add(softskill: SoftSkillModel) {
    softskill.company_id = JSON.parse(localStorage.getItem('userInfo')).company_id;
    return this.httpClient.post(this.urlApi, JSON.stringify(softskill), this.authService.createOptions())
      .map((res) => res.json())
      .catch(e => {
        console.log(e.status);
        return Observable.throw({ "Errors": e.json(status) });
      });
  }

  update(softskill: SoftSkillModel) {
    let urlPut = `${this.urlApi}/${softskill._id}`;
    return this.httpClient.put(urlPut, JSON.stringify(softskill), this.authService.createOptions())
      .map((res) => res.json())
      .catch(e => {
        console.log(e.status);
        return Observable.throw({ "Errors": e.json(status) });
      });
  }

  updateToDelete(softskill: SoftSkillModel) {
    let urlPut = `${this.urlApi}/update/${softskill._id}`;
    return this.httpClient.put(urlPut, JSON.stringify(softskill), this.authService.createOptions())
      .map((res) => res.json())
  }

  delete(softskill: SoftSkillModel) {
    let urlDelete = `${this.urlApi}/${softskill._id}`;
    return this.httpClient.delete(urlDelete, this.authService.createOptions())
      .map((res) => res.json());
  }

  getAll() {
    let company_id = JSON.parse(localStorage.getItem("userInfo")).company_id;
    return this.httpClient.get(this.urlApi + "/getall/" + company_id)
      .map((res) => res.json());
  }

  getById(softskill: SoftSkillModel) {
    let urlGet = `${this.urlApi}/${softskill._id}`;
    return this.httpClient.get(urlGet, this.authService.createOptions())
      .map((res) => res.json());
  }



  search(request: SoftSkillsRequest) {
    request.company_id = JSON.parse(localStorage.getItem('userInfo')).company_id;
    let query: string = `${this.urlApi}/search`;
    return this.httpClient.post(query, request, this.authService.createOptions())
      .map((res) => res.json());
  }

  searchIfExists(request: SoftSkillsRequest) {
    request.company_id = JSON.parse(localStorage.getItem('userInfo')).company_id;
    let query: string = `${this.urlApi}/searchifexists`;
    return this.httpClient.post(query, request, this.authService.createOptions())
      .map((res) => res.json());
  }

  // public itemsRequest = (text: string): Observable<Array<string>> => {
  //   let softskills = new Array<string>();

  //   var obs = new Observable<Array<string>>(observer => {
  //     let request = new SoftSkillsRequest();
  //     request.name = text;
  //     request.limit = 20;
  //     request.page = 1;

  //     let query: string = `${this.urlApi}/search`;

  //     this.httpClient.post(query, request, this.authService.createOptions()).subscribe(res => {
  //       for (let item of res.json().result)
  //         softskills.push(item.name);
  //       observer.next(softskills);
  //     }
  //   });
  //   return obs;
  // }

}
