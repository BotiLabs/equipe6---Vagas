import { Injectable, EventEmitter } from '@angular/core';

import { CandidateModel } from "../src/app/models/candidate.model";

@Injectable()
export class InteractionListenService {

  notifier = new EventEmitter<CandidateModel>();
  constructor() {

  }
  publish(candidate: CandidateModel) {
    this.notifier.emit(candidate);
  }

}
