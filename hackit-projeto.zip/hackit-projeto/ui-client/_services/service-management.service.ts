import { ServiceManagementModel } from './../src/app/models/service-management.model';
import { Injectable } from '@angular/core';
import { HttpClient } from './http-client';
import { AuthService } from './auth.service';
import { environment } from '../src/environments/environment';
import { Observable } from 'rxjs/Rx';


@Injectable()
export class ManagementService {


    constructor(
        private httpClient: HttpClient,
        private authService: AuthService
    ) { this.company_id = JSON.parse(localStorage.getItem('userInfo')).company_id }

    urlApi: string = `${environment.baseUrlApi}/configuration`;
    company_id: string;

    getAll() {
        return this.httpClient.get(this.urlApi + "/" + this.company_id)
            .map((res) => res.json());
    }

    update(config: ServiceManagementModel) {
        let urlPut = `${this.urlApi}/${this.company_id}`;
        return this.httpClient.put(urlPut, JSON.stringify(config), this.authService.createOptions())
            .map((res) => res.json())
            .catch(e => {
                console.log(e.status);
                return Observable.throw({ "Errors": e.json(status) });
            });
    }
}