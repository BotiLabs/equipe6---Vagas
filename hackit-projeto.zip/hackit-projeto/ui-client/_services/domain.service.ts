import { Injectable } from '@angular/core';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/catch';
import { Observable } from 'rxjs/Rx';

import { LogModel } from '../src/app/models/log.model';
import { HttpClient } from './http-client';
import { environment } from '../src/environments/environment';
import { LogsRequest } from '../src/app/common/logs.request';
import { AuthService } from './auth.service';

@Injectable()


export class DomainService {

  constructor(
    private httpClient: HttpClient,
    private authService: AuthService
  ) { }

  urlApi: string = `${environment.baseUrlApi}/domain`;


  searchByDomain(request) {
    return this.httpClient.post(this.urlApi, JSON.stringify(request))
      .map((res) => res.json())
      .catch(e => {
        console.log(e.status);
        return Observable.throw({ "Errors": e.json(status) });
      });
  }




}
