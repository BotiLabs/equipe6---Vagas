import { Injectable } from '@angular/core';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/catch';
import { Observable } from 'rxjs/Rx';

import { SearchOpModel } from '../src/app/models/searchOp.model';
import { HttpClient } from './http-client';
import { environment } from '../src/environments/environment';
import { SearchOpRequest } from '../src/app/common/search-opp.request';
import { AuthService } from './auth.service';

@Injectable()


export class SearchOp {

  constructor(
    private httpClient: HttpClient,
    private authService: AuthService
  ) { }

  urlApi: string = `${environment.baseUrlApi}/searchopp`;


  
  add(searchOpModel: SearchOpModel) {
    searchOpModel.company_id = JSON.parse(localStorage.getItem('userInfo')).company_id;
    return this.httpClient.post(this.urlApi, JSON.stringify(searchOpModel), this.authService.createOptions())
      .map((res) => res.json())
      .catch(e => {
        console.log(e.status);
        return Observable.throw({ "Errors": e.json(status) });
      });
  }
  
  search(request: SearchOpRequest) {
    request.company_id = JSON.parse(localStorage.getItem('userInfo')).company_id;
    let query: string = `${this.urlApi}/search`;
    return this.httpClient.post(query, request, this.authService.createOptions())
      .map((res) => res.json());
  }

  update(search: SearchOpModel) {
    let urlPut = `${this.urlApi}/${search._id}`;
    return this.httpClient.put(urlPut, JSON.stringify(search), this.authService.createOptions())
      .map((res) => res.json());
  }

  delete(search: SearchOpModel) {
    let urlDelete = `${this.urlApi}/${search._id}`;
    return this.httpClient.delete(urlDelete, this.authService.createOptions())
      .map((res) => res.json());
  }
}