import { Location } from '@angular/common';
import { CustomerModel } from './../src/app/models/customerModel';
import { Injectable } from '@angular/core';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/catch';
import { Observable } from 'rxjs/Rx';

import { OpportunityModel } from '../src/app/models/opportunity.model';
import { HttpClient } from './http-client';
import { AuthService } from './auth.service';
import { environment } from '../src/environments/environment';
import { ErrorHandler } from '../src/app/app.error-handler';
import { OpportunitiesRequest } from '../src/app/common/opportunities.request';
import { LocationModel } from '../src/app/models/location.model';
import { LocationOpportunityRequest } from '../src/app/common/location-opportunity.request';
import { InvolvedPeople } from '../src/app/models/involvedPeople';
@Injectable()
export class OpportunityService {

  constructor(
    private httpClient: HttpClient,
    private authService: AuthService) { }

  urlApi: string = `${environment.baseUrlApi}/opportunities`;
  urlApi2: string = `${environment.baseUrlApi}/location`;


  save(opportunity: OpportunityModel) {
    opportunity.company_id = JSON.parse(localStorage.getItem('userInfo')).company_id;
    return this.httpClient.post(this.urlApi, JSON.stringify(opportunity))
      .map((res) => res.json())
      .catch(e => {
        console.log(e.status);
        return Observable.throw({ "Errors": e.json(status) });
      });
  }

  update(opportunity: OpportunityModel) {
    opportunity.company_id = JSON.parse(localStorage.getItem('userInfo')).company_id;
    let urlPut = `${this.urlApi}/${opportunity._id}`;
    return this.httpClient.put(urlPut, JSON.stringify(opportunity), this.authService.createOptions())
      .map((res) => res.json());
  }

  createCustomer(customerModel: CustomerModel) {
    customerModel.company_id = JSON.parse(localStorage.getItem('userInfo')).company_id;
    let urlCustomer = `${environment.baseUrlApi}/customer`;
    return this.httpClient.post(urlCustomer, JSON.stringify(customerModel), this.authService.createOptions())
      .map((res) => res.json())
      .catch(e => {
        console.log(e.status);
        return Observable.throw({ "Errors": e.json(status) });
      });
  }


  createLocation(locationModel: LocationModel) {
    locationModel.company_id = JSON.parse(localStorage.getItem('userInfo')).company_id;
    let urlCustomer = `${environment.baseUrlApi}/locations`;
    return this.httpClient.post(urlCustomer, JSON.stringify(locationModel), this.authService.createOptions())
      .map((res) => res.json())
      .catch(e => {
        console.log(e.status);
        return Observable.throw({ "Errors": e.json(status) });
      });
  }

  getCustomer() {
    let user = JSON.parse(localStorage.getItem("userInfo"));
    let urlCustomer = `${environment.baseUrlApi}/customer/getall/${user.company_id}`;
    return this.httpClient.get(urlCustomer, this.authService.createOptions())
      .map((res) => res.json())
      .catch(e => {
        console.log(e);
        return Observable.throw({ "Errors": e.json(status) });
      });
  }

  updateCustomer(customer: CustomerModel) {
    let urlPut = `${environment.baseUrlApi}/customer/${customer._id}`;
    return this.httpClient.put(urlPut, JSON.stringify(customer))
      .map((res) => res.json());
  }

  updateToDelete(customer: CustomerModel) {
    let urlPut = `${environment.baseUrlApi}/customer/update/${customer._id}`;
    return this.httpClient.put(urlPut, JSON.stringify(customer), this.authService.createOptions())
      .map((res) => res.json())
  }

  getCustomerById(customer: CustomerModel) {
    let urlGet = `${environment.baseUrlApi}/customer/${customer._id}`;
    return this.httpClient.get(urlGet, this.authService.createOptions())
      .map((res) => res.json());
  }

  add(customer: CustomerModel) {
    customer.company_id = JSON.parse(localStorage.getItem('userInfo')).company_id;
    return this.httpClient.post(this.urlApi, JSON.stringify(customer), this.authService.createOptions())
      .map((res) => res.json())
      .catch(e => {
        console.log(e.status);
        return Observable.throw({ "Errors": e.json(status) });
      });
  }

  getLocationById(location: LocationModel) {
    let urlGet = `${this.urlApi2}/${location}`;
    return this.httpClient.get(urlGet, this.authService.createOptions())
      .map((res) => res.json());
  }

  getLocationByCustomerId(custumerId) {
    let urlGet = `${environment.baseUrlApi}/locationcustomer/${custumerId}`;
    return this.httpClient.get(urlGet, this.authService.createOptions())
      .map((res) => res.json());
  }

  searchCustomer(request: any) {
    request.company_id = JSON.parse(localStorage.getItem('userInfo')).company_id;
    let urlCustomer = `${environment.baseUrlApi}/customer/search`;
    return this.httpClient.post(urlCustomer, JSON.stringify(request))
      .map((res) => res.json())
      .catch(e => {
        console.log(e.status);
        return Observable.throw({ "Errors": e.json(status) });
      });
  }

  getLocation() {
    let user = JSON.parse(localStorage.getItem("userInfo"));
    let urlLocation = `${environment.baseUrlApi}/locations/getall/${user.company_id}`;
    return this.httpClient.get(urlLocation, this.authService.createOptions())
      .map((res) => res.json())
      .catch(e => {
        console.log(e);
        return Observable.throw({ "Errors": e.json(status) });
      });
  }

  updateLocation(location: LocationModel) {
    let urlPut = `${environment.baseUrlApi}/location/update/${location._id}`;
    return this.httpClient.put(urlPut, JSON.stringify(location))
      .map((res) => res.json());
  }

  searchLocations(location: LocationOpportunityRequest) {
    location.company_id = JSON.parse(localStorage.getItem('userInfo')).company_id;
    let urlLocation = `${environment.baseUrlApi}/locations/search`;
    return this.httpClient.post(urlLocation, JSON.stringify(location), this.authService.createOptions())
      .map((res) => res.json())
      .catch(e => {
        console.log(e.status);
        return Observable.throw({ "Errors": e.json(status) });
      });
  }

  // delete(opportunity: OpportunityModel) {
  //   let urlDelete = `${this.urlApi}/${opportunity._id}`;
  //   return this.httpClient.delete(urlDelete, this.authService.createOptions())
  //     .map((res) => res.json());
  // }

  search(request: OpportunitiesRequest) {
    request.company_id = JSON.parse(localStorage.getItem('userInfo')).company_id;
    let query: string = `${this.urlApi}/search`;
    return this.httpClient.post(query, request)
      .map((res) => res.json())
      .catch(e => {
        console.log(e.status);
        return Observable.throw({ "Errors": e.json(status) });
      });
  }

  async searchOp(request: OpportunitiesRequest) {
    request.company_id = JSON.parse(localStorage.getItem('userInfo')).company_id;
    let query: string = `${this.urlApi}/search`;
    // return this.httpClient.post(query, request)
    //   .map((res) => res.json())
    //   .catch(e => {
    //     console.log(e.status);
    //     return Observable.throw({ "Errors": e.json(status) });
    //   });
    return this.httpClient.post(query, request)
    .map((res) => res.json())
    .toPromise()
    .catch((error: any)=>{
      return Observable.throw(error);
    })

  }

  searchOpSkills(request: OpportunitiesRequest) {
    let query: string = `${this.urlApi}/opportunitysimilar`;
    return this.httpClient.post(query, request)
      .map((res) => res.json());
  }

  getById(_id: string) {
    let urlGetById = `${this.urlApi}/${_id}`;
    return this.httpClient.get(urlGetById, this.authService.createOptions())
      .map((res) => res.json());
  }

  getAll() {
    let company_id = JSON.parse(localStorage.getItem('userInfo')).company_id;
    return this.httpClient.get(this.urlApi + "/getall/" + company_id, this.authService.createOptions())
      .map((res) => res.json());
  }

  getByStatus(status: any) {
    let company_id = JSON.parse(localStorage.getItem('userInfo')).company_id;
    console.log(status, company_id);
    let urlGetByStatus: string = `${environment.baseUrlApi}/opportunities/searchbystatus/${company_id}`
    return this.httpClient.post(urlGetByStatus, status)
      .map((res) => res.json());
  }

  getBusinessUnit() {
    let company_id = localStorage.getItem("company_id")
    let urlBusinessUnit: string = `${environment.baseUrlApi}/businessUnit/${company_id}`
    return this.httpClient.get(urlBusinessUnit, this.authService.createOptions())
      .map((res) => res.json());
  }

  getCustomerName() {
    let company_id = localStorage.getItem("company_id")
    let urlCustomerName: string = `${environment.baseUrlApi}/customerName/${company_id}`
    return this.httpClient.get(urlCustomerName, this.authService.createOptions())
      .map((res) => res.json());
  }

  getBetweenDate() {
    let company_id = localStorage.getItem("company_id")
    let urlBetweenDate: string = `${environment.baseUrlApi}/registrationDateOpp/${company_id}`
    return this.httpClient.get(urlBetweenDate, this.authService.createOptions())
      .map((res) => res.json());
  }

  sortOpportunity(opportunity: any) {
    opportunity.company_id = JSON.parse(localStorage.getItem('userInfo')).company_id;
    let urlSort: string = `${environment.baseUrlApi}/opportunity/sort/${opportunity.company_id}`
    return this.httpClient.post(urlSort, JSON.stringify(opportunity), this.authService.createOptions())
      .map((res) => res.json());
  }

  buildQueryString(request: OpportunitiesRequest) {

    let retorno = "?";

    if (request.customerName !== "") {
      if (retorno != "?")
        retorno += "&"
      retorno += "customerName=" + request.customerName;
    }

    if (request.businessUnit !== -1) {
      if (retorno != "?")
        retorno += "&"
      retorno += "businessUnit=" + request.businessUnit;
    }

    if (request.location !== "") {
      if (retorno != "?")
        retorno += "&"
      retorno += "location=" + request.location;
    }

    if (request.speciality != "") {
      if (retorno != "?")
        retorno += "&"
      retorno += "speciality=" + request.speciality;
    }
    return retorno = (retorno != "?") ? retorno : "";
  }

  count(request: OpportunitiesRequest) {
    request.company_id = JSON.parse(localStorage.getItem('userInfo')).company_id;
    let urlCount = `${this.urlApi}/count/${request.company_id}`;
    return this.httpClient.get(urlCount, this.authService.createOptions())
      .map((res) => res.json());
  }

  getOpportunitiesForInteraction() {
    let company_id = JSON.parse(localStorage.getItem('userInfo')).company_id;
    let urlInteraction = `${environment.baseUrlApi}/opportunity/interaction/${company_id}`;
    return this.httpClient.get(urlInteraction, this.authService.createOptions())
      .map((res) => res.json());
  }

  getOpportunitiesByStatus() {
    let company_id = JSON.parse(localStorage.getItem('userInfo')).company_id;
    let urlInteraction = `${environment.baseUrlApi}/opportunity/status/${company_id}`;
    return this.httpClient.get(urlInteraction, this.authService.createOptions())
      .map((res) => res.json());
  }

  searchReportOpportunityClosed(request) {
    let company_id = JSON.parse(localStorage.getItem('userInfo')).company_id;
    let query: string = `${environment.baseUrlApi}/opportunity/reportclosed/${company_id}`;
    return this.httpClient.post(query, JSON.stringify(request), this.authService.createOptions())
      .map((res) => res.json());
  }


  getOpportunityLocation() {
    let urlLocation = `${environment.baseUrlApi}/opportunities`;
    return this.httpClient.get(urlLocation, this.authService.createOptions())
      .map((res) => res.json());
  }

  deleteCandidateOpportunity(query) {
    let urlDelete = `${environment.baseUrlApi}/opportunities/deletecandidate`;
    return this.httpClient.post(urlDelete, query, this.authService.createOptions())
      .map((res) => res.json());
  }

  getPriorityOpportunity() {
    let company_id = JSON.parse(localStorage.getItem('userInfo')).company_id;
    let utlPriority = `${environment.baseUrlApi}/opportunity/priorityopp/${company_id}`;
    return this.httpClient.get(utlPriority, this.authService.createOptions())
      .map((res) => res.json());
  }

  getProcessOpportunities() {
    let company_id = JSON.parse(localStorage.getItem('userInfo')).company_id;
    let utlCountCandidates = `${environment.baseUrlApi}/opportunity/countcandidates/${company_id}`;
    return this.httpClient.get(utlCountCandidates, this.authService.createOptions())
      .map((res) => res.json());
  }

  updateLocationCustomer(customerModel: CustomerModel) {
    let locationCustomerRoute = `${environment.baseUrlApi}/customer/update`;
    return this.httpClient.post(locationCustomerRoute, JSON.stringify(customerModel), this.authService.createOptions())
      .map((res) => res.json());
  }

  updateInvolvedPeople(involvedPeople: InvolvedPeople[], _id: string) {
    let url = `${environment.baseUrlApi}/opportunity/involvedPeople/${_id}`;

    return this.httpClient.post(url, JSON.stringify(involvedPeople), this.authService.createOptions())
      .map((res) => res.json());
  }

  exportList(query: OpportunitiesRequest) {
    let company_id = JSON.parse(localStorage.getItem('userInfo')).company_id;
    let url: string = `${environment.baseUrlApi}/opportunity/exportlist/${company_id}`;
    return this.httpClient.post(url, query, this.authService.createOptions())
      .map((res) => res.json())
      .catch(e => {
        console.log(e.status);
        return Observable.throw({ "Errors": e.json(status) });
      });
  }

  getSla() {
    let company_id = JSON.parse(localStorage.getItem('userInfo')).company_id;
    let url: string = `${environment.baseUrlApi}/slaopp/${company_id}`;
    return this.httpClient.get(url, this.authService.createOptions())
      .map((res) => res.json())
      .catch(e => {
        console.log(e.status);
        return Observable.throw({ "Errors": e.json(status) });
      });
  }

  searchOppForProfile(_id: string) {
    let urlGetById = `${this.urlApi}/searchforprofile/${_id}`;
    return this.httpClient.get(urlGetById, this.authService.createOptions())
      .map((res) => res.json());
  }

  custumerById(id: any) {
    let urlPut = `${environment.baseUrlApi}/customer/custoById`;
    let v = {};
    v = {"id": id};
    return this.httpClient.post(urlPut, v)
      .map((res) => res.json());
  }

}
