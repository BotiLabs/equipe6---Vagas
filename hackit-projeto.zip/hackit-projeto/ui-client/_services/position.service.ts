import { Injectable } from '@angular/core';

@Injectable()
export class PositionService {

  constructor() { }

  getPositions() {
    return ["Agile Coach",
      "Analista Financeiro",
      "Analista de Banco de Dados",
      "Analista de DevOPS",
      "Analista de Qualidade - Automação",
      "Analista de Qualidade - Manual",
      "Analista de Negócio",
      "Analista de Requisitos",
      "Arquiteto(a) de Software",
      "Arquiteto (a) de Soluções",
      "Desenvolvedor(a) Mobile",
      "Desenvolvedor(a) Back-End",
      "Desenvolvedor(a) Back-End Magento",
      "Desenvolvedor(a) Front-End",
      "Desenvolvedor(a) Front-End e Designer",
      "Desenvolvedor(a) Front-End Mobile",
      "Desenvolvedor(a) Front-End Magento",
      "Desenvolvedor(a) Full-Stack",
      "Densenvolvedor(a) Java",
      "Desenvolvedor(a) NodeJS",
      "Desenvolvedor(a) Oracle",
      "Desenvolvedor(a) PHP",
      "Desenvolvedor(a) PL SQL",
      "Desenvolvedor(a) Ruby",
      "Desenvolvedor(a) .NET",
      "Designer UX/UI",
      "Gerente de Projeto",
      "Product Owner",
      "Scrum Master",
      "Outro cargo"]
  }

}
