import { Injectable } from '@angular/core';

import { CandidatesMatchRequest } from '../src/app/common/candidates-match.request';
import { HttpClient } from './http-client';
import { environment } from '../src/environments/environment';
import { AuthService } from './auth.service';
import { OpportunityModel } from '../src/app/models/opportunity.model';

@Injectable()
export class MatchService {

  urlApi: string = `${environment.baseUrlApi}/candidates/match`;

  constructor(private httpClient: HttpClient,
    private authService: AuthService) { }

  //public specialities: string[] = [];
  public opportunities: OpportunityModel[] = [];

  hasOpportunities(): boolean {
    return this.opportunities !== undefined && this.opportunities.length > 0;
  }

  setOpportunities(opportunities: OpportunityModel[]) {
    this.opportunities = [];
    this.opportunities = opportunities;
  }

  setOpportunity(opportunity: OpportunityModel) {
    this.opportunities = [];
    this.opportunities.push(opportunity);
  }

  searchForMatch(request: CandidatesMatchRequest) {
    request.company_id = JSON.parse(localStorage.getItem('userInfo')).company_id;
    return this.httpClient.post(this.urlApi, request, this.authService.createOptions())
      .map((res) => res.json());
  }

  searchByCurriculum(request: CandidatesMatchRequest) {
    request.company_id = JSON.parse(localStorage.getItem('userInfo')).company_id;
    let urlCv = this.urlApi + "c"
    return this.httpClient.post(this.urlApi, request, this.authService.createOptions())
      .map((res) => res.json());
  }

}
