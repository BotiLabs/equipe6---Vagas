import { Injectable } from '@angular/core';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/catch';
import { Observable } from 'rxjs/Rx';

import { EvaluationModel } from '../src/app/models/evaluation.model';
import { HttpClient } from './http-client';
import { environment } from '../src/environments/environment';
import { AuthService } from './auth.service';
import { ErrorHandler } from '../src/app/app.error-handler';
import { EvaluationsRequest } from '../src/app/common/evaluations.request';
import { combineAll } from 'rxjs/operator/combineAll';


@Injectable()
export class EvaluationService {
    constructor(
        private authService: AuthService,
        private httpClient: HttpClient) {

    }

    urlApi: string = `${environment.baseUrlApi}/evaluations`;

    add(evaluation: EvaluationModel) {
        evaluation.company_id = JSON.parse(localStorage.getItem('userInfo')).company_id;
        return this.httpClient.post(this.urlApi, JSON.stringify(evaluation), this.authService.createOptions())
            .map((res) => res.json())
            .catch(e => {
                return Observable.throw({ "Errors": e.json(status) });
            });
    }

    update(evaluation: EvaluationModel) {
        let urlPut = `${this.urlApi}/${evaluation._id}`;

        return this.httpClient.put(urlPut, JSON.stringify(evaluation), this.authService.createOptions())
            .map((res) => res.json())
            .catch(e => {
                return Observable.throw({ "Errors": e.json(status) });
            });
    }

    getById(_id: string) {
        let urlGetById = `${this.urlApi}/${_id}`;
        return this.httpClient.get(urlGetById, this.authService.createOptions())
            .map((res) => res.json())
            .catch(e => {
                return Observable.throw({ "Errors": e.json(status) });
            });
    }

    search(request: EvaluationsRequest) {
        request.company_id = JSON.parse(localStorage.getItem('userInfo')).company_id;
        let query: string = `${this.urlApi}/search`;

        return this.httpClient.post(query, request, this.authService.createOptions())
            .map((res) => res.json())
            .catch(e => {
                return Observable.throw({ "Errors": e.json(status) });
            });
    }

    getSum(_id: string) {
        let company_id = JSON.parse(localStorage.getItem('userInfo')).company_id;
        let urlGetById = `${this.urlApi}/sum`;
        return this.httpClient.post(urlGetById, { _id: _id, company_id: company_id }, this.authService.createOptions())
            .map((res) => res.json())
            .catch(e => {
                return Observable.throw({ "Errors": e.json(status) });
            });
    }

    getByEmail = (email: string) => {
        let company_id = JSON.parse(localStorage.getItem('userInfo')).company_id;
        let urlGetById = `${this.urlApi}/email`
        return this.httpClient
            .post(urlGetById, { email: email, company_id: company_id }, this.authService.createOptions())
            .map(res => res.json())
            .catch(e => {
                return Observable.throw({ "Errors": e.json(status) });
            });
    }
}
