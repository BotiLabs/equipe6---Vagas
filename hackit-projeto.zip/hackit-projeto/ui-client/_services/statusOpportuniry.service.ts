import { Injectable } from '@angular/core';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/catch';
import { Observable } from 'rxjs/Rx';
import { HttpClient } from './http-client';
import { environment } from '../src/environments/environment';
import { AuthService } from './auth.service';

@Injectable()


export class StatusOfOpportunityService {

    constructor(
        private httpClient: HttpClient,
        private authService: AuthService
    ) { }

    urlApi: string = `${environment.baseUrlApi}/statusopportunity`;

    getAll() {
        return this.httpClient.get(this.urlApi, this.authService.createOptions())
            .map((res) => res.json());
    }

}
