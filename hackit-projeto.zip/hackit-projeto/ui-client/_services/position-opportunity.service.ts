import { Injectable } from '@angular/core';

@Injectable()
export class PositionOpportunityService {
    constructor() { }

    getPositionsOpportunity() {
        return [
        "Analista",
        "Head",
        "Business Partner"
        ]
    }
}