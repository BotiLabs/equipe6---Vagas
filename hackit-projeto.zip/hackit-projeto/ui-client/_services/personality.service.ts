import { Injectable } from '@angular/core';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { Observable } from 'rxjs/Rx';

import { HttpClient } from './http-client';
import { environment } from '../src/environments/environment';
import { AuthService } from './auth.service';


@Injectable()
export class PersonalityService { 
    constructor(
        private httpClient: HttpClient,
        private authService: AuthService) { }
    
      urlApi: string = `${environment.baseUrlApi}/personality`;
      text: string;
      content:any[] = [];

    translate(text: string) {
        let query: string = `${environment.baseUrlApi}/translate`;
        return this.httpClient.post(query, {text: text}, this.authService.createOptions())
            .map((res) => res.json());
    }

    getPersonality(text: string) {
        this.text = text;

        return this.httpClient.post(this.urlApi, JSON.stringify({text: this.text}), 
            this.authService.createOptions())
            .map((res) => res.json());
    }   
      
}