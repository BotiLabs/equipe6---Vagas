import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions } from '@angular/http';
import 'rxjs/add/operator/map';
import { environment } from '../src/environments/environment';
import { HttpClient } from './http-client';
import { AuthService } from './auth.service';
import { TestingModel } from '../src/app/models/testing.model';

@Injectable()
export class TestingService {
    constructor(
        private httpClient: HttpClient,
        private authService: AuthService) { }

    baseUrlApi: string = `${environment.baseUrlApi}/testing`;
    testing: TestingModel;
    type: String[];

    get() {
        let company_id = JSON.parse(localStorage.getItem('userInfo')).company_id;
        return this.httpClient.get(this.baseUrlApi + "/getall/" + company_id, this.authService.createOptions())
            .map((res) => res.json());
    }

    search(type) {
        let company_id = JSON.parse(localStorage.getItem('userInfo')).company_id;
        let query: string = `${this.baseUrlApi}/search`;
        return this.httpClient.post(query, { type: type, company_id: company_id }, this.authService.createOptions())
            .map((res) => res.json());
    }
}