import { Jsonp } from '@angular/http/src/http';
import { state } from '@angular/animations';
import { Observable } from 'rxjs/Observable';
import { Injectable } from '@angular/core';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/catch';
import { CandidateModel } from '../src/app/models/candidate.model';
import { CandidatesRequest } from '../src/app/common/candidates.request';
import { HttpClient } from './http-client';
import { environment } from '../src/environments/environment';
import { AuthService } from './auth.service';
import { ErrorHandler } from '../src/app/app.error-handler';
import { error } from 'selenium-webdriver';
import { Http } from '@angular/http';
@Injectable()
export class CandidateService {
  constructor(
    private authService: AuthService,
    private httpClient: HttpClient,
    private http: Http) { }

  urlApi: string = `${environment.baseUrlApi}/candidates`;
  urlApiChart: string = `${environment.baseUrlApi}/candidate`


  toFormDataUpload(fields) {
    var form = new FormData();
    var file = 0;
    for (let field of Object.keys(fields)) {
      if (field == 'file') {
        form.append('file', fields['file'][0], fields['file'][0].name);
      }
    }
    return form;
  }

  uploadCurriculum(candidate: CandidateModel) {
    candidate.company_id = JSON.parse(localStorage.getItem('userInfo')).company_id;
    let url = `${this.urlApiChart}/upload/${candidate.company_id}`
    return this.http.post(url, this.toFormDataUpload(candidate), this.authService.createOptions())
      .map((res) => res.json())
      .catch(e => {
        console.log(e.status);
        return Observable.throw({ "Errors": e.json(status) });
      });
  }

  add(candidate: CandidateModel) {
    candidate.company_id = JSON.parse(localStorage.getItem('userInfo')).company_id;
    return this.httpClient.post(this.urlApi, JSON.stringify(candidate), this.authService.createOptions())
      .map((res) => res.json())
      .catch(e => {
        console.log(e.status);
        return Observable.throw({ "Errors": e.json(status) });
      });
  }

  update(candidate: CandidateModel) {
    candidate.company_id = JSON.parse(localStorage.getItem('userInfo')).company_id;
    let urlPut = `${this.urlApi}/${candidate._id}`;
    return this.httpClient.put(urlPut, JSON.stringify(candidate), this.authService.createOptions())
      .map((res) => res.json())
      .catch(e => {
        console.log(e.status);
        return Observable.throw({ "Errors": e.json(status) });
      });
  }

  // delete(candidate: CandidateModel) {
  //   let urlDelete = `${this.urlApi}/${candidate._id}`;
  //   return this.httpClient.delete(urlDelete, this.authService.createOptions())
  //     .map((res) => res.json());
  // }


  getById(_id: string) {
    let urlGetById = `${this.urlApi}/${_id}`;
    return this.httpClient.get(urlGetById, this.authService.createOptions())
      .map((res) => res.json());
  }

  search(request: CandidatesRequest) {
    request.company_id = JSON.parse(localStorage.getItem('userInfo')).company_id;
    let query: string = `${this.urlApi}/search`;
    return this.httpClient.post(query, request, this.authService.createOptions())
      .map((res) => res.json());
  }

  findBlockedCandidates(request: CandidatesRequest) {
    let company_id = JSON.parse(localStorage.getItem('userInfo')).company_id;
    let url: string = `${environment.baseUrlApi}/candidate/blocked/${company_id}`
    return this.httpClient.post(url, request, this.authService.createOptions())
      .map((res => res.json()))
  }

  count(request: CandidatesRequest) {
    request.company_id = JSON.parse(localStorage.getItem('userInfo')).company_id;
    let urlCount = `${this.urlApi}/count/${request.company_id}`;
    return this.httpClient.get(urlCount, this.authService.createOptions())
      .map((res) => res.json());
  }


  countIndication() {
    let company_id = JSON.parse(localStorage.getItem('userInfo')).company_id;
    let urlCount = `${this.urlApi}/countIndication/${company_id}`;
    return this.httpClient.get(urlCount, this.authService.createOptions())
      .map((res) => res.json());
  }

  // geyByOrigin(){
  //   let urlOrigin = `${this.urlApiChart}/origin`;
  //   return this.httpClient.get(urlOrigin, this.authService.createOptions())
  //     .map((res) => res.json());
  // }

  searchByOriginWithDate(origin: any) {
    let company_id = JSON.parse(localStorage.getItem('userInfo')).company_id;
    let urlOrigin = `${this.urlApiChart}/origin/${company_id}`;
    return this.httpClient.post(urlOrigin, JSON.stringify(origin), this.authService.createOptions())
      .map((res) => res.json())
      .catch(e => {
        console.log(e.status);
        return Observable.throw({ "Errors": e.json(status) });
      });
  }

  geyByProfile() {
    let company_id = JSON.parse(localStorage.getItem('userInfo')).company_id;
    let urlOrigin = `${this.urlApiChart}/profile/${company_id}`;
    return this.httpClient.get(urlOrigin, this.authService.createOptions())
      .map((res) => res.json());
  }

  sortCandidate(candidate: any) {
    let urlSort: string = `${this.urlApiChart}/sort`
    return this.httpClient.post(urlSort, JSON.stringify(candidate), this.authService.createOptions())
      .map((res) => res.json());
  }

  searchReportCandidate(request) {
    let company_id = JSON.parse(localStorage.getItem('userInfo')).company_id;
    let query: string = `${environment.baseUrlApi}/candidate/candidatejourney/${company_id}`;
    return this.httpClient.post(query, JSON.stringify(request), this.authService.createOptions())
      .map((res) => res.json())
      .catch(e => {
        return Observable.throw({ "Errors": e.json(status) });
      })
  }

  getProcessCandidates() {
    let company_id = JSON.parse(localStorage.getItem('userInfo')).company_id;
    let url: string = `${environment.baseUrlApi}/candidate/process/${company_id}`
    return this.httpClient.get(url)
      .map((res => res.json()))
      .catch(e => {
        console.log(e.status);
        return Observable.throw({ "Errors": e.json(status) });
      });
  }

  getCandidatesAndInterviews() {
    let company_id = JSON.parse(localStorage.getItem('userInfo')).company_id;
    let url: string = `${environment.baseUrlApi}/candidate/candidatesinterviews/${company_id}`
    return this.httpClient.get(url)
      .map((res => res.json()))
      .catch(e => {
        console.log(e.status);
        return Observable.throw({ "Errors": e.json(status) });
      });
  }

  exportList(query: CandidatesRequest) {
    let company_id = JSON.parse(localStorage.getItem('userInfo')).company_id;
    let url: string = `${environment.baseUrlApi}/candidate/exportlist/${company_id}`;
    return this.httpClient.post(url, query, this.authService.createOptions())
      .map((res) => res.json())
      .catch(e => {
        console.log(e.status);
        return Observable.throw({ "Errors": e.json(status) });
      });
  }

  exportListo0rigin(query: CandidatesRequest) {
    let company_id = JSON.parse(localStorage.getItem('userInfo')).company_id;
    let url: string = `${environment.baseUrlApi}/candidate/exportlistorigins/${company_id}`;
    return this.httpClient.post(url, query, this.authService.createOptions())
      .map((res) => res.json())
      .catch(e => {
        console.log(e.status);
        return Observable.throw({ "Errors": e.json(status) });
      });
  }

  getByEmail(email: string) {
    let company_id = JSON.parse(localStorage.getItem('userInfo')).company_id;
    let url: string = `${environment.baseUrlApi}/candidate/email/${company_id}`;
    return this.httpClient.post(url, JSON.stringify({ email: email }), this.authService.createOptions())
      .map((res) => res.json())
      .catch(e => {
        console.log(e.status);
        return Observable.throw({ "Errors": e.json(status) });
      });
  }

  getLatLon(info: string){
    let url: string = `${environment.baseUrlApi}/candidate/location`;
    return this.httpClient.post(url, JSON.stringify({ locationInfo: info })).
    map((res) => res.json())
    .toPromise()
    .catch(e => {
      console.log(e.staus);
      return Observable.throw({"erros": status});
    })   
  }

  getLatLonCep(address){
    let url: string = `${environment.baseUrlApi}/candidate/locationcep`;
    return this.httpClient.post(url, JSON.stringify(address)).
    map((res) => res.json())
    .toPromise()
    .catch(e => {
      console.log(e);
      return Observable.throw({"erros": status});
    })
  }

  getDistance(data: any){
    let url: string = `${environment.baseUrlApi}/candidate/distance`;
    return this.httpClient.post(url, JSON.stringify(data)).
    map((res: any) => res._body)
    .toPromise()
    .catch(e => {
      console.log(e.status);
      return Observable.throw({"erros": status})
    });
  }

  
  searchRecruiter(_id: string) {
    let urlGetById = `${this.urlApiChart}/searchrecruiter/${_id}`;
    return this.httpClient.get(urlGetById, this.authService.createOptions())
      .map((res) => res.json()).catch(e => {
        console.log(e.status);
        return Observable.throw({"erros": status})
      });
  }
}
