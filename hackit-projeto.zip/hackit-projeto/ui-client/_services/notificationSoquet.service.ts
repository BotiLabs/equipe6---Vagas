import { Subject } from 'rxjs/Subject';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import * as io from 'socket.io-client';
import { environment } from '../src/environments/environment';
import { AuthService } from './auth.service';
import { HttpClient } from './http-client';
import { NotificationModel } from '../src/app/models/notification.model';
@Injectable()
export class NotificationServ {
  constructor(
    private authService: AuthService,
    private httpClient: HttpClient
  ) { }
  urlApi: string = `${environment.originalUrlApi}`;
  private socket;
  validateEmail: boolean = false;

  insert(notification: NotificationModel) {
    let urlNotification = `${this.urlApi}/api/notification`;
    return this.httpClient.post(urlNotification, JSON.stringify(notification))
      .map((res) => res.json())
      .catch(e => {
        console.log(e.status);
        return Observable.throw({ "Errors": e.json(status) });
      });
     
  }

  delete(notification: NotificationModel) {
    let urlDelete = `${this.urlApi}/api/notification/${notification._id}`;
    return this.httpClient.delete(urlDelete, this.authService.createOptions())
      .map((res) => res.json());
  }

  search(notification: NotificationModel) {
    let urlNotification = `${this.urlApi}/api/notification/searchoninit`;
    return this.httpClient.post(urlNotification, JSON.stringify(notification))
      .map((res) => res.json())
      .catch(e => {
        console.log(e.status);
        return Observable.throw({ "Errors": e.json(status) });
      });
        
  }

  sendMessage(message, email, notification) {
    let userInfo = this.authService.getUserInfoModel();
    this.socket.emit('add-notification', notification);
  }

  getNotification() {
    let observable = new Observable(observer => {
      this.socket = io(this.urlApi);
      this.socket.on('notification', (data) => {
        observer.next(data);
      });
      return () => {
        this.socket.disconnect();
      };
    })

    return observable;
  }

}