import { Injectable } from '@angular/core';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/catch';
import { Observable } from 'rxjs/Rx';

import { InteractionModel } from '../src/app/models/interaction.model';
import { HttpClient } from './http-client';
import { environment } from '../src/environments/environment';
import { AuthService } from './auth.service';
import { InteractionsRequest } from '../src/app/common/interactions.request';
import { ReportHiredRequest } from '../src/app/common/reportHired.request';

@Injectable()
export class InteractionService {

  constructor(
    private httpClient: HttpClient,
    private authService: AuthService) { }

  urlApi: string = `${environment.baseUrlApi}/interactions`;

  add(interaction: InteractionModel) {
    interaction.company_id = JSON.parse(localStorage.getItem('userInfo')).company_id;
    return this.httpClient.post(this.urlApi, JSON.stringify(interaction), this.authService.createOptions())
      .map((res) => res.json()).catch(e => {
        console.log(e.status);
        return Observable.throw({ "Errors": e.json(status) });
      });
  }

  searchHiredRequest(request: ReportHiredRequest) {
    let company_id = JSON.parse(localStorage.getItem('userInfo')).company_id;
    let query: string = `${this.urlApi}/findreporthired/${company_id}`;
    return this.httpClient.post(query, JSON.stringify(request), this.authService.createOptions())
      .map((res) => res.json());
  }

  addHired(interaction: InteractionModel) {
    return this.httpClient.post(`${this.urlApi}/reporthired`, JSON.stringify(interaction), this.authService.createOptions())
      .map((res) => res.json()).catch(e => {
        console.log(e.status);
        return Observable.throw({ "Errors": e.json(status) });
      });
  }

  // delete(id: string) {
  //   let urlDelete =  `${this.urlApi}/${id}`;
  //   return this.httpClient.delete( urlDelete, this.authService.createOptions())
  //     .map((res) => res.json());
  // }

  update(interaction: InteractionModel) {
    interaction.company_id = JSON.parse(localStorage.getItem('userInfo')).company_id;
    let urlPut = `${this.urlApi}/${interaction._id}`;
    return this.httpClient.put(urlPut, JSON.stringify(interaction), this.authService.createOptions())
      .map((res) => res.json())
  }

  async search(interaction: any){
    let company_id = JSON.parse(localStorage.getItem('userInfo')).company_id;
    let i = {}
    i = {
      "company_id": company_id,
      "opportunityId": interaction,
      "action": 2,
      "status": 4
    }
    let url = this.urlApi + "/search";
    // return this.httpClient.post(url, i).map((res)=> res.json());
    return this.httpClient.post(url, i)
    .map((res) => res.json())
    .toPromise()
    .catch((error: any)=>{
      return Observable.throw(error);
    })
  }

  getAll() {
    return this.httpClient.get(this.urlApi, this.authService.createOptions())
      .map((res) => res.json());
  }

  searchActionReport(request: InteractionsRequest) {
    let company_id = JSON.parse(localStorage.getItem('userInfo')).company_id;
    let query: string = `${environment.baseUrlApi}/interactions/actionreport/${company_id}`;
    return this.httpClient.post(query, JSON.stringify(request), this.authService.createOptions())
      .map((res) => res.json());
  }

  getByCandidateId(candidateId: string) {
    let urlGetByCandidateId = `${this.urlApi}/candidates/${candidateId}`;
    //console.log(urlGetByCandidateId);
    return this.httpClient.get(urlGetByCandidateId, this.authService.createOptions())
      .map((res) => res.json());
  }


  getReports() {
    let company_id = JSON.parse(localStorage.getItem('userInfo')).company_id;
    let urlReports = `${this.urlApi}/report/${company_id}`
    return this.httpClient.get(urlReports, this.authService.createOptions())
      .map((res) => res.json());
  }

  searchReports(query) {
    let company_id = JSON.parse(localStorage.getItem('userInfo')).company_id;
    let urlReports = `${this.urlApi}/report/${company_id}`
    return this.httpClient.post(urlReports, query, this.authService.createOptions())
      .map((res) => res.json());
  }

  getReportsContratation() {
    let company_id = JSON.parse(localStorage.getItem('userInfo')).company_id;
    let urlReports = `${this.urlApi}/reportcontratation/${company_id}`;
    return this.httpClient.get(urlReports, this.authService.createOptions())
      .map((res) => res.json());
  }

  reportsContratationBetweenDate(query) {
    let company_id = JSON.parse(localStorage.getItem('userInfo')).company_id;
    return this.httpClient.post(`${this.urlApi}/reportcontratation/${company_id}`, JSON.stringify(query), this.authService.createOptions())
      .map((res) => res.json())
      .catch(e => Observable.throw({ "Errors": e.json(status) }));
  }

  findToDisapprove(interaction: InteractionModel) {
    let company_id = JSON.parse(localStorage.getItem('userInfo')).company_id;
    var urlDisaprove = `${this.urlApi}/findtodisapprove/${company_id}`
    return this.httpClient.post(urlDisaprove, JSON.stringify(interaction), this.authService.createOptions())
      .map((res) => res.json())
      .catch(e => {
        console.log(e.status)
        return Observable.throw({ "Errors": e.json(status) })
      });
  }

  exportList(query: InteractionsRequest) {
    let company_id = JSON.parse(localStorage.getItem('userInfo')).company_id;
    let url: string = `${environment.baseUrlApi}/interactions/exportlist/${company_id}`;
    return this.httpClient.post(url, query, this.authService.createOptions())
      .map((res) => res.json())
      .catch(e => {
        console.log(e.status);
        return Observable.throw({ "Errors": e.json(status) });
      });
  }

  exportContratationList(query: ReportHiredRequest) {
    let company_id = JSON.parse(localStorage.getItem('userInfo')).company_id;
    let url: string = `${environment.baseUrlApi}/interactions/exportcontratationreport/${company_id}`;
    return this.httpClient.post(url, query, this.authService.createOptions())
      .map((res) => res.json())
      .catch(e => {
        console.log(e.status);
        return Observable.throw({ "Errors": e.json(status) });
      });
  }
}
