import { Injectable } from '@angular/core';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/catch';
import { Observable } from 'rxjs/Rx';
import { HttpClient } from './http-client';
import { environment } from '../src/environments/environment';
import { AuthService } from './auth.service';
@Injectable()
export class OriginService {


  constructor(private httpClient: HttpClient) { }

  getAllOrigins() {
    let url = `${environment.baseUrlApi}/origin`
    return this.httpClient.get(url)
      .map((res) => res.json())
      .catch(e => {
        console.log(e.status);
        return Observable.throw({ "Errors": e.json(status) });
      });
  }

  getOrigins() {
    return [
      "ApInfo",
      'Busca no Google',
      'Blog FCamara',
      'Divulgação Mastertech',
      'Facebook FCamara',
      'Gama Academy',
      'Grupos do Facebook',
      'Grupos do LinkedIn',
      'Hackathon FCamara',
      'Indicação',
      'Instagram FCamara',
      'LinkedIn FCamara',
      'Notícias',
      "Programa Thor",
      'Publicação no LinkedIn de um(a) Recrutador(a)',
      'Sangue Laranja',
      'Um(a) recrutador(a) te abordou',
      'WhatsApp',
      'Youtube FCamara',
      'Outro',
      'Chat']
  }

}
