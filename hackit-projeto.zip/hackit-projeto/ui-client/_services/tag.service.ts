import { Injectable } from '@angular/core';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { Observable } from 'rxjs/Rx';

import { HttpClient } from './http-client';
import { environment } from '../src/environments/environment';
import { AuthService } from './auth.service';
import { TagModel } from '../src/app/models/tag.model';
import { TagsRequest } from '../src/app/common/tags.request';

@Injectable()
export class TagService {

  constructor(
    private httpClient: HttpClient,
    private authService: AuthService
  ) { }



  urlApi: string = `${environment.baseUrlApi}/tags`;

  add(tag: TagModel) {
    tag.company_id = JSON.parse(localStorage.getItem('userInfo')).company_id;
    return this.httpClient.post(this.urlApi, JSON.stringify(tag), this.authService.createOptions())
      .map((res) => res.json())
      .catch(e => {
        console.log(e.status);
        return Observable.throw({ "Errors": e.json(status) });
      });
  }

  update(tag: TagModel) {
    let urlPut = `${this.urlApi}/${tag._id}`;
    return this.httpClient.put(urlPut, JSON.stringify(tag), this.authService.createOptions())
      .map((res) => res.json())
      .catch(e => {
        console.log(e.status);
        return Observable.throw({ "Errors": e.json(status) });
      });
  }

  updateToDelete(tag: TagModel) {
    let urlPut = `${this.urlApi}/update/${tag._id}`;
    return this.httpClient.put(urlPut, JSON.stringify(tag), this.authService.createOptions())
      .map((res) => res.json())
  }

  delete(tag: TagModel) {
    let urlDelete = `${this.urlApi}/${tag._id}`;
    return this.httpClient.delete(urlDelete, this.authService.createOptions())
      .map((res) => res.json());
  }

  getAll() {
    let company_id = JSON.parse(localStorage.getItem("userInfo")).company_id;
    return this.httpClient.get(this.urlApi + "/getall/" + company_id)
      .map((res) => res.json());
  }

  getById(tag: TagModel) {
    let urlGet = `${this.urlApi}/${tag._id}`;
    return this.httpClient.get(urlGet, this.authService.createOptions())
      .map((res) => res.json());
  }



  search(request: TagsRequest) {
    request.company_id = JSON.parse(localStorage.getItem('userInfo')).company_id;
    let query: string = `${this.urlApi}/search`;
    return this.httpClient.post(query, request, this.authService.createOptions())
      .map((res) => res.json());
  }

  searchIfExists(request: TagsRequest) {
    request.company_id = JSON.parse(localStorage.getItem('userInfo')).company_id;
    let query: string = `${this.urlApi}/searchifexists`;
    return this.httpClient.post(query, request, this.authService.createOptions())
      .map((res) => res.json());
  }

  // public itemsRequest = (text: string): Observable<Array<string>> => {
  //   let tags = new Array<string>();

  //   var obs = new Observable<Array<string>>(observer => {
  //     let request = new TagsRequest();
  //     request.name = text;
  //     request.limit = 20;
  //     request.page = 1;

  //     let query: string = `${this.urlApi}/search`;

  //     this.httpClient.post(query, request, this.authService.createOptions()).subscribe(res => {
  //       for (let item of res.json().result)
  //         tags.push(item.name);
  //       observer.next(tags);
  //     }
  //   });
  //   return obs;
  // }

}
