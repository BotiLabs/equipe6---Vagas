import { Injectable } from "@angular/core";
import { CanDeactivate, ActivatedRouteSnapshot, RouterStateSnapshot } from "@angular/router";
import { EditComponent } from "../src/app/pages/candidate/edit/edit.component";
import { Observable } from "rxjs";
import { EnumsHelper } from "../src/app/common/enums-helper";

@Injectable()
export class CanDeactivateService implements CanDeactivate<EditComponent> {
    enumsHelper: EnumsHelper = new EnumsHelper();

    canDeactivate(
        component: EditComponent,
        currentRoute: ActivatedRouteSnapshot,
        currentState: RouterStateSnapshot,
        nextState: RouterStateSnapshot
    ): Observable<boolean> | Promise<boolean> | boolean {
        if (!component.isClear)
            return confirm("Vocẽ possui alterações que não foram salvas, tem certeza que deseja sair?");
        else
            return true
    }
}