'use strict';

var mongoose = require('mongoose'),
    Utils = require('../../domain/utils/util'),
    SearchCandidate = require('../../domain/models/searchOfCandidate').SearchCandidate;

//Insert a new search
exports.create = (req, res) => {
    let searchs = [];
    var body = req.body;
    var name = body.nameSearch.toUpperCase();

    //Validate search if exists
    SearchCandidate.findOne({ nameSearch: name })
        .exec()
        .then((result => {
            if (result) {
                res.status(400).send({
                    message: "Esta pesquisa já foi cadastrada",
                    result: result
                });
            } else {

                SearchCandidate.findOne().sort({ number: -1 }).limit(1)
                    .exec()
                    .then((resul => {
                        var search = new SearchCandidate({ nameSearch: name });
                        var status;
                        var searchCandidate = new SearchCandidate(req.body);
                        if (resul) {
                            if (resul.number) {
                                searchCandidate.number = ++resul.number;
                            }
                        } else {
                            searchCandidate.number = 1;
                        }
                        searchCandidate.nameSearch = name;
                        searchs.push(searchCandidate);

                        searchCandidate.save(searchs, function (err, docs) {
                            if (err) {
                                return res.status(400).send({
                                    message: Utils.getErrorMessageFromModel(err),
                                    erro: err
                                });
                            } else {
                                res.json(docs);
                            }
                        });
                    }));
            }
        })).catch((err => {
            return res.status(500).send({
                message: Utils.getErrorMessageFromModel(err)
            });
        }));
}

//Search existings Searchs
exports.search = (req, res) => {
    let objRes = {
        result: null,
        count: 0
    };

    var query = {};
    var mysort = { number: -1 };
    var body = req.body;
    query.company_id = body.company_id;

    query.userEmail = body.userEmail;
    SearchCandidate.count(query, function (err, count) {
        if (err) {
            res.status(404).send({
                message: Utils.getErrorMessageFromModel(err)
            });
        } else {
            objRes.count = count;
            SearchCandidate.find(query, function (err, result) {
                if (err) {
                    res.status(404).send({
                        message: Utils.getErrorMessageFromModel(err)
                    });
                } else {
                    objRes.result = result;
                    res.json(objRes);
                }
            }).sort(mysort).skip(body.limit * (body.page - 1)).limit(body.limit);
        }
    });
};


exports.read = (req, res) => {
    res.json(req.search);
};
//Find a searchCandidate to next method
exports.searchCandidateById = (req, res, next, id) => {
    SearchCandidate.findById(id, (err, search) => {
        if (err) {
            return next(err);
        }
        if (!search) {
            return res.status(400).send({
                message: 'Failed to load opportunity ' + id
            });
        }

        req.search = search;

        next();
    });
};
//Update a search of candidate
exports.update = (req, res) => {
    // console.log(req)
    // console.log(req.search, req.body);
    var searchCandidate = req.search;

    for (var prop in req.body) {
        searchCandidate[prop] = req.body[prop];
    }

    searchCandidate.save((err) => {
        if (err) {
            return res.status(400).send({
                message: Utils.getErrorMessageFromModel(err)
            });
        } else {
            res.json(searchCandidate)
        }
    });
};

//Delete a search of candidate
exports.delete = (req, res) => {
    var searchCandidate = req.search;

    searchCandidate.remove((err) => {
        if (err) {
            return res.status(400).send({
                message: Utils.getErrorMessageFromModel(err)
            });
        } else {
            res.json(searchCandidate);
        }
    });
};

