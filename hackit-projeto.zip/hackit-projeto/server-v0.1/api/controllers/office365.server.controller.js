'use strict';

var mongoose = require('mongoose'),
    config = require('../../config/config'),
    Utils = require('../../domain/utils/util'),
    authHelper = require('../../domain/office365/authHelper'),
    requestUtil = require('../../domain/office365/requestUtil'),
    User = require('../../domain/models/user').User,
    Company = require('../../domain/models/company').Company,
    jwt = require('jsonwebtoken'),
    querystring = require("querystring");


//Insert a new notification
exports.authOffice365 = (req, res) => {
    authHelper.init()
    if (req.query.code !== undefined) {
        console.log(req.query)
        authHelper.getTokenFromCode(req.query.code, (e, accessToken, refreshToken) => {
            if (e === null) {
                requestUtil.getUserData(accessToken, async (firstRequestError, firstTryUser) => {
                    if (!firstTryUser || firstTryUser == null) {
                        res.status(403).send("Não autorizado.")
                    }
                    let returnAuth = {
                        user: undefined,
                        token: undefined
                    }
                    let userInfo = {
                        email: firstTryUser.userPrincipalName,
                        firstName: firstTryUser.givenName.substring(0, firstTryUser.givenName.indexOf(" ")),
                        lastName: firstTryUser.surname,
                        username: firstTryUser.mail,
                        company_id: undefined,
                        token: undefined,
                        office365: true
                    };


                    try {
                        let company = await Company.findOne({
                            tenant: userInfo.email.substring(userInfo.email.indexOf('@') + 1, userInfo.email.length)
                        })

                        if (!company) {
                            return res.status(404).send("Usuario não encontrado")
                        }

                        let user = await User.findOne({
                            email: userInfo.email
                        })

                        if (!user) {
                            let userToSave = new User(userInfo);
                            if (!userInfo.firstName) {
                                userToSave.firstName = firstTryUser.givenName;
                            }
                            userToSave.provider = 'jwt';
                            userToSave.company_id = company._id;
                            userToSave.password = userToSave.firstName + '@' + company.tenant + 123;
                            await userToSave.save();
                            return res.status(403).send("Sua solicitação foi enviada, em breve você será liberado.")
                        }

                        if (user)
                            if (!user.approved) {
                                return res.status(403).send("Sua solicitação foi enviada, em breve você será liberado.")
                            }

                        var token = jwt.sign(user, config.secret, {
                            expiresIn: 180 * 180 // in seconds
                        });
                        userInfo.token = 'JWT ' + token;
                        userInfo.company_id = company._id;

                        let qs = querystring.stringify(userInfo)

                        let environment = 'https://portal.hapin.com.br/#'
                        switch (process.env.NODE_ENV) {
                            case "development":
                                environment = 'http://localhost:4200/#'
                                break;

                            case "homolog":
                                environment = 'https://d2zd6xu89s2cvw.cloudfront.net/#'
                                break;

                            case "production":
                                environment = 'https://portal.hapin.com.br/#'
                                break;

                            default:
                                break;
                        }
                        res.redirect(`${environment}/loading?` + qs)

                    } catch (e) {
                        return res.status(500).send(Utils.getErrorMessageFromModel(e))
                    }
                });
            }
        })
    } else {
        res.redirect(authHelper.getAuthUrl());
    }

}