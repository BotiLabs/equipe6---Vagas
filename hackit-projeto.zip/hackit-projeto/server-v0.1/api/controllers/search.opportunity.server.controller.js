'use strict';

var mongoose = require('mongoose'),
    Utils = require('../../domain/utils/util'),
    SearchOp = require('../../domain/models/searchOfOpportunity').SearchOp;

//Insert a new search
exports.create = (req, res) => {
    let searchs = [];
    var body = req.body;
    var name = body.nameSearch.toUpperCase();

    //Validate search if exists
    SearchOp.findOne({
            nameSearch: name,
            company_id: company_id
        })
        .exec()
        .then((result => {
            if (result) {
                res.status(400).send({
                    message: "Esta pesquisa já foi cadastrada",
                    result: result
                });
            } else {
                SearchOp.findOne().sort({
                        number: -1
                    }).limit(1)
                    .exec()
                    .then((resul => {
                        var search = new SearchOp({
                            nameSearch: name
                        });
                        var status;
                        var searchOp = new SearchOp(req.body);
                        if (resul) {
                            if (resul.number) {

                                searchOp.number = ++resul.number;
                            }
                        } else {
                            searchOp.number = 1;
                        }
                        searchOp.nameSearch = name;
                        searchs.push(searchOp);


                        searchOp.save(searchs, function (err, docs) {
                            if (err) {

                                return res.status(400).send({
                                    message: Utils.getErrorMessageFromModel(err),
                                    erro: err
                                });
                            } else {
                                res.json(docs);
                            }
                        });
                    }));
            }
        })).catch((err => {
            return res.status(500).send({
                message: Utils.getErrorMessageFromModel(err)
            });
        }));
}

//Search existings searchs of opportunities
exports.search = (req, res) => {
    let objRes = {
        result: null,
        count: 0
    };

    var query = {};
    var mysort = {
        number: -1
    };
    var body = req.body;
    query.company_id = body.company_id;

    query.userEmail = body.userEmail;
    SearchOp.count(query, function (err, count) {
        if (err) {
            res.status(404).send({
                message: Utils.getErrorMessageFromModel(err)
            });
        } else {
            objRes.count = count;
            SearchOp.find(query, function (err, result) {
                if (err) {
                    res.status(404).send({
                        message: Utils.getErrorMessageFromModel(err)
                    });
                } else {
                    objRes.result = result;
                    res.json(objRes);
                }
            }).sort(mysort).skip(body.limit * (body.page - 1)).limit(body.limit);
        }
    });
};

exports.read = (req, res) => {
    res.json(req.search);
};


//Find a searchOpportunity to next method
exports.searchOpportunityById = (req, res, next, id) => {
    SearchOp.findById(id, (err, search) => {
        if (err) {
            return next(err);
        }
        if (!search) {
            return res.status(400).send({
                message: 'Failed to load opportunity ' + id
            });
        }

        req.search = search;

        next();
    });
};

//Update a search of opportunity
exports.update = (req, res) => {
    // console.log(req)
    // console.log(req.search, req.body);
    var searchOpportunity = req.search;

    for (var prop in req.body) {
        searchOpportunity[prop] = req.body[prop];
    }

    searchOpportunity.save((err) => {
        if (err) {
            return res.status(400).send({
                message: Utils.getErrorMessageFromModel(err)
            });
        } else {
            res.json(searchOpportunity)
        }
    });
};

//Delete a search of opportunity
exports.delete = (req, res) => {
    var searchOpportunity = req.search;

    searchOpportunity.remove((err) => {
        if (err) {
            return res.status(400).send({
                message: Utils.getErrorMessageFromModel(err)
            });
        } else {
            res.json(searchOpportunity);
        }
    });
};