const AWS = require('aws-sdk');
AWS.config.update({
  accessKeyId: "AKIAIIYBIR5ZVXDQXAMA",
  secretAccessKey: "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"
});

var path = require('path');
const fs = require('fs');

var s3bucket = new AWS.S3("fcamaracvs");
exports.upload = function (req, res, object, callback) {

  //console.log('object.constructor.modelName', object.constructor.modelName);
  // console.log('req.files', req.files);
  if (!req.files || !req.files.file && !req.files.files) {
    return
  }


  var object = object;
  var files = req.files.files || req.files.file;
  var entities = req.entities;
  var modelName = object.constructor.modelName;

  // console.log("modelName", modelName)
  String.prototype.lowerFirstLetter = function () {
    return this.charAt(0).toLowerCase() + this.slice(1);
  }

  //Find object model
  const Model = require('../../domain/models/' + modelName.lowerFirstLetter());
  var count = 0;
  var array = [];

  var file = (files.length > 0 ? files : [files]);
  // console.log("file", file);
  // console.log("files", files);
  // console.log("path", files.path)

  var fileUp = req.files.file;

  fs.readFile(files.path, function (err, data) {
    if (err) throw err; // Something went wrong!
    var s3bucket = new AWS.S3({
      options: {
        bucket: "fcamaracvs",
        key: 'AKIAIIYBIR5ZVXDQXAMA',
        secret: "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",
        endpoint: "https://s3.console.aws.amazon.com/s3/buckets/fcamaracvs/sanguebkp",
        acl: "public-read"
      }
    });
    s3bucket.createBucket(function () {
      var params = {
        Bucket: 'fcamaracvs',
        ContentType: fileUp.type,
        Key: `sanguebkp/${fileUp.originalFilename}`, //file.name doesn't exist as a property
        Body: data,
        ACL: 'public-read'
      };

      s3bucket.upload(params, function (err, data) {
        // Whether there is an error or not, delete the temp file

        fs.unlink(files.path, function (err) {
          if (err) {
            console.error('err', err);
          }
          console.log(files.path);
          console.log('Temp File Delete');
        });

        if (err) {
          console.log('ERROR MSG: ', err);
          callback(object);
        } else {
          console.log(data.Location);
          object.curriculum = data.Location;
          callback(object)
        }
      });
    });
  });
};


