'use strict';
const fetch = require('node-fetch');
const pdf = require('pdf-to-text');
const textract = require('textract');
const geolib = require('geolib')
const NodeGeocoder = require('node-geocoder');
const geoLib = require('geo-lib');
const ObjectId = require('mongoose').Types.ObjectId;
var mongoose = require('mongoose'),
    Utils = require('../../domain/utils/util'),
    Candidate = require('../../domain/models/candidate').Candidate,
    Interaction = require('../../domain/models/interaction').Interaction,
    Opportunity = require('../../domain/models/opportunity').Opportunity,
    elasticsearch = require('elasticsearch'),
    Tag = require('../../domain/models/tag').Tag,
    client = new elasticsearch.Client({
        host: 'localhost:9200',
        log: 'trace'
    }),
    attachment = require("./attachment.js");
var options = {
    provider: 'google',

    // Optional depending on the providers
    httpAdapter: 'https', // Default
    apiKey: 'AIzaSyDdpulKaAUIyo3pdAbtJXwrzb7c9juN_rA', // for Mapquest, OpenCage, Google Premier
    formatter: null         // 'gpx', 'string', ...
};

exports.locationInfo = async (req, res) => {
    let infoLocation = req.body.locationInfo;

    var geocoder = NodeGeocoder(options);

    // Using callback
    geocoder.geocode(infoLocation, function (err, r) {
        if (err) return res.send(err);
        if(r.length === 0) return res.send({});
        if (r && r[0] && r[0].latitude) {
            const resul = { "latitude": r[0].latitude, "longitude": r[0].longitude };
            return res.status(200).send(resul);
        }
        return res.send({});
    });
}

exports.locationInfoCep = async (req, res) => {
    var geocoder = NodeGeocoder(options);

    // Using callback
    geocoder.geocode({country: 'Brazil', address: `${req.body.district}, ${req.body.city}`}, function (err, r) {
        if (err) return res.send(err);
        if(r.length === 0) return res.send({});
        if (r && r[0] && r[0].latitude) {
            const resul = { "latitude": r[0].latitude, "longitude": r[0].longitude };
            return res.status(200).send(resul);
        }
        return res.send({});
    });
}
exports.distanceBetween = async (req, res) => {
    const distance = geolib.getDistanceSimple(req.body.origin, req.body.destination);
    let distanceInKM = Math.floor(distance/1000)
    if (distanceInKM < 1) distanceInKM = 1
    return res.send(`${distanceInKM} km`)
}



exports.createSangueLaranja = async (req, res) => {
    console.log(req.body);
    if (req.body.origin == null) {
        req.body.origin = "Outro"
    }

    if (req.body.position == null) {
        req.body.position = "Outro cargo"
    }
    var candidate = await new Candidate(extractSkills(req.body));
    res.json(candidate);

};



//Insert a new candidate
exports.create = (req, res) => {
    if (req.body.origin == null) {
        req.body.origin = "Outro"
    }

    if (req.body.position == null) {
        req.body.position = "Outro cargo"
    }

    var candidate = new Candidate(req.body);
    candidate.noAscentName = validateAscentClientname(candidate.name)
    candidate.email = req.body.email.toLowerCase();
    var hour = new Date().getTime();
    var date = new Date(hour);
    candidate.registrationDate = date;
    candidate.emailWithCompany = candidate.email + candidate.company_id;
    if (req.body.origin != "Um(a) recrutador(a) te abordou") {
        candidate.approachRs = '';
    }
    candidate
        .save()
        .then((savedCandidate) => {
            res.json(savedCandidate);
        })
        .catch(err => {
            if (err.code == 11000) {
                return res.status(400).send({
                    message: "Um candidato com este email já foi cadastrado!"
                });
            } else {
                return res.status(400).send({
                    message: Utils.getErrorMessageFromModel(err)
                });
            }
        });
};

exports.uploadCurriculum = async (req, res) => {
    var candidate = new Candidate(req.body);
    candidate.company_id = req.params.companyId;
    if (req.files && req.files.file) {
        var fileUp = req.files.file;
        if (fileUp) {
            if (fileUp.type != 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' && fileUp.type != 'application/pdf' && fileUp.type != 'application/msword') {
                return res.status(400).send({
                    message: "Só aceitamos arquivos do tipo pdf ou word(doc ou docx)!"
                })
            }

            attachment.upload(req, res, candidate, savedCandidateWithFile => {
                extractSkillsHapin(savedCandidateWithFile, res);
            })
        }
    }
}
//seleciona os candidatos a partir de uma query
exports.extractText = async (req, res) => {
    let objRes = {
        result: {},
        count: 0
    }

    let query = {};

    query.company_id = "5b575557d10c2a62568fdd86";
    query.curriculum = {
        $ne: ""
    }

    query.textCv = null;

    let c = await Candidate.count(query)
        .sort('-created_at').exec((err, count) => {
            objRes.count = count;
            if (err) {
                res.status(400).send({
                    message: Utils.getErrorMessageFromModel(err)
                });
            } else {
                Candidate.findOne(query, function (err, candidates) {
                    objRes.result = candidates;
                    if (err) {
                        res.status(400).send({
                            message: Utils.getErrorMessageFromModel(err)
                        });
                    } else {

                        // res.json(objRes);
                        var candidate = extract(candidates);


                    }
                })
            }
        });
}

//extrai textos dos cvs e atualiza os candidatos
async function extract(candidate) {
    // console.log(candidate);

    var pdf_path = candidate.curriculum;

    console.log("cvvv", pdf_path);
    await textract.fromUrl(pdf_path, function (error, text) {

        if (error) {
            candidate.textCv = "sem texto";

            candidate
                .save()
                .then((savedCandidate) => {
                    console.log("salvo sem texto", savedCandidate.name);
                    let oi = exports.extractText();
                    // return savedCandidate;

                })
                .catch(err => {
                    console.log(err);
                    let oi = exports.extractText();
                    // return err;
                });


        } else {
            candidate.textCv = text;
            candidate
                .save()
                .then((savedCandidate) => {
                    console.log("salvo com texto", savedCandidate.name);
                    let oi = exports.extractText();
                    // return savedCandidate;
                })
                .catch(err => {
                    console.log(err);
                    let oi = exports.extractText();
                    // return err;

                });

        }

    });
}

async function extractSkills(candidate) {
    var skills = await Tag.find({
        company_id: candidate.company_id,
        visible: {
            $ne: false
        }
    })
        .then(tags => {
            return tags;
        })
        .catch(err => {
            return res.status(500).send({
                message: Utils.getErrorMessageFromModel(err)
            })
        })
    var pdf_path = candidate.curriculum;
    await textract.fromUrl(pdf_path, function (error, text) {
        console.log(text);
        if (text != undefined) {
            var texto2 = text.toUpperCase();
            var skillsEncontradas = [];

            for (var k = 0; k < nameSkills.length; k++) {
                let n = nameSkills[k];
                if (texto2.indexOf(" " + n + " ") > -1 || texto2.indexOf(" " + n + ",") > -1) {
                    skillsEncontradas.push(n);
                }
            }
            var candidateComing = new Candidate(candidate);
            candidateComing.skills = skillsEncontradas;
            candidateComing.email = candidate.email.toLowerCase();
            var hour = new Date().getTime();
            var date = new Date(hour);
            candidateComing.registrationDate = date;
            candidateComing.emailWithCompany = candidateComing.email + candidateComing.company_id;
            candidateComing.noAscentName = validateAscentClientname(candidateComing.name)
            candidateComing
                .save()
                .then((savedCandidate) => {
                    return savedCandidate;
                })
                .catch(err => {
                    if (err.code == 11000) {
                        return {
                            message: "Um candidato com este email já foi cadastrado!"
                        }
                    } else {
                        return {
                            message: Utils.getErrorMessageFromModel(err)
                        };
                    }
                });
        } else {
            var candidateComing = new Candidate(candidate);
            candidateComing.skills = [];
            candidateComing.email = candidate.email.toLowerCase();
            var hour = new Date().getTime();
            var date = new Date(hour);
            candidateComing.registrationDate = date;
            candidateComing.emailWithCompany = candidateComing.email + candidateComing.company_id;
            candidateComing.noAscentName = validateAscentClientname(candidateComing.name)
            candidateComing
                .save()
                .then((savedCandidate) => {
                    return savedCandidate;
                })
                .catch(err => {
                    if (err.code == 11000) {
                        return {
                            message: "Um candidato com este email já foi cadastrado!"
                        };
                    } else {
                        return {
                            message: Utils.getErrorMessageFromModel(err)
                        };
                    }
                });
        }
    })
}


async function extractSkillsHapin(candidate, res) {
    var skills = await Tag.find({
        company_id: candidate.company_id,
        visible: {
            $ne: false
        }
    })
        .then(tags => {
            return tags;
        })
        .catch(err => {
            return res.status(500).send({
                message: Utils.getErrorMessageFromModel(err)
            })
        })
    var nameSkills = [];
    skills.map(person => {
        nameSkills.push(person.name)
    });

    var pdf_path = candidate.curriculum;
    var candidateReturn = await textract.fromUrl(pdf_path, function (error, text) {
        if (error) {
            console.log(error)
        }
        if (text != undefined) {
            var texto2 = text.toUpperCase();
            var skillsEncontradas = [];

            let email = findEmail(texto2);

            let linkedin = findLinkein(texto2);

            candidate.email = email;
            candidate.linkedinUrl = linkedin;

            for (var k = 0; k < nameSkills.length; k++) {
                let n = nameSkills[k];
                if (texto2.indexOf(" " + n + " ") > -1 || texto2.indexOf(" " + n + ",") > -1) {
                    skillsEncontradas.push(n);
                }
            }
            var candidateComing = new Candidate(candidate);
            candidateComing.secondarySkills = skillsEncontradas;
            res.json(candidateComing);
        } else {
            var candidateComing = new Candidate(candidate);
            res.json(candidateComing);
        }
    })

    return candidateReturn;
}

function findEmail(texto) {
    let email = undefined;
    if (texto.indexOf("@") > -1) {
        let textArr = texto.split(' ');

        textArr.forEach(txt => {
            if (txt.indexOf('@') > -1) {

                if (txt.indexOf("E-MAIL:"))
                    txt.replace("E-MAIL:", "");

                if (txt.indexOf("EMAIL:"))
                    txt.replace("EMAIL:", "");

                email = txt.trim();
            }
        })
    }

    if (email) {
        if (email.indexOf(' ') > -1) {
            let replace = email.substring(email.indexOf(" "), email.length);
            email = email.replace(replace, "");
        }
    }
    if (email) {
        return email.toLowerCase();
    } else {
        return undefined;
    }
}


function findLinkein(texto) {
    let linkedin = undefined;
    if (texto.indexOf("LINKEDIN") > -1) {
        let textArr = texto.split(' ');

        textArr.forEach(txt => {
            if (txt.indexOf('LINKEDIN') > -1) {

                if (txt.indexOf("LINKEDIN:"))
                    txt.replace("LINKEDIN:", "");

                linkedin = txt.trim();
            }
        })
    }

    if (linkedin) {
        if (linkedin.indexOf(' ') > -1) {
            let replace = linkedin.substring(linkedin.indexOf(" "), linkedin.length);
            linkedin = linkedin.replace(replace, "");
        }
    }
    if (linkedin) {
        return linkedin.toLowerCase();
    } else {
        return undefined;
    }
}


//List existing candidates
exports.list = (req, res, company_id) => {
    Candidate.find({
        company_id: company_id
    })
        .populate('opportunities')
        .sort('-created_at').exec((err, candidates) => {
            if (err) {
                res.status(400).send({
                    message: Utils.getErrorMessageFromModel(err)
                });
            } else {
                res.json(candidates);
            }
        });
};

exports.listCandidateToUpdate = (req, res) => {
    Candidate.find({
        status: {
            $in: [3, 5, 7, 8, 1]
        }
    })
        .populate('opportunities')
        .sort('-created_at').exec((err, candidates) => {
            if (err) {
                res.status(400).send({
                    message: Utils.getErrorMessageFromModel(err)
                });
            } else {
                res.json(candidates);
            }
        });
};

exports.findBlockedCandidates = (req, res) => {
    let objRes = {
        result: {},
        count: 0
    }

    var body = req.body;

    var query = {};

    var body = req.body;
    if (body.name !== undefined && body.name !== "")
        query.$and = [];

    if (body.name !== undefined && body.name !== "")
        query.$and.push({
            $or: [{
                noAscentName: new RegExp(body.name, "i")
            }, {
                email: new RegExp(body.name, "i")
            }]
        });

    if (body.email !== undefined && body.email !== "")
        query.email = new RegExp(body.email, 'i');

    query.isBlocked = true;
    query.company_id = req.company_id;
    Candidate.count(query)
        .sort('-created_at').exec((err, count) => {
            objRes.count = count;
            if (err) {
                res.status(400).send({
                    message: Utils.getErrorMessageFromModel(err)
                });
            } else {
                Candidate.find(query, function (err, candidates) {
                    if (err) {
                        res.status(400).send({
                            message: Utils.getErrorMessageFromModel(err)
                        });
                    } else {
                        objRes.result = candidates;
                        res.json(objRes);
                    }
                })
                    .sort('-created_at')
                    .skip(body.limit * (body.page - 1)).limit(body.limit);
            }
        });
};

//List a candidate
exports.read = (req, res) => {
    res.json(req.candidate);
};

//Find a candidate to next method
exports.candidateById = (req, res, next, id) => {
    Candidate
        .findById(id, (err, candidate) => {
            if (err) {
                return next(err);
            }
            if (!candidate) {
                return res.status(400).send({
                    message: 'Failed to load candidate ' + id
                });
            }
            req.candidate = candidate;
            next();
        })
        .populate('opportunities')
};

//Find a company_id to next method
exports.prepareCompanyId = (req, res, next, id) => {
    req.company_id = id;
    next()
};

//Update a candidate
exports.update = async (req, res) => {
    var candidate = req.candidate;
    console.log(req.body.status)
    candidate.emailWithCompany = candidate.email + candidate.company_id;
    for (var prop in req.body) {
        candidate[prop] = req.body[prop];
    }
    if (candidate.origin != "Um(a) recrutador(a) te abordou") {
        candidate.approachRs = '';
    }
    candidate
        .save()
        .then((savedCandidate) => {
            res.json(savedCandidate);
        })
        .catch(err => {
            if (err.code == 11000) {
                return res.status(400).send({
                    message: "Um candidato com este email já foi cadastrado!"
                });
            } else {
                return res.status(400).send({
                    message: Utils.getErrorMessageFromModel(err)
                });
            }
        });
};

//Update candidate without interactions between 20 days 
exports.updateAfter20Days = (req, res) => {
    Candidate.findOne({
        _id: req.body._id
    }, function (err, doc) {
        console.log("status antigo", doc.status)
        doc.status = 0;
        console.log("status novo", doc.status)
        doc.save();
    }).catch(err => {
        console.log(err);
    });
};

// //Delete a candidate
exports.delete = (req, res) => {
    var candidate = req.candidate;

    candidate.remove((err) => {
        if (err) {
            return res.status(400).send({
                message: Utils.getErrorMessageFromModel(err)
            });
        } else {
            res.json(candidate);
        }
    });
};

exports.search = (req, res) => {
    console.log(req.body);
    let objRes = {
        result: null,
        count: 0
    };
    var query = {};

    var body = req.body;
    query.company_id = body.company_id;
    var totalArray = [];
    var returnCandidate = [];
    let skills = [];
    let secondarySkills = [];

    if (body.userEmail !== undefined) {
        query.userEmail = body.userEmail
    }

    if (body.name !== undefined && body.name !== "")
        query.$or = [{
            noAscentName: new RegExp(body.name, "i")
        }, {
            email: new RegExp(body.name, "i")
        }];


    if (body.skills) {
        for (var i = 0; i < body.skills.length; i++) {
            if (i == 0) {
                var calc = body.skills.length + 2;
            } else {
                var calc = body.skills.length - i;
            }
            totalArray.push({
                "pontuation": calc,
                "skill": body.skills[i]
            })
        }
    }

    if (body.sort) {
        if (body.sort.query.relevance) {
            var queryRelevance = body.sort.query;
            body.sort = undefined;
        }
    }
    if (body.status !== undefined && body.status != -1 && body.status.length > 0)
        query.status = {
            $in: body.status
        };

    if (body.profile !== undefined && body.profile >= 0)
        query.profile = body.profile;

    if (body.skills !== undefined && body.skills.length > 0) {
        query.skills = {
            '$in': body.skills.map(function (v) {
                return v;
            })

        }
    }

    if (body.email !== undefined && body.email !== "")
        query.email = new RegExp(body.email, 'i');

    if (body.position !== undefined && body.position !== "" && body.position.length > 0)
        query.position = {
            $in: body.position
        }

    if (body.yearsOfExperience)
        query.yearsOfExperience = body.yearsOfExperience;

    if (body.phone !== undefined && body.phone !== "")
        query.phone = new RegExp(body.phone, 'i');

    if (body.origin !== undefined && body.origin !== "")
        query.origin = new RegExp(body.origin, 'i');

    if (body.rank)
        query.rank = body.rank;

    if (body.initialDate && body.registrationDate) {
        query.registrationDate = {
            $gte: body.initialDate,
            $lt: body.registrationDate
        };
    } else if (body.initialDate) {
        query.registrationDate = {
            $gte: body.initialDate
        };
    } else if (body.registrationDate) {
        query.registrationDate = {
            $lt: body.registrationDate
        };
    }

    query.visible = {
        $ne: false
    }

    Candidate.count(query, function (err, count) {
        if (err) {
            res.status(404).send({
                message: Utils.getErrorMessageFromModel(err)
            });
        } else {
            objRes.count = count;
            //Sortable search
            if (body.sort) {

                let queryToDo = [{
                    $match: query
                },
                {
                    $lookup: {
                        from: "statusofcandidates",
                        localField: "status",
                        foreignField: "number",
                        as: "statusJoin"
                    },

                },
                {
                    $sort: body.sort['query']
                }
                ]

                if (!body.skills.length > 0) {
                    queryToDo = [{
                        $match: query
                    },
                    {
                        $lookup: {
                            from: "statusofcandidates",
                            localField: "status",
                            foreignField: "number",
                            as: "statusJoin"
                        },

                    },
                    {
                        $sort: body.sort['query']
                    },
                    {
                        $skip: body.limit * (body.page - 1)
                    },
                    {
                        $limit: body.limit
                    }
                    ]
                }

                const orders = Candidate.aggregate(queryToDo, function (error, candidates) {
                    objRes.count = count;
                    if (error) {
                        return res.status(400).send({
                            message: Utils.getErrorMessageFromModel(err)
                        });
                    } else {
                        if (body.skills.length > 0) {
                            candidates.forEach(candidate => {

                                var totalQuery = 0;
                                if (body.skills) {
                                    for (let p of totalArray) {
                                        totalQuery = totalQuery + p.pontuation;
                                    }
                                }

                                candidate['relevance'] = undefined;
                                let countSkill = 0;
                                let total = 0;
                                //Creating object with a body skill and her pontuation
                                candidate.skills.map(skill => {
                                    totalArray.forEach(res => {
                                        if (skill == res.skill) {
                                            total = total + res.pontuation;
                                        }
                                    })
                                })

                                if (candidate.textCv && candidate.textCv != "Não foi possível ler este currículo") {
                                    countSkill = 0;

                                    candidate.textCv.toUpperCase();
                                    totalArray.forEach(res => {
                                        candidate.textCv.match(new RegExp(" " + res.skill + " " + "|" + " " + res.skill + ",", "g")) ? countSkill = candidate.textCv.match(new RegExp(" " + res.skill + " " + "|" + " " + res.skill + ",", "g")).length : countSkill = 0;


                                        total = total + countSkill;
                                        totalQuery = totalQuery + countSkill;
                                    })
                                }
                                let relevance = (total / totalQuery) * 100;
                                candidate['relevance'] = {
                                    "relevance": relevance.toFixed(1),
                                    "pontuacaoCandidato": total,
                                    "potuacaoTotal": totalQuery
                                };
                                returnCandidate.push(candidate);
                            });
                            //If sorted by grid

                            function paginate(array, page_size, page_number) {
                                --page_number; // because pages logically start with 1, but technically with 0
                                return array.slice(page_number * page_size, (page_number + 1) * page_size);
                            }
                            objRes.result = paginate(returnCandidate, body.limit, body.page);;
                        } else {
                            objRes.result = candidates;
                        }
                        res.json(objRes);

                    }
                })

                //Default search
            } else {

                let queryToDo = [{
                    $match: query
                },
                {
                    $lookup: {
                        from: "statusofcandidates",
                        localField: "status",
                        foreignField: "number",
                        as: "statusJoin"
                    },

                }
                ]

                if (!body.skills.length > 0) {
                    queryToDo = [{
                        $match: query
                    },
                    {
                        $lookup: {
                            from: "statusofcandidates",
                            localField: "status",
                            foreignField: "number",
                            as: "statusJoin"
                        },

                    },
                    {
                        $skip: body.limit * (body.page - 1)
                    },
                    {
                        $limit: body.limit
                    }
                    ]
                }
                const orders = Candidate.aggregate(queryToDo, function (error, candidates) {
                    if (error) {
                        return res.status(404).send({
                            message: Utils.getErrorMessageFromModel(errors)
                        });
                    } else {
                        if (body.lastInteractionDate) {
                            var listByLastInteraction = [];
                            // listByLastInteraction = await filterByLastInteraction(candidates, body.lastInteractionDate);
                            candidates = []
                            listByLastInteraction.sort(function (a, b) {
                                return b.lastInteractionDate - a.lastInteractionDate;
                            });

                            for (let c of listByLastInteraction) {

                                if (c != undefined) {
                                    candidates.push(c);
                                }
                            }
                            objRes.count = candidates.length;
                        }


                        if (body.skills.length > 0) {
                            candidates.forEach(candidate => {
                                var totalQuery = 0;
                                //Creating object with a body skill and her pontuation
                                if (body.skills) {
                                    for (let p of totalArray) {
                                        totalQuery = totalQuery + p.pontuation;
                                    }
                                }
                                candidate['relevance'] = undefined;
                                let total = 0;
                                let countSkill = 0;
                                candidate.skills.map(skill => {
                                    totalArray.forEach(res => {
                                        if (skill == res.skill) {
                                            total = total + res.pontuation;
                                        }
                                    })
                                })

                                if (candidate.textCv) {
                                    if (candidate.textCv != "Não foi possível ler este currículo") {

                                        countSkill = 0;
                                        candidate.textCv.toUpperCase();
                                        totalArray.forEach(res => {
                                            candidate.textCv.match(new RegExp(" " + res.skill + " " + "|" + " " + res.skill + ",", "g")) ? countSkill = candidate.textCv.match(new RegExp(" " + res.skill + " " + "|" + " " + res.skill + ",", "g")).length : countSkill = 0;

                                            total = total + countSkill;
                                            totalQuery = totalQuery + countSkill;
                                        })
                                    }
                                }
                                let relevance = (total / totalQuery) * 100;
                                candidate['relevance'] = {
                                    "relevance": relevance.toFixed(1),
                                    "pontuacaoCandidato": total,
                                    "potuacaoTotal": totalQuery
                                };
                                returnCandidate.push(candidate);

                            });

                            //Sorting asc
                            returnCandidate.sort(function (a, b) {
                                if (a.relevance) {

                                    if (b.relevance.relevance == a.relevance.relevance) {
                                        return b.relevance.pontuacaoCandidato - a.relevance.pontuacaoCandidato;
                                    }
                                    return b.relevance.relevance - a.relevance.relevance;
                                }
                            });

                            //If sorted by grid
                            if (queryRelevance) {
                                if (queryRelevance.relevance) {
                                    returnCandidate.sort(function (a, b) {
                                        if (queryRelevance.relevance == 1) {
                                            if (b.relevance.relevance == a.relevance.relevance) {
                                                return a.relevance.pontuacaoCandidato - b.relevance.pontuacaoCandidato;
                                            }
                                            return a.relevance.relevance - b.relevance.relevance;
                                        } else {
                                            if (b.relevance.relevance == a.relevance.relevance) {
                                                return b.relevance.pontuacaoCandidato - a.relevance.pontuacaoCandidato;
                                            }
                                            return b.relevance.relevance - a.relevance.relevance;
                                        }
                                    });
                                }
                            }

                            function paginate(array, page_size, page_number) {
                                --page_number; // because pages logically start with 1, but technically with 0
                                return array.slice(page_number * page_size, (page_number + 1) * page_size);
                            }
                            objRes.result = paginate(returnCandidate, body.limit, body.page);;
                        } else {
                            objRes.result = candidates;
                        }
                        res.json(objRes);
                    }
                })
            }

        }
    });

};

async function filterByLastInteraction(candidates, lastInteractionDate) {
    var listByLastInteraction = [];
    var candidatesArray = []
    candidates.forEach(candidate => {

        var p1 = new Promise(
            function (resolve, reject) {
                Interaction.findOne({
                    "candidateId": candidate._id,
                    "registrationDate": {
                        $gte: lastInteractionDate
                    }
                })
                    .sort({
                        "registrationDate": -1
                    })
                    .exec()
                    .then(lastInteraction => {
                        if (lastInteraction) {
                            if (lastInteraction.registrationDate) {
                                candidate.lastInteractionDate = lastInteraction.registrationDate;
                                resolve(candidate)
                            } else {
                                resolve(undefined);
                            }
                        } else {
                            resolve(undefined);
                        }
                    }).catch(err => {
                        reject(err);
                    })

            });

        candidatesArray.push(p1)
    });

    // console.log("candidatesArray",candidatesArray)
    var allCandidates = await (Promise.all(candidatesArray))
    return allCandidates;
}

exports.searchForMatch = (req, res) => {
    let objRes = {
        result: [],
        count: 0,
        existsInDB: false
    };
    var mongoQuery = {};
    var esQuery = "";
    var body = req.body;
    var resultFound = [];
    var countFound = 0;
    var resultNotFound = [];
    var countNotFound = 0;

    if (body.status !== undefined && body.status.length > 0) {
        mongoQuery.status = {
            '$in': body.status
        };
    }
    if (body.skills !== undefined && body.skills.length > 0) {
        mongoQuery.skills = {
            '$regex': new RegExp(mongoQuery.skills, 'i'),
            '$options': 'i',
            '$in': body.skills.map(function (v) {
                return new RegExp(v, 'i');
            })
        };
        esQuery = body.skills[0];
        for (let i = 1; i < body.skills.length; i++) {
            esQuery = esQuery + " AND " + body.skills[i];
        }
    }

    mongoQuery.visible = {
        $ne: false
    };
    mongoQuery.company_id = body.company_id;

    Candidate.count(mongoQuery, function (err, count) {
        if (err) {
            res.status(404).send({
                message: Utils.getErrorMessageFromModel(err)
            });
        } else {
            countFound = count;
            Candidate.find(mongoQuery, function (err, result) {
                if (err) {
                    res.status(404).send({
                        message: Utils.getErrorMessageFromModel(err)
                    });
                }
                // else if (count == 0) {
                //     client.search({
                //         index: 's3cvs',
                //         filterPath: ['hits.hits'],
                //         type: 'cv',
                //         body: {
                //             min_score: 0.21,
                //             query: {
                //                 match: {
                //                     "file.file": esQuery
                //                 }
                //             }
                //         }
                //     }
                //     , function (error, response) {
                //         if (error) {
                //             // console.log(error);
                //         }
                //         for (let i = 0; i < response.hits.hits.length; i++) {
                //             var promise = new Promise(function (resolve, reject) {
                //                 Candidate.findOne({
                //                     "curriculum": response.hits.hits[i]._source.source_url
                //                 }, function (err, res) {
                //                     if (err) {
                //                         reject(err);
                //                         return handleError(err);
                //                     }
                //                     if (res) {
                //                         // console.log("inseriu um achado");
                //                         resultFound.push(res);
                //                         countFound++
                //                     } else {
                //                         resultNotFound.push(response.hits.hits[i]);
                //                         countNotFound++
                //                         // console.log("inseriu um nao achado, count: " + countNotFound);
                //                     }
                //                     resolve()
                //                 });
                //             });
                //         }
                //         promise.then(function () {
                //             if (countFound > 0) {
                //                 objRes.existsInDB = true;
                //                 objRes.result = resultFound;
                //                 objRes.count = countFound;
                //                 // console.log(JSON.stringify(objRes));
                //                 res.json(objRes);
                //             } else {
                //                 objRes.existsInDB = false;
                //                 objRes.result = resultNotFound;
                //                 objRes.count = countNotFound;
                //                 // console.log(JSON.stringify(objRes));
                //                 res.json(objRes);
                //             }
                //             // console.log("count found é: " + countFound);
                //             // console.log("countNotFound é: " + countNotFound)
                //         })
                //             .catch(function (err) {
                //                 res.status(500).send({
                //                     message: 'Falha ao processar sua requisição'
                //                 });
                //             });
                //     });
                // } 
                else {
                    objRes.existsInDB = true;
                    objRes.result = result;
                    objRes.count = countFound;
                    res.json(objRes);
                }
            }).skip(body.limit * (body.page - 1)).limit(body.limit);
        }
    });
};

exports.count = (req, res) => {

    Candidate.count({
        company_id: req.company_id,
        visible: {
            $ne: false
        }
    }, function (err, result) {

        if (err) {
            res.status(404).send({
                message: Utils.getErrorMessageFromModel(err)
            });
        } else {
            res.status(200).json(result);
        }
    });
}


//List existing candidates by origin
exports.listByOriginWithDate = (req, res) => {
    var objRes = {
        resultS: [],
        count: 0
    }

    var body = req.body;
    var query = [{
        $match: {
            visible: {
                $ne: false
            },
            company_id: req.company_id
        }
    },
    {
        $group: {
            "_id": "$origin",
            count: {
                $sum: 1
            }
        }
    }
    ];
    if (body.initialDate && body.finalDate) {
        query = [{
            $match: {
                company_id: req.company_id,
                visible: {
                    $ne: false
                },
                registrationDate: {
                    $gte: new Date(body.initialDate),
                    $lte: new Date(body.finalDate)
                }
            }
        }, {
            $group: {
                "_id": "$origin",
                count: {
                    $sum: 1
                }
            }
        }];
    } else if (body.initialDate) {
        query = [{
            $match: {
                company_id: req.company_id,
                visible: {
                    $ne: false
                },
                registrationDate: {
                    $gte: new Date(body.initialDate)
                }
            }
        }, {
            $group: {
                "_id": "$origin",
                count: {
                    $sum: 1
                }
            }
        }];
    } else if (body.finalDate) {
        query = [{
            $match: {
                company_id: req.company_id,
                visible: {
                    $ne: false
                },
                registrationDate: {
                    $lte: new Date(body.finalDate)
                }
            }
        }, {
            $group: {
                "_id": "$origin",
                count: {
                    $sum: 1
                }
            }
        }];
    }

    if (body.sort) {
        query.push({
            $sort: body.sort['query']
        });
    }

    Candidate.aggregate((query), function (err, result) {
        if (err) {
            res.status(400).send({
                message: Utils.getErrorMessageFromModel(err)
            });
        } else {
            objRes.result = result;
            objRes.count = result.length;
            res.json(objRes);
        }
    });
};

// List existing candidates by profile
exports.listByProfile = (req, res) => {

    var query =
        Candidate.aggregate(([{
            $match: {
                visible: {
                    $ne: false
                },
                company_id: req.company_id
            }
        }, {
            $group: {
                "_id": "$position",
                count: {
                    $sum: 1
                }
            }
        }]), function (err, result) {
            if (err) {
                res.status(400).send({
                    message: Utils.getErrorMessageFromModel(err)
                });
            } else {
                res.json(result);
            }
        });
};

// Sort colums of candidate
exports.sortCandidate = (req, res) => {
    var objRes = {
        result: [],
        count: 0
    }
    var query = req.body


    Candidate.count({
        visible: {
            $ne: false
        },
        company_id: req.company_id
    }, function (err, result) {

        if (err) {
            return res.status(400).send({
                message: Utils.getErrorMessageFromModel(err)
            });
        } else {

            objRes.count = result;
            Candidate.find({
                visible: {
                    $ne: false
                }
            }).sort(query.query).skip(query.limit * (query.page - 1)).limit(query.limit).exec((error, candidate) => {
                if (error) {
                    return res.status(400).send({
                        message: Utils.getErrorMessageFromModel(err)
                    });
                } else {

                    objRes.result = candidate;
                    res.json(objRes);

                }
            })
        }
    })
}

exports.reportCandidateJourney = async (req, res) => {
    var body = req.body;
    var resultado = [];
    var queryCandidate = [];
    var queryToInteraction = [];
    var cont;
    var opp = undefined;
    var oppArray = [];
    var actualDate = new Date();
    var objRes = {
        result: [],
        count: 0,
        export: []
    }
    if (body.userName && body.initialDate && body.finalDate) {

        queryCandidate = {
            visible: {
                $ne: false
            },
            company_id: req.company_id,
            registrationDate: {
                $gt: new Date(body.initialDate),
                $lt: new Date(body.finalDate)
            }
        }

        queryToInteraction = {
            "interactions.visible": {
                $ne: false
            },
            "interactions.company_id": req.company_id,
            "interactions.userFirstName": body.userName
        }

    } else if (body.initialDate && body.finalDate) {

        queryCandidate = {
            visible: {
                $ne: false
            },
            company_id: req.company_id,
            registrationDate: {
                $gt: new Date(body.initialDate),
                $lt: new Date(body.finalDate)
            }
        }

        queryToInteraction = {
            "interactions.visible": {
                $ne: false
            },
            "interactions.company_id": req.company_id
        }


    } else if (body.userName && body.initialDate) {

        queryCandidate = {
            visible: {
                $ne: false
            },
            company_id: req.company_id,
            registrationDate: {
                $gt: new Date(body.initialDate),
                $lt: actualDate
            }
        }

        queryToInteraction = {
            "interactions.visible": {
                $ne: false
            },
            "interactions.company_id": req.company_id,
            "interactions.userFirstName": body.userName
        };


    } else if (body.userName && body.finalDate) {

        queryCandidate = {
            visible: {
                $ne: false
            },
            company_id: req.company_id,
            registrationDate: {
                $lt: new Date(body.finalDate)
            }
        }

        queryToInteraction = {
            "interactions.visible": {
                $ne: false
            },
            "interactions.company_id": req.company_id,
            "interactions.userFirstName": body.userName
        }

    } else if (body.initialDate) {

        queryCandidate = {
            visible: {
                $ne: false
            },
            company_id: req.company_id,
            registrationDate: {
                $gt: new Date(body.initialDate),
                $lt: actualDate
            }
        }

        queryToInteraction = {
            "interactions.visible": {
                $ne: false
            },
            "interactions.company_id": req.company_id
        }

    } else if (body.finalDate) {

        queryCandidate = {
            visible: {
                $ne: false
            },
            company_id: req.company_id,
            registrationDate: {
                $lt: new Date(body.finalDate)
            }
        }

        queryToInteraction = {
            "interactions.visible": {
                $ne: false
            },
            "interactions.company_id": req.company_id
        }


    } else if (body.userName) {

        queryCandidate = {
            company_id: req.company_id,
            visible: {
                $ne: false
            }
        }

        queryToInteraction = {
            "interactions.visible": {
                $ne: false
            },
            "interactions.userFirstName": body.userName,
            "interactions.company_id": req.company_id
        }


    } else {

        queryCandidate = {
            visible: {
                $ne: false
            },
            company_id: req.company_id
        }

        queryToInteraction = {
            "interactions.visible": {
                $ne: false
            },
            "interactions.company_id": req.company_id
        }
    }

    queryToInteraction['interactions.status'] = {
        $in: [1, 7, 8]
    }

    var query = [{
        $match: queryCandidate
    },
    {
        $lookup: {
            "from": "interactions",
            "localField": "_id",
            "foreignField": "candidateId",
            "as": "interactions"
        }
    },
    {
        $match: queryToInteraction
    },
    {
        $skip: body.limit * (body.page - 1)
    },
    {
        $limit: body.limit
    }
    ]

    var countQuery = [{
        $match: queryCandidate
    },
    {
        $lookup: {
            "from": "interactions",
            "localField": "_id",
            "foreignField": "candidateId",
            "as": "interactions"
        }
    },
    {
        $match: queryToInteraction
    },
    {
        $count: "total"
    }
    ];
    let count = await Candidate.aggregate(countQuery)
        .then(count => {
            if (count[0]) {
                return count[0].total;
            } else {
                return 0;
            }
        }).catch(err => {
            res.status(500).send({
                message: Utils.getErrorMessageFromModel(err)
            })
        })

    let result = await Candidate.aggregate(query)
        .then(candidates => {
            candidates.forEach(c => {
                let interviewSelection = c.interactions.filter(x => x.status == 1);
                interviewSelection.sort((a, b) => {
                    return a.registrationDate - b.registrationDate;
                })

                if (interviewSelection[0]) {
                    c.interviewSelection = interviewSelection[0].registrationDate;
                }

                let interviewClient = c.interactions.filter(x => x.status == 7);
                interviewClient.sort((a, b) => {
                    return a.registrationDate - b.registrationDate;
                })

                if (interviewClient[0]) {
                    c.interviewClient = interviewClient[0].registrationDate;
                }

                let approval = c.interactions.filter(x => x.status == 8);
                approval.sort((a, b) => {
                    return a.approval - b.approval;
                })

                if (approval[0]) {
                    c.approval = approval[0].registrationDate;
                }
            })
            return candidates;
        }).catch(err => {
            res.status(500).send({
                message: Utils.getErrorMessageFromModel(err)
            })
        })

    objRes.result = result;
    objRes.count = count;
    res.json(objRes);
}

//Automatico
exports.addTextCv = async (req, res) => {
    var candidatesArray = [];
    Candidate.find({
        noAscentName: null
    })
        .exec()
        .then(candidates => {
            candidates.forEach(candidate => {

                var palavraSemAcento = "";
                var caracterComAcento = "ícáàãâäéèêëíìîïóòõôöúùûüçÁÀÃÂÄÉÈÊËÍÌÎÏÓÒÕÖÔÚÙÛÜÇ";
                var caracterSemAcento = "icaaaaaeeeeiiiiooooouuuucAAAAAEEEEIIIIOOOOOUUUUC";

                for (var i = 0; i < candidate.name.length; i++) {
                    var char = candidate.name.substr(i, 1);
                    var indexAcento = caracterComAcento.indexOf(char);
                    if (indexAcento != -1) {
                        palavraSemAcento += caracterSemAcento.substr(indexAcento, 1);
                    } else {
                        palavraSemAcento += char;
                    }
                }

                candidate.noAscentName = palavraSemAcento;

                candidate.save()
                    .then(res => {
                        console.log(res)
                    })
                    .catch(err => {
                        console.log(err);
                    })

            })
        })
        .catch(err => {
            return res.json(err)
        })

}

exports.candidateJourneyToXlsv = async (req, res) => {
    var body = req.body;
    var queryCandidate = [];
    var queryToInteraction = [];
    var actualDate = new Date();
    var objRes = {
        result: [],
        count: 0,
        export: []
    }

    if (body.userName && body.initialDate && body.finalDate) {

        queryCandidate = {
            visible: {
                $ne: false
            },
            company_id: req.company_id,
            registrationDate: {
                $gt: new Date(body.initialDate),
                $lt: new Date(body.finalDate)
            }
        }

        queryToInteraction = {
            "interactions.visible": {
                $ne: false
            },
            "interactions.company_id": req.company_id,
            "interactions.userFirstName": body.userName
        }

    } else if (body.initialDate && body.finalDate) {

        queryCandidate = {
            visible: {
                $ne: false
            },
            company_id: req.company_id,
            registrationDate: {
                $gt: new Date(body.initialDate),
                $lt: new Date(body.finalDate)
            }
        }

        queryToInteraction = {
            "interactions.visible": {
                $ne: false
            },
            "interactions.company_id": req.company_id
        }


    } else if (body.userName && body.initialDate) {

        queryCandidate = {
            visible: {
                $ne: false
            },
            company_id: req.company_id,
            registrationDate: {
                $gt: new Date(body.initialDate),
                $lt: actualDate
            }
        }

        queryToInteraction = {
            "interactions.visible": {
                $ne: false
            },
            "interactions.company_id": req.company_id,
            "interactions.userFirstName": body.userName
        };


    } else if (body.userName && body.finalDate) {

        queryCandidate = {
            visible: {
                $ne: false
            },
            company_id: req.company_id,
            registrationDate: {
                $lt: new Date(body.finalDate)
            }
        }

        queryToInteraction = {
            "interactions.visible": {
                $ne: false
            },
            "interactions.company_id": req.company_id,
            "interactions.userFirstName": body.userName
        }

    } else if (body.initialDate) {

        queryCandidate = {
            visible: {
                $ne: false
            },
            company_id: req.company_id,
            registrationDate: {
                $gt: new Date(body.initialDate),
                $lt: actualDate
            }
        }

        queryToInteraction = {
            "interactions.visible": {
                $ne: false
            },
            "interactions.company_id": req.company_id
        }

    } else if (body.finalDate) {

        queryCandidate = {
            visible: {
                $ne: false
            },
            company_id: req.company_id,
            registrationDate: {
                $lt: new Date(body.finalDate)
            }
        }

        queryToInteraction = {
            "interactions.visible": {
                $ne: false
            },
            "interactions.company_id": req.company_id
        }


    } else if (body.userName) {

        queryCandidate = {
            company_id: req.company_id,
            visible: {
                $ne: false
            }
        }

        queryToInteraction = {
            "interactions.visible": {
                $ne: false
            },
            "interactions.userFirstName": body.userName,
            "interactions.company_id": req.company_id
        }


    } else {

        queryCandidate = {
            visible: {
                $ne: false
            },
            company_id: req.company_id
        }

        queryToInteraction = {
            "interactions.visible": {
                $ne: false
            },
            "interactions.company_id": req.company_id
        }
    }

    queryToInteraction['interactions.status'] = {
        $in: [1, 7, 8]
    }

    var queryToExport = [{
        $match: queryCandidate
    },
    {
        $lookup: {
            "from": "interactions",
            "localField": "_id",
            "foreignField": "candidateId",
            "as": "interactions"
        }
    },
    {
        $match: queryToInteraction
    }
    ]

    let exportCandidates = await Candidate.aggregate(queryToExport)
        .then(candidates => {
            candidates.forEach(c => {
                let interviewSelection = c.interactions.filter(x => x.status == 1);
                interviewSelection.sort((a, b) => {
                    return a.registrationDate - b.registrationDate;
                })

                if (interviewSelection[0]) {
                    c.interviewSelection = interviewSelection[0].registrationDate;
                }

                let interviewClient = c.interactions.filter(x => x.status == 7);
                interviewClient.sort((a, b) => {
                    return a.registrationDate - b.registrationDate;
                })

                if (interviewClient[0]) {
                    c.interviewClient = interviewClient[0].registrationDate;
                }

                let approval = c.interactions.filter(x => x.status == 8);
                approval.sort((a, b) => {
                    return a.approval - b.approval;
                })

                if (approval[0]) {
                    c.approval = approval[0].registrationDate;
                }
            })
            return candidates;
        }).catch(err => {
            res.status(500).send({
                message: Utils.getErrorMessageFromModel(err)
            })
        })

    objRes.export = transformCandidateReport(exportCandidates);
    res.json(objRes)

}

function transformCandidateReport(candidates) {
    let obj = {
        "Candidato": undefined,
        "Forma": undefined,
        "Data De Candidatura": undefined,
        "Entrevista Seleção": undefined,
        "Entrevista Cliente": undefined,
        "Aprovado": undefined
    }

    let exportItensArr = [];
    exportItensArr.push(Object.keys(obj));
    for (var i = 0; i < candidates.length; i++) {
        let bodyArr = []
        for (let key of Object.keys(obj)) {
            switch (key) {
                case "Candidato":
                    if (candidates[i].name) {
                        bodyArr.push(candidates[i].name);
                    } else {
                        bodyArr.push(" ");
                    }
                    break;
                case "Forma":
                    if (candidates[i].typeOfOrigin == 0) {
                        bodyArr.push("Inbound");
                    } else if (candidates[i].typeOfOrigin == 1) {
                        bodyArr.push("Outbound");
                    } else {
                        bodyArr.push(" ");
                    }
                    break;
                case "Data De Candidatura":
                    if (candidates[i].registrationDate) {
                        bodyArr.push(formatDate(candidates[i].registrationDate));
                    } else {
                        bodyArr.push(" ");
                    }
                    break;
                case "Entrevista Seleção":
                    if (candidates[i].interviewSelection) {
                        bodyArr.push(formatDate(candidates[i].interviewSelection));
                    } else {
                        bodyArr.push("Não Realizada.");
                    }
                    break;
                case "Entrevista Cliente":
                    if (candidates[i].interviewClient) {
                        bodyArr.push(formatDate(candidates[i].interviewClient));
                    } else {
                        bodyArr.push("Não Realizada.");
                    }
                    break;
                case "Aprovado":
                    if (candidates[i].approval) {
                        bodyArr.push(formatDate(candidates[i].approval));
                    } else {
                        bodyArr.push("Não Realizada.");
                    }
                    break;
            }
        }
        exportItensArr.push(bodyArr);
    }
    return exportItensArr;
}

function formatDate(date) {
    if (date) {
        var day = date.getDate();
        var monthIndex = date.getMonth() + 1;
        var year = date.getFullYear();

        return day + '/' + monthIndex + '/' + year;
    } else {
        return "";
    }
}

function transformCandidateReport(candidates) {
    let obj = {
        "Candidato": undefined,
        "Forma": undefined,
        "Data De Candidatura": undefined,
        "Entrevista Seleção": undefined,
        "Entrevista Cliente": undefined,
        "Aprovado": undefined
    }

    let exportItensArr = [];
    exportItensArr.push(Object.keys(obj));
    for (var i = 0; i < candidates.length; i++) {
        let bodyArr = []
        for (let key of Object.keys(obj)) {
            switch (key) {
                case "Candidato":
                    if (candidates[i].name) {
                        bodyArr.push(candidates[i].name);
                    } else {
                        bodyArr.push(" ");
                    }
                    break;
                case "Forma":
                    if (candidates[i].typeOfOrigin == 0) {
                        bodyArr.push("Inbound");
                    } else if (candidates[i].typeOfOrigin == 1) {
                        bodyArr.push("Outbound");
                    } else {
                        bodyArr.push(" ");
                    }
                    break;
                case "Data De Candidatura":
                    if (candidates[i].registrationDate) {
                        bodyArr.push(formatDate(candidates[i].registrationDate));
                    } else {
                        bodyArr.push(" ");
                    }
                    break;
                case "Entrevista Seleção":
                    if (candidates[i].interviewSelection) {
                        bodyArr.push(formatDate(candidates[i].interviewSelection));
                    } else {
                        bodyArr.push("Não Realizada.");
                    }
                    break;
                case "Entrevista Cliente":
                    if (candidates[i].interviewClient) {
                        bodyArr.push(formatDate(candidates[i].interviewClient));
                    } else {
                        bodyArr.push("Não Realizada.");
                    }
                    break;
                case "Aprovado":
                    if (candidates[i].approval) {
                        bodyArr.push(formatDate(candidates[i].approval));
                    } else {
                        bodyArr.push("Não Realizada.");
                    }
                    break;
            }
        }
        exportItensArr.push(bodyArr);
    }
    return exportItensArr;
}

function formatDate(date) {
    if (date) {
        var day = date.getDate();
        var monthIndex = date.getMonth() + 1;
        var year = date.getFullYear();

        return day + '/' + monthIndex + '/' + year;
    } else {
        return "";
    }
}



exports.processReport = async (req, res) => {
    console.log(req.params);


    let objRes = {
        contact: undefined,
        process: undefined,
        approval: undefined,
        hiring: undefined
    }
    objRes.contact = await getContactCandidates({
        action: 1,
        company_id: req.company_id
    });
    objRes.process = await getContactCandidates({
        status: {
            $in: [1, 7]
        },
        company_id: req.company_id
    });
    objRes.approval = await getContactCandidates({
        status: 8,
        company_id: req.company_id
    });
    objRes.hiring = await getContactCandidates({
        status: 4,
        company_id: req.company_id
    });
    res.json(objRes);
}

async function getContactCandidates(query) {
    var count = await Interaction.aggregate([{
        $match: query
    },
    {
        $group: {
            "_id": "$candidateId"
        }
    },
    {
        $lookup: {
            from: "candidates",
            localField: "_id",
            foreignField: "_id",
            as: "candidates"
        }
    },
    {
        $count: "total"
    }
    ])
        .then(candidates => {
            if (candidates)
                if (candidates[0]) {
                    return candidates[0].total;
                }
                else
                    return 0;
        })
        .catch(err => {
            return {
                message: Utils.getErrorMessageFromModel(err)
            }
        })

    return count;
}

exports.getCandidatesAndInterviews = async (req, res) => {
    let objRes = {
        candidates: {},
        interactions: {},
        percentCandidates: 0,
        percentInteractions: 0
    }

    var candidates = await candidatesByRegistrationDate(req.company_id);
    var interactions = await interactionsByInterview(req.company_id);
    objRes.candidates = await reduceArray(candidates);
    objRes.interactions = await reduceArray(interactions);
    let countAll = await countCandidatesAndInterviews(req.company_id);

    if (countAll.countInteractions > 0) {
        var calcInteractions = interactions.length / countAll.countInteractions;
        objRes.percentInteractions = await getPercent(calcInteractions);
    } else {
        var calcInteractions = interactions.length;
        objRes.percentInteractions = calcInteractions * 100;
    }

    if (countAll.countCandidates > 0) {
        var calcCandidates = candidates.length / countAll.countCandidates;
        objRes.percentCandidates = await getPercent(calcCandidates);
    } else {
        var calcCandidates = candidates.length;
        objRes.percentCandidates = calcCandidates * 100;
    }

    res.json(objRes);
}

async function candidatesByRegistrationDate(company_id) {
    var date = new Date();
    var day = date.getUTCDate();
    var month = date.getUTCMonth() + 1;
    var year = date.getUTCFullYear();
    let date2 = new Date(year + "-" + month + "-" + day)
    date2 = date2.getTime() + 75599999;

    var ret = await Candidate.find({
        company_id: company_id,
        registrationDate: {
            $gte: new Date(new Date(year + "-" + month + "-01") - 10800001),
            $lte: new Date(date2)
        }
    })
        .sort({
            registrationDate: 1
        })
        .then(candidates => {
            return candidates
        })
        .catch(err => {
            return err
        })
    return ret;
}


async function interactionsByInterview(company_id) {
    var date = new Date();
    var day = date.getUTCDate();
    var month = date.getUTCMonth() + 1;
    var year = date.getUTCFullYear();
    let date2 = new Date(year + "-" + month + "-" + day)
    date2 = date2.getTime() + 75599999;
    var ret = await Interaction.find({
        action: 4,
        company_id: company_id,
        registrationDate: {
            $gte: new Date(new Date(year + "-" + month + "-01") - 10800001),
            $lte: new Date(date2)
        }
    })
        .sort({
            registrationDate: 1
        })
        .then(interactions => {
            return interactions
        })
        .catch(err => {
            return err
        })
    return ret;
}

function reduceArray(objects) {
    let arrReturn = [];
    let days = [];
    objects.forEach(can => {
        var date = new Date(can.registrationDate)
        days.push(date.getUTCDate());
    })

    var countedDate = days.reduce(function (allNames, name) {
        if (name in allNames) {
            allNames[name]++;
        } else {
            allNames[name] = 1;
        }
        return allNames;
    }, {});

    for (var i = 0; i < Object.keys(countedDate).length; i++) {
        arrReturn.push({
            day: Object.keys(countedDate)[i],
            count: Object.values(countedDate)[i]
        })
    }
    return arrReturn;
}

async function countCandidatesAndInterviews(company_id) {
    var objRet = {
        countCandidates: 0,
        countInteractions: 0
    }
    var date = new Date();
    var day = date.getUTCDate();
    var month = date.getUTCMonth();
    if (month == 0) {
        month = 12
    }
    var year = date.getUTCFullYear();
    let date2 = new Date(year + "-" + month + "-" + day)
    date2 = date2.getTime() + 75599999;
    var retCandidate = await Candidate.count({
        company_id: company_id,
        registrationDate: {
            $gte: new Date(new Date(year + "-" + month + "-01") - 10800001),
            $lte: new Date(date2)
        }
    })
        .sort({
            registrationDate: 1
        })
        .then(candidates => {
            return candidates
        })
        .catch(err => {
            return err
        })


    var retInteraction = await Interaction.count({
        action: 4,
        company_id: company_id,
        registrationDate: {
            $gte: new Date(new Date(year + "-" + month + "-01") - 10800001),
            $lte: new Date(date2)
        }
    })
        .sort({
            registrationDate: 1
        })
        .then(candidates => {
            return candidates
        })
        .catch(err => {
            return err
        })

    objRet.countCandidates = retCandidate;
    objRet.countInteractions = retInteraction;
    return objRet;

}


function getPercent(value) {
    var percentReturn = value;
    if (percentReturn != 1)
        percentReturn = percentReturn - 1;

    return percentReturn * 100;
}

exports.addPrimarySkills = async (req, res) => {
    var candidatesArray = [];
    Candidate.find({})
        .exec()
        .then(candidates => {
            candidates.forEach(candidate => {

                candidate.skills.map(skill => {
                    if (candidate.skills.indexOf(skill) == -1) {
                        candidate.skills.push(skill)
                    }
                })
                candidate.save()
                    .then(res => {
                        console.log(res)
                    })
                    .catch(err => {
                        console.log(err);
                    })

            })
        })
        .catch(err => {
            return res.json(err)
        })

}


exports.exportCandidatesToXlsx = (req, res) => {
    var query = {};

    var body = req.body;
    var totalArray = [];
    var returnCandidate = [];

    let secondarySkills = [];
    if (body.name !== undefined && body.name !== "")
        query.$or = [{
            noAscentName: new RegExp(body.name, "i")
        }, {
            email: new RegExp(body.name, "i")
        }];


    if (body.skills) {
        for (var i = 0; i < body.skills.length; i++) {
            if (i == 0) {
                var calc = body.skills.length + 2;
            } else {
                var calc = body.skills.length - i;
            }
            totalArray.push({
                "pontuation": calc,
                "skill": body.skills[i]
            })
        }
    }

    if (body.sort) {
        if (body.sort.query.relevance) {
            var queryRelevance = body.sort.query;
            body.sort = undefined;
        }
    }
    if (body.status !== undefined && body.status != -1 && body.status.length > 0)
        query.status = {
            $in: body.status
        };

    if (body.profile !== undefined && body.profile >= 0)
        query.profile = body.profile;

    if (body.skills !== undefined && body.skills.length > 0) {
        query.skills = {
            '$in': body.skills.map(function (v) {
                return v;
            })

        }
    }

    if (body.email !== undefined && body.email !== "")
        query.email = new RegExp(body.email, 'i');

    if (body.position !== undefined && body.position !== "" && body.position.length > 0)
        query.position = {
            $in: body.position
        }

    if (body.yearsOfExperience)
        query.yearsOfExperience = body.yearsOfExperience;

    if (body.phone !== undefined && body.phone !== "")
        query.phone = new RegExp(body.phone, 'i');

    if (body.origin !== undefined && body.origin !== "")
        query.origin = new RegExp(body.origin, 'i');

    if (body.rank)
        query.rank = body.rank;

    if (body.initialDate && body.registrationDate) {
        query.registrationDate = {
            $gte: body.initialDate,
            $lt: body.registrationDate
        };
    } else if (body.initialDate) {
        query.registrationDate = {
            $gte: body.initialDate
        };
    } else if (body.registrationDate) {
        query.registrationDate = {
            $lt: body.registrationDate
        };
    }

    query.visible = {
        $ne: false
    }

    query.isBlocked = {
        $ne: true
    }

    query.company_id = req.company_id;

    Candidate.aggregate([{
        $match: query
    },
    {
        $lookup: {
            from: "statusofcandidates",
            localField: "status",
            foreignField: "number",
            as: "statusJoin"
        },

    },
    {
        $project: {
            "Nome": "$name",
            "E-mail": "$email",
            "Currículo": "$curriculum",
            "Linkedin": "$linkedinUrl",
            "Status": "$statusJoin.name",
            "Cargo": "$position"
        }
    }
    ]).then(candidates => {
        let returnCandidates = validate(candidates);
        res.json(returnCandidates);
    })
        .catch(err => {
            return res.status(500).send({
                "message": "Erro ao exportar"
            })
        })
}


function validate(candidates) {
    let obj = {
        name: undefined,
        email: undefined,
        curriculum: undefined,
        linkedinUrl: undefined,
        status: undefined,
        position: undefined,
        relevance: undefined
    }

    let exportItensArr = [];
    let headerArr = [];

    for (var i = 0; i < candidates.length; i++) {
        let bodyArr = []
        for (let key of Object.keys(candidates[i])) {
            if (key != "_id") {
                let index = Object.keys(candidates[i]).indexOf(key);
                if (i == 0) {
                    headerArr.push(key)
                }
                if (key != 'Status') {
                    bodyArr.push(Object.values(candidates[i])[index])

                } else {
                    bodyArr.push(candidates[i].Status)
                }
            }
        }
        if (i == 0) {
            exportItensArr.push(headerArr)
        }
        exportItensArr.push(bodyArr);
    }
    return exportItensArr;
}

function validateAscentClientname(name) {
    var palavra = name;

    var palavraSemAcento = "";
    var caracterComAcento = "ícáàãâäéèêëíìîïóòõôöúùûüçÁÀÃÂÄÉÈÊËÍÌÎÏÓÒÕÖÔÚÙÛÜÇ";
    var caracterSemAcento = "icaaaaaeeeeiiiiooooouuuucAAAAAEEEEIIIIOOOOOUUUUC";

    for (var i = 0; i < palavra.length; i++) {
        var char = palavra.substr(i, 1);
        var indexAcento = caracterComAcento.indexOf(char);
        if (indexAcento != -1) {
            palavraSemAcento += caracterSemAcento.substr(indexAcento, 1);
        } else {
            palavraSemAcento += char;
        }
    }
    return palavraSemAcento;
}

exports.originReportToXlsv = (req, res) => {
    var body = req.body;
    var query = [];

    if (body.initialDate && body.finalDate) {
        query = [{
            $match: {
                visible: {
                    $ne: false
                },
                company_id: req.company_id,
                registrationDate: {
                    $gte: new Date(body.initialDate),
                    $lte: new Date(body.finalDate)
                }
            }
        }, {
            $group: {
                "_id": "$origin",
                count: {
                    $sum: 1
                }
            }
        }]
    } else if (body.initialDate) {
        query = [{
            $match: {
                visible: {
                    $ne: false
                },
                company_id: req.company_id,
                registrationDate: {
                    $gte: new Date(body.initialDate)
                }
            }
        }, {
            $group: {
                "_id": "$origin",
                count: {
                    $sum: 1
                }
            }
        }]
    } else if (body.finalDate) {
        query = [{
            $match: {
                visible: {
                    $ne: false
                },
                company_id: req.company_id,
                registrationDate: {
                    $lte: new Date(body.finalDate)
                }
            }
        }, {
            $group: {
                "_id": "$origin",
                count: {
                    $sum: 1
                }
            }
        }]
    } else {
        query = [{
            $match: {
                company_id: req.company_id,
                visible: {
                    $ne: false
                }
            }
        }, {
            $group: {
                "_id": "$origin",
                count: {
                    $sum: 1
                }
            }
        }]
    }

    if (body.sort) {
        query.push({
            $sort: body.sort['query']
        });
    }

    Candidate.aggregate(query, function (err, result) {
        if (err) {
            res.status(400).send({
                message: Utils.getErrorMessageFromModel(err)
            });
        } else {

            var resultValidate = 0;
            var returns = false;
            for (var i = 0; i < result.length; i++) {
                if (result[i]) {
                    if (result[i]._id == "" || result[i]._id == null) {
                        resultValidate = resultValidate + result[i].count;
                        result.splice(i, 1);

                    }
                    if (result[i]._id == "Outro") {
                        returns = true;
                        result[i].count = result[i].count + resultValidate;
                    }
                }
            }
            if (returns == false) {
                if (resultValidate > 0) {
                    result.push({
                        "_id": "Outro",
                        "count": resultValidate
                    });
                }
            }
            let resultToReturn = validateOriginReport(result);
            res.json(resultToReturn);
        }
    });
}


function validateOriginReport(origins) {
    let obj = {
        "Origem": undefined,
        "Quantidade de candidatos": undefined
    }

    let exportItensArr = [];

    exportItensArr.push(Object.keys(obj))
    for (var i = 0; i < origins.length; i++) {
        let bodyArr = []
        for (let key of Object.keys(obj)) {
            switch (key) {
                case "Origem":
                    bodyArr.push(origins[i]._id);
                    break;
                case "Quantidade de candidatos":
                    bodyArr.push(origins[i].count);
                    break;

                default:
                    break;
            }
        }
        exportItensArr.push(bodyArr);
    }
    return exportItensArr;
}

exports.getCandidateByEmail = (req, res) => {

    Candidate.findOne({
        email: req.body.email,
        company_id: req.params.companyId
    })
        .populate('opportunities')
        .then(candidate => {
            res.json(candidate);
        })
        .catch(err => {
            return res.status(500).send({
                message: Utils.getErrorMessageFromModel(err)
            })
        })
}

exports.emailWithCompany = (req, res) => {
    console.log("a   ")
    Candidate.find().then(candidates => {
        candidates.forEach(c => {
            c.emailWithCompany = c.email + c.company_id;
            console.log(c.emailWithCompany)
            c.save().then(cand => {
                console.log(c)
            }).catch(err => {
                console.log(err)
            })
        })


    }).catch(err => {

    })
}

exports.searchRecruiter = (req, res) => {
    console.log(req.params.candidateId)
    const id = req.params.candidateId;

    Candidate.aggregate([
        {
            $match: {
                _id: { $eq: ObjectId(id) }

            }
        },
        {
            $lookup:
            {
                from: "users",
                localField: "userEmail",
                foreignField: "email",
                as: "user",
            }
        },
        { $unwind: "$user" }

    ]).then(result => {
        console.log(result)
        return res.status(200).send(result);
    })
};