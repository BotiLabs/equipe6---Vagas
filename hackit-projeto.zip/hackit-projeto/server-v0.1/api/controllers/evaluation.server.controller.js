'use strict';

var mongoose = require('mongoose'),
    Utils = require('../../domain/utils/util'),
    Evaluation = require('../../domain/models/evaluation').Evaluation,
    Testing = require('../../domain/models/testing').Testing,
    candidate = require('../../api/controllers/candidate.server.controller'),
    auth_external = require('../controllers/authExternal.server.controller'),
    Type = require('../../domain/models/type').Type;

exports.create = async (req, res) => {
    console.log(req.body);
    let ifUserExists = false;

    let searchUser = await auth_external.findUser(req, res);
    if (searchUser)
        ifUserExists = true;

    req.body.startedEvaluation = req.body.startedEvaluation;
    req.body.fullName = req.body.name;
    Evaluation.find().sort({
            number: -1
        }).limit(1)
        .exec()
        .then((async result => {
            var evaluation = new Evaluation(req.body);

            if (result.length>0) {
                if (result[0].number) {
                    evaluation.number = ++result[0].number;
                } else {
                    evaluation.number = 1;
                }
            } else {
                evaluation.number = 1;
            }
            let evArr = []
            for (var i = 0; i < evaluation.type.length; i++) {
                let type = await Type.findOne({
                        id: evaluation.type[i]
                    }).then(type => {
                        return type;
                    })
                    .catch(err => {
                        return undefined;
                    })
                let evToSave = new Evaluation(evaluation);
                if (i > 0) {
                    evToSave.number = evaluation.number + i;
                }
                if (type) {
                    evToSave.discription = type.discription;
                }
                let hour = new Date().getTime();
                evToSave.registrationDate = new Date(hour)
                evToSave.type = [];
                evToSave._id = undefined;
                evToSave.companyId = evToSave.company_id;
                evToSave.type.push(evaluation.type[i]);
                evArr.push(evToSave)
            }
            Evaluation.insertMany(evArr)
                .then(async (evaluations) => {
                    if (!ifUserExists) {
                        let user = await auth_external.signup(req, res);
                    }
                    res.json(evaluations);
                })
                .catch(err => {
                    return res.status(400).send({
                        message: Utils.getErrorMessageFromModel(err)
                    });
                })
        }))
        .catch(err => {
            res.status(500).send({
                message: Utils.getErrorMessageFromModel(err)
            })
        });
}


//Find a company_id to next method
exports.prepareCompanyId = (req, res, next, id) => {
    req.company_id = id;
    next()
};

exports.list = (req, res) => {
    Evaluation.find({
            company_id: req.company_id
        })
        .sort('-created_at').exec((err, evaluations) => {
            if (err) {
                return res.status(400).send({
                    message: Utils.getErrorMessageFromModel(err)
                });
            } else {
                res.json(evaluations);
            }
        });
}

exports.read = (req, res) => {
    res.json(req.evaluation);
};

exports.delete = (req, res) => {
    var evaluation = req.evaluation;
    evaluation.remove((err) => {
        if (err) {
            return res.status(400).send({
                message: Utils.getErrorMessageFromModel(err)
            });
        } else {
            res.json(evaluation);
        }
    });
}

exports.evaluationById = (req, res, next, id) => {
    Evaluation.findById(id, (err, evaluation) => {
        if (err) {
            return next(err);
        }
        if (!evaluation) {
            return res.status(400).send({
                message: 'Failed to load evaluation ' + id
            });
        }

        req.evaluation = evaluation;
        next();
    })
};

exports.update = (req, res) => {
    var evaluation = req.evaluation;
    for (var prop in req.body) {
        evaluation[prop] = req.body[prop];
    }

    console.log(evaluation)
    // console.log(evaluation)
    evaluation.save().then(function (evaluation) {
        res.status(200).json(evaluation)

    }).catch(err => {
        return res.status(400).send({
            message: Utils.getErrorMessageFromModel(err)
        });
    });
}

exports.push = (req, res) => {
    var testing = req.body.testings;
    var id = req.body._id;

    Evaluation.findOneAndUpdate(
        id, {
            $push: {
                testings: testing
            }
        },
        (err, evaluation) => {
            if (err) {
                res.status(400).send({
                    message: Utils.getErrorMessageFromModel(err)
                });
            } else {
                res.json(evaluation);
            }
        });
}

exports.search = (req, res) => {
    let objRes = {
        result: null,
        count: 0
    };

    var verify;
    var query = {};
    var body = "";
    body = req.body;
    query.company_id = body.company_id;

    var d = new Date(body.initialDate)
    var e = new Date(body.date)

    if (body.withDate) {
        query.date = {
            $exists: true
        }
    } else if (body.withDate == false) {
        query.date = {
            $exists: false
        }
    }

    if (body.initialDate && body.date) {
        query.date = {
            $gte: body.initialDate,
            $lt: body.date
        };
    } else if (body.initialDate) {
        query.date = {
            $gte: body.initialDate
        };
    } else if (body.date) {
        query.date = {
            $lt: body.date
        };
    }
    // if (body.date !== undefined && body.date !== "")
    //     query.date = { $gte: body.initialDate, $lt: body.date };

    if (body.dateValidator !== undefined && body.dateValidator !== "")
        query.date = body.dateValidator;

    if (body.name == "" && body.email == "") {
        query.email = new RegExp(body.email, "i");
        query.name = new RegExp(body.name, "i");
        verify = false;
    } else {
        if (body.name && body.email == "") {
            verify = true;
            query = {
                $text: {
                    $search: body.name,
                    $diacriticSensitive: false
                }
            }
        } else if (body.name && body.email) {
            query = {
                $text: {
                    $search: body.name,
                    $diacriticSensitive: false
                }
            }
            query.email = new RegExp(body.email, "i");
        } else if (body.name == "" && body.email) {
            query.email = new RegExp(body.email, "i");
        } else {
            query.email = new RegExp(body.email, "i");
        }
    }

    Evaluation.count(query, function (err, count) {
        if (err) {
            res.status(404).send({
                message: Utils.getErrorMessageFromModel(err)
            });
        } else {
            objRes.count = count;
            if (body.sort) {
                Evaluation.find(query).sort(body.sort['query']).skip(body.limit * (body.page - 1)).limit(body.limit).exec((error, evaluation) => {
                    if (error) {
                        return res.status(400).send({
                            message: Utils.getErrorMessageFromModel(err)
                        });
                    } else {

                        objRes.result = evaluation;
                        objRes.verify = verify;
                        res.json(objRes);

                    }
                })
            } else {
                Evaluation.find(query, function (err, result) {
                    if (err) {
                        res.status(404).send({
                            message: Utils.getErrorMessageFromModel(err)
                        });
                    } else {
                        objRes.result = result;
                        objRes.verify = verify;
                        res.json(objRes);
                    }
                }).sort({
                    "date": -1
                }).skip(body.limit * (body.page - 1)).limit(body.limit);
            }

        }
    });
};

exports.findEvaluationByEmail = (req, res) => {
    console.log(req.body);
    let objRes = {
        result: null,
        count: 0
    };

    Evaluation.count({
            email: req.body.email,
            company_id: req.body.company_id
        },
        function (err, count) {
            if (err) {
                res.status(404).send({
                    message: Utils.getErrorMessageFromModel(err)
                });
            } else {
                objRes.count = count;
                Evaluation.find({
                    email: req.body.email,
                    company_id: req.body.company_id
                }, function (err, evaluation) {
                    if (err) {
                        res.status(400).send({
                            message: Utils.getErrorMessageFromModel(err)
                        });
                    }
                    if (!evaluation) {
                        res.status(204).send({
                            message: 'Usuário não encontrado'
                        });
                    } else {
                        objRes.result = evaluation;
                        res.json(objRes);
                    }
                });
            }
        });
};

exports.getType = (req, res) => {
    var query = {};
    var body = req.body;

    Evaluation.find({
        _id: req.body._id,
        company_id: req.body.company_id
    }, function (err, evaluation) {
        if (err) {
            res.status(404).send({
                message: Utils.getErrorMessageFromModel(err)
            });
        } else {
            res.json(evaluation);
        }
    }).select('type');
};

exports.saveAnswers = (req, res) => {

    var body = req.body;
    Evaluation.findOneAndUpdate({
            _id: body._id
        },
        // body._id,
        {
            $set: {
                "testing": body.testing,
                "date": body.date,
                "personality": body.personality,
                "answerTime": body.answerTime,
            }
        },
        (err, evaluation) => {
            if (err) {
                res.status(400).send({
                    message: Utils.getErrorMessageFromModel(err)
                });
            } else {
                res.json(evaluation);
            }
        });
};

exports.sum = (req, res) => {
    let themes = [];
    let sum = 0;
    let all = [];

    Testing.aggregate([{
        "$group": {
            _id: '$theme',
        }
    }], (err, result) => {
        if (err) {
            res.status(400).send({
                message: Utils.getErrorMessageFromModel(err)
            });
        } else {
            for (let key in result) {
                themes.push(result[key]._id);
            }

            Evaluation
                .find({
                    _id: req.body._id,
                    company_id: req.body.company_id
                })
                .exec((err, result) => {
                    if (err) {
                        res.status(404).send({
                            message: Utils.getErrorMessageFromModel(err)
                        });
                    } else {
                        for (let key in result) {
                            for (let c in themes) {
                                for (let item of result[key].testing) {
                                    if (item.theme == themes[c]) {
                                        if (item.theme != "Redação") {
                                            sum = sum + item.answer.weight;
                                        }
                                    }
                                }
                                all.push({
                                    "theme": themes[c],
                                    "total": sum
                                });
                                sum = 0;
                            }


                        }
                        res.json(all);
                    }
                });
        }
    });
}