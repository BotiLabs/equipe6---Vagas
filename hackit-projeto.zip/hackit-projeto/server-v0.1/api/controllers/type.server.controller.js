'use strict';

var mongoose = require('mongoose'),
    Utils = require('../../domain/utils/util'),
    Type = require('../../domain/models/type').Type;


exports.create = (req, res) => {
    let type = new Type(req.body);
    type.save()
        .then(savedType => {
            res.json(savedType);
        })
        .catch(err => {
            if (err.code == 11000) {
                return res.status(400).send({
                    message: "Já existe uma avaliação deste tipo"
                })
            }
            res.status(500).send({
                message: Utils.getErrorMessageFromModel(err)
            })
        })
}

exports.getAll = (req, res) => {
    Type.find({
            company_id: req.params.companyId
        })
        .then(types => {
            res.json(types);
        })
        .catch(err => {
            res.status(500).send({
                message: Utils.getErrorMessageFromModel(err)
            })
        })
}