'use strict';
var ObjectId = require('mongoose').Types.ObjectId;
var mongoose = require('mongoose'),
    Utils = require('../../domain/utils/util'),
    Customer = require('../../domain/models/customer').Customer,
    Location = require('../../domain/models/location').Location;

//Insert a new interaction
exports.create = (req, res) => {
    var body = req.body;
    var name = body.name.toUpperCase();
    body.name = name;
    var customer = new Customer(body);
    let hour = new Date().getTime();
    let date = new Date(hour);
    customer.registrationDate = date;
    Customer.findOne({
            name: name,
            company_id: customer.company_id
        })
        .exec()
        .then((result => {
            if (result) {
                res.status(400).send({
                    message: "Este cliente já foi cadastrado",
                    result: result
                });
            } else {
                customer.save().
                then(customer => {
                        if (customer.unity.length > 0) {
                            let location = new Location(customer.unity[customer.unity.length - 1])
                            location.clientLocation = customer._id;
                            location.company_id = customer.company_id;
                            location.save()
                                .then(location => {
                                    res.json(customer);
                                })
                                .catch(err => {
                                    return res.status(400).send({
                                        message: Utils.getErrorMessageFromModel(err)
                                    });
                                })
                        } else {
                            res.json(customer)
                        }
                    })
                    .catch(err => {
                        return res.status(400).send({
                            message: Utils.getErrorMessageFromModel(err)
                        });
                    })
            }
        })).catch((err => {
            return res.status(500).send({
                message: Utils.getErrorMessageFromModel(err)
            });
        }))

};


//Find a company_id to next method
exports.prepareCompanyId = (req, res, next, id) => {
    req.company_id = id;
    next()
};

exports.list = (req, res) => {
    let objRes = {
        result: null,
        count: 0
    };

    Customer.count({}, function (err, count) {
        if (err) {
            res.status(404).send({
                message: Utils.getErrorMessageFromModel(err)
            });
        } else {
            objRes.count = count;
            Customer.find({
                    company_id: req.company_id
                })
                .populate('logs')
                .sort('-created_at').exec((err, Customer) => {
                    if (err) {
                        res.status(400).send({
                            message: Utils.getErrorMessageFromModel(err)
                        });
                    }
                    objRes.result = Customer;
                    res.json(objRes)
                });
        }
    });
};


exports.search = (req, res) => {
    let objRes = {
        result: null,
        count: 0
    };

    var body = req.body;

    var query = {};
    query.company_id = body.company_id;

    var query2 = {};

    if (body.name !== undefined && body.name !== "")
        query.name = new RegExp(body.name, 'i');

    if (body.unity !== undefined && body.unity !== "")
        query2['locations.discription'] = new RegExp(body.unity, 'i');

    if (body.location !== undefined && body.location !== "")
        query2.$or = [{
                "locations.streetAddress": new RegExp(body.location, 'i')
            },
            {
                "locations.district": new RegExp(body.location, 'i')
            },
            {
                "locations.state": new RegExp(body.location, 'i')
            }
        ];

    Customer.aggregate([{
                $match: query
            },
            {
                $lookup: {
                    from: "locations",
                    localField: "_id",
                    foreignField: "clientLocation",
                    as: "locations"
                },

            },
            {
                $match: query2
            },
            {
                $count: "total"
            }
        ]).then(count => {
            if (count[0]) {
                objRes.count = count[0].total;
            } else {
                objRes.count = 0;
            }
            Customer.aggregate([{
                        $match: query
                    },
                    {
                        $lookup: {
                            from: "locations",
                            localField: "_id",
                            foreignField: "clientLocation",
                            as: "locations"
                        },

                    },
                    {
                        $match: query2
                    },
                    {
                        $skip: body.limit * (body.page - 1)
                    },
                    {
                        $limit: body.limit
                    }
                ]).then(customers => {
                    objRes.result = customers;
                    res.json(objRes)
                })
                .catch(err => {
                    res.status(500).send({
                        message: Utils.getErrorMessageFromModel(err)
                    })
                })
        })
        .catch(err => {
            res.status(500).send({
                message: Utils.getErrorMessageFromModel(err)
            })
        });
};

exports.read = (req, res) => {
    res.json(req.customer);
};

exports.cusById = (req, res) =>{
    
    let id = req.body.id;
    console.log("chegou",id);

    Customer.findById(id, (err, customer) => {
        if (err) {
            return res(err);
        }
        if (!customer) {
            return res.status(400).send({
                message: 'Failed to load customer ' + id
            });
        }
    
        return res.json(customer);

        
        
    })
};

//Find a customer to next method
exports.customerById = (req, res, next, id) => {
    Customer.findById(id, (err, customer) => {
        if (err) {
            return next(err);
        }
        if (!customer) {
            return res.status(400).send({
                message: 'Failed to load customer ' + id
            });
        }

        req.customer = customer;
        next();
    })
};


//Update a customer
exports.update = (req, res) => {
    var customer = req.customer;

    for (var prop in req.body) {
        customer[prop] = req.body[prop];
    }
    customer.name = customer.name.toUpperCase();

    customer.save((err) => {
        if (err) {
            return res.status(400).send({
                message: Utils.getErrorMessageFromModel(err)
            });
        } else {
            res.json(customer)
        }
    });
};

exports.updateToDelete = (req, res) => {
    var customer = req.customer;

    for (var prop in req.body) {
        customer[prop] = req.body[prop];
    }
    var name = req.body.name.toUpperCase();
    customer.name = name;
    Customer.findOne({
            name: name
        })
        .exec()
        .then((result => {

            if (result) {
                return res.status(400).send({
                    message: "Já existe um cliente com este nome"
                });
            } else {
                customer.save((err) => {
                    if (err) {
                        return res.status(400).send({
                            message: Utils.getErrorMessageFromModel(err)
                        });
                    } else {
                        res.json(customer)
                    }
                }).catch((err => {
                    return res.status(500).send({
                        message: Utils.getErrorMessageFromModel(err)
                    });
                }))
            }
        }));
};

exports.updateLocationsCustomer = async (req, res) => {
    var customer = req.body;
    let location = new Location(customer.unity[customer.unity.length - 1])
    location.clientLocation = customer._id;
    location.company_id = customer.company_id;
    let customerModel = {};
    customerModel = await findCustomerById(customer._id);
    customerModel.unity = customer.unity;
    Location.findOne({
            "clientLocation": customer._id,
            "discription": location.discription
        })
        .then(response => {
            if (!response) {
                location.save()
                    .then(location => {
                        customerModel.save()
                            .then(updatedCustomer => {
                                res.json(updatedCustomer);
                            })
                            .catch(err => {
                                return res.status(400).send({
                                    message: Utils.getErrorMessageFromModel(err)
                                })
                            })
                    })
                    .catch(err => {
                        return res.status(400).send({
                            message: Utils.getErrorMessageFromModel(err)
                        });
                    })
            } else {
                return res.status(400).send({
                    message: "Já existe uma localização com esta descrição"
                });
            }
        }).catch(err => {
            return res.status(400).send({
                message: Utils.getErrorMessageFromModel(err)
            });
        })
};

async function findCustomerById(customerId) {
    let resp = await Customer.findOne({
            "_id": new ObjectId(customerId)
        })
        .then(response => {
            return response;
        })
        .catch(err => {
            return err;
        })

    return resp;
}