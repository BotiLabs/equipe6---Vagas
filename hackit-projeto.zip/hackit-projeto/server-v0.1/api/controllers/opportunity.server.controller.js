'use strict';
var ObjectId = require('mongoose').Types.ObjectId;
var mongoose = require('mongoose'),
    Utils = require('../../domain/utils/util'),
    Opportunity = require('../../domain/models/opportunity').Opportunity,
    Interaction = require('../../domain/models/interaction').Interaction;
//Insert a new opportunity

//Find a company_id to next method
exports.prepareCompanyId = (req, res, next, id) => {
    req.company_id = id;
    next()
};

exports.create = (req, res) => {
    Opportunity.count({}, function (err, count) {
        var body = req.body;
        var number = body.number;

        Opportunity.find({
            company_id: req.body.company_id
        }).sort({
            number: -1
        }).limit(1)
            .exec()
            .then((result => {
                if (err) {
                    return res.status(404).send({
                        message: Utils.getErrorMessageFromModel(err)
                    });
                } else {
                    let opportunities = [];

                    var opportunity = new Opportunity(req.body);

                    if (result.length > 0) {
                        if (result[0].number) {
                            opportunity.number = ++result[0].number;
                        }
                    } else {
                        opportunity.number = 1;
                    }

                    opportunity.save((err, opportunitySaved) => {
                        if (err) {
                            return res.status(400).send({
                                message: Utils.getErrorMessageFromModel(err)
                            });
                        } else {
                            res.status(200).json(opportunitySaved);
                        }
                    });
                }
            }))

    });

};

//Update a opportunity
exports.update = (req, res) => {
    var opportunity = req.opportunity;
    for (var prop in req.body) {
        opportunity[prop] = req.body[prop];
    }
    if (opportunity.qtdOpportunities == 0) {
        opportunity.status = 1
    }
    opportunity.lastAlterationDate = new Date();
    opportunity.save((err) => {
        if (err) {
            return res.status(400).send({
                message: Utils.getErrorMessageFromModel(err)
            });
        } else {
            res.json(opportunity)
        }
    });
};

//Delete a opportunity
exports.delete = (req, res) => {
    var opportunity = req.opportunity;

    opportunity.remove((err) => {
        if (err) {
            return res.status(400).send({
                message: Utils.getErrorMessageFromModel(err)
            });
        } else {
            res.json(opportunity);
        }
    });
};

//Find a opportunity to next method
exports.opportunityById = (req, res, next, id) => {
    Opportunity.findById(id, (err, opportunity) => {
        if (err) {
            return next(err);
        }
        if (!opportunity) {
            return res.status(400).send({
                message: 'Failed to load opportunity ' + id
            });
        }

        req.opportunity = opportunity;

        next();
    });
};

exports.searchAnything = (req, res) => {
    var query = req.body;
    Opportunity.find({
        status: 0,
        $or: [{
            name: new RegExp(req.body.name, "i")
        },
        {
            specialities: {
                $in: [RegExp(req.body.name, "i")]
            }
        },
        {
            'opportunityLocation.district': new RegExp(req.body.name, "i")
        },
        {
            'opportunityLocation.state': new RegExp(req.body.name, "i")
        },
        ],


    }).then(result => {
        res.json(result)
    })
        .catch(err => {
            console.log(err)
        })
}

exports.search = (req, res) => {
    console.log(req.body);
    let objRes = {
        result: null,
        count: 0
    };
    var query = {};
    let body = req.body;

    if (!body.company_id) {
        return res.status(400).send({
            message: "Erro de identificação recarregue a página!"
        })
    }

    query.company_id = body.company_id;

    if (body.location !== undefined && body.location !== "")
        query.location = new RegExp(body.location, "i");

    if (body.customerName !== undefined && body.customerName !== "")
        query.customerName = new RegExp(body.customerName, "i");
    if (body.businessUnit !== undefined && body.businessUnit != -1)
        query.businessUnit = body.businessUnit;

    if (body.responsible !== undefined && body.responsible !== "")
        query.responsible = new RegExp(body.responsible, 'i');

    if (body.value !== undefined && body.value !== "")
        query.value = new RegExp(body.value, 'i');

    if (body.name !== undefined && body.name !== "")
        query.name = new RegExp(body.name, 'i');

    if (body.customerName !== undefined && body.customerName !== "")
        query.customerName = new RegExp(body.customerName, 'i');

    if (body.opportunityLocation) {
        if (body.opportunityLocation.state !== undefined && body.opportunityLocation.state !== "") {
            query['opportunityLocation.state'] = new RegExp(body.opportunityLocation.state, "i");
        }
    }

    if (body.profile !== undefined && body.profile >= 0)
        query.profile = body.profile;

    if (body.status !== undefined && body.status >= 0)
        query.status = body.status;

    if (body.number !== undefined)
        query.number = body.number;

    if (body.priority !== undefined && body.priority != -1)
        query.priority = body.priority;

    if (body.initialDate && body.registrationDate) {
        query.registrationDate = {
            $gte: body.initialDate,
            $lt: body.registrationDate
        };
    } else if (body.initialDate) {
        query.registrationDate = {
            $gte: body.initialDate
        };
    } else if (body.registrationDate) {
        query.registrationDate = {
            $lt: body.registrationDate
        };
    }

    if (body.specialities !== undefined && body.specialities.length > 0) {
        query.specialities = {
            '$in': body.specialities.map(function (v) {
                return v.toUpperCase();
            })
        }

    }

    query.visible = {
        $ne: false
    }
    if (body.involvedPeople !== undefined && body.involvedPeople.length > 0) {
        query["involvedPeople.name"] = {
            '$in': body.involvedPeople.map(function (v) {
                return v;
            })
        }

    }

    let project = projectFields();

    Opportunity.count(query, function (err, count) {
        if (err) {
            res.status(404).send({
                message: Utils.getErrorMessageFromModel(err)
            });
        } else {

            if (body.sort) {
                const orders = Opportunity.aggregate([{
                    $match: query
                },
                {
                    $lookup: {
                        from: "statusofopportunities",
                        localField: "status",
                        foreignField: "number",
                        as: "statusJoin"
                    },

                },
                    project,
                {
                    $sort: body.sort['query']
                },
                {
                    $skip: body.limit * (body.page - 1)
                },
                {
                    $limit: body.limit
                }
                ], function (err, result) {
                    objRes.count = count;
                    if (err) {
                        res.status(404).send({
                            message: Utils.getErrorMessageFromModel(err)
                        });
                    } else {
                        objRes.result = result;
                        res.json(objRes);
                    }
                });
            } else {
                const orders = Opportunity.aggregate([{
                    $match: query
                },
                {
                    $lookup: {
                        from: "statusofopportunities",
                        localField: "status",
                        foreignField: "number",
                        as: "statusJoin"
                    },
                },
                    project,
                {
                    $skip: body.limit * (body.page - 1)
                },
                {
                    $limit: body.limit
                }

                ], function (err, result) {
                    objRes.count = count;
                    if (err) {
                        res.status(404).send({
                            message: Utils.getErrorMessageFromModel(err)
                        });
                    } else {
                        objRes.result = result;
                        res.json(objRes);
                    }
                });
            }
        };
    });
}

function projectFields() {
    let project = {
        $project: {
            name: "$name",
            description: "description",
            responsible: "$responsible",
            value: "$value",
            profile: "$profile",
            customerName: "$customerName",
            location: "$location",
            businessUnit: "$businessUnit",
            status: "$status",
            specialities: "$specialities",
            isActive: "$isActive",
            number: "$number",
            candidates: "$candidates",
            registrationDate: "$registrationDate",
            emailResponsible: "$emailResponsible",
            priority: "$priority",
            visible: "$visible",
            opportunityLocation: "$opportunityLocation",
            qtdOpportunities: "$qtdOpportunities",
            initialQtd: "$initialQtd",
            historic: "$historic",
            emailWatching: "$emailWatching",
            involvedPeople: "$involvedPeople",
            closedDate: "$closedDate",
            lastAlterationDate: "$lastAlterationDate",
            statusJoin: "$statusJoin",
            candidatesLength: {
                "$size": "$candidates"
            }
        }
    }
    return project;
}
//List a opportunity
exports.read = (req, res) => {
    res.json(req.opportunity);
};

//List existing opportunities
exports.list = (req, res) => {
    Opportunity.find({
        company_id: req.company_id,
        visible: {
            $ne: false
        }
    }, function (err, opportunities) {
        if (err) {
            res.status(400).send({
                message: Utils.getErrorMessageFromModel(err)
            });
        } else {
            res.json(opportunities);
        }
    });
};

exports.listTerceiros = (req, res) => {
    let objRes = {
        opportunities: []
    }
    Opportunity.find({
        visible: {
            $ne: false
        }
    }, function (err, opportunities) {
        if (err) {
            res.status(400).send({
                message: Utils.getErrorMessageFromModel(err)
            });
        } else {
            for (let i = 0; i < opportunities.length; i++) {
                let district;
                opportunities[i].opportunityLocation ? district = opportunities[i].opportunityLocation.district : opportunities;

                objRes.opportunities.push({
                    "qtdOpportunities": opportunities[i].qtdOpportunities,
                    "name": opportunities[i].name,
                    "specialities": opportunities[i].specialities,
                    "district": district,
                    "description": opportunities[i].description

                });
            }
            res.json(objRes);
        }
    });
};

//List existing opportunities
exports.listForInteraction = (req, res) => {
    Opportunity.find({
        "status": {
            $in: [0, 2]
        },
        company_id: req.company_id,
        visible: {
            $ne: false
        }
    }, function (err, opportunities) {
        if (err) {
            res.status(400).send({
                message: Utils.getErrorMessageFromModel(err)
            });
        } else {
            res.json(opportunities)

        }
    })
};

// Count opportunity
exports.count = (req, res) => {

    Opportunity.count({
        company_id: req.company_id
    }, function (err, result) {

        if (err) {
            res.status(404).send({
                message: Utils.getErrorMessageFromModel(err)
            });
        } else {
            res.status(200).json(result);
        }
    });
}

// List Opportunity by custommer
exports.listByCustommer = (req, res) => {

    var query =
        Opportunity.aggregate(([{
            $group: {
                "_id": "$customerName",
                company_id: req.company_id,
                count: {
                    $sum: 1
                }
            }
        }]), function (err, result) {
            if (err) {
                res.status(400).send({
                    message: Utils.getErrorMessageFromModel(err)
                });
            } else {
                res.json(result);
            }
        });
};

// List Opportunity by businessUnit
exports.listByBusinessUnit = (req, res) => {

    var query =
        Opportunity.aggregate(([{
            $group: {
                "_id": "$businessUnit",
                company_id: req.company_id,
                count: {
                    $sum: 1
                }
            }
        }]), function (err, result) {
            if (err) {
                res.status(400).send({
                    message: Utils.getErrorMessageFromModel(err)
                });
            } else {
                res.json(result);
            }
        });
};

// Get opportunities by period
exports.getBetweenDate = (req, res) => {
    var actualDate = new Date();
    var lastMonth = actualDate - 2678400000;
    var query =
        Opportunity.find({
            company_id: req.company_id,
            "registrationDate": {
                $gte: lastMonth,
                $lt: actualDate
            }
        }, function (err, result) {
            if (err) {
                res.status(400).send({
                    message: Utils.getErrorMessageFromModel(err)
                });
            } else {
                res.json(result);
            }
        });
};


// Sort colums of opportunity
exports.sortOpportunity = (req, res) => {
    var query = req.body;
    Opportunity.find({
        company_id: req.company_id,
        visible: {
            $ne: false
        }
    }).sort(query).exec((err, opportunity) => {
        if (err) {
            res.status(400).send({
                message: Utils.getErrorMessageFromModel(err)
            });
        } else {
            res.json(opportunity);
        }
    });
}

exports.listByStatus = async (req, res) => {
    let company_id = req.company_id;
    let resultCount = await calculateClosedOpp(company_id);
    let resultOp1 =
        await Opportunity.aggregate([{
            $match: {
                "company_id": company_id,
                status: {
                    $in: [0, 2, 3]
                }
            }
        }, {
            $group: {
                "_id": "$status",
                "count": {
                    $sum: "$qtdOpportunities"
                }
            }
        }]).then(result => {
            return result;
        }).catch(err => {
            return res.status(500).send({
                message: Utils.getErrorMessageFromModel(err)
            })
        })

    let resultOp2 = await Opportunity.aggregate([{
        $match: {
            "company_id": company_id,
            "status": 1
        }
    },
    {
        $group: {
            "_id": "$status",
            "count": {
                $sum: "$initialQtd"
            }
        }
    }
    ])
        .then(result => {
            return result[0];
        }).catch(err => {
            return res.status(500).send({
                message: Utils.getErrorMessageFromModel(err)
            })
        });
    resultCount.forEach(r => {
        if (r) {
            if (r.calc)
                if (r.calc > 0) {
                    resultOp2 ? resultOp2.count + r.calc : resultOp2 = {
                        _id: 1,
                        count: r.calc
                    }
                }
        }
    })

    resultOp1.push(resultOp2);
    res.json(resultOp1)
};


async function calculateClosedOpp(company_id) {
    var result = Opportunity.aggregate([{
        $match: {
            company_id: company_id,
            status: {
                $in: [0, 2, 3]
            }
        }
    },
    {
        $group: {
            "_id": "$status",
            "count1": {
                $sum: "$qtdOpportunities"
            },
            "count2": {
                $sum: "$initialQtd"
            }
        }
    },
    {
        $project: {
            "calc": {
                $subtract: ["$count2", "$count1"]
            }
        }
    }
    ]).then(result => {
        return result;
    }).catch(err => {
        return res.status(500).send({
            "message": Utils.getErrorMessageFromModel(err)
        })
    })

    return result;

}

exports.reportClosedOpportunities = (req, res) => {
    var resultClosed = [];
    var queryInteraction = undefined;
    var queryOpp = undefined;
    var objRes = {
        result: {},
        count: 0,
        export: {}
    }
    var body = req.body;
    if (body.validation == 1) {

        queryOpp = {
            visible: {
                $ne: false
            },
            status: 1
        }


        if (body.initialDate && body.finalDate && body.userName) {

            queryInteraction = {
                "interaction.visible": {
                    $ne: false
                },
                "interaction.status": 4,
                "interaction.registrationDate": {
                    $gt: new Date(body.initialDate),
                    $lt: new Date(body.finalDate)
                },
                "interaction.userFirstName": body.userName
            }


        } else if (body.initialDate && body.finalDate) {

            queryInteraction = {
                "interaction.visible": {
                    $ne: false
                },
                "interaction.status": 4,
                "interaction.registrationDate": {
                    $gt: new Date(body.initialDate),
                    $lt: new Date(body.finalDate)
                }
            }


        } else if (body.initialDate && body.userName) {

            queryInteraction = {
                visible: {
                    $ne: false
                },
                "interaction.status": 4,
                "interaction.userFirstName": body.userName,
                "interaction.registrationDate": {
                    $gte: new Date(body.initialDate)
                }
            }

        } else if (body.finalDate && body.userName) {

            queryInteraction = {
                "interaction.visible": {
                    $ne: false
                },
                "interaction.status": 4,
                "interaction.userFirstName": body.userName,
                "interaction.registrationDate": {
                    $lt: new Date(body.finalDate)
                }
            }


        } else if (body.initialDate) {

            queryInteraction = {
                "interaction.visible": {
                    $ne: false
                },
                "interaction.status": 4,
                "interaction.registrationDate": {
                    $gte: new Date(body.initialDate)
                }
            }


        } else if (body.finalDate) {

            queryInteraction = {
                "interaction.visible": {
                    $ne: false
                },
                "interaction.status": 4,
                registrationDate: {
                    $lt: new Date(body.finalDate)
                }
            }


        } else if (body.userName) {

            queryInteraction = {
                "interaction.visible": {
                    $ne: false
                },
                "interaction.status": 4,
                userFirstName: body.userName
            }

        } else {

            queryInteraction = {
                "interaction.visible": {
                    $ne: false
                },
                "interaction.status": 4
            }

        }

    } else if (body.validation == 2) {

        queryInteraction = {
            "interaction.visible": {
                $ne: false
            },
            "interaction.status": 4
        }

        if (body.initialDate && body.finalDate) {

            queryOpp = {
                registrationDate: {
                    $gt: new Date(body.initialDate),
                    $lt: new Date(body.finalDate)
                },
                visible: {
                    $ne: false
                },
                status: 1
            }

        } else if (body.initialDate) {

            queryOpp = {
                registrationDate: {
                    $gte: new Date(body.initialDate)
                },
                visible: {
                    $ne: false
                },
                status: 1
            }

        } else if (body.finalDate) {

            queryOpp = {
                registrationDate: {
                    $lte: new Date(body.finalDate)
                },
                visible: {
                    $ne: false
                },
                status: 1
            }

        } else {

            queryOpp = {
                visible: {
                    $ne: false
                },
                status: 1
            }

        }

    } else {

        if (body.userName) {

            queryInteraction = {
                "interaction.visible": {
                    $ne: false
                },
                "interaction.status": 4,
                "interaction.userFirstName": body.userName
            }

        } else {

            queryInteraction = {
                visible: {
                    $ne: false
                },
                "interaction.status": 4
            }

        }
        queryOpp = {
            visible: {
                $ne: false
            },
            status: 1
        }

    }
    var query = [{
        $match: queryOpp
    },
    {
        $lookup: {
            "from": "interactions",
            "localField": "_id",
            "foreignField": "opportunity",
            "as": "interaction"
        }
    },
    {
        $match: queryInteraction
    }
    ]

    if (body.sort) {
        if (!body.sort['query.slaApproval'])
            query.push({
                $sort: body.sort['query']
            })
    }
    Opportunity.aggregate(query).then(closedOpp => {
        closedOpp.forEach(opp => {
            opp.interaction = opp.interaction.filter(x => x.status == 4);
            opp.interaction.sort((a, b) => {
                return a.registrationDate - b.registrationDate;
            })
            if (opp.registrationDate) {
                var sla = opp.interaction[0].registrationDate - opp.registrationDate;
                var calcSla = sla / 86400000;
                opp.slaApproval = calcSla.toFixed(0);
            }
        })
        if (body.sort) {
            if (body.sort['query'].slaApproval) {
                closedOpp.sort((a, b) => {
                    if (body.sort['query'].slaApproval == 1) {
                        return a.slaApproval - b.slaApproval;
                    }
                    if (body.sort['query'].slaApproval == -1) {
                        return b.slaApproval - a.slaApproval;
                    }
                })
            }
        }

        function paginate(array, page_size, page_number) {
            --page_number; // because pages logically start with 1, but technically with 0
            return array.slice(page_number * page_size, (page_number + 1) * page_size);
        }
        var resl = paginate(closedOpp, 10, body.page);
        objRes.result = resl;
        objRes.count = closedOpp.length;
        objRes.export = closedOpportunitiesToXlsv(closedOpp)
        res.json(objRes);
    }).catch(err => {
        res.status(500).send({
            message: Utils.getErrorMessageFromModel(err)
        })
    })
}

exports.findSkillsOpportunity = (req, res) => {
    let objRes = {
        result: null,
        count: 0
    };

    let body = req.body;

    let id = body._id;
    let skills = body.specialities;
    let query = {};
    query = skills;


    if (skills != "") {
        Opportunity.find({
            "specialities": {
                $eq: skills
            },
            "status": 1,
            "_id": {
                $ne: (id)
            }
        }, function (err, opportunities) {
            if (err) {
                res.status(400).send({
                    message: Utils.getErrorMessageFromModel(err)
                });
            } else {
                objRes.result = opportunities;
                res.status(200).json(objRes);
            }
        });
    } else {
        console.log("Sem skills");
    }
}

exports.deleteCandidateOpportunity = async (req, res) => {
    var body = req.body;

    Opportunity.findOne({
        _id: body._id
    })
        .then(op => {
            var candidate = op.candidates.indexOf(body.candidateId);
            if (candidate > -1) {
                op.candidates.splice(candidate, 1);
            }
            op.save()
                .then(response => {
                    res.json(response);
                })
                .catch(err => {
                    return res.json(err);
                })
        })
        .catch(err => {
            return res.json(err);
        })
}

exports.getPriorityCount = async (req, res) => {
    Opportunity.aggregate([{
        $match: {
            company_id: req.company_id
        }
    }, {
        $group: {
            "_id": "$priority",
            "count": {
                $sum: 1
            }
        }
    }])
        .then(priorities => {
            res.json(priorities);
        })
        .catch(err => {
            return res.status(500).send({
                message: Utils.getErrorMessageFromModel(err)
            })
        })
}

exports.candidatesOpportunitiesCount = async (req, res) => {
    var objRes = {
        withCandidateCount: "",
        withoutCandidateCount: ""
    }

    objRes.withCandidateCount = await getOpportunitiesWithCandidates(req.company_id);
    objRes.withoutCandidateCount = await getOpportunitiesWithoutCandidates(req.company_id);

    res.json(objRes);
}


async function getOpportunitiesWithoutCandidates(company_id) {
    var count = await Opportunity.count({
        company_id: company_id,
        "candidates": {
            $size: 0
        }
    })
        .then(countOpp => {
            return countOpp
        })
        .catch(err => {
            return err;
        })
    return count;
}

async function getOpportunitiesWithCandidates(company_id) {
    var count = await Opportunity.count({
        company_id: company_id,
        "candidates.0": {
            $exists: true
        }
    })
        .then(countOpp => {
            return countOpp
        })
        .catch(err => {
            return err;
        })
    return count;
}


exports.updateInvolvedPeople = (req, res) => {

    var opportunity = req.opportunity;

    var body = req.body;

    opportunity.involvedPeople = body;

    opportunity.save((err) => {
        if (err) {
            return res.status(400).send({
                message: Utils.getErrorMessageFromModel(err)
            });
        } else {
            res.json(opportunity)
        }
    });

}

exports.exportOpportunitiesToXlsx = (req, res) => {
    let objRes = {
        result: null,
        count: 0
    };
    var query = {};
    let body = req.body;
    query.location = new RegExp(body.location, "i");

    query.customerName = new RegExp(body.customerName, "i");
    if (body.businessUnit !== undefined && body.businessUnit != -1)
        query.businessUnit = body.businessUnit;

    if (body.responsible !== undefined && body.responsible !== "")
        query.responsible = new RegExp(body.responsible, 'i');

    if (body.value !== undefined && body.value !== "")
        query.value = new RegExp(body.value, 'i');

    if (body.name !== undefined && body.name !== "")
        query.name = new RegExp(body.name, 'i');

    if (body.customerName !== undefined && body.customerName !== "")
        query.customerName = new RegExp(body.customerName, 'i');

    if (body.opportunityLocation) {
        if (body.opportunityLocation.state !== undefined && body.opportunityLocation.state !== "") {
            query['opportunityLocation.state'] = new RegExp(body.opportunityLocation.state, "i");
        }
    }

    if (body.profile !== undefined && body.profile >= 0)
        query.profile = body.profile;

    if (body.status !== undefined && body.status >= 0)
        query.status = body.status;

    if (body.number !== undefined)
        query.number = body.number;

    if (body.priority !== undefined && body.priority != -1)
        query.priority = body.priority;

    if (body.initialDate && body.registrationDate) {
        query.registrationDate = {
            $gte: body.initialDate,
            $lt: body.registrationDate
        };
    } else if (body.initialDate) {
        query.registrationDate = {
            $gte: body.initialDate
        };
    } else if (body.registrationDate) {
        query.registrationDate = {
            $lt: body.registrationDate
        };
    }

    if (body.specialities !== undefined && body.specialities.length > 0) {
        query.specialities = {
            '$in': body.specialities.map(function (v) {
                return v.toUpperCase();
            })
        }

    }

    if (body.involvedPeople !== undefined && body.involvedPeople.length > 0) {
        query["involvedPeople.name"] = {
            '$in': body.involvedPeople.map(function (v) {
                return v;
            })
        }

    }

    query.company_id = req.company_id;

    Opportunity.aggregate([{
        $match: query
    },
    {
        $lookup: {
            from: "statusofopportunities",
            localField: "status",
            foreignField: "number",
            as: "statusJoin"
        },

    },
    {
        $project: {
            "Id": "$number",
            "Nome": "$name",
            "Cliente": "$customerName",
            "Status": "$statusJoin.name",
            "Candidatos": "$candidates",
            "location": "$opportunityLocation.discription",
            "finalQtd": "$qtdOpportunities",
            "initialQtd": "$initialQtd",
            "Prioridade": "$priority",
            "registrationDate": "$registrationDate",
            "lastAlterationDate": "$lastAlterationDate"
        }
    }
    ]).then(opportunities => {
        if (opportunities.length > 0) {
            let returnOpportunities = validate(opportunities);
            res.json(returnOpportunities);
        } else {
            res.json(opportunities);
        }
    })
        .catch(err => {
            return res.status(500).send({
                "message": "Erro ao exportar"
            })
        })
}


function validate(opportunities) {
    let exportItensArr = [];
    let headerArr = [];
    let keys = {
        "Id": "",
        "Nome": "",
        "Cliente": "",
        "Candidatos": "",
        "Status": "",
        "Qtd. Vagas": "",
        "Prioridade": "",
        "Data de Cadastro": "",
        "Ultima Alteração": ""
    }
    let arrObjKeys = Object.keys(keys);
    exportItensArr.push(arrObjKeys);


    for (var i = 0; i < opportunities.length; i++) {
        let bodyArr = []
        for (let key of Object.keys(keys)) {
            if (key != "_id") {
                switch (key) {
                    case "Status":
                        bodyArr.push(opportunities[i].Status)
                        break;
                    case "Id":
                        bodyArr.push(opportunities[i].Id)
                        break;
                    case "Nome":
                        bodyArr.push(opportunities[i].Nome)
                        break;
                    case "Cliente":
                        if (opportunities[i].location) {
                            bodyArr.push(opportunities[i].Cliente + " " + opportunities[i].location)
                        } else {
                            bodyArr.push(opportunities[i].Cliente)
                        }
                        break;
                    case "Candidatos":
                        bodyArr.push(opportunities[i].Candidatos.length)
                        break;
                    case "Prioridade":
                        bodyArr.push(getDiscriptionPriority(opportunities[i].Prioridade))
                        break;
                    case "Qtd. Vagas":
                        bodyArr.push(opportunities[i].finalQtd + "/" + opportunities[i].initialQtd)
                        break;
                    case "Data de Cadastro":
                        bodyArr.push(formatDate(opportunities[i].registrationDate));
                        break;
                    case "Ultima Alteração":
                        bodyArr.push(formatDate(opportunities[i].lastAlterationDate));
                        break
                }
            }
        }
        exportItensArr.push(bodyArr);
    }
    return exportItensArr;
}

function getDiscriptionPriority(key) {
    let priority = "";
    switch (key) {
        case 0:
            priority = "Baixa";
            break;
        case 1:
            priority = "Média";
            break;
        case 2:
            priority = "Alta";
            break;

        default:
            priority = "Baixa";
            break;
    }
    return priority;
}

exports.slaOpp = async (req, res) => {
    Opportunity.aggregate([{
        $match: {
            status: 1,
            company_id: req.company_id
        }
    },
    {
        $lookup: {
            from: "interactions",
            localField: "_id",
            foreignField: "opportunity",
            as: "interaction"
        }
    },
    {
        $match: {
            "interaction.status": {
                $eq: 4
            }
        }
    }, {
        $sort: {
            "interaction.registrationDate": -1
        }
    }
    ]).
        then(result => {
            let objReturn = {
                registrationDate: undefined,
                closedDate: undefined,
                sla: undefined
            }
            let dateArr = [];
            result.forEach(r => {
                if (r.interaction.length > 0) {
                    r.interaction.sort(function (a, b) {
                        return a.registrationDate - b.registrationDate;
                    })
                    let InitialDate = r.registrationDate;
                    let closeDate = getinteractionDate(r.interaction);
                    r.closedDate = closeDate.registrationDate;
                    if (r.registrationDate) {
                        objReturn.registrationDate = r.registrationDate.getTime();
                        objReturn.closedDate = r.closedDate.getTime();
                        objReturn.sla = objReturn.closedDate - objReturn.registrationDate;
                        dateArr.push(objReturn.sla)
                    }
                }
            })
            let sla = 0;
            dateArr.forEach(date => {
                sla = sla + date;
            })
            if (sla > 0 && dateArr.length > 0) {
                let timeCalc = sla / dateArr.length;
                let daysCalcReturn = timeCalc / 86400000
                res.json(daysCalcReturn.toFixed(0));
            } else {
                res.json(0)
            }
        })
        .catch(err => {
            return res.status(500).send({
                message: Utils.getErrorMessageFromModel(err)
            })
        })
}

function getinteractionDate(interactions) {
    let interactionsReturn = []
    interactions.forEach(r => {
        if (r.status == 4) {
            interactionsReturn.push(r)
        }
    })
    return interactionsReturn[0];
}


function formatDate(date) {
    if (date) {
        var day = date.getDate();
        var monthIndex = date.getMonth() + 1;
        var year = date.getFullYear();

        return day + '/' + monthIndex + '/' + year;
    } else {
        return "";
    }
}

function closedOpportunitiesToXlsv(opportunities) {
    let exportItensArr = [];
    let headerArr = [];
    let keys = {
        "Cliente": "",
        "Vaga": "",
        "Abertura": "",
        "Aprovação": "",
        "SLA": ""
    }

    let arrObjKeys = Object.keys(keys);
    exportItensArr.push(arrObjKeys);

    for (var i = 0; i < opportunities.length; i++) {
        let bodyArr = []
        for (let key of Object.keys(keys)) {
            if (key != "_id") {
                switch (key) {
                    case "Vaga":
                        bodyArr.push(opportunities[i].name)
                        break;
                    case "Cliente":
                        if (opportunities[i].customerName) {
                            bodyArr.push(opportunities[i].customerName);
                        } else {
                            bodyArr.push(" ");
                        }
                        break;
                    case "Abertura":
                        if (opportunities[i].registrationDate) {
                            bodyArr.push(formatDate(opportunities[i].registrationDate));
                        } else {
                            bodyArr.push("Não possuímos a data de cadastro da vaga");
                        }
                        break;
                    case "Aprovação":
                        bodyArr.push(formatDate(opportunities[i].interaction[0].registrationDate));
                        break
                    case "SLA":
                        if (opportunities[i].registrationDate) {
                            bodyArr.push(opportunities[i].slaApproval + " Dias");
                        } else {
                            bodyArr.push("Não possuímos este dado");
                        }
                        break
                }
            }
        }
        exportItensArr.push(bodyArr);
    }
    return exportItensArr;
}

exports.searchByStatus = (req, res) => {

    var query = {};

    if (req.body._id != undefined) {
        query._id = req.body._id;
    }

    query.company_id = req.params.companyId;

    query.status = req.body.status;


    console.log(query);

    Opportunity.find(query, (err, opp) => {
        if (err) {
            return (res.err);
        }
        if (!opp) {
            return res.status(400).send({
                message: 'Failed to load opportunity'
            });
        }
        return res.status(200).send(opp);
    }).sort({
        number: 1
    })
};

exports.findOppForProfile = (req, res) => {
    console.log(req.params.opportunityId)
    const id = req.params.opportunityId;

    Opportunity.aggregate([
        {
            $match: {
                _id: {
                   $eq: ObjectId(id)
                }
            }

        },
        {
            $lookup:
            {
                from: "users",
                localField: "emailResponsible",
                foreignField: "email",
                as: "user",
            },
        },        
        { $unwind: "$user" }

    ]).then(result => {
        console.log(result)
        return res.status(200).send(result);
    })
};
