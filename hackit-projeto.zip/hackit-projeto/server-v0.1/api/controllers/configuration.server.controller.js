var mongoose = require('mongoose'),
    Configuration = require('../../domain/models/configuration').Configuration;


exports.update = async (req, res) => {
    let company_id = req.company_id;

    try {
        let configuration = await Configuration.findOne({
            company_id: company_id
        }).then(r => {
            return r;
        })
        await Configuration.findByIdAndUpdate(configuration._id, {
            $set: {
                interactionEmail: req.body.interactionEmail,
                reprovalEmail: req.body.reprovalEmail,
                statusRobot: req.body.statusRobot
            }
        })
        res.status(200).send({
            message: 'Configuração alterada com sucesso!'
        });
    } catch (e) {
        res.status(500).send({
            message: 'Falha ao processar aquisição'
        });
    }
}

exports.get = async (req, res) => {
    let company_id = req.company_id;
    var data = await Configuration.findOne({
        company_id: company_id
    });

    return res.status(200).json(data);  


}

exports.create = async (req, res) => {
    try {

        let newConfiguration = {
            company_id: req.company_id,
            interactionEmail: req.body.interactionEmail,
            reprovalEmail: req.body.reprovalEmail,
            statusRobot: req.body.statusRobot
        };

        var configuration = await createConfig(newConfiguration);

        res.status(200).json(configuration);

    } catch (err) {
        res.status(500).send(err);
    }
}

var createConfig = async (config) => {

    let obj = new Configuration(config);
    return await obj.save();
}

exports.configurationId = (req, res, next, id) => {
    req.company_id = id;
    next();
}