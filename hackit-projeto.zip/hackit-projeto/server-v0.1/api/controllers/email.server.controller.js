'use strict';

const nodemailer = require('../../node_modules/nodemailer/lib/nodemailer');
var schedule = require('node-schedule');

let transporter = nodemailer.createTransport({
    service: "SendinBlue",
    auth: {
        user: 'rafael.ferreira@fcamara.com.br',
        pass: '1BSGdvE2LTQrgkyU'
    },
    logger: false,
    debug: false
});

exports.send = (req, res) => {
    let message = {
        from: 'FCamara <hap-in@fcamara.com.br>',
        to: req.body.to,
        subject: req.body.subject,
        text: req.body.text
    };

    transporter.sendMail(message, (error, info) => {
        if (error) {
            res.sendStatus(500);
            console.log('Erro no envio');
            console.log(error.message);
            return process.exit(1);
        }
        res.sendStatus(200);
        console.log('Email enviado com sucesso');
        console.log(nodemailer.getTestMessageUrl(info));
    });
};


exports.sendRecoveryEmail = (req, res, email, callback) => {
    let message = {
        from: 'FCamara <hap-in@fcamara.com.br>',
        to: email.to,
        subject: email.subject,
        text: email.text
    };

    transporter.sendMail(message, (error, info) => {
        if (error) {
            res.sendStatus(500);
            console.log('Erro no envio');
            console.log(error.message);
            return process.exit(1);
        }
        res.status(200).send({
            "message": "Um email foi encaminhado para você com as intruções de recuperação de senha"
        });
    });
};

exports.sendReprovedEmail = (req, res) => {
    var hour = new Date().getTime();
    var date = new Date(hour);
    // let dateCalc = date.getTime() + 172800000; after 2 days
    let dateCalc = date.getTime() + 300000; // 5 minutes
    date = new Date(dateCalc);
    console.log(date.getFullYear(), date.getMonth(), date.getDate(), date.getHours(), date.getMinutes(), date.getSeconds())
    var j = schedule.scheduleJob(date, function () {

        let message = {
            from: 'FCamara <hap-in@fcamara.com.br>',
            to: req.body.to,
            subject: req.body.subject,
            text: req.body.text
        };

        transporter.sendMail(message, (error, info) => {
            if (error) {
                res.sendStatus(500);
                console.log('Erro no envio');
                console.log(error.message);
                return process.exit(1);
            }

            console.log(nodemailer.getTestMessageUrl(info));
        });

    });

    res.sendStatus(200);
}