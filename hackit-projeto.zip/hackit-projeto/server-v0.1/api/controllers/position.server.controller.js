'use strict'
var mongoose = require('mongoose'),
    Utils = require('../../domain/utils/util'),
    Position = require('../../domain/models/position').Position;


exports.getAllPosition = async (req, res) => {


    Position.find({}, (err, ret) => {
        if (err) {
            return err;
        }
        if (!ret) {

            return res.status(400).send({
                message: 'falha ao pesquisar'
            })
        }
        return res.status(200).json(ret);
    })
}

exports.createPosition = async (req, res) => {
    let body = req.body;

    let position = new Position(body);

    position.save()
        .then((dptsave) => {
            res.json(dptsave);
        })
        .catch(err => {
            console.log(err);
            res.status(400).send({
                message: err
            })
        });
}