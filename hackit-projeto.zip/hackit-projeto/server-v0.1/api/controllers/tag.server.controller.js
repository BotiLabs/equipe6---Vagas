'use strict';

var mongoose = require('mongoose'),
    Utils = require('../../domain/utils/util'),
    Tag = require('../../domain/models/tag').Tag;

//Find a company_id to next method
exports.prepareCompanyId = (req, res, next, id) => {
    req.company_id = id;
    next()
};

//Insert a new tag
exports.create = (req, res) => {

    var body = req.body;
    var name = body.name.toUpperCase();
    body.name = name;
    var tag = new Tag(body);
    tag.nameWithCompany = tag.name + tag.company_id;
    //Validate tags if exists
    Tag.findOne({
            name: name,
            visible: {
                $ne: false
            },
            company_id: body.company_id
        })
        .exec()
        .then((result => {
            if (result && result.visible == true) {
                res.status(400).send({
                    message: "Esta Tag já foi cadastrada",
                    result: result
                });
            } else {
                tag.save((err) => {
                    if (err) {
                        return res.status(400).send({
                            message: Utils.getErrorMessageFromModel(err),
                            erro: err
                        });
                    } else {
                        res.json(tag);
                    }
                });
            }
        })).catch((err => {
            return res.status(500).send({
                message: Utils.getErrorMessageFromModel(err)
            });
        }))
};

//List existing tags
exports.list = (req, res) => {
    Tag.find({
            visible: {
                $ne: false
            },
            company_id: req.company_id
        })
        //populate('opportunities')
        .sort('-created_at').exec((err, tags) => {
            if (err) {
                res.status(400).send({
                    message: Utils.getErrorMessageFromModel(err)
                });
            } else {
                res.json(tags);
            }
        });
};

//List a tag
exports.read = (req, res) => {
    res.json(req.tag);
};

//Find a tag to next method
exports.tagById = (req, res, next, id) => {
    Tag.findById(id, (err, tag) => {
        if (err) {
            return next(err);
        }
        if (!tag) {
            return res.status(400).send({
                message: 'Failed to load tag ' + id
            });
        }

        req.tag = tag;
        next();
    })
};

//Update a tag
exports.update = (req, res) => {
    var tag = req.tag;

    for (var prop in req.body) {
        tag[prop] = req.body[prop];
    }
    tag.name = tag.name.toUpperCase();
    tag.nameWithCompany = tag.name + tag.company_id;
    console.log(tag)
    tag.save((err) => {
        if (err) {
            return res.status(400).send({
                message: Utils.getErrorMessageFromModel(err)
            });
        } else {
            res.json(tag)
        }
    });
};


exports.updateToDelete = (req, res) => {
    var tag = req.tag;
    var name = req.body.name.toUpperCase();
    for (var prop in req.body) {
        tag[prop] = req.body[prop];
    }
    tag.name = name;
    tag.nameWithCompany = tag.name + tag.company_id;
    Tag.findOne({
            name: name,
            visible: {
                $ne: false
            },
            company_id: tag.company_id
        })
        .exec()
        .then((result => {
            if (result && result.visible == true) {
                res.status(400).send({
                    message: "Esta Tag já foi cadastrada",
                    result: result
                });
            } else {
                tag.save((err) => {
                    if (err) {
                        return res.status(400).send({
                            message: Utils.getErrorMessageFromModel(err)
                        });
                    } else {
                        res.json(tag)
                    }
                });

            }
        })).catch((err => {
            return res.status(500).send({
                message: Utils.getErrorMessageFromModel(err)
            });
        }))
};
//Delete a tag
exports.delete = (req, res) => {
    var tag = req.tag;

    tag.remove((err) => {
        if (err) {
            return res.status(400).send({
                message: Utils.getErrorMessageFromModel(err)
            });
        } else {
            res.send({

                message: ('Tag removida com sucesso.')
            })
        }
    });
};

// Search a tag
exports.search = (req, res) => {
    let objRes = {
        result: null,
        count: 0
    };

    var query = {};
    var body = req.body;
    query.company_id = body.company_id;

    query.name = new RegExp(body.name, "i");
    query.visible = {
        $ne: false
    }
    Tag.count(query, function (err, count) {
        if (err) {
            res.status(404).send({
                message: Utils.getErrorMessageFromModel(err)
            });
        } else {
            objRes.count = count;
            Tag.find(query, function (err, result) {
                if (err) {
                    res.status(404).send({
                        message: Utils.getErrorMessageFromModel(err)
                    });
                } else {
                    objRes.result = result;
                    res.json(objRes);
                }
            }).skip(body.limit * (body.page - 1)).limit(body.limit);
        }
    });
};

// Search a tag without reg exp
exports.searchIfExists = (req, res) => {
    let objRes = {
        result: null,
        count: 0
    };

    var query = {};
    var body = req.body;
    var name = body.name.toUpperCase();
    query.name = name;

    query.company_id = body.company_id;
    query.visible = {
        $ne: false
    }
    Tag.count(query, function (err, count) {
        if (err) {
            res.status(404).send({
                message: Utils.getErrorMessageFromModel(err)
            });
        } else {
            objRes.count = count;
            Tag.findOne(query, function (err, result) {
                if (err) {
                    res.status(404).send({
                        message: Utils.getErrorMessageFromModel(err)
                    });
                } else {
                    if (result) {
                        res.json("Esta tag já existe");
                    } else {
                        res.json("Não encontramos esta tag. Deseja criar uma nova?");
                    }

                }
            }).skip(body.limit * (body.page - 1)).limit(body.limit);
        }
    });
};