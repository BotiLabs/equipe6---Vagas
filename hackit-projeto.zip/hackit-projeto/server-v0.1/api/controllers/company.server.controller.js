'use strict';

var mongoose = require('mongoose'),
  Utils = require('../../domain/utils/util'),
  Company = require('../../domain/models/company').Company

//Insert a new company
exports.create = (req, res) => {
  var company = new Company(req.body);

  company.save((err) => {
    if (err) {
      return res.status(400).send({
        message: Utils.getErrorMessageFromModel(err)
      });
    } else {
      res.json(company);
    }
  });
};

exports.search = (req, res) => {
  let objRes = {
    result: null,
    count: 0
  };
  var query = {};
  var body = req.body;

  if (body.name !== undefined && body.name != "")
    query.name = body.name;

  Company.count(query, function (err, count) {
    if (err) {
      res.status(404).send({
        message: Utils.getErrorMessageFromModel(err)
      });
    } else {
      objRes.count = count;
      Company.find(query, function (err, result) {
        if (err) {
          res.status(404).send({
            message: Utils.getErrorMessageFromModel(err)
          });
        } else {
          objRes.result = result;
          res.json(objRes);
        }
      }).skip(body.limit * (body.page - 1)).limit(body.limit);
    }
  });
};

//delete a company
exports.delete = (req, res, next) => {

  Company.findOne({
    _id: req.params.companyId
  }).remove().exec(company => {
    res.send({
      message: 'Company removida com sucesso.'
    });
  }).catch(err => {
    res.status(500).send({
      message: Utils.getErrorMessageFromModel(err)
    });
  })
};

//List existing logs
exports.list = (req, res) => {
  Company.find({
      visible: {
        $ne: false
      }
    })
    .populate('logs')
    .sort('-created_at').exec((err, Company) => {
      if (err) {
        res.status(400).send({
          message: Utils.getErrorMessageFromModel(err)
        });
      } else {
        res.json(Company);
      }
    });
};

exports.getCompanyById = (req, res) => {
  res.json(req.company);
};

//Find a company to next method
exports.companyById = (req, res, next, id) => {
  Company
    .findById(id, (err, company) => {
      if (err) {
        return next(err);
      }
      if (!company) {
        return res.status(400).send({
          message: 'Failed to load company ' + id
        });
      }
      req.company = company;
      next();
    })
};

//Update a company
exports.update = (req, res) => {
  // console.log(req)
  // console.log(req.candidate, req.body);
  var company = req.company;

  for (var prop in req.body) {
    company[prop] = req.body[prop];
  }

  company.save((err) => {
    if (err) {
      return res.status(400).send({
        message: Utils.getErrorMessageFromModel(err)
      });
    } else {
      res.json(company)
    }
  });
};