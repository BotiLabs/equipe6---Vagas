'use strict';

var mongoose = require('mongoose'),
    Questions = require('../../domain/models/testingtype').Testingtype,
    Utils = require('../../domain/utils/util');

//Find a company_id to next method
exports.prepareCompanyId = (req, res, next, id) => {
    req.company_id = id;
    next()
};

exports.create = (req, res) => {
    var questions = new Questions(req.body);

    questions.save((err) => {
        if (err) {
            return res.status(400).send({
                message: Utils.getErrorMessageFromModel(err)
            });
        } else {
            res.json(questions);
        }
    });
}

exports.list = (req, res) => {
    Questions.find({
            company_id: req.company_id
        })
        .sort('date').exec((err, questions) => {
            if (err) {
                return res.status(400).send({
                    message: Utils.getErrorMessageFromModel(err)
                });
            } else {
                res.json(questions);
            }
        });
}

exports.questions = (req, res) => {
    var questions = req.questions;

    for (var item in req.body) {
        questions[item] = req.body[item];
    }

    questions.save((err) => {
        if (err) {
            return res.status(400).send({
                message: Utils.getErrorMessageFromModel(err)
            });
        } else {
            res.json(questions)
        }
    });
}

    
exports.questionsById = (req, res, next, id) => {

    Questions.findById(id, (err, questionsId) => {
        if (err) {
            return next(err);
        }
        if (!questionsId) {
           return res.status(400).send({
           message: 'Failed to load question ' + id
           });
        }
          req.questions = questionsId;
          next();
       });
  };


exports.read = (req, res) => {
    res.json(req.questions);
    // console.log('Função Read');
};

exports.delete = (req, res) => {
    var questions = req.questions;
    questions.remove((err) => {
        if (err) {
            return res.status(400).send({
                message: Utils.getErrorMessageFromModel(err)
            });
        } else {
            res.json(questions);
        }
    });
}

exports.questionsById = (req, res, next, id) => {

    Questions.findById(id, (err, questionsId) => {
        if (err) {
            return next(err);
        }
        if (!questionsId) {
            return res.status(400).send({
                message: 'Failed to load question ' + id
            });
        }
        req.questions = questionsId;
        next();
    });
    //console.log("funcionou");
};

exports.update = (req, res) => {
    var questions = req.questions;

    for (var item in req.body) {
        questions[item] = req.body[item];
    }

    questions.save((err) => {
        if (err) {
            return res.status(400).send({
                message: Utils.getErrorMessageFromModel(err)
            });
        } else {
            res.json(questions)
        }
    })
}

exports.search = (req, res) => {
    let objRes = {
        result: null,
        count: 0
    };

    var query = {};
    var body = req.body;
    query.company_id = body.company_id;

    query.name = new RegExp(body.name, "i");

    Questions.count(query, function (err, count) {
        if (err) {
            res.status(404).send({
                message: Utils.getErrorMessageFromModel(err)
            });
        } else {
            objRes.count = count;
            Questions.find(query, function (err, result) {
                if (err) {
                    res.status(404).send({
                        message: Utils.getErrorMessageFromModel(err)
                    });
                } else {
                    objRes.result = result;
                    res.json(objRes);
                }
            }).sort({
                "date": -1
            }).skip(body.limit * (body.page - 1)).limit(10);
        }
    });
};