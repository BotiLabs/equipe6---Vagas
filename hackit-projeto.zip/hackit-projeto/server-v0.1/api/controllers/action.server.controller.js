'use strict'

var mongoose = require('mongoose'),
    Utils = require('../../domain/utils/util'),
    Action = require('../../domain/models/action').Action;

exports.getAll = (req, res) => {
    //Por enquanto as ações serão as mesmas para todas as empresas.
    Action.find({
            // company_id: req.params.companyId
        })
        .then(actions => {
            res.json(actions);
        })
        .catch(err => {
            return res.status(500).json({
                "message": Utils.getErrorMessageFromModel(err)
            })
        })
}

exports.create = (req, res) => {
    let action = new Action(req.body);

    action.save()
        .then(savedAction => {
            res.json(savedAction)
        })
        .catch(err => {
            return res.status(500).send({
                "message": Utils.getErrorMessageFromModel(err)
            })
        })
}