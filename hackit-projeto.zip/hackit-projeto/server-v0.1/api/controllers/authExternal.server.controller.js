'use strict';

var mongoose = require('mongoose'),
    config = require('../../config/config'),
    Utils = require('../../domain/utils/util'),
    UserExternal = require('../../domain/models/userexternal').UserExternal,
    Evaluation = require('../../domain/models/evaluation').Evaluation,
    Company = require('../../domain/models/company').Company,
    Email = require('../../domain/models/email').Email,
    passport = require('passport'),
    jwt = require('jsonwebtoken'),
    uploadUserImage = require("./uploadUserImage"),
    emailRecovery = require("./email.server.controller"),
    generator = require('generate-password');


exports.session = async function (req, res) {
    res.json(req.user);
};


exports.signup = async (req, res) => {
    var user = new UserExternal(req.body);
    user.provider = 'jwt';
    user.emailWithCompany = user.email + user.company_id;
    user.password = generator.generate({
        length: 8,
        numbers: true
    });

    let company = {};
    try {
        company = await Company.findById(user.company_id)
    } catch (e) {
        return res.status(500).send({
            message: "Erro de identificação, fale com sua recrutadora."
        })
    }
    user.userName = user.email.substring(0, user.email.indexOf('@')) + "_" + company.tag;

    user.password = user.password + '@' + company.tag;
    req.body.to = user.email;
    req.body.subject = "Avaliação hapin";
    let link = "https://recrutamento-avaliacoes.fcamara.com.br/#/login"

    switch (process.env.NODE_ENV) {
        case 'development':
            link = "http://localhost:4201/#/login"
            break;
        case 'homolog':
            link = "http://54.163.157.220:4201/#/login"
            break;
        case 'production':
            link = "https://recrutamento-avaliacoes.fcamara.com.br/#/login"
            break;
        default:
            link = "https://recrutamento-avaliacoes.fcamara.com.br/#/login"
            break;
    }
    req.body.text = `Você foi selecionado para realizar uma avaliação, <br> seu usuario para se logar é ${user.userName} <br> e sua senha para se logar é: ${user.password}, <br> <a href='${link}'>Link</a>`

    let userReturn = await user.save()
        .then(user => {
            emailRecovery.send(req, res);
            return user;
        })
        .catch(err => {
            if (err) {
                if (err.errors.email) {
                    return {
                        message: "Este email já existe"
                    }
                }
                return {
                    message: Utils.getErrorMessageFromModel(err)
                }
            }
        });

    return userReturn;
};


exports.token = async (req, res) => {

    let tag = req.body.password.substring(req.body.password.indexOf('@') + 1, req.body.password.length)
    let company = undefined;

    try {
        company = await Company.findOne({
            tag: tag
        })
    } catch (e) {
        return res.status(400).send({
            message: "Código inválido."
        })
    }


    if (!company) {
        return res.status(400).send({
            message: "Código inválido."
        })
    }

    UserExternal.findOne({
        userName: req.body.userName,
        company_id: company._id
    }).then(user => {
        if (!user) {
            res.status(404).send({
                message: 'Usuário não encontrado'
            });
        } else {
            var isMatch = user.authenticate(req.body.password)
            if (isMatch) {
                var token = jwt.sign(user, config.secret, {
                    expiresIn: 60 * 20 // in seconds
                });

                Evaluation.findOne({
                    email: user.email,
                    company_id: company._id
                }).then(candidate => {

                    if (!candidate) {
                        res.status(404).send({
                            message: "Usuário não encontrado"
                        });
                    } else {
                        res.status(200).json({
                            userInfo: {
                                name: user.fullName,
                                email: user.email,
                                idCandidate: candidate._id,
                                company_id: user.company_id
                            },
                            success: true,
                            token: 'JWT ' + token
                        });
                    }

                }).catch(err => {

                    res.status(400).send({
                        message: Utils.getErrorMessageFromModel(err)
                    })
                })

            } else {
                res.status(401).send({
                    message: 'Senha incorreta'
                });
            }
        }
    }).catch(err => {
        if (err) {
            res.status(400).send({
                message: Utils.getErrorMessageFromModel(err)
            });
        }
    });


};


exports.findUser = async (req, res) => {

    let user = await UserExternal.findOne({
            email: req.body.email,
            company_id: req.body.company_id
        })
        .then(user => {
            return user
        })
        .catch(err => {
            return {
                message: Utils.getErrorMessageFromModel(err)
            }
        })

    return user;
}

exports.updateUserExternalPassword = (req, res) => {
    UserExternal.findOne({
        "userName": req.body.userName
    }).then(async user => {
        if (!user) {
            res.status(400).send({
                message: "Usuario não encontrado :("
            })
        }
        user.password = generator.generate({
            length: 8,
            numbers: true
        });

        let company = await Company.findById(user.companyId)
            .then(company => {
                return company;
            })
            .catch(err => {
                return res.status(500).send({
                    message: Utils.getErrorMessageFromModel(err)
                })
            })

        user.password = user.password + '@' + company.tag;

        req.body.to = user.email;
        req.body.subject = "Avaliação hapin - Recuperação de senha";
        req.body.text = `Olá ${user.fullName}, sua nova senha para se logar é: ${user.password}`

        user.save()
            .then(async user => {
                req.user = user;
                await emailRecovery.send(req, res);
                res.json(user)
            })
            .catch(err => {
                res.status(500).send({
                    message: Utils.getErrorMessageFromModel(err)
                })
            })
    }).catch(err => {
        res.status(500).send({
            message: Utils.getErrorMessageFromModel(err)
        })
    })
}