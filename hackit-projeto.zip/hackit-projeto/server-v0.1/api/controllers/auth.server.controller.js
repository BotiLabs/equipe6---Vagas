'use strict';

var mongoose = require('mongoose'),
    config = require('../../config/config'),
    Utils = require('../../domain/utils/util'),
    User = require('../../domain/models/user').User,
    Evaluation = require('../../domain/models/evaluation').Evaluation,
    Email = require('../../domain/models/email').Email,
    passport = require('passport'),
    jwt = require('jsonwebtoken'),
    uploadUserImage = require("./uploadUserImage"),
    emailRecovery = require("./email.server.controller"),
    Company = require('../../domain/models/company').Company;

exports.session = function (req, res) {
    res.json(req.user);
};

exports.signup = (req, res) => {
    var user = new User(req.body);
    user.provider = 'jwt';
    let tenant = req.body.email.substring(req.body.email.indexOf("@") + 1, req.body.email.length);
    Company.findOne({
        tenant: tenant
    }).then(r => {
        if (r) {
            user.company_id = r._id;
            user.emailWithCompany = user.email.toLowerCase() + r._id;
            user.usernameWithCompany = user.username.toLowerCase() + r._id;
            user.save()
                .then(savedUser => {
                    res.json(savedUser.user_info);
                })
                .catch(err => {
                    if (err) {
                        if (err.errors.emailWithCompany) {
                            return res.status(400).send({
                                message: "Este email já existe"
                            });
                        }
                        if (err.errors.usernameWithCompany) {
                            return res.status(400).send({
                                message: "Este usuario já existe"
                            });
                        }
                        return res.status(400).send({
                            message: Utils.getErrorMessageFromModel(err)
                        });
                    }
                });
        } else {
            return res.status(400).send({
                message: "Não existe uma empresa com este domínio"
            });
        }
    })
        .catch(err => {
            return res.status(500).send({
                message: Utils.getErrorMessageFromModel(err)
            })
        })
};

exports.emailAuthorization = async (req, res) => {
    User.find({
        email: req.body.email
    }).then(async user => {
        if (user[0].loginCount) {
            user[0].loginCount++
        } else {
            user[0].loginCount = 1;
        }

        if (user != '') {
            if (user[0].approved == false) {
                return res.status(200).send({
                    message: 'Sua solicitação foi enviada, em breve você será liberado'
                });
            }
        }
        if (user == '') {
            return res.status(200).send({
                message: 'Não autorizado'
            });
        } else {
            res.status(200).send({
                message: 'Authorized',
                company_id: user[0].company_id,
                user: user
            });
        }
    }).catch(err => {
        if (err) {
            res.status(400).send({
                message: Utils.getErrorMessageFromModel(err)
            });
        }
    });
};

//Adicionar Company_id
async function updateUserLoginCount(user) {
    //Atualizando contagem de login
    let hour = new Date().getTime()
    let date = new Date(hour);

    let updateLoginCount = await User.updateOne({
        _id: user._id,
        company_id: user.company_id
    }, {
            $set: {
                loginCount: user.loginCount,
                lastLoginDate: date
            }
        }).then(savedUser => {
            return savedUser
        }).catch(err => {
            return err;
        })
    return updateLoginCount;
}

exports.token = async (req, res) => {

    let tenant = req.body.email.substring(req.body.email.indexOf("@") + 1, req.body.email.length);
    let company = await Company.findOne({
        tenant: tenant
    }).then(company => {
        return company;
    }).catch(err => {
        return res.status(500).send({
            message: Utils.getErrorMessageFromModel(err)
        })
    })

    if (!company) {
        return res.status(400).send({
            message: "Usuário não encontrado."
        })
    }
    User.findOne({
        email: req.body.email,
        company_id: company._id.toString()
    }).then(async user => {

        if (!user) {
            res.status(404).send({
                message: 'Usuário não encontrado'
            });
        } else {

            if (user.approved == false) {
                return res.status(400).send({
                    message: 'Sua solicitação foi enviada, em breve você será liberado'
                });
            }
            var isMatch = user.authenticate(req.body.password)
            if (isMatch) {
                var token = jwt.sign(user, config.secret, {
                    expiresIn: 180 * 180 // in seconds
                });

                if (user.loginCount) {
                    user.loginCount++;
                } else {
                    user.loginCount = 0;
                }

                let updateUser = await updateUserLoginCount(user);
                res.status(200).json({
                    userInfo: {
                        _id: user._id,
                        username: user.username,
                        firstname: user.firstName,
                        lastname: user.lastName,
                        email: user.email,
                        profileImage: user.profileImage,
                        company_id: user.company_id
                    },
                    success: true,
                    token: 'JWT ' + token
                });
            } else {
                res.status(401).send({
                    message: 'Senha incorreta'
                });
            }

        }
    }).catch(err => {
        if (err) {
            res.status(400).send({
                message: Utils.getErrorMessageFromModel(error)
            });
        }
    });
};

exports.tokenExternal = (req, res) => {
    Evaluation.findOne({
        email: req.body.email
    }).then(user => {
        if (!user) {
            res.status(404).send({
                message: "Candidato não encontrado"
            });
        } else {
            var token = jwt.sign(user, config.secret, {
                expiresIn: 60 * 60 // in seconds 'Antigo --> expiresIn: 60 * 20'
            });
            res.status(200).json({
                userInfo: {
                    name: user.username,
                    email: user.email,
                    idCandidate: user.idCandidate
                },
                success: true,
                token: 'JWT ' + token
            });
        }
    }).catch(err => {

        res.status(400).send({
            message: Utils.getErrorMessageFromModel(err)
        })


    })
};

exports.findUserByEmail = (req, res) => {
    User.findOne({
        email: req.body.email
    }, function (err, user) {
        if (err) {
            res.status(400).send({
                message: Utils.getErrorMessageFromModel(err)
            });
        }

        if (!user) {
            res.status(404).send({
                message: 'Usuário não encontrado'
            });
        } else {
            res.status(200).json({
                firstName: user.firstName,
                lastName: user.lastName,
                email: user.email,
            })
        }
    });
};

exports.ensureAuthenticated = (req, res, next) => {
    var token = getToken(req.headers);

    if (token) {
        var decoded = jwt.decode(token, config.secret);
        if (decoded == null) {
            return res.status(403).send({
                message: 'Token inválido'
            });
        }
        next();
    } else return res.status(403).send({
        message: 'Nenhum token foi enviado.'
    });
};

exports.getUsers = (req, res) => {

    let objRes = {
        result: [],
        count: 0
    }

    let company_id = req.params.company_id;
    User.count({
        company_id: company_id
    }).then(count => {
        objRes.count = count;
        User.find({
            company_id: company_id
        }).then(r => {
            objRes.result = r;
            res.status(200).json(objRes)
        }).catch(err => {

            return res.status(400).send({
                err
            });;
        })
    }).catch(err => {

        return res.status(400).send({
            err
        });;
    })
}

//Find a company_id to next method
exports.prepareCompanyId = (req, res, next, id) => {
    req.company_id = id;
    next()
};


exports.searchUsers = (req, res) => {
    var body = req.body;
    let objRes = {
        result: [],
        count: 0
    }

    let query = {};
    if (req.company_id)
        query.company_id = req.company_id;
    else
        return res.status(500).send({
            message: "Erro na busca, por falor se deslogar e logar novamente"
        })

    if (body.firstName !== undefined && body.firstName !== "")
        query.firstName = new RegExp(body.firstName, 'i');

    if (body.lastName !== undefined && body.lastName !== "")
        query.lastName = new RegExp(body.lastName, 'i');
    User.count(query).then(count => {
        objRes.count = count;
        User.find(query)
            .skip(body.limit * (body.page - 1))
            .limit(body.limit)
            .then(r => {
                objRes.result = r;
                res.status(200).json(objRes)
            }).catch(err => {
                return res.status(400).send({
                    err
                });
            })
    }).catch(err => {

        return res.status(400).send({
            err
        });
    })

}

exports.read = (req, res) => {
    res.json(req.user)
};

exports.updateUserApproval = (req, res) => {
    var user = new User(req.user);
    if (user.approved == false) {
        user.approved = true;
    } else {
        user.approved = false;
    }

    User.update({
        _id: user._id
    }, user, function (err, raw) {
        if (err) {
            res.send(err);
        }
        res.send(raw);
    });
}

exports.updateUserWatch = (req, res) => {
    var user = new User(req.user);
    var body = req.body;
    user.watch = body.watch

    User.update({
        _id: user._id
    }, user, function (err, raw) {
        if (err) {
            res.send(err);
        }
        res.send(raw);
    });
}

var getToken = function (headers) {
    if (headers && headers.authorization) {
        var parted = headers.authorization.split(' ');
        if (parted.length === 2) {
            return parted[1];
        } else {
            return null;
        }
    } else {
        return null;
    }
}

exports.userById = (req, res, next, id) => {
    User.findById(id, (err, user) => {
        if (err) {
            return next(err);
        }
        if (!user) {
            return res.status(400).send({
                message: 'Failed to load user ' + id
            });
        }

        req.user = user;
        next();
    })
};

exports.updateUserImage = async (req, res) => {
    let user = new User(req.user)
    uploadUserImage.upload(req, res, req.user, function (userWithImage) {
        User.updateOne({
            "_id": req.user._id
        }, {
                $set: {
                    "profileImage": userWithImage.profileImage
                }
            }).then(savedUser => {
                res.json(userWithImage)
            })
            .catch(err => {
                return res.status(500).send({
                    message: Utils.getErrorMessageFromModel(err)
                })
            })
    })
}

exports.editUsers = (req, res) => {
    let user = new User(req.user);

    for (var item in req.body) {
        user[item] = req.body[item];
    }

    User.updateOne({
        "_id": req.user._id
    }, {
            $set: {
                "firstName": req.body.firstName
            }
        }).then(savedUser => {
            res.json(savedUser)
        })
}

exports.verifyEmailIfExists = (req, res) => {
    emailExistence.check('email@domain.com', function (err, res) { });
}

exports.getUsersMultiSelect = (req, res) => {
    if (!req.params.company_id) {
        return res.status(400).send({
            message: "Erro de identificação, atualize a página"
        })
    }
    User.find({
        approved: {
            $ne: false
        },
        company_id: req.params.company_id
    })
        .then(users => {
            res.json(users)
        })
        .catch(err => {
            return res.status(500).send({
                message: Utils.getErrorMessageFromModel(err)
            })
        })
}

exports.validateIfEmailExists = (req, res) => {

    let emailModel = {
        to: req.body.email,
        subject: "Recuperação de senha",
        text: ""
    }
    User.findOne({
        email: req.body.email
    })
        .then(user => {
            if (user) {
                if (user.lastChangeCode) {
                    user.lastChangeCode++;
                } else {
                    user.lastChangeCode = 1;
                }
                User.updateOne({
                    _id: user._id
                }, {
                        $set: {
                            lastChangeCode: user.lastChangeCode,
                            changeValidated: false
                        }
                    })
                    .then(user => {
                        console.log("success");
                    })
                    .catch(err => {
                        res.status(500).send({
                            message: Utils.getErrorMessageFromModel(err)
                        })
                    })
                emailModel.text = `<a href='${req.body.url}/recovery/?id=${user._id}&&lastChangeCode=${user.lastChangeCode}&&changeValidated=${user.changeValidated}'>Clique aqui para realizar a recuperação de senha</a>`
                emailRecovery.sendRecoveryEmail(req, res, emailModel, status => { })
                // res.json(user)
            } else {
                res.status(400).send({
                    message: "Não encontramos este email"
                })
            }
        })
        .catch(err => {
            res.status(500).send({
                message: Utils.getErrorMessageFromModel(err)
            })
        })
}


exports.updateUserPassword = (req, res) => {
    var user = new User(req.user);

    user.password = req.body.password;
    user.changeValidated = true;
    user.save()
        .then(user => {
            res.json(user);
        })
        .catch(err => {
            res.status(500).send({
                message: Utils.getErrorMessageFromModel(err)
            })
        })
}

exports.getUserById = (req, res) => {
    User.findOne({
        _id: req.body._id
    })
        .then(user => {
            res.json(user);
        })
        .catch(err => {
            res.status(500).send({
                message: Utils.getErrorMessageFromModel(err)
            })
        })
}
// terá que ser alterado futuramente
exports.updateUserLoginCount = async (req, res) => {
    if (!req.body.email) {
        return res.status(400).send({
            message: "Não encontramos este usuário."
        })
    }
    let userToUpdate = await User.findOne({
        email: req.body.email
    }).then(user => {
        if (!user) {
            res.status(400).send({
                message: "Não encontramos um usuário com este E-mail."
            })
        }
        if (user.loginCount) {
            user.loginCount++;
        } else {
            user.loginCount = 1;
        }
        return updateUserLoginCount(user);
    }).catch(err => {
        return err;
    })

    res.json({
        message: "Logado"
    })

}