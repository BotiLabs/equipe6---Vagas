'use strict';
var ObjectId = require('mongoose').Types.ObjectId;
var mongoose = require('mongoose'),
    Utils = require('../../domain/utils/util'),
    Interaction = require('../../domain/models/interaction').Interaction,
    InteractionHired = require('../../domain/models/interactionHired').InteractionHired,
    LogUser = require('../../domain/models/log').LogUser;


//Insert a new interaction
exports.create = (req, res) => {
    var interaction = new Interaction(req.body);
    interaction.save((err) => {
        if (err) {
            return res.status(400).send({
                message: Utils.getErrorMessageFromModel(err)
            });
        } else {
            res.json(interaction);
        }
    });
};

exports.createHired = (req, res) => {
    var interactionHired = new InteractionHired(req.body);

    interactionHired.save((err) => {
        if (err) {
            return res.status(400).send({
                message: Utils.getErrorMessageFromModel(err)
            });
        } else {
            res.json(interactionHired);
        }
    });
};

exports.search = (req, res)=>{
    console.log(req.body);
  

    Interaction.find(req.body, (err, resul) =>{
        if(err){
            return "Sem dados" + err;
        }

        if (!resul) {
            return res.status(400).send({
                message: 'Failed to load interection '
            });
        }

       return res.status(200).json(resul);
    })
}

exports.findByCandidateId = (req, res, next) => {
    Interaction.find({
        "candidateId": req.params.candidateId,
        visible: {
            $ne: false
        }
    }, function (err, interactions) {
        if (err) {
            res.status(400).send({
                message: Utils.getErrorMessageFromModel(err)
            });
        } else {
            res.json(interactions);
        }
    }).sort({
        "$natural": -1
    })
        .populate('opportunity');

};

//delete a interaction
exports.delete = (req, res, next) => {

    Interaction.findOne({
        _id: req.params.interactionId
    }).remove().exec(interaction => {
        res.send({
            message: 'Interaction removida com sucesso.'
        });
    }).catch(err => {
        res.status(500).send({
            message: Utils.getErrorMessageFromModel(err)
        });
    })
};

//List existing logs
exports.list = (req, res) => {
    Interaction.find({
        visible: {
            $ne: false
        }
    })
        .populate('logs')
        .sort('-created_at').exec((err, Interaction) => {
            if (err) {
                res.status(400).send({
                    message: Utils.getErrorMessageFromModel(err)
                });
            } else {
                res.json(Interaction);
            }
        });
};


exports.listInteractionToUpdateCandidate = (req, res) => {
    var body = req.body;
    Interaction.find({
        visible: {
            $ne: false
        },
        "candidateId": body.candidateId,
        "registrationDate": {
            $gte: body.registrationDate
        }
    })
        .populate('logs')
        .sort('-created_at').exec((err, Intera) => {
            if (err) {
                res.status(400).send({
                    message: Utils.getErrorMessageFromModel(err)
                });
            } else if (Intera.length > 0) {
                res.json(Intera);
            } else {
                var interact = {};
                interact.candidateId = body.candidateId;
                interact.status = 0;
                interact.action = 0;
                interact.userFirstName = "Robo Admin";
                interact.userEmail = "roboAdmin@email.com";
                var hour = new Date().getTime();
                var date = new Date(hour);
                interact.registrationDate = date;
                interact.observation = "Status do candidato alterado para Cadastrado devido a 20 dias de inatividade.";
                interact.profile = -1;
                interact = new Interaction(interact);
                interact.save((err, resIntera) => {
                    if (err) {
                        console.log({
                            message: Utils.getErrorMessageFromModel(err)
                        });
                    } else {
                        LogUser.find().sort({
                            number: -1
                        }).limit(1)
                            .exec()
                            .then((result => {
                                let logs = [];
                                var logUser = {};

                                logUser.userEmail = "roboAdmin@email.com";
                                logUser.userFirstName = "Robo Admin";
                                logUser.discriptionLog = "Retornou o status de um candidato";
                                logUser = new LogUser(logUser);
                                if (result) {
                                    if (result[0].number) {
                                        logUser.number = ++result[0].number;
                                    }
                                } else {
                                    logUser.number = 1;
                                }
                                logs.push(logUser);


                                logUser.save(logs, function (err, docs) {
                                    if (err) {
                                        console.log({
                                            message: Utils.getErrorMessageFromModel(err)
                                        });
                                    } else {
                                        console.log(docs);
                                    }
                                });
                            }));
                        res.json([]);
                    }
                });

            }

        });
};

exports.report = (req, res) => {
    var query =
        Interaction
            .aggregate(([{
                $match: {
                    visible: {
                        $ne: false
                    },
                    "company_id": req.company_id
                }
            }, {
                $group: {
                    "_id": "$userFirstName",
                    "action": {
                        $push: "$action"
                    },
                    "date": {
                        $push: "$registrationDate"
                    }
                }
            }]), function (err, result) {
                if (err) {
                    res.status(400).send({
                        message: Utils.getErrorMessageFromModel(err)
                    });
                } else {
                    for (var i = 0; i < result.length; i++) {
                        if (result[i]) {
                            for (var y = 0; y < result[i].date.length; y++) {
                                result[i].date[y] = result[i].date[y].getTime()
                            }
                        }
                    }
                    res.json(result);
                }
            })
};

//Find a company_id to next method
exports.prepareCompanyId = (req, res, next, id) => {
    req.company_id = id;
    next()
};

exports.reportContratation = (req, res) => {
    var query =
        Interaction.aggregate(([{
            $match: {
                visible: {
                    $ne: false
                },
                company_id: req.company_id
            }
        }, {
            $group: {
                "_id": "$userFirstName",
                "status": {
                    $push: "$status"
                },
                "date": {
                    $push: "$registrationDate"
                },
                "candidateId": {
                    $push: "$candidateId"
                },
                "opportunityId": {
                    $push: "$opportunityId"
                }
            }
        }]), function (err, result) {
            if (err) {
                res.status(400).send({
                    message: Utils.getErrorMessageFromModel(err)
                });
            } else {
                for (var i = 0; i < result.length; i++) {
                    if (result[i]) {
                        for (var y = 0; y < result[i].date.length; y++) {
                            result[i].date[y] = result[i].date[y].getTime()
                        }
                    }
                }
                res.json(result);
            }
        });
};

exports.reportWithDate = (req, res) => {
    var body = req.body;

    if (body.userEmail && body.initialDate && body.finalDate) {
        var query = [{
            $match: {
                visible: {
                    $ne: false
                },
                company_id: req.company_id,
                userEmail: body.userEmail,
                registrationDate: {
                    $gt: new Date(body.initialDate),
                    $lt: new Date(body.finalDate)
                }
            }
        }, {
            $group: {
                "_id": "$action",
                count: {
                    $sum: 1
                }
            }
        }];
        var query2 = [{
            $match: {
                visible: {
                    $ne: false
                },
                company_id: req.company_id,
                status: 4,
                userEmail: body.userEmail,
                registrationDate: {
                    $gt: new Date(body.initialDate),
                    $lt: new Date(body.finalDate)
                }
            }
        }, {
            $group: {
                "_id": "$status",
                count: {
                    $sum: 1
                }
            }
        }];
    } else if (body.initialDate && body.finalDate) {
        var query = [{
            $match: {
                visible: {
                    $ne: false
                },
                company_id: req.company_id,
                registrationDate: {
                    $gt: new Date(body.initialDate),
                    $lt: new Date(body.finalDate)
                }
            }
        }, {
            $group: {
                "_id": "$action",
                count: {
                    $sum: 1
                }
            }
        }];
        var query2 = [{
            $match: {
                visible: {
                    $ne: false
                },
                company_id: req.company_id,
                status: 4,
                registrationDate: {
                    $gt: new Date(body.initialDate),
                    $lt: new Date(body.finalDate)
                }
            }
        }, {
            $group: {
                "_id": "$status",
                count: {
                    $sum: 1
                }
            }
        }];
    } else if (body.userEmail && body.initialDate) {
        var query = [{
            $match: {
                visible: {
                    $ne: false
                },
                company_id: req.company_id,
                userEmail: body.userEmail,
                registrationDate: {
                    $gt: new Date(body.initialDate)
                }
            }
        }, {
            $group: {
                "_id": "$action",
                count: {
                    $sum: 1
                }
            }
        }];
        var query2 = [{
            $match: {
                visible: {
                    $ne: false
                },
                company_id: req.company_id,
                status: 4,
                userEmail: body.userEmail,
                registrationDate: {
                    $gt: new Date(body.initialDate)
                }
            }
        }, {
            $group: {
                "_id": "$status",
                count: {
                    $sum: 1
                }
            }
        }];
    } else if (body.userEmail && body.finalDate) {
        var query = [{
            $match: {
                visible: {
                    $ne: false
                },
                company_id: req.company_id,
                userEmail: body.userEmail,
                registrationDate: {
                    $lt: new Date(body.finalDate)
                }
            }
        }, {
            $group: {
                "_id": "$action",
                count: {
                    $sum: 1
                }
            }
        }];
        var query2 = [{
            $match: {
                visible: {
                    $ne: false
                },
                company_id: req.company_id,
                status: 4,
                userEmail: body.userEmail,
                registrationDate: {
                    $lt: new Date(body.finalDate)
                }
            }
        }, {
            $group: {
                "_id": "$status",
                count: {
                    $sum: 1
                }
            }
        }];
    } else if (body.initialDate) {
        var query = [{
            $match: {
                visible: {
                    $ne: false
                },
                company_id: req.company_id,
                registrationDate: {
                    $gt: new Date(body.initialDate)
                }
            }
        }, {
            $group: {
                "_id": "$action",
                count: {
                    $sum: 1
                }
            }
        }];
        var query2 = [{
            $match: {
                visible: {
                    $ne: false
                },
                company_id: req.company_id,
                status: 4,
                registrationDate: {
                    $gt: new Date(body.initialDate)
                }
            }
        }, {
            $group: {
                "_id": "$status",
                count: {
                    $sum: 1
                }
            }
        }];
    } else if (body.finalDate) {
        var query = [{
            $match: {
                visible: {
                    $ne: false
                },
                company_id: req.company_id,
                registrationDate: {
                    $lt: new Date(body.finalDate)
                }
            }
        }, {
            $group: {
                "_id": "$action",
                count: {
                    $sum: 1
                }
            }
        }];
        var query2 = [{
            $match: {
                visible: {
                    $ne: false
                },
                company_id: req.company_id,
                status: 4,
                registrationDate: {
                    $lt: new Date(body.finalDate)
                }
            }
        }, {
            $group: {
                "_id": "$status",
                count: {
                    $sum: 1
                }
            }
        }];
    } else if (body.userEmail) {
        var query = [{
            $match: {
                visible: {
                    $ne: false
                },
                company_id: req.company_id,
                userEmail: body.userEmail
            }
        }, {
            $group: {
                "_id": "$action",
                count: {
                    $sum: 1
                }
            }
        }];
        var query2 = [{
            $match: {
                visible: {
                    $ne: false
                },
                company_id: req.company_id,
                status: 4,
                userEmail: body.userEmail
            }
        }, {
            $group: {
                "_id": "$status",
                count: {
                    $sum: 1
                }
            }
        }];
    } else {
        var query = [{
            $match: {
                visible: {
                    $ne: false
                },
                company_id: req.company_id,
            }
        }, {
            $group: {
                "_id": "$action",
                count: {
                    $sum: 1
                }
            }
        }];
        var query2 = [{
            $match: {
                visible: {
                    $ne: false
                },
                company_id: req.company_id,
                status: 4
            }
        }, {
            $group: {
                "_id": "$status",
                count: {
                    $sum: 1
                }
            }
        }];
    }


    Interaction.aggregate((query), function (err, result) {
        if (err) {
            res.status(400).send({
                message: Utils.getErrorMessageFromModel(err)
            });
        } else {
            Interaction.aggregate((query2), function (err, result2) {
                if (err) {
                    res.status(400).send({
                        message: Utils.getErrorMessageFromModel(err)
                    });
                } else {
                    if (result2[0]) {
                        var feedback = {
                            "status": result2[0]._id,
                            "count": result2[0].count
                        }
                    }
                    result.push(feedback);
                    res.json(result);
                }
            });
        }
    });


};

exports.reportContratationBetWeenDate = (req, res) => {
    var body = req.body;
    var id = req.body.id;
    var queryselection;
    var processArray1 = [];
    var processArray2 = [];
    var processArray3 = [];
    var processArray4 = [];
    var reportProcess1 = 0;
    var reportProcess2 = 0;
    var reportProcess3 = 0;
    var reportProcess4 = 0;
    var reportProcess5 = 0;
    var reportProcess6 = 0;
    var reportProcess7 = 0;
    var reportProcess8 = 0;
    var reportProcess9 = 0;
    var reportProcess10 = 0;
    var reportProcess11 = 0;
    var reportProcess12 = 0;
    var reportProcess13 = 0;
    var reportProcess14 = 0;
    var reportProcess15 = 0;
    var reportProcess16 = 0;
    var reportProcessArray = [];

    if (body.initialDate && body.finalDate) {
        queryselection = [{
            $match: {
                company_id: req.company_id,
                visible: {
                    $ne: false
                },
                registrationDate: {
                    $gte: new Date(body.initialDate),
                    $lte: new Date(body.finalDate)
                }
            }
        }, {
            $group: {
                "_id": "$userFirstName",
                "status": {
                    $push: "$status"
                },
                "date": {
                    $push: "$registrationDate"
                },
                "candidateId": {
                    $push: "$candidateId"
                },
                "opportunityId": {
                    $push: "$opportunityId"
                }
            }
        }];
    } else if (body.initialDate) {
        queryselection = [{
            $match: {
                company_id: req.company_id,
                visible: {
                    $ne: false
                },
                registrationDate: {
                    $gte: new Date(body.initialDate)
                }
            }
        }, {
            $group: {
                "_id": "$userFirstName",
                "status": {
                    $push: "$status"
                },
                "date": {
                    $push: "$registrationDate"
                },
                "candidateId": {
                    $push: "$candidateId"
                },
                "opportunityId": {
                    $push: "$opportunityId"
                }
            }
        }];
    } else if (body.finalDate) {
        queryselection = [{
            $match: {
                company_id: req.company_id,
                visible: {
                    $ne: false
                },
                registrationDate: {
                    $lte: new Date(body.finalDate)
                }
            }
        }, {
            $group: {
                "_id": "$userFirstName",
                "status": {
                    $push: "$status"
                },
                "date": {
                    $push: "$registrationDate"
                },
                "candidateId": {
                    $push: "$candidateId"
                },
                "opportunityId": {
                    $push: "$opportunityId"
                }
            }
        }];
    } else {
        queryselection = [{
            $match: {
                company_id: req.company_id,
                visible: {
                    $ne: false
                }
            }
        }, {
            $group: {
                "_id": "$userFirstName",
                "status": {
                    $push: "$status"
                },
                "date": {
                    $push: "$registrationDate"
                },
                "candidateId": {
                    $push: "$candidateId"
                },
                "opportunityId": {
                    $push: "$opportunityId"
                }
            }
        }];
    }
    var query =
        Interaction.aggregate((queryselection), function (err, result) {
            if (err) {
                res.status(400).send({
                    message: Utils.getErrorMessageFromModel(err)
                });
            } else {
                //Em processo recrutamento
                for (var i = 0; i < result.length; i++) {

                    for (var y = 0; y < result[i].status.length; y++) {

                        if (result[i].status[y] == 7) {
                            processArray1.push({
                                "userName": result[i]._id,
                                "candidateId": result[i].candidateId[y],
                                "date": result[i].date[y],
                                "opportunityId": result[i].opportunityId[y],
                                "status": result[i].status[y]
                            });
                            if (id != -1) {
                                if (result[i]._id == id) {
                                    reportProcess1++;
                                }
                            } else {
                                reportProcess1++;
                            }
                        }
                    }

                }

                //Em processo recrutamento ========>>>> Em processo seleção
                for (var j = 0; j < processArray1.length; j++) {
                    for (var ji = 0; ji < result.length; ji++) {
                        for (var jy = 0; jy < result[ji].status.length; jy++) {
                            //Em processo recrutamento ========>>>> Emn processo seleção
                            if (result[ji].status[jy] == 1) {
                                if (result[ji].opportunityId[jy] + result[ji].candidateId[jy] == processArray1[j].opportunityId + processArray1[j].candidateId) {
                                    processArray2.push({
                                        "userName": result[ji]._id,
                                        "candidateId": result[ji].candidateId[jy],
                                        "date": result[ji].date[jy],
                                        "opportunityId": result[ji].opportunityId[jy],
                                        "status": result[ji].status[jy]
                                    });

                                    if (id != -1) {
                                        if (result[ji]._id == id) {
                                            reportProcess2++;
                                        }
                                    } else {
                                        reportProcess2++;
                                    }
                                }
                            }

                            //Em processo recrutamento ========>>>> declinou
                            if (result[ji].status[jy] == 2) {

                                if (result[ji].opportunityId[jy] + result[ji].candidateId[jy] == processArray1[j].opportunityId + processArray1[j].candidateId) {
                                    if (processArray2.find(x => x.opportunityId + x.candidateId === result[ji].opportunityId[jy] + result[ji].candidateId[jy]) == undefined) {
                                        if (id != -1) {
                                            if (result[ji]._id == id) {
                                                reportProcess3++;
                                            }
                                        } else {
                                            reportProcess3++;
                                        }
                                    }
                                }
                            }


                            //Em processo recrutamento ========>>>> reprovado
                            if (result[ji].status[jy] == 3) {

                                if (result[ji].opportunityId[jy] + result[ji].candidateId[jy] == processArray1[j].opportunityId + processArray1[j].candidateId) {
                                    if (processArray2.find(x => x.opportunityId + x.candidateId === result[ji].opportunityId[jy] + result[ji].candidateId[jy]) == undefined) {
                                        if (id != -1) {
                                            if (result[ji]._id == id) {
                                                reportProcess4++;
                                            }
                                        } else {
                                            reportProcess4++;
                                        }
                                    }
                                }
                            }


                            //Em processo recrutamento ========>>>> Disponível
                            if (result[ji].status[jy] == 5) {
                                if (result[ji].opportunityId[jy] + result[ji].candidateId[jy] == processArray1[j].opportunityId + processArray1[j].candidateId) {
                                    if (processArray2.find(x => x.opportunityId + x.candidateId === result[ji].opportunityId[jy] + result[ji].candidateId[jy]) == undefined) {
                                        if (id != -1) {
                                            if (result[ji]._id == id) {
                                                reportProcess5++;
                                            }
                                        } else {
                                            reportProcess5++;
                                        }
                                    }
                                }
                            }


                        }
                    }
                }


                //Em processo seleção ====> em processo cliente;
                /*
                |                                               |
                |                                               |  
                |                                               |      
                */
                if (processArray2.length > 0) {
                    for (var j = 0; j < processArray2.length; j++) {
                        for (var ji = 0; ji < result.length; ji++) {
                            for (var jy = 0; jy < result[ji].status.length; jy++) {


                                //Em processo seleção ========>>>> Em processo cliente
                                if (result[ji].status[jy] == 8) {

                                    if (result[ji].opportunityId[jy] + result[ji].candidateId[jy] == processArray2[j].opportunityId + processArray2[j].candidateId) {
                                        processArray3.push({
                                            "userName": result[ji]._id,
                                            "candidateId": result[ji].candidateId[jy],
                                            "date": result[ji].date[jy],
                                            "opportunityId": result[ji].opportunityId[jy]
                                        });
                                        if (id != -1) {
                                            if (result[ji]._id == id) {
                                                reportProcess6++;
                                            }
                                        } else {
                                            reportProcess6++;
                                        }
                                    }
                                }



                                //Em processo seleção ========>>>> declinou
                                if (result[ji].status[jy] == 2) {
                                    if (result[ji].opportunityId[jy] + result[ji].candidateId[jy] == processArray2[j].opportunityId + processArray2[j].candidateId) {
                                        if (processArray3.find(x => x.opportunityId + x.candidateId === result[ji].opportunityId[jy] + result[ji].candidateId[jy]) == undefined) {
                                            if (id != -1) {
                                                if (result[ji]._id == id) {
                                                    reportProcess7++;
                                                }
                                            } else {
                                                reportProcess7++;
                                            }
                                        }
                                    }
                                }

                                //Em processo seleção ========>>>> reprovado
                                if (result[ji].status[jy] == 3) {
                                    if (result[ji].opportunityId[jy] + result[ji].candidateId[jy] == processArray2[j].opportunityId + processArray2[j].candidateId) {
                                        if (processArray3.find(x => x.opportunityId + x.candidateId === result[ji].opportunityId[jy] + result[ji].candidateId[jy]) == undefined) {

                                            if (id != -1) {
                                                if (result[ji]._id == id) {
                                                    reportProcess8++;
                                                }
                                            } else {
                                                reportProcess8++;
                                            }

                                        }

                                    }
                                }


                                //Em processo seleção ========>>>> Disponível
                                if (result[ji].status[jy] == 5) {
                                    if (result[ji].opportunityId[jy] + result[ji].candidateId[jy] == processArray2[j].opportunityId + processArray2[j].candidateId) {
                                        if (processArray3.find(x => x.opportunityId + x.candidateId === result[ji].opportunityId[jy] + result[ji].candidateId[jy]) == undefined) {

                                            if (id != -1) {
                                                if (result[ji]._id == id) {
                                                    reportProcess9++;
                                                }
                                            } else {
                                                reportProcess9++;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                //Em processo cliente ====> Contratado;
                /*
                |                                               |
                |                                               |  
                |                                               |      
                */
                if (processArray3.length > 0) {
                    for (var j = 0; j < processArray3.length; j++) {
                        for (var ji = 0; ji < result.length; ji++) {
                            for (var jy = 0; jy < result[ji].status.length; jy++) {


                                //Em processo cliente ====> Contratado;
                                if (result[ji].status[jy] == 4) {
                                    if (result[ji].opportunityId[jy] + result[ji].candidateId[jy] == processArray3[j].opportunityId + processArray3[j].candidateId) {
                                        processArray4.push({
                                            "userName": result[ji]._id,
                                            "candidateId": result[ji].candidateId[jy],
                                            "date": result[ji].date[jy],
                                            "opportunityId": result[ji].opportunityId[jy]
                                        });

                                        if (id != -1) {
                                            if (result[ji]._id == id) {
                                                reportProcess10++;
                                            }
                                        } else {
                                            reportProcess10++;
                                        }
                                    }

                                }



                                //Em processo cliente ========>>>> declinou
                                if (result[ji].status[jy] == 2) {
                                    if (result[ji].opportunityId[jy] + result[ji].candidateId[jy] == processArray3[j].opportunityId + processArray3[j].candidateId) {
                                        if (processArray4.find(x => x.opportunityId + x.candidateId === result[ji].opportunityId[jy] + result[ji].candidateId[jy]) == undefined) {
                                            if (id != -1) {
                                                if (result[ji]._id == id) {
                                                    reportProcess11++;
                                                }
                                            } else {
                                                reportProcess11++;
                                            }
                                        }
                                    }
                                }


                                //Em processo cliente ========>>>> reprovado
                                if (result[ji].status[jy] == 3) {
                                    if (result[ji].opportunityId[jy] + result[ji].candidateId[jy] == processArray3[j].opportunityId + processArray3[j].candidateId) {

                                        if (processArray4.find(x => x.opportunityId + x.candidateId === result[ji].opportunityId[jy] + result[ji].candidateId[jy]) == undefined) {
                                            if (id != -1) {
                                                if (result[ji]._id == id) {
                                                    reportProcess12++;
                                                }
                                            } else {
                                                reportProcess12++;
                                            }

                                        }

                                    }
                                }


                                //Em processo cliente ========>>>> Disponível
                                if (result[ji].status[jy] == 5) {

                                    if (result[ji].opportunityId[jy] + result[ji].candidateId[jy] == processArray3[j].opportunityId + processArray3[j].candidateId) {

                                        if (processArray4.find(x => x.opportunityId + x.candidateId === result[ji].opportunityId[jy] + result[ji].candidateId[jy]) == undefined) {
                                            if (id != -1) {
                                                if (result[ji]._id == id) {
                                                    reportProcess13++;
                                                }
                                            } else {
                                                reportProcess13++;
                                            }

                                        }

                                    }
                                }

                            }
                        }
                    }
                }



                //Contratado;
                /*
                |                                               |
                |                                               |  
                |                                               |      
                */
                if (processArray4.length > 0) {
                    for (var j = 0; j < processArray4.length; j++) {
                        for (var ji = 0; ji < result.length; ji++) {
                            for (var jy = 0; jy < result[ji].status.length; jy++) {


                                //Contratado ========>>>> declinou
                                if (result[ji].status[jy] == 2) {

                                    if (result[ji].opportunityId[jy] + result[ji].candidateId[jy] == processArray3[j].opportunityId + processArray3[j].candidateId) {
                                        if (processArray4.find(x => x.opportunityId + x.candidateId === result[ji].opportunityId[jy] + result[ji].candidateId[jy])) {
                                            if (id != -1) {
                                                if (result[ji]._id == id) {
                                                    reportProcess14++;
                                                }
                                            } else {
                                                reportProcess14++;
                                            }

                                        }

                                    }
                                }


                                //Contratado ========>>>> reprovado
                                if (result[ji].status[jy] == 3) {

                                    if (result[ji].opportunityId[jy] + result[ji].candidateId[jy] == processArray3[j].opportunityId + processArray3[j].candidateId) {
                                        if (processArray4.find(x => x.opportunityId + x.candidateId === result[ji].opportunityId[jy] + result[ji].candidateId[jy])) {
                                            if (id != -1) {
                                                if (result[ji]._id == id) {
                                                    reportProcess15++;
                                                }
                                            } else {
                                                reportProcess15++;
                                            }


                                        }
                                    }
                                }


                                //Contratado ========>>>> Disponível
                                if (result[ji].status[jy] == 5) {
                                    if (result[ji].opportunityId[jy] + result[ji].candidateId[jy] == processArray3[j].opportunityId + processArray3[j].candidateId) {
                                        if (processArray4.find(x => x.opportunityId + x.candidateId === result[ji].opportunityId[jy] + result[ji].candidateId[jy])) {
                                            if (id != -1) {
                                                if (result[ji]._id == id) {
                                                    reportProcess16++;
                                                }
                                            } else {
                                                reportProcess16++;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                reportProcessArray.push(reportProcess1);
                reportProcessArray.push(reportProcess2);
                reportProcessArray.push(reportProcess3);
                reportProcessArray.push(reportProcess4);
                reportProcessArray.push(reportProcess5);
                reportProcessArray.push(reportProcess6);
                reportProcessArray.push(reportProcess7);
                reportProcessArray.push(reportProcess8);
                reportProcessArray.push(reportProcess9);
                reportProcessArray.push(reportProcess10);
                reportProcessArray.push(reportProcess11);
                reportProcessArray.push(reportProcess12);
                reportProcessArray.push(reportProcess13);
                reportProcessArray.push(reportProcess14);
                reportProcessArray.push(reportProcess15);
                reportProcessArray.push(reportProcess16);
                res.json(reportProcessArray);
            }
        });
};


//List a interaction
exports.read = (req, res) => {
    res.json(req.interaction);
};

//Find a interaction to next method
exports.interactionById = (req, res, next, id) => {
    Interaction
        .findById(id, (err, interaction) => {
            if (err) {
                return next(err);
            }
            if (!interaction) {
                return res.status(400).send({
                    message: 'Failed to load interaction ' + id
                });
            }
            req.interaction = interaction;
            next();
        })
};

//Update a interaction
exports.update = (req, res) => {
    var interaction = req.interaction;

    for (var prop in req.body) {
        interaction[prop] = req.body[prop];
    }

    interaction.save((err) => {
        if (err) {
            return res.status(400).send({
                message: Utils.getErrorMessageFromModel(err)
            });
        } else {
            res.json(interaction)
        }
    });
};

exports.findToChangeStatusToDisapprove = async (req, res) => {
    var body = req.body;
    Interaction.aggregate([{
        $match: {
            "candidateId": new ObjectId(body.candidateId),
            "opportunityId": {
                $ne: body.opportunityId
            },
            "company_id": req.company_id
        }
    },
    {
        $group: {
            "_id": "$opportunity",
            "count": {
                $sum: 1
            },
            "registrationDate": {
                $push: "$registrationDate"
            },
            "status": {
                $push: "$status"
            }
        }
    },

    {
        $project: {
            "opportunityId": "$_id",
            "registrationDate": "$registrationDate",
            "status": "$status"
        }
    }, {
        $lookup: {
            'from': 'opportunities',
            'localField': 'opportunityId',
            'foreignField': '_id',
            'as': 'opportunity'
        }
    }
    ])
        .then(result => {
            let resArray = [];
            result.forEach(res => {
                console.log(res)
                if (res.opportunityId != '' && res.opportunityId != null && res.opportunityId != undefined) {
                    let resValidated = {
                        opportunityId: "",
                        changeStatus: []
                    }
                    if (res.opportunity[0].status != 1 && res.opportunity[0].status != 3) {
                        resValidated.opportunityId = res.opportunityId;
                        for (var i = 0; i < res.registrationDate.length; i++) {
                            resValidated.changeStatus.push({
                                "registrationDate": res.registrationDate[i],
                                "status": res.status[i]
                            });
                        }

                        resValidated.changeStatus.sort(function (a, b) {
                            return b.registrationDate - a.registrationDate;
                        })

                        resValidated.changeStatus[0].status != 3 && resValidated.changeStatus[0].status != 2 ? resArray.push(resValidated) : resValidated;
                    }
                }
            })
            console.log(resArray)
            res.json(resArray)
        })
        .catch(err => {
            res.send({
                message: Utils.getErrorMessageFromModel(err)
            })
        })
}


exports.actionReport = async (req, res) => {
    let body = req.body;
    let query = {};
    let objRes = {
        result: {},
        count: 0
    }

    var sort = {};

    if (body.sort)
        sort = body.sort['query'];

    if (body.action !== undefined && body.action != -1)
        query.action = body.action


    if (body.userEmail !== undefined && body.userEmail != '')
        query.userEmail = body.userEmail

    if (body.initialDate && body.finalDate) {
        query.registrationDate = {
            $gte: new Date(body.initialDate),
            $lt: new Date(body.finalDate)
        };
    } else if (body.initialDate) {
        query.registrationDate = {
            $gte: new Date(body.initialDate)
        };
    } else if (body.finalDate) {
        query.registrationDate = {
            $lt: new Date(body.finalDate)
        };
    }

    query.company_id = req.company_id;

    var queryToDo = [{
        $match: query
    },
    {
        $lookup: {
            from: "candidates",
            localField: "candidateId",
            foreignField: "_id",
            as: "candidate"
        },

    },
    {
        $lookup: {
            from: "statusofcandidates",
            localField: "status",
            foreignField: "number",
            as: "statusJoin"
        },

    }
    ]
    if (body.sort)
        queryToDo.push({
            $sort: sort
        })

    queryToDo.push({
        $skip: body.limit * (body.page - 1)
    })
    queryToDo.push({
        $limit: body.limit
    });

    Interaction.countDocuments(query).then(count => {

        objRes.count = count;
        Interaction.aggregate(queryToDo).then(interactions => {
            objRes.result = interactions
            res.json(objRes)
        }).catch(err => {
                return res.send({
                    message: Utils.getErrorMessageFromModel(err)
                })
            })
    }).catch(err => {
        return res.send({
            message: Utils.getErrorMessageFromModel(err)
        })
    })
}



exports.reportHired = (req, res) => {
    let objRes = {
        result: null,
        count: 0
    };

    var body = req.body;
    var query = {};

    var query2 = {};

    if (body.status !== undefined && body.status >= 0)
        query.status = body.status;

    if (body.customerName !== undefined && body.customerName != "")
        query2["opportunities.customerName"] = RegExp(body.customerName, "i");

    if (body.userEmail !== undefined && body.userEmail != "")
        query.userEmail = RegExp(body.userEmail, "i");

    if (body.priority !== undefined && body.priority >= 0)
        query2["opportunities.priority"] = (body.priority)

    if (body.initialDate && body.finalDate) {
        body.initialDate = new Date(body.initialDate).getTime() - 10800000
        body.finalDate = new Date(body.finalDate).getTime() + 84400000
        query.registrationDate = {
            $gt: new Date(body.initialDate),
            $lt: new Date(body.finalDate)
        };
    } else if (body.initialDate) {
        body.initialDate = new Date(body.initialDate).getTime() - 10800000
        query.registrationDate = {
            $gt: new Date(body.initialDate)
        };
    } else if (body.finalDate) {
        body.finalDate = new Date(body.finalDate).getTime() + 84400000
        query.registrationDate = {
            $lt: new Date(body.finalDate)
        };
    }

    query.company_id = req.company_id;

    let queryToDo = [{
        $match: query
    },
    {
        $lookup: {
            from: "candidates",
            localField: "candidateId",
            foreignField: "_id",
            as: "candidate"
        },

    },
    {
        $lookup: {
            from: "opportunities",
            localField: "opportunity",
            foreignField: "_id",
            as: "opportunities"
        },

    },
    {
        $match: query2
    }, {
        $group: {
            _id: '$candidateId',
            userFirstName: {
                $first: '$userFirstName'
            },
            customerName: {
                $first: '$opportunities.customerName'
            },
            id: {
                $first: '$opportunities.number'
            },
            opportunity: {
                $first: '$opportunities.name'
            },
            priority: {
                $first: '$opportunities.priority'
            },
            candidate: {
                $first: '$candidate.name'
            },
            registrationDate: {
                $first: '$registrationDate'
            }
        }
    }
    ];

    let queryFind = [{
        $match: query
    },
    {
        $lookup: {
            from: "candidates",
            localField: "candidateId",
            foreignField: "_id",
            as: "candidate"
        },

    },
    {
        $lookup: {
            from: "opportunities",
            localField: "opportunity",
            foreignField: "_id",
            as: "opportunities"
        },

    },
    {
        $match: query2
    }, {
        $group: {
            _id: '$candidateId',
            userFirstName: {
                $first: '$userFirstName'
            },
            customerName: {
                $first: '$opportunities.customerName'
            },
            id: {
                $first: '$opportunities.number'
            },
            opportunity: {
                $first: '$opportunities.name'
            },
            priority: {
                $first: '$opportunities.priority'
            },
            candidate: {
                $first: '$candidate.name'
            },
            registrationDate: {
                $first: '$registrationDate'
            }
        }
    }
    ];
    if (body.sort)
        queryFind.push({
            $sort: body.sort['query']
        })

    queryFind.push({
        $skip: body.limit * (body.page - 1)
    })

    queryFind.push({
        $limit: body.limit
    })

    queryToDo.push({
        $count: "total"
    })

    Interaction.aggregate(queryToDo).then(count => {
        objRes.count = 0;
        if (count[0])
            objRes.count = count[0].total;

        Interaction.aggregate(queryFind).then(interactions => {
            objRes.result = interactions;
            res.json(objRes)
        })
            .catch(err => {
                return res.send({
                    message: Utils.getErrorMessageFromModel(err)
                })
            })

    })
        .catch(err => {
            res.status(500).send({
                message: Utils.getErrorMessageFromModel(err)
            })
        })
}

function validateActionReport(interactions) {
    let exportItensArr = [];
    let keys = {
        "Ação": "",
        "Candidato": "",
        "Data": "",
        "Vaga": "",
        "Status": ""
    }
    let arrObjKeys = Object.keys(keys);
    exportItensArr.push(arrObjKeys);

    for (var i = 0; i < interactions.length; i++) {
        let bodyArr = []
        for (let key of Object.keys(keys)) {
            if (key != "_id") {
                switch (key) {
                    case "Status":
                        if (interactions[i].statusJoin) {
                            if (interactions[i].statusJoin[0]) {
                                bodyArr.push(interactions[i].statusJoin[0].name)
                            } else {
                                bodyArr.push(" ")
                            }
                        } else {
                            bodyArr.push(" ")
                        }
                        break;
                    case "Candidato":
                        if (interactions[i].candidate) {
                            if (interactions[i].candidate[0]) {
                                bodyArr.push(interactions[i].candidate[0].name)
                            } else {
                                bodyArr.push(" ")
                            }
                        } else {
                            bodyArr.push(" ")
                        }
                        break;
                    case "Vaga":
                        bodyArr.push(interactions[i].opportunityName)
                        break;
                    case "Data":
                        bodyArr.push(formatDate(interactions[i].registrationDate));
                        break;
                    case "Ação":
                        bodyArr.push(formatAction(interactions[i].action));
                        break;
                }
            }
        }
        exportItensArr.push(bodyArr);
    }
    return exportItensArr;
}


function formatDate(date) {
    if (date) {
        var day = date.getDate();
        var monthIndex = date.getMonth() + 1;
        var year = date.getFullYear();

        return day + '/' + monthIndex + '/' + year;
    } else {
        return "";
    }
}

function formatAction(action) {
    switch (action) {
        case 1:
            return "Contato";
        case 2:
            return "Contratação";
        case 3:
            return "Avaliação";
        case 4:
            return "Entrevista  R&S";
        case 5:
            return "Entrevista/Teste Técnico";
        case 6:
            return "Entrevista Cliente";
        case 7:
            return "Análise";
        default:
            return "";
    }
}

exports.actionReportXlsv = (req, res) => {
    let body = req.body;
    let query = {};

    var sort = {};

    if (body.sort)
        sort = body.sort['query'];

    if (body.action !== undefined && body.action != -1)
        query.action = body.action


    if (body.userEmail !== undefined && body.userEmail != '')
        query.userEmail = body.userEmail

    if (body.initialDate && body.finalDate) {
        query.registrationDate = {
            $gte: new Date (body.initialDate),
            $lt: new Date (body.finalDate)
        };
    } else if (body.initialDate) {
        query.registrationDate = {
            $gte: new Date (body.initialDate)
        };
    } else if (body.finalDate) {
        query.registrationDate = {
            $lt: new Date (body.finalDate)
        };
    }

    query.company_id = req.company_id;

    var queryToDo = [{
        $match: query
    },
    {
        $lookup: {
            from: "candidates",
            localField: "candidateId",
            foreignField: "_id",
            as: "candidate"
        },

    },
    {
        $lookup: {
            from: "statusofcandidates",
            localField: "status",
            foreignField: "number",
            as: "statusJoin"
        },

    }
    ]
    if (body.sort)
        queryToDo.push({
            $sort: sort
        })

    Interaction.aggregate(queryToDo).then(interactions => {
        let returnInteractions = validateActionReport(interactions);
        res.json(returnInteractions);
    })
        .catch(err => {
            return res.status(500).send({
                message: "Erro ao exportar"
            })
        })

}


exports.contratationReportXlsv = (req, res) => {


    var body = req.body;
    var query = {};

    var query2 = {};

    if (body.status !== undefined && body.status >= 0)
        query.status = body.status;

    if (body.customerName !== undefined && body.customerName != "")
        query2["opportunities.customerName"] = RegExp(body.customerName, "i");

    if (body.userEmail !== undefined && body.userEmail != "")
        query.userEmail = RegExp(body.userEmail, "i");

    if (body.priority !== undefined && body.priority >= 0)
        query2["opportunities.priority"] = (body.priority)

    if (body.initialDate && body.finalDate) {
        query.registrationDate = {
            $gt: new Date(body.initialDate),
            $lt: new Date(body.finalDate)
        };
    } else if (body.initialDate) {
        query.registrationDate = {
            $gt: new Date(body.initialDate)
        };
    } else if (body.finalDate) {
        query.registrationDate = {
            $lt: new Date(body.finalDate)
        };
    }
    query.company_id = req.company_id;
    query2.company_id = req.company_id;

    let queryToDo = [{
        $match: query
    },
    {
        $lookup: {
            from: "candidates",
            localField: "candidateId",
            foreignField: "_id",
            as: "candidate"
        },

    },
    {
        $lookup: {
            from: "opportunities",
            localField: "opportunity",
            foreignField: "_id",
            as: "opportunities"
        },

    },
    {
        $match: query2
    }, {
        $group: {
            _id: '$candidateId',
            userFirstName: {
                $first: '$userFirstName'
            },
            customerName: {
                $first: '$opportunities.customerName'
            },
            id: {
                $first: '$opportunities.number'
            },
            opportunity: {
                $first: '$opportunities.name'
            },
            priority: {
                $first: '$opportunities.priority'
            },
            candidate: {
                $first: '$candidate.name'
            },
            registrationDate: {
                $first: '$registrationDate'
            }
        }
    }
    ];
    if (body.sort)
        queryToDo.push({
            $sort: body.sort['query']
        })

    Interaction.aggregate(queryToDo).then(interactions => {
        let result = validateContratationReport(interactions);
        res.json(result)
    })
        .catch(err => {
            return res.send({
                message: Utils.getErrorMessageFromModel(err)
            })
        })

}


function validateContratationReport(interactions) {
    let exportItensArr = [];
    let keys = {
        "Analista": "",
        "Cliente": "",
        "ID": "",
        "Vaga": "",
        "Prioridade": "",
        "Candidato": "",
        "Data": ""
    }
    let arrObjKeys = Object.keys(keys);
    exportItensArr.push(arrObjKeys);

    for (var i = 0; i < interactions.length; i++) {
        let bodyArr = []
        for (let key of Object.keys(keys)) {
            if (key != "_id") {
                switch (key) {
                    case "Candidato":
                        if (interactions[i].candidate) {
                            if (interactions[i].candidate[0]) {
                                bodyArr.push(interactions[i].candidate[0])
                            } else {
                                bodyArr.push(" ")
                            }
                        } else {
                            bodyArr.push(" ")
                        }
                        break;
                    case "Cliente":
                        if (interactions[i].customerName) {
                            if (interactions[i].customerName[0]) {
                                interactions[i].customerName[0] ? bodyArr.push(interactions[i].customerName[0]) : bodyArr.push(" ");
                            } else {
                                bodyArr.push(" ")
                            }
                        } else {
                            bodyArr.push(" ")
                        }
                        break;
                    case "Vaga":
                        if (interactions[i].opportunity) {
                            if (interactions[i].opportunity[0]) {
                                bodyArr.push(interactions[i].opportunity[0])
                            } else {
                                bodyArr.push(" ")
                            }
                        } else {
                            bodyArr.push(" ")
                        }
                        break;
                    case "Prioridade":
                        if (interactions[i].priority) {
                            if (interactions[i].priority[0]) {
                                interactions[i].priority[0] ? bodyArr.push(formatPriority(interactions[i].priority[0])) : bodyArr.push("Sem Prioridade");

                            } else {
                                bodyArr.push(" ")
                            }
                        } else {
                            bodyArr.push(" ")
                        }
                        break;
                    case "Data":
                        bodyArr.push(formatDate(interactions[i].registrationDate));
                        break;
                    case "Analista":
                        bodyArr.push(interactions[i].userFirstName);
                        break;
                    case "ID":
                        if (interactions[i].id) {
                            if (interactions[i].id[0]) {
                                bodyArr.push(interactions[i].id[0]);
                            } else {
                                bodyArr.push(" ")
                            }
                        } else {
                            bodyArr.push(" ")
                        }
                        break;
                }
            }
        }
        exportItensArr.push(bodyArr);
    }
    return exportItensArr;
}

function formatPriority(priority) {
    let opPriority = undefined;
    switch (priority) {
        case 0:
            opPriority = "Baixa"
            break;
        case 1:
            opPriority = "Média"
            break;
        case 2:
            opPriority = "Alta"
            break

        default:
            break;
    }
    return opPriority;
}