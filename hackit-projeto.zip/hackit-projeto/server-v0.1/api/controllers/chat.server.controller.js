var http = require('http');
var ConversationV1 = require('watson-developer-cloud/conversation/v1');
var config = require('../../config/config');
//var recrutamentoOpportunites = require('../controllers/opportunities.controller');

exports.post2async = (req, res) => {

    var conversation = new ConversationV1({
        username: config.username,
        password: config.password,
        version_date: ConversationV1.VERSION_DATE_2017_05_26
    });

    var teste;

    conversation.message({
        workspace_id: config.workspace_id,
        input: { text: req.body.input.text },
        context: req.body.context,
        output: { parent_intention: req.body.output.parent_intention }
    }, function (err, response) {
        if (err) {
            console.error(err);
        } else {
            if (response.output.parent_intention && response.output.parent_intention === "vaga_dev") {
                response.output.text = "Certo, temos vagas com essas skills, clique no botão abaixo";

                // obterSkills(response.entities)
                // .then(resultado => {
                //     return recrutamentoOpportunites.GetAllOpportunities(resultado);
                // })
                // .then((result) => {
                //     console.log(result);
                // }).catch(error => {
                //     console.log(error);
                // });
                obterSkills(response.entities)
                .then(resultado => {
                    console.log(resultado);
                });
            }

            res.send(JSON.stringify(response));
        }
    });


};

var obterSkills = function (entidadesSkills) {
    return new Promise((resolve, reject) => {
        var listaSkills = [];

        entidadesSkills.forEach(function (x) {
            if (x.entity == 'tecnologia')
                listaSkills.push(x.value);
        });
        return resolve(listaSkills);
    });

};