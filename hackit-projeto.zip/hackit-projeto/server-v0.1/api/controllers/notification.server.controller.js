'use strict';

var mongoose = require('mongoose'),
    Utils = require('../../domain/utils/util'),
    NotificationUser = require('../../domain/models/notification').NotificationUser;


//Insert a new notification
exports.create = (req, res) => {
    let notifications = [];
    var body = req.body;


    //Validate search if exists
    NotificationUser.findOne().sort({ number: -1 }).limit(1)
        .exec()
        .then((resul => {
            var notificationUser = new NotificationUser(req.body);
            if (resul) {
                if (resul.number) {
                    notificationUser.number = ++resul.number;
                }
            } else {
                notificationUser.number = 1;
            }
            notifications.push(notificationUser);

            notificationUser.save(notifications, function (err, docs) {
                if (err) {
                    return res.status(400).send({
                        message: Utils.getErrorMessageFromModel(err),
                        erro: err
                    });
                } else {
                    res.json(docs);
                }
            });
        }));
}

exports.searchOnInit = (req, res) => {
    let objRes = {
        result: null,
        count: 0
    };
    var query = {};
    var mysort = { number: -1 };
    var body = req.body;

    query.responsibleEmail = body.responsibleEmail;
    NotificationUser.count(query, function (err, count) {
        if (err) {
            res.status(404).send({
                message: Utils.getErrorMessageFromModel(err)
            });
        } else {
            objRes.count = count;
            NotificationUser.find(query, function (err, result) {
                if (err) {
                    res.status(404).send({
                        message: Utils.getErrorMessageFromModel(err)
                    });
                } else {
                    objRes.object = result;
                    res.json(objRes);
                }
            }).sort(mysort).skip(body.limit * (body.page - 1)).limit(body.limit);
        }
    });
};

//List a candidate
exports.read = (req, res) => {
    res.json(req.notification);
};

//Find a candidate to next method
exports.notificationById = (req, res, next, id) => {
    NotificationUser
        .findById(id, (err, notification) => {
            if (err) {
                return next(err);
            }
            if (!notification) {
                return res.status(400).send({
                    message: 'Failed to load notification ' + id
                });
            }
            req.notification = notification;
            next();
        })
};

//Delete a notification
exports.delete = (req, res) => {
    var notification = req.notification;

    notification.remove((err) => {
        if (err) {
            return res.status(400).send({
                message: Utils.getErrorMessageFromModel(err)
            });
        } else {
            res.json(notification);
        }
    });
};
