'use strict';

var mongoose = require('mongoose'),
    Utils = require('../../domain/utils/util'),
    SoftSkills = require('../../domain/models/softskills').SoftSkills;

//Find a company_id to next method
exports.prepareCompanyId = (req, res, next, id) => {
    req.company_id = id;
    next()
};

//Insert a new softskills
exports.create = (req, res) => {

    var body = req.body;
    var softskill = body.softskill.toUpperCase();
    body.softskill = softskill;
    var softskills = new SoftSkills(body);
    softskills.nameWithCompany = softskills.softskill + softskills.company_id;
    //Validate softskillss if exists
    SoftSkills.findOne({
        softskill: softskill,
            visible: {
                $ne: false
            },
            company_id: body.company_id
        })
        .exec()
        .then((result => {
            if (result && result.visible == true) {
                res.status(400).send({
                    message: "Esta SoftSkills já foi cadastrada",
                    result: result
                });
            } else {
                softskills.save((err) => {
                    if (err) {
                        return res.status(400).send({
                            message: Utils.getErrorMessageFromModel(err),
                            erro: err
                        });
                    } else {
                        res.json(softskills);
                    }
                });
            }
        })).catch((err => {
            return res.status(500).send({
                message: Utils.getErrorMessageFromModel(err)
            });
        }))
};

//List existing softskillss
exports.list = (req, res) => {
    SoftSkills.find({
            visible: {
                $ne: false
            },
            company_id: req.company_id
        })
        //populate('opportunities')
        .sort('-created_at').exec((err, softskillss) => {
            if (err) {
                res.status(400).send({
                    message: Utils.getErrorMessageFromModel(err)
                });
            } else {
                res.json(softskillss);
            }
        });
};

//List a softskills
exports.read = (req, res) => {
    res.json(req.softskills);
};

//Find a softskills to next method
exports.softskillsById = (req, res, next, id) => {
    SoftSkills.findById(id, (err, softskills) => {
        if (err) {
            return next(err);
        }
        if (!softskills) {
            return res.status(400).send({
                message: 'Failed to load softskills ' + id
            });
        }

        req.softskills = softskills;
        next();
    })
};

//Update a softskills
exports.update = (req, res) => {
    var softskills = req.softskills;

    for (var prop in req.body) {
        softskills[prop] = req.body[prop];
    }
    softskills.softskill = softskills.softskill.toUpperCase();
    softskills.nameWithCompany = softskills.softskill + softskills.company_id;
    console.log(softskills)
    softskills.save((err) => {
        if (err) {
            return res.status(400).send({
                message: Utils.getErrorMessageFromModel(err)
            });
        } else {
            res.json(softskills)
        }
    });
};


exports.updateToDelete = (req, res) => {
    var softskills = req.softskills;
    var softskill = req.body.softskill.toUpperCase();
    for (var prop in req.body) {
        softskills[prop] = req.body[prop];
    }
    softskills.softskill = softskill;
    softskills.nameWithCompany = softskills.softskill + softskills.company_id;
    SoftSkills.findOne({
        softskill: softskill,
            visible: {
                $ne: false
            },
            company_id: softskills.company_id
        })
        .exec()
        .then((result => {
            if (result && result.visible == true) {
                res.status(400).send({
                    message: "Esta SoftSkills já foi cadastrada",
                    result: result
                });
            } else {
                softskills.save((err) => {
                    if (err) {
                        return res.status(400).send({
                            message: Utils.getErrorMessageFromModel(err)
                        });
                    } else {
                        res.json(softskills)
                    }
                });

            }
        })).catch((err => {
            return res.status(500).send({
                message: Utils.getErrorMessageFromModel(err)
            });
        }))
};
//Delete a softskills
exports.delete = (req, res) => {
    var softskills = req.softskills;

    softskills.remove((err) => {
        if (err) {
            return res.status(400).send({
                message: Utils.getErrorMessageFromModel(err)
            });
        } else {
            res.send({

                message: ('SoftSkills removida com sucesso.')
            })
        }
    });
};

// Search a softskills
exports.search = (req, res) => {
    let objRes = {
        result: null,
        count: 0
    };

    var query = {};
    var body = req.body;
    query.company_id = body.company_id;

    query.softskill = new RegExp(body.softskill, "i");
    query.visible = {
        $ne: false
    }
    SoftSkills.count(query, function (err, count) {
        if (err) {
            res.status(404).send({
                message: Utils.getErrorMessageFromModel(err)
            });
        } else {
            objRes.count = count;
            SoftSkills.find(query, function (err, result) {
                if (err) {
                    res.status(404).send({
                        message: Utils.getErrorMessageFromModel(err)
                    });
                } else {
                    objRes.result = result;
                    res.json(objRes);
                }
            }).skip(body.limit * (body.page - 1)).limit(body.limit);
        }
    });
};

// Search a softskills without reg exp
exports.searchIfExists = (req, res) => {
    let objRes = {
        result: null,
        count: 0
    };

    var query = {};
    var body = req.body;
    var softskill = body.softskill.toUpperCase();
    query.softskill = softskill;

    query.company_id = body.company_id;
    query.visible = {
        $ne: false
    }
    SoftSkills.count(query, function (err, count) {
        if (err) {
            res.status(404).send({
                message: Utils.getErrorMessageFromModel(err)
            });
        } else {
            objRes.count = count;
            SoftSkills.findOne(query, function (err, result) {
                if (err) {
                    res.status(404).send({
                        message: Utils.getErrorMessageFromModel(err)
                    });
                } else {
                    if (result) {
                        res.json("Esta softskills já existe");
                    } else {
                        res.json("Não encontramos esta softskills. Deseja criar uma nova?");
                    }

                }
            }).skip(body.limit * (body.page - 1)).limit(body.limit);
        }
    });
};