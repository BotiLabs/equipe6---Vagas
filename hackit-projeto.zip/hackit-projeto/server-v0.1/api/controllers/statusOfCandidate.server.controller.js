'use strict'
var mongoose = require('mongoose'),
    Utils = require('../../domain/utils/util'),
    StatusOfCandidate = require('../../domain/models/statusCandidate').StatusOfCandidate;

exports.getAllByCompany = async (req, res) => {
    var query = {};

    query.company_id = req.params.id_company;

    let statusList = await StatusOfCandidate.find(query).then(listStatus => {
        return listStatus;
    }).catch(err => {
        return res.status(500).send({
            message: Utils.getErrorMessageFromModel(err)
        })
    })

    let statusDefaulList = await StatusOfCandidate.find({
        default: true
    }).then(listStatus => {
        return listStatus;
    }).catch(err => {
        return res.status(500).send({
            message: Utils.getErrorMessageFromModel(err)
        })
    })

    for (let s of statusDefaulList) {
        statusList.push(s);
    }

    res.json(statusList);
}

exports.getAllDefaultStatus = (req, res) => {
    StatusOfCandidate.find({
        default: true
    }).then(listStatus => {
        res.json(listStatus)
    }).catch(err => {
        return res.status(500).send({
            message: Utils.getErrorMessageFromModel(err)
        })
    })
}