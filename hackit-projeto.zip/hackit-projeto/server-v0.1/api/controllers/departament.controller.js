'use strict'
var mongoose = require('mongoose'),
    Utils = require('../../domain/utils/util'),
    Departament = require('../../domain/models/departament').Departament

exports.getAllDepartament = async (req, res) => {
    var query = {};

    query.company_id = req.params.id_company;
        Departament.find(query, (err, ret) =>{
        if(err){
            return err;
        }
        if(!ret){

            return res.status(400).send({
                message: 'falha ao pesquisar'
            })
        }
        return res.status(200).json(ret);
    })
}

exports.createDepartament = async (req, res) => {
    let body = req.body;

    let departament = new Departament(body);

    departament.save()
        .then((dptsave) => {
            res.json(dptsave);
        })
        .catch(err => {
            res.status(400).send({
                message: "não salvou"
            })
        });
}