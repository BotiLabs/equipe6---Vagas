'use strict';

var mongoose = require('mongoose'),
    Qualification = require('../../domain/models/qualification').Qualification,
    Candidate = require('../../domain/models/candidate').Candidate,
    Utils = require('../../domain/utils/util'),
    Tag = require('../../domain/models/tag').Tag;


exports.create = async (req, res) => {
    var qualifications = req.body;
    var length = qualifications.length;

    await findCandidates(qualifications);

    await validateTags(qualifications);

    await validateQualifications(qualifications);

    if (qualifications.length > 0) {
        Qualification.insertMany(qualifications, function (error, docs) {
            if (error) {
                return res.status(400).send({
                    message: Utils.getErrorMessageFromModel(error)
                });
            }
            var insertedMsg = "";
            var duplicatedMsg = "";
            var duplicateds = length - qualifications.length;;

            switch (qualifications.length) {
                case 1:
                    insertedMsg = "1 candidato importado com sucesso"
                    break;
                case 0:

                    break;

                default:
                    insertedMsg = qualifications.length.toString() + " candidatos importados com sucesso"
                    break;
            }

            switch (duplicateds) {
                case 1:
                    duplicatedMsg = " e 1 candidato já existia no sistema."
                    break;
                case 0:

                    break;
                default:
                    duplicatedMsg = " e " + duplicateds + " candidatos já existiam no sistema."
                    break;
            }
            res.json({ "insertedMsg": insertedMsg, "duplicatedMsg": duplicatedMsg });
            // res.json(qualifications);
        })
    } else {
        return res.status(400).send({
            message: "Estes candidatos já existem no sistema"
        });
    }
}


async function validateQualifications(qualifications) {
    var qualificationsArray = []
    qualifications.forEach(qualification => {
        qualificationsArray.push(qualification.email)
    })

    await Qualification.find({ "email": { $in: qualificationsArray } })
        .then(res => {
            res.forEach(r => {
                if (qualifications.indexOf(r)) {
                    qualifications.splice(r, 1)
                }
            })
            return qualifications;
        }).catch(err => {
            return res.status(400).send({
                message: Utils.getErrorMessageFromModel(err)
            });
        })
}

async function findCandidates(qualifications) {
    var qualificationsArrayFind = []
    var qualificationCandidate = [];
    qualifications.forEach(qualification => {
        qualificationsArrayFind.push(qualification.email)
    })
    await Candidate.find({ "email": { $in: qualificationsArrayFind } })
        .then(candidates => {
            candidates.forEach(qualification => {
                qualificationCandidate.push(qualification.email)
            })

            qualifications.forEach(candidate => {
                var index = qualificationCandidate.indexOf(candidate.email)
                if (index > -1) {
                    candidates[index].mainSkills = qualifications[qualifications.indexOf(candidate)].mainSkills;
                    candidates[index].secondarySkills = qualifications[qualifications.indexOf(candidate)].secondarySkills;
                    candidates[index].desiredHiring = qualifications[qualifications.indexOf(candidate)].desiredHiring;
                    candidates[index].discription = qualifications[qualifications.indexOf(candidate)].discription;
                    candidates[index].save()
                        .then(result => { })
                        .catch(err => { console.log(err) })
                } else {
                    var candidateToSave = new Candidate(candidate)
                    var hour = new Date().getTime()
                    candidateToSave.registrationDate = new Date(hour)
                    candidateToSave.save()
                        .then(result => { console.log(result) })
                        .catch(err => { console.log(err) })
                }
            })
        })
        .catch(err => {
            console.log(err)
        })
}

async function validateTags(qualifications) {
    var tagsQualifications = []
    qualifications.forEach(qualificationTags => {
        qualificationTags.mainSkills.map(tag => {
            tagsQualifications.push(tag)
        })
        qualificationTags.secondarySkills.map(tag => {
            tagsQualifications.push(tag)
        })
    });

    await Tag.find({})
        .then(tags => {
            var tagsNames = [];
            tags.forEach(r => {
                tagsNames.push(r.name)
            });
            tagsQualifications.map(tag => {
                if (tagsNames.indexOf(tag) == -1) {
                    var tagToSave = new Tag();
                    tagToSave.name = tag;
                    tagToSave.save()
                        .then(savedTag => {
                            console.log(savedTag);
                        })
                        .catch(err => {
                            console.log(err);
                        })
                    tagsNames.push(tag)
                }
            })
        })
        .catch(err => {

        })
}