'use strict'
var mongoose = require('mongoose'),
    Utils = require('../../domain/utils/util'),
    StatusOfOpportunity = require('../../domain/models/statusOpportunity').StatusOfOpportunity;

exports.getAll = (req, res) => {
    StatusOfOpportunity.find({})
        .then(statusOpp => {
            res.json(statusOpp);
        })
        .catch(err => {
            return res.status(400).json({ "message": Utils.getErrorMessageFromModel(err) })
        })
}