'use strict'

var mongoose = require('mongoose'),
    Utils = require('../../domain/utils/util'),
    Func = require('../../domain/models/function').Function;



exports.create = (req, res) => {
    let func = new Func(req.body);
    let hour = new Date().getTime();
    let date = new Date(hour);
    func.registrationDate = date;
    func.save()
        .then(savedFunc => {
            res.json(savedFunc);
        })
        .catch(err => {
            return res.status(500).send({
                message: Utils.getErrorMessageFromModel(err)
            })
        })
}

exports.getAllFuncs = (req, res) => {
    Func.find({
            company_id: req.company_id
        })
        .then(funcs => {
            res.json(funcs)
        })
        .catch(err => {
            return res.status(500).send({
                message: Utils.getErrorMessageFromModel(err)
            })
        })
}

exports.createId = (req, res, next, id) => {
    req.company_id = id;
    next();
}