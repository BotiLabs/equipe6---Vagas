'use strict'
var mongoose = require('mongoose'),
    Utils = require('../../domain/utils/util'),
    Approach = require('../../domain/models/approach').Approach;

exports.getAll = (req, res) => {
    Approach.find({})
        .then(approach => {
            res.json(approach);
        })
        .catch(err => {
            return res.status(500).json({
                "message": Utils.getErrorMessageFromModel(err)
            })
        })
}