'use strict';

var mongoose = require('mongoose'),
    Utils = require('../../domain/utils/util'),
    Location = require('../../domain/models/location').Location;

//Insert a new location
exports.create = (req, res) => {

    var body = req.body;
    var location = new Location(body);
    location.discription = body.discription.toLowerCase();
    location.save((err) => {
        if (err) {
            if (err.code == 11000) {
                return res.status(400).send({
                    message: "Uma pesquisa com esta descrição já foi cadastrada"
                });
            } else {
                return res.status(400).send({
                    message: Utils.getErrorMessageFromModel(err)
                });
            }
        } else {
            res.json(location);
        }
    });
};

exports.read = (req, res) => {
    res.json(req.location);
};

exports.search = (req, res) => {
    let objRes = {
        result: null,
        count: 0
    };
    var query = {};
    var body = req.body;
    query.company_id = body.company_id;

    if (body.streetAddress !== undefined && body.streetAddress !== "")
        query.streetAddress = new RegExp(body.streetAddress, 'i');

    if (body.district !== undefined && body.district !== "")
        query.district = new RegExp(body.district, 'i');

    if (body.state !== undefined && body.state !== "")
        query.state = new RegExp(body.state, 'i');

    if (body.discription !== undefined && body.discription !== "")
        query.discription = new RegExp(body.discription, 'i');

    query.clientLocation = body.clientLocation;


    Location.count(query, function (err, count) {
        if (err) {
            res.status(404).send({
                message: Utils.getErrorMessageFromModel(err)
            });
        } else {
            objRes.count = count;
            Location.find(query, function (err, result) {
                if (err) {
                    res.status(404).send({
                        message: Utils.getErrorMessageFromModel(err)
                    });
                } else {
                    objRes.result = result;
                    res.json(objRes);
                    // console.log(objRes);
                }
            }).skip(body.limit * (body.page - 1)).limit(body.limit);
        }
    });
};

//Find a company_id to next method
exports.prepareCompanyId = (req, res, next, id) => {
    req.company_id = id;
    next()
};

exports.list = (req, res) => {
    Location.find({
            company_id: req.company_id
        })
        .populate('logs')
        .sort('-created_at').exec((err, Location) => {
            if (err) {
                res.status(400).send({
                    message: Utils.getErrorMessageFromModel(err)
                });
            } else {
                res.json(Location);
            }
        });
};


exports.locationById = (req, res, next, id) => {
    Location.findById(id, (err, location) => {
        if (err) {
            return next(err);
        }
        if (!location) {
            return res.status(400).send({
                message: 'Failed to load location ' + id
            });
        }

        req.location = location;
        next();
    })
};

//Update a location
exports.update = (req, res) => {
    var location = req.location;

    for (var prop in req.body) {
        location[prop] = req.body[prop];
    }
    location.save((err) => {
        if (err) {
            return res.status(400).send({
                message: Utils.getErrorMessageFromModel(err)
            });
        } else {
            res.json(location)
        }
    });
};