'use strict';

var mongoose = require('mongoose'),
    Utils = require('../../domain/utils/util'),
    LogUser = require('../../domain/models/log').LogUser;

//Insert a new log
exports.create = (req, res) => {

    LogUser.find().sort({ number: -1 }).limit(1)
        .exec()
        .then((result => {
            let logs = [];

            var logUser = new LogUser(req.body);
            if (result) {
                if(result[0].number){
                logUser.number = ++result[0].number;
                }
            }else{
                logUser.number = 1;
            }
            logs.push(logUser);


            logUser.save(logs, function (err, docs) {
                if (err) {
                    return res.status(400).send({
                        message: Utils.getErrorMessageFromModel(err)
                    });
                } else {
                    return res.json(docs);
                }
            });
        }));
};

//List existing logs
exports.list = (req, res) => {
    LogUser.find({company_id: req.company_id})
        .populate('logs')
        .sort('-created_at').exec((err, LogUser) => {
            if (err) {
                res.status(400).send({
                    message: Utils.getErrorMessageFromModel(err)
                });
            } else {
                res.json(LogUser);
            }
        });
};

//Find a company_id to next method
exports.prepareCompanyId = (req, res, next, id) => {
    req.company_id = id;
    next()
};

exports.search = (req, res) => {
    let objRes = {
        result: null,
        count: 0
    };

    var body = req.body;
    var mysort = { number: -1 };
    var userFirstName = new RegExp(body.userEmail, "i");
    var userEmail = new RegExp(body.userFirstName, "i");
    var discriptionLog = new RegExp(body.discriptionLog, "i");
    var company_id = new RegExp(body.company_id, "i");


    LogUser.count({ $or: [{ userEmail }, { userFirstName }, { discriptionLog }, {company_id}] }, function (err, count) {
        if (err) {
            res.status(404).send({
                message: Utils.getErrorMessageFromModel(err)
            });
        } else {
            objRes.count = count;

            if(body.sort){
                LogUser.find({ $or: [{ userEmail }, { userFirstName }, { discriptionLog }, {company_id}] }).sort(body.sort['query']).skip(body.limit * (body.page - 1)).limit(body.limit).exec((error, logs) => {
                    if(error){
                       return   res.status(400).send({
                           message: Utils.getErrorMessageFromModel(err)
                       });
                    }else{
           
                       objRes.result = logs;
                     res.json(objRes);
                    
                    }
                   })
            }else{
                LogUser.find({ $or: [{ userEmail }, { userFirstName }, { discriptionLog }, {company_id}] }, function (err, result) {
                    if (err) {
                        res.status(404).send({
                            message: Utils.getErrorMessageFromModel(err)
                        });
                    } else {
                        objRes.result = result;
                        res.json(objRes);
                    }
                }).sort(mysort).skip(body.limit * (body.page - 1)).limit(body.limit);
            }
        }
    });
};


exports.searchOnInit = (req, res) => {
    let objRes = {
        result: null,
        count: 0
    };

    var query = {};
    var mysort = { number: -1 };
    var body = req.body;
    query.company_id = body.company_id;

    query.userEmail = body.userEmail;
    LogUser.count(query, function (err, count) {
        if (err) {
            res.status(404).send({
                message: Utils.getErrorMessageFromModel(err)
            });
        } else {
            objRes.count = count;
            LogUser.find(query, function (err, result) {
                if (err) {
                    res.status(404).send({
                        message: Utils.getErrorMessageFromModel(err)
                    });
                } else {
                    objRes.result = result;
                    res.json(objRes);
                }
            }).sort(mysort).skip(body.limit * (body.page - 1)).limit(body.limit);
        }
    });
};