'use strict';
var Configuration = require('../../domain/models/configuration').Configuration;

var fetch = require('node-fetch');
exports.findCandidatesToUpdate = async () => {

    var data = await Configuration.findOne();

    if (data.statusRobot == true) {
        console.log("Configuração Robo Status ligada.")

        // console.log("executou");
        var candidates = await fetch('http://localhost:3000/api/candidate/listupdate').then(response => {
            return response.json()
        }).then(json => {
            return json
        });

        var hour = new Date().getTime();
        var registrationDate = hour - 1728000000;

        var interactionsArray = []
        // console.log(candidates)
        for (let c of candidates) {
            var body = {
                "candidateId": c._id,
                "registrationDate": registrationDate
            }
            var interactions = await fetch('http://localhost:3000/api/interactions/updatecandidate', {
                    method: 'POST',
                    body: JSON.stringify(body),
                    headers: {
                        'Content-Type': 'application/json'
                    }
                })
                .then(response => {
                    return response.json()
                })
                .then(json => {
                    return json
                });
            interactionsArray.push({
                "candidateId": c._id,
                "interactions": interactions
            });
            // console.log(interactions);
            if (interactions.length < 1) {
                fetch('http://localhost:3000/api/candidate/updateaftertwentydays', {
                        method: 'POST',
                        body: JSON.stringify(c),
                        headers: {
                            'Content-Type': 'application/json'
                        }
                    })
                    .then(response => {
                        return response.json()
                    })
                    .then(json => {
                        return json
                    });
                interactionsArray.push({
                    "candidateId": c._id,
                    "interactions": interactions
                });

                if (interactions.length < 1) {
                    fetch('http://localhost:3000/api/candidate/updateaftertwentydays', {
                            method: 'POST',
                            body: JSON.stringify(c),
                            headers: {
                                'Content-Type': 'application/json'
                            }
                        })
                        .then(response => {
                            console.log(response.json())
                        })
                        .then(json => {
                            console.log(json)
                        });
                }
            }
        }
    } else {
        console.log("Configuração Robo Status desligada.")

    }
}