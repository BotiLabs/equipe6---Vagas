'use strict';

var mongoose = require('mongoose'),
    Testing = require('../../domain/models/testing').Testing,
    Utils = require('../../domain/utils/util'),
    shuffle = require('shuffle-array')

//Find a company_id to next method
exports.prepareCompanyId = (req, res, next, id) => {
    req.company_id = id;
    next()
};

exports.createTesting = (req, res) => {
    var testing = new Testing(req.body);

    testing.save((err) => {
        if (err) {
            return res.status(400).send({
                message: Utils.getErrorMessageFromModel(err)
            });
        } else {
            res.json(testing);
        }
    });
}

exports.list = (req, res) => {
    Testing.find({
            company_id: req.company_id
        })
        .sort('date').exec((err, testing) => {
            if (err) {
                return res.status(400).send({
                    message: Utils.getErrorMessageFromModel(err)
                });
            } else {
                res.json(testing);
            }
        });
}

exports.delete = (req, res) => {
    var testing = req.testing;
    testing.remove((err) => {
        if (err) {
            return res.status(400).send({
                message: Utils.getErrorMessageFromModel(err)
            });
        } else {
            res.json(testing);
        }
    });
}

exports.testingById = (req, res, next, id) => {
    Testing.findById(id, (err, testing) => {
        if (err) {
            return next(err);
        }
        if (!testing) {
            return res.status(400).send({
                message: 'Failed to load testing ' + id
            });
        }

        req.testing = testing;
        next();
    })
};

//por tipo
exports.search = (req, res) => {
    let themes = [];
    let aux = [];
    let questions = [];
    let item = [];


    item = req.body['type'];

    Testing.aggregate(
        [{
            $match: {
                company_id: req.body.company_id
            }
        }, {
            "$group": {
                _id: '$theme'
            }

        }],
        (err, result) => {
            if (err) {
                res.status(400).send({
                    message: Utils.getErrorMessageFromModel(err)
                });
            } else {
                result.map(theme => themes.push(theme._id))
            }
            if (result.length == 0) {
                res.json([]);
            }

            Testing.find().sort("type").where("type").in(item).exec((err, result) => {
                if (err) {
                    res.status(404).send({
                        message: Utils.getErrorMessageFromModel(err)
                    });
                } else {
                    for (let item of themes) {
                        result.map(testing => item == testing.theme ? aux.push(testing) : "")
                        questions.push(shuffle.pick(aux, {
                            'picks': 3
                        })) // <----
                        aux = [];
                    }

                    questions = questions.reduce((a, b) => {
                        return a.concat(b)
                    });
                    res.json(questions);
                }
            })
        }
    )
};