'use strict';

var mongoose = require('mongoose'),
  Utils = require('../../domain/utils/util'),
  watson = require('watson-developer-cloud');

const translate = require('google-translate-api');

exports.translate = (req, res) => {
  var text = req.body.text;

  var language_translator = watson.language_translator({
    "url": "https://gateway.watsonplatform.net/language-translator/api",
    "username": "2f77c7f0-422d-4230-929c-9282445d2967",
    "password": "gaHZI0x0xW8P",
    "version": 'v2'
  });

  language_translator.translate({
      "text": text,
      "source": "pt",
      "target": "en"
    }, function(err, translation) {
    if (err)
      res.json(err)
    else
      res.json(translation.translations[0]);
  });
}

exports.personalInsights = (req, res) => {
  var personality_insights = watson.personality_insights({
    username: '4d8ba657-8c08-4171-934f-7c3148f8ead9',
    password: 'ERaQO7YqSzvc',
    version: 'v2'
  });

  var params = req.body.text;

  personality_insights.profile({
    "text": {
    "contentItems": [
       {
           "content": params,
           "created": 1447639154000,
           "id": "666073008692314113",
           "language": "en",
           "sourceid": "Text Example",
           "userid": "Test 2017-10-16"
        }
      ]
   }
  }, function (error, response) {
    if (error) {
      console.log('error:', error);
      res.json(error); 
    }
    else
      if(response) {
          var result = [];
          
          var personality = response.tree.children[0].children[0].children;
          // var needs = response.tree.children[1].children[0];
          // var values = response.tree.children[2].children[0].children[1];
          
          for(let key of personality) {
              result.push({ name: key.name, percentage: parseFloat(key.percentage).toFixed(2) });
          }
    
          // result.push({ name: needs.name, percentage: parseFloat(needs.percentage).toFixed(2) });
          // result.push({ name: values.name, percentage: parseFloat(values.percentage).toFixed(2) });
    
          res.json(result);
      }
  });
}
