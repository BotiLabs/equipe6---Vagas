'use strict'
var mongoose = require('mongoose'),
    Utils = require('../../domain/utils/util'),
    Origin = require('../../domain/models/origin').Origin;


exports.getAll = (req, res) => {
    Origin.find({})
        .then(origin => {
            res.json(origin);
        })
        .catch(err => {
            return res.status(400).json({ "message": Utils.getErrorMessageFromModel(err) })
        })
}