var evaluation = require('../controllers/evaluation.server.controller'),
    testing = require('../controllers/evaluation.server.controller'),
    auth = require('../controllers/auth.server.controller');

module.exports = (app) => {
    app.route('/api/evaluations')
        .post(auth.ensureAuthenticated, evaluation.create);

    app.route('/api/evaluations/getall/:companyId')
        .get(auth.ensureAuthenticated, evaluation.list)

    app.route('/api/evaluations/type')
        .post(auth.ensureAuthenticated, evaluation.getType)

    app.route('/api/evaluations/search')
        .post(auth.ensureAuthenticated, evaluation.search)

    app.route('/api/evaluations/testing')
        .post(auth.ensureAuthenticated, evaluation.push)
        .put(auth.ensureAuthenticated, evaluation.saveAnswers);

    app.route('/api/evaluations/email')
        .post(evaluation.findEvaluationByEmail);


    app.route('/api/evaluations/sum')
        .post(auth.ensureAuthenticated, evaluation.sum);

    app.route('/api/evaluations/:evaluationId')
        .get(auth.ensureAuthenticated, evaluation.read)
        .put(auth.ensureAuthenticated, evaluation.update)
        .delete(auth.ensureAuthenticated, evaluation.delete)


    app.param('evaluationId', evaluation.evaluationById);
    app.param('companyId', evaluation.prepareCompanyId);
}