var getCityState = require('../controllers/cityState.server.controller');

module.exports = (app) => {
    app.route('/api/citystate')
        .get(getCityState.cityState)
}