var personality = require('../controllers/personality.server.controller'),
auth = require('../controllers/auth.server.controller');

module.exports = (app) => {
    app.route('/api/translate')
        .post(personality.translate);
    
    app.route('/api/personality')
        .post(personality.personalInsights);
}