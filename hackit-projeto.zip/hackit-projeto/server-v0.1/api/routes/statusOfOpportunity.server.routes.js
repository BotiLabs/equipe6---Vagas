var statusOpp = require('../controllers/statusOfOpportunity.controller'),
    auth = require('../controllers/auth.server.controller');

module.exports = (app) => {
    app.route('/api/statusopportunity')
        .get(auth.ensureAuthenticated, statusOpp.getAll)
        // .post(auth.ensureAuthenticated, statusCan.create);

}

