var testing = require('../controllers/testing.server.controller'),
    auth = require('../controllers/auth.server.controller');

module.exports = (app) => {
    app.route('/api/testing')
        .post(auth.ensureAuthenticated, testing.createTesting);

    app.route('/api/testing/getall/:companyId')
        .get(auth.ensureAuthenticated, testing.list)

    app.route('/api/testing/:testingId')
        .delete(auth.ensureAuthenticated, testing.delete)

    app.route('/api/testing/search')
        .post(auth.ensureAuthenticated, testing.search);

    app.param('testingId', testing.testingById);
    app.param('companyId', testing.prepareCompanyId);
}