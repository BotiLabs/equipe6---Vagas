var origin = require('../controllers/origin.server.controller'),
    auth = require('../controllers/auth.server.controller');

module.exports = (app) => {
    app.route('/api/origin')
        .get( origin.getAll)
        // .post(auth.ensureAuthenticated, statusCan.create);
}

