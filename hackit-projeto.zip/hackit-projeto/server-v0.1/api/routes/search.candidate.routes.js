var searchCandidate = require('../controllers/search.candidate.server.controller');
auth = require('../controllers/auth.server.controller');

module.exports = (app) => {
    app.route('/api/searchcan')
        .post(auth.ensureAuthenticated, searchCandidate.create);

    app.route('/api/searchcan/search')
        .post(auth.ensureAuthenticated, searchCandidate.search);

    app.route('/api/searchcan/:searchId')
        .get(auth.ensureAuthenticated, searchCandidate.read)
        .put(auth.ensureAuthenticated, searchCandidate.update)
        .delete(auth.ensureAuthenticated, searchCandidate.delete);

    app.param('searchId', searchCandidate.searchCandidateById);
}