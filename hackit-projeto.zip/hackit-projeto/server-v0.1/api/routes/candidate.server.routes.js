var candidate = require('../controllers/candidate.server.controller'),
    auth = require('../controllers/auth.server.controller');
var multipart = require('connect-multiparty');
var multipartMiddleware = multipart();
var express = require('express');

var app = express()
module.exports = (app) => {
    app.param('candidateId', candidate.candidateById);
    app.param('companyId', candidate.prepareCompanyId);

    app.route('/api/candidates')
        .post(multipartMiddleware, candidate.create, function (req, res) { });

    app.route('/api/candidates/getall/:companyId')
        .get(auth.ensureAuthenticated, candidate.list)

    app.route('/api/candidates/count/:companyId')
        .get(auth.ensureAuthenticated, candidate.count);

    app.route('/api/candidates/match')
        .post(auth.ensureAuthenticated, candidate.searchForMatch);

    app.route('/api/candidates/search')
        .post(auth.ensureAuthenticated, candidate.search);

    app.route('/api/candidates/:candidateId')
        .get(auth.ensureAuthenticated, candidate.read)
        .put(multipartMiddleware, candidate.update, function (req, res) { })
        .delete(auth.ensureAuthenticated, candidate.delete);

    app.route('/api/candidate/origin/:companyId')
        // .get(candidate.listByOriginWithDate)
        .post(candidate.listByOriginWithDate);

    app.route('/api/candidate/profile/:companyId')
        .get(candidate.listByProfile);

    app.route('/api/candidate/sort')
        .post(auth.ensureAuthenticated, candidate.sortCandidate);

    app.route('/api/candidate/blocked/:companyId')
        .post(candidate.findBlockedCandidates);

    app.route('/api/candidate/fc')
        .post(auth.ensureAuthenticated, candidate.createSangueLaranja);

    app.route('/api/candidate/candidatejourney')
        .post(candidate.reportCandidateJourney);

    app.route('/api/candidate/candiatejourneyxlsv')
        .post(candidate.candidateJourneyToXlsv);

    app.route('/api/candidate/listupdate')
        .get(candidate.listCandidateToUpdate);

    app.route('/api/candidate/updateaftertwentydays')
        .post(candidate.updateAfter20Days);

    app.route('/api/candidate/process/:companyId')
        .get(candidate.processReport);

    app.route('/api/candidate/candidatesinterviews/:companyId')
        .get(candidate.getCandidatesAndInterviews);

    // app.route('/api/candidate/findcv')
    // .get(candidate.addTextCv);


    // app.route('/api/candidate/addmainskills')
    // .get(candidate.addPrimarySkills);

    app.route('/api/candidate/findcv')
        .get(candidate.addTextCv);

    app.route('/api/candidate/addmainskills')
        .get(candidate.addPrimarySkills);

    app.route('/api/candidate/upload/:companyId')
        .post(multipartMiddleware, candidate.uploadCurriculum, function (req, res) { console.log(req.body) });

    app.route('/api/candidate/exportlist/:companyId')
        .post(candidate.exportCandidatesToXlsx);

    app.route('/api/candidate/exportlistorigins/:companyId')
        .post(candidate.originReportToXlsv);

    app.route('/api/candidate/email/:companyId')
        .post(candidate.getCandidateByEmail);

    app.route('/api/candidate/location')
        .post(candidate.locationInfo);

    app.route('/api/candidate/distance')
        .post(candidate.distanceBetween);

        app.route('/api/candidate/locationcep')
            .post(candidate.locationInfoCep);

    app.route('/api/candidate/extracttext')
        .get(candidate.extractText);

    app.route('/api/candidate/searchrecruiter/:candidateId')
        .get(candidate.searchRecruiter);

}