var searchOp = require('../controllers/search.opportunity.server.controller');
auth = require('../controllers/auth.server.controller');

module.exports = (app) => {
    app.route('/api/searchopp')
        .post(auth.ensureAuthenticated, searchOp.create);

    app.route('/api/searchopp/search')
        .post(auth.ensureAuthenticated, searchOp.search);

    app.route('/api/searchopp/:searchOpId')
        .get(auth.ensureAuthenticated, searchOp.read)
        .put(auth.ensureAuthenticated, searchOp.update)
        .delete(auth.ensureAuthenticated, searchOp.delete);

    app.param('searchOpId', searchOp.searchOpportunityById);
}