var depart = require('../controllers/departament.controller'),
    auth = require('../controllers/auth.server.controller');

module.exports = (app) => {
    app.route('/api/departament/:id_company')
        .get(depart.getAllDepartament)
        .post(depart.createDepartament);
}
