var qualification = require('../controllers/qualification.server.controller'),
    auth = require('../controllers/auth.server.controller');

module.exports = (app) => {
    app.route('/api/qualifications')
        // .get(qualification.list)// auth.ensureAuthenticated
        .post(auth.ensureAuthenticated, qualification.create);

}