var configuration = require('../controllers/configuration.server.controller');

module.exports = (app) => {
    app.route('/api/configuration/:companyId')
    .put(configuration.update)

    app.route('/api/configuration/:companyId')
    .get(configuration.get)
    .post(configuration.create)

    app.param('companyId', configuration.configurationId)
}
