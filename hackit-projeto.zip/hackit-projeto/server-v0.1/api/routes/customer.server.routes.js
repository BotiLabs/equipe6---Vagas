var custumer = require('../controllers/customer.server.controller'),
    auth = require('../controllers/auth.server.controller');

module.exports = (app) => {
    app.param('companyId', custumer.prepareCompanyId);
    
    app.route('/api/customer')
        .post(custumer.create)

    app.route('/api/customer/getall/:companyId')
        .get(custumer.list); //auth.ensureAuthenticated,

    app.route('/api/customer/search')
        .post(custumer.search);


    app.route('/api/customer/:customerId')
        .get(auth.ensureAuthenticated, custumer.read)
        .put(custumer.update);


    app.route('/api/customer/update/:customerId')
        .put(auth.ensureAuthenticated, custumer.updateToDelete);

    app.param('customerId', custumer.customerById);

    app.route('/api/customer/update')
        .post(custumer.updateLocationsCustomer);

    app.route('/api/customer/custoById')
        .post(custumer.cusById)
}
