var interaction = require('../controllers/interaction.server.controller'),
    auth = require('../controllers/auth.server.controller');

module.exports = (app) => {
    app.route('/api/interactions')
        .post(interaction.create)
        .get(auth.ensureAuthenticated, interaction.list);

    app.route('/api/interactions/search')
        .post(interaction.search);    

    app.route('/api/interactions/candidates/:candidateId')
        .get(auth.ensureAuthenticated, interaction.findByCandidateId);


    app.route('/api/interactions/:interactionId')
        .delete(auth.ensureAuthenticated, interaction.delete)
        .put(auth.ensureAuthenticated, interaction.update);

    app.param('interactionId', interaction.interactionById);

    app.route('/api/interactions/report/:companyId')
        .get(auth.ensureAuthenticated, interaction.report)
        .post(auth.ensureAuthenticated, interaction.reportWithDate);

    app.route('/api/interactions/reportcontratation/:companyId')
        .get(auth.ensureAuthenticated, interaction.reportContratation)
        .post(auth.ensureAuthenticated, interaction.reportContratationBetWeenDate);

    app.route('/api/interactions/updatecandidate')
        .post(interaction.listInteractionToUpdateCandidate);

    app.route('/api/interactions/findtodisapprove/:companyId')
        .post(interaction.findToChangeStatusToDisapprove);

    app.param('companyId', interaction.prepareCompanyId);

    app.route('/api/interactions/actionreport/:companyId')
        .post(auth.ensureAuthenticated, interaction.actionReport);

    app.route('/api/interactions/reporthired')
        .post(auth.ensureAuthenticated, interaction.createHired);

    app.route('/api/interactions/findreporthired/:companyId')
        .post(auth.ensureAuthenticated, interaction.reportHired);

    app.route('/api/interactions/exportlist/:companyId')
        .post(auth.ensureAuthenticated, interaction.actionReportXlsv);

    app.route('/api/interactions/exportcontratationreport/:companyId')
        .post(auth.ensureAuthenticated, interaction.contratationReportXlsv);
}