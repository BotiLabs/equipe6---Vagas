var office = require('../controllers/office365.server.controller');

module.exports = (app) => {
    app.route('/api/token/office365')
        .get(office.authOffice365)
}