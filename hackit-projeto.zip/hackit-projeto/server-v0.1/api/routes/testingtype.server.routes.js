var testingtype = require('../controllers/testingtype.server.controller'),
    auth = require('../controllers/auth.server.controller');

module.exports = (app) => {
    app.route('/api/testingtype')
        .post(auth.ensureAuthenticated, testingtype.create);

    app.route('/api/testingtype/getall/companyId')
        .get(auth.ensureAuthenticated, testingtype.list)

    app.route('/api/testingtype/search')
        .post(auth.ensureAuthenticated, testingtype.search);

    app.route('/api/testingtype/:questionsId')
        .get(auth.ensureAuthenticated, testingtype.read)
        .put(auth.ensureAuthenticated, testingtype.update)
        .delete(auth.ensureAuthenticated, testingtype.delete);

    app.param('questionsId', testingtype.questionsById);
    app.param('companyId', testingtype.prepareCompanyId);
}