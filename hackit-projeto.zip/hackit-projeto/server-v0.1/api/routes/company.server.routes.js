var company = require('../controllers/company.server.controller'),
    auth = require('../controllers/auth.server.controller');

module.exports = (app) => {
    app.route('/api/companies')
        .post(company.create)
        .get(auth.ensureAuthenticated, company.list);

    app.route('/api/companies/:companyId')
        .delete(auth.ensureAuthenticated, company.delete)
        .put(auth.ensureAuthenticated, company.update)
        .get(auth.ensureAuthenticated, company.getCompanyById);

    app.param('companyId', company.companyById);

    
    app.route('/api/companies/search')
        .post(auth.ensureAuthenticated, company.search);
}
