var position = require('../controllers/position.server.controller'),
    auth = require('../controllers/auth.server.controller');

module.exports = (app) => {
    app.route('/api/position/:company_id')
        .get(position.getAllPosition)
        .post(position.createPosition);}
