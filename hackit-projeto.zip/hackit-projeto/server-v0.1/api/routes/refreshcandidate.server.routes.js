var refresh = require('../controllers/refreshcandidates.server.controller');

module.exports = (app) => {
    app.route('/api/refreshcandidates')
        .get(refresh.findCandidatesToUpdate);
    

}


