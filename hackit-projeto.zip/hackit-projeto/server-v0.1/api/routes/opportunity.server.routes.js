var opportunity = require('../controllers/opportunity.server.controller'),
    auth = require('../controllers/auth.server.controller');

module.exports = (app) => {
    app.route('/api/opportunities')
        .post(opportunity.create)

    app.route('/api/opportunities/getall/:companyId')
        .get(auth.ensureAuthenticated, opportunity.list);

    app.route('/api/opportunities/opportunities_terceiros')
        .get(auth.ensureAuthenticated, opportunity.listTerceiros);

    app.route('/api/opportunities/count/:companyId')
        .get(auth.ensureAuthenticated, opportunity.count);

    app.route('/api/opportunities/search')
        .post(opportunity.search);

    app.route('/api/opportunities/searchanything')
        .post(opportunity.searchAnything)

    app.route('/api/opportunities/:opportunityId')
        .get(auth.ensureAuthenticated, opportunity.read)
        .put(opportunity.update)
        .delete(auth.ensureAuthenticated, opportunity.delete);

    app.param('opportunityId', opportunity.opportunityById);

    app.param('companyId', opportunity.prepareCompanyId);

    app.route('/api/businessUnit/:companyId')
        .get(auth.ensureAuthenticated, opportunity.listByBusinessUnit);

    app.route('/api/customerName/:companyId')
        .get(auth.ensureAuthenticated, opportunity.listByCustommer);

    app.route('/api/registrationDateOpp/:companyId')
        .get(auth.ensureAuthenticated, opportunity.getBetweenDate);

    app.route('/api/opportunity/sort/:companyId')
        .post(auth.ensureAuthenticated, opportunity.sortOpportunity);

    app.route('/api/opportunity/interaction/:companyId')
        .get(auth.ensureAuthenticated, opportunity.listForInteraction);

    app.route('/api/opportunity/status/:companyId')
        .get(auth.ensureAuthenticated, opportunity.listByStatus);

    app.route('/api/opportunity/reportclosed/:companyId')
        .post(opportunity.reportClosedOpportunities);

    app.route('/api/opportunities/opportunitysimilar')
        .post(opportunity.findSkillsOpportunity);

    app.route('/api/opportunities/deletecandidate')
        .post(opportunity.deleteCandidateOpportunity);

    app.route('/api/opportunity/priorityopp/:companyId')
        .get(auth.ensureAuthenticated, opportunity.getPriorityCount);

    app.route('/api/opportunity/countcandidates/:companyId')
        .get(opportunity.candidatesOpportunitiesCount);


    app.route('/api/opportunity/involvedPeople/:opportunityId')
        .post(opportunity.updateInvolvedPeople);

    app.route('/api/opportunity/exportlist/:companyId')
        .post(opportunity.exportOpportunitiesToXlsx);

    app.route('/api/slaopp/:companyId')
        .get(opportunity.slaOpp);

    app.route('/api/opportunities/searchbystatus/:companyId')
        .post(opportunity.searchByStatus);

    app.route('/api/opportunities/searchforprofile/:opportunityId')
        .get(opportunity.findOppForProfile)

}