var notificationUser = require('../controllers/notification.server.controller'),
    auth = require('../controllers/auth.server.controller');

module.exports = (app) => {
    app.route('/api/notification')
        .post(notificationUser.create)

    app.route('/api/notification/:notificationId')
        .get(auth.ensureAuthenticated, notificationUser.read)
        .delete(notificationUser.delete)


    app.param('notificationId', notificationUser.notificationById);

    app.route('/api/notification/searchoninit')
        .post(notificationUser.searchOnInit);

}