var softskills = require('../controllers/softskills.server.controller'),
    auth = require('../controllers/auth.server.controller');

module.exports = (app) => {
    app.route('/api/softskills')
        .post(softskills.create);

        app.route('/api/softskills/getall/:companyId')
            .get(softskills.list)// auth.ensureAuthenticated

    app.route('/api/softskills/search')
        .post(auth.ensureAuthenticated, softskills.search);


    app.route('/api/softskills/:softskillsId')
        .get(auth.ensureAuthenticated, softskills.read)
        .put(auth.ensureAuthenticated, softskills.update)
        .delete(auth.ensureAuthenticated, softskills.delete);


    app.route('/api/softskills/update/:softskillsId')
        .put(auth.ensureAuthenticated, softskills.updateToDelete);

    app.param('softskillsId', softskills.softskillsById);
    app.param('companyId', softskills.prepareCompanyId);

    app.route('/api/softskills/searchifexists')
        .post(softskills.searchIfExists);
}