var tag = require('../controllers/tag.server.controller'),
    auth = require('../controllers/auth.server.controller');

module.exports = (app) => {
    app.route('/api/tags')
        .post(tag.create);

        app.route('/api/tags/getall/:companyId')
            .get(tag.list)// auth.ensureAuthenticated

    app.route('/api/tags/search')
        .post(auth.ensureAuthenticated, tag.search);


    app.route('/api/tags/:tagId')
        .get(auth.ensureAuthenticated, tag.read)
        .put(auth.ensureAuthenticated, tag.update)
        .delete(auth.ensureAuthenticated, tag.delete);


    app.route('/api/tags/update/:tagId')
        .put(auth.ensureAuthenticated, tag.updateToDelete);

    app.param('tagId', tag.tagById);
    app.param('companyId', tag.prepareCompanyId);

    app.route('/api/tags/searchifexists')
        .post(tag.searchIfExists);
}