var functions = require('../controllers/function.server.controller'),
    auth = require('../controllers/auth.server.controller');

module.exports = (app) => {
    app.route('/api/functions')
        .post(functions.create);

    app.route('/api/functions/:companyId')
        .get(functions.getAllFuncs)

    app.param('companyId', functions.createId)

}