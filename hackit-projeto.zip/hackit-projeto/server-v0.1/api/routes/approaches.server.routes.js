var approach = require('../controllers/approaches.server.controller'),
    auth = require('../controllers/auth.server.controller');

module.exports = (app) => {
    app.route('/api/approach')
        .get( approach.getAll)
        // .post(auth.ensureAuthenticated, statusCan.create);
}

