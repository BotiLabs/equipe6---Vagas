var auth = require('../controllers/authExternal.server.controller'),
    type = require('../controllers/type.server.controller');

module.exports = (app) => {
    app.route('/api/types')
        .post(type.create);

    app.route('/api/types/:companyId')
        .get(type.getAll);

};