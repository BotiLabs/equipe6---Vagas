var statusCan = require('../controllers/statusOfCandidate.server.controller'),
    auth = require('../controllers/auth.server.controller');

module.exports = (app) => {
    app.route('/api/statuscandidate/:id_company')
        .get(statusCan.getAllByCompany)
    // .post(auth.ensureAuthenticated, statusCan.create);
    app.route('/api/statuscandidate')
        .get(statusCan.getAllDefaultStatus)
}