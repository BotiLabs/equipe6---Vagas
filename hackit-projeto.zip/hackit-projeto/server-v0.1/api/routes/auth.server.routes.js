var auth = require('../controllers/auth.server.controller');
var tempToken = "JWT " + "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyIkX18iOnsic3RyaWN0TW9kZSI6dHJ1ZSwic2VsZWN0ZWQiOnt9LCJnZXR0ZXJzIjp7fSwiX2lkIjoiNTlhY2M4OGYyNDc5OGEzMTk0NTFmZjQyIiwid2FzUG9wdWxhdGVkIjpmYWxzZSwiYWN0aXZlUGF0aHMiOnsicGF0aHMiOnsicHJvdmlkZXIiOiJpbml0IiwicGFzc3dvcmQiOiJpbml0IiwidXNlcm5hbWUiOiJpbml0IiwibGFzdE5hbWUiOiJpbml0IiwiZmlyc3ROYW1lIjoiaW5pdCIsIl9fdiI6ImluaXQiLCJlbWFpbCI6ImluaXQiLCJzYWx0IjoiaW5pdCIsIl9pZCI6ImluaXQifSwic3RhdGVzIjp7Imlnbm9yZSI6e30sImRlZmF1bHQiOnt9LCJpbml0Ijp7Il9fdiI6dHJ1ZSwiZW1haWwiOnRydWUsInBhc3N3b3JkIjp0cnVlLCJ1c2VybmFtZSI6dHJ1ZSwibGFzdE5hbWUiOnRydWUsImZpcnN0TmFtZSI6dHJ1ZSwicHJvdmlkZXIiOnRydWUsInNhbHQiOnRydWUsIl9pZCI6dHJ1ZX0sIm1vZGlmeSI6e30sInJlcXVpcmUiOnt9fSwic3RhdGVOYW1lcyI6WyJyZXF1aXJlIiwibW9kaWZ5IiwiaW5pdCIsImRlZmF1bHQiLCJpZ25vcmUiXX0sInBhdGhzVG9TY29wZXMiOnt9LCJlbWl0dGVyIjp7ImRvbWFpbiI6bnVsbCwiX2V2ZW50cyI6e30sIl9ldmVudHNDb3VudCI6MCwiX21heExpc3RlbmVycyI6MH19LCJpc05ldyI6ZmFsc2UsIl9kb2MiOnsiX192IjowLCJlbWFpbCI6ImxpZmVsaXBlN0BsaXZlLmNvbSIsInBhc3N3b3JkIjoiT1J2QU5QVWdiMThtZ3hIYUxBOGhra3hGTE1IU2tRL3FkclpITTZLUHRhWFI1WlQ2OW9nL0xUYW9WSFhQV05aWUp6YTVXYzdjaFZZME90dWFma3BVeVE9PSIsInVzZXJuYW1lIjoibGlmZWxpcGU3IiwibGFzdE5hbWUiOiJPbGl2ZWlyYSIsImZpcnN0TmFtZSI6IkzDrXZlcnRvbiIsInByb3ZpZGVyIjoiand0Iiwic2FsdCI6IkTvv71ENEXvv71cdTAwMTbvv73vv73vv71rRe-_ve-_vVx1MDAxOSIsIl9pZCI6IjU5YWNjODhmMjQ3OThhMzE5NDUxZmY0MiJ9LCIkaW5pdCI6dHJ1ZSwiaWF0IjoxNTA0NDk3MTUxLCJleHAiOjE1MDQ0OTcxNzF9.8YxLAUu2u9UVsHiKlloORQ0p6WdtywNIZ7mLJaNAOh8"
var multipart = require('connect-multiparty');
var multipartMiddleware = multipart();

module.exports = (app) => {
    app.route('/api/signup')
        .post(auth.signup);

    app.route('/api/token')
        .post(auth.token);

    app.route('/api/user')
        .post(auth.ensureAuthenticated, auth.findUserByEmail);

    app.route('/api/tokenuser')
        .post(auth.tokenExternal);

    app.route('/api/authentication')
        .post(auth.emailAuthorization);

    app.route('/api/getuser/:company_id')
        .get(auth.getUsers);

    app.route('/api/searchuser/:companyId')
        .post(auth.searchUsers);

    app.route('/api/user/:userId')
        .get(auth.ensureAuthenticated, auth.read)
        .put(auth.updateUserApproval);

    app.route('/api/user2/:userId')
        .get(auth.ensureAuthenticated, auth.read)
        .put(auth.updateUserWatch);

    app.route('/api/user3/:userId')
        .put(auth.editUsers);

    app.route('/api/updateuserimage/:userId')
        .put(multipartMiddleware, auth.updateUserImage, function (req, res) {})

    app.route('/api/updateuserpassword/:userId')
        .put(auth.updateUserPassword);

    app.param('userId', auth.userById);
    app.param('companyId', auth.prepareCompanyId);

    app.route('/api/getusersmulti/:company_id')
        .get(auth.getUsersMultiSelect);

    app.route('/api/validateifemailexists')
        .post(auth.validateIfEmailExists);

    app.route('/api/userbyid')
        .post(auth.getUserById)

    app.route('/api/login/office365')
        .post(auth.ensureAuthenticated, auth.updateUserLoginCount);
};