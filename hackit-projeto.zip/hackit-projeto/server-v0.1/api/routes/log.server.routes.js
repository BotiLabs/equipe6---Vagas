var logUser = require('../controllers/log.server.controller'),
    auth = require('../controllers/auth.server.controller');

module.exports = (app) => {
    app.param('companyId', logUser.prepareCompanyId);

    app.route('/api/logs/getall/:companyId')
        .get(auth.ensureAuthenticated, logUser.list)

    app.route('/api/logs')
        .post(auth.ensureAuthenticated, logUser.create);

    app.route('/api/logs/search')
        .post(auth.ensureAuthenticated, logUser.search);

    app.route('/api/logs/searchoninit')
        .post(auth.ensureAuthenticated, logUser.searchOnInit);
}

