var chat = require('../controllers/chat.server.controller');

module.exports = (app) => {
    app.route('/api/chat/talk')
        .post(chat.post2async);
};