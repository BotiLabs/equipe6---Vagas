var location = require('../controllers/location.server.controller'),
    auth = require('../controllers/auth.server.controller');

module.exports = (app) => {
    app.route('/api/locations')
        .post(location.create)

    app.route('/api/locations/getall/:companyId')
        .get(location.list); //auth.ensureAuthenticated,

    app.route('/api/locations/search')
        .post(auth.ensureAuthenticated, location.search)
    //auth.ensureAuthenticated,


    app.route('/api/location/:locationsId')
        .get(auth.ensureAuthenticated, location.read)

    app.route('/api/location/update/:locationsId')
        .put(location.update)


    app.param('locationsId', location.locationById);
    app.param('companyId', location.prepareCompanyId);
}