var action = require('../controllers/action.server.controller'),
    auth = require('../controllers/auth.server.controller');

module.exports = (app) => {
    app.route('/api/action')
        .post(action.create);

    app.route('/api/action/:companyId')
        .get(auth.ensureAuthenticated, action.getAll);
}