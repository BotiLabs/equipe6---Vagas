var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var TagSchema = new Schema({
    name: {
        type: String,
        required: [true, "Informe o nome da tag"],
        trim:true
    },
    nameWithCompany: {
        type: String,
        unique: true
    },
    visible: {
        type: Boolean,
        default: true
    },
    company_id: {
        type: String,
        required: [true, "Erro ao salvar, recarregue a página"]
    },
    companyId: {
        type: Schema.Types.ObjectId,
        ref: 'Company'
    }
});

TagSchema.pre('save', function (next) {
    this.companyId = this.company_id;
    next();
});

module.exports.Tag = mongoose.model('Tag', TagSchema);