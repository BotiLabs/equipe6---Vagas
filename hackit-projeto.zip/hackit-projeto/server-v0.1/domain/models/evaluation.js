var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var EvaluationSchema = new Schema({
    name: {
        type: String
    },
    email: {
        type: String,
        match: [/.+\@.+\..+/, "Informe um endereço de e-mail válido"]
    },
    idCandidate: String,
    date: Date,
    startedEvaluation: Boolean,
    type: [],
    number: Number,
    answerTime: Number,
    initialDate: Date,
    registrationDate: Date,
    personality: [{
        name: {
            type: String
        },
        percentage: {
            type: Number
        }
    }],
    testing: [{
        questionId: {
            type: String
        },
        question: {
            type: String
        },
        theme: {
            type: String
        },
        answer: {
            // _id: { type: String},
            // answer: { type: String },
            // weight: { type: Number }
        }
    }],
    company_id: {
        type: String,
        required: [true, "Erro ao salvar, recarregue a página"]
    },
    companyId: {
        type: Schema.Types.ObjectId,
        ref: 'Company'
    },
    discription: {
        type: String
    },
    userEmail: {
        type: String,
        trim: true,
    }

});

EvaluationSchema.index({
    name: 'text',
    email: 'text'
});


module.exports.Evaluation = mongoose.model('Evaluation', EvaluationSchema);