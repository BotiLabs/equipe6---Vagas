var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var hour = new Date().getTime();
var date = new Date(hour);

var SearchOfCandidateScheema = new Schema({
    userEmail: {
        type: String
    },
    userFirstName: {
        type: String
    },
    name: {
        type: String
    },
    email: {
        type: String,
        match: [/.+\@.+\..+/, "Informe um endereço de e-mail válido"]
    },
    nameSearch: {
        type: String
    },
    number: {
        type: Number
    },
    skills: [],
    registrationDate: {
        type: Date,
        default: date
    },
    status: [],
    position: {
        type: String
    },
    company_id: {
        type: String,
        required: [true, "Erro ao salvar, recarregue a página"]
    },
    companyId: {
        type: Schema.Types.ObjectId,
        ref: 'Company'
    }
});

SearchOfCandidateScheema.pre('save', function (next) {
    this.companyId = this.company_id;
    next();
});
module.exports.SearchCandidate = mongoose.model('searchOfCandidate', SearchOfCandidateScheema);