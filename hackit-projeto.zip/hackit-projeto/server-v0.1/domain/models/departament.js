var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var DepartamentSchema = new Schema({
    name: {
        type: String,
        required: [true, "Informe o nome do departamento"]
    },
    number: {
        type: Number,
        unique: true,
        required: [true, "Informe o id do departamento"]
    },
    company_id: {
        type: String
    },
    companyId: {
        type: Schema.Types.ObjectId,
        ref: 'Company'
    }
});

DepartamentSchema.pre('save', function (next) {
    this.companyId = this.company_id;
    next();
});
module.exports.Departament = mongoose.model('Departament', DepartamentSchema);