var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var hour = new Date().getTime();
var date = new Date(hour);

var LogUserScheema = new Schema({
    userEmail: {
        type: String
    },
    userFirstName: {
        type: String
    },
    registrationDate: {
        type: Date,
        default: date
    },
    discriptionLog: {
        type: String
    },
    number: {
        type: Number
    },
    company_id: {
        type: String,
        required: [true, "Erro ao salvar, recarregue a página"]
    },
    companyId: {
        type: Schema.Types.ObjectId,
        ref: 'Company'
    }
});

LogUserScheema.pre('save', function (next) {
    this.companyId = this.company_id;
    next();
})
module.exports.LogUser = mongoose.model('Log', LogUserScheema);