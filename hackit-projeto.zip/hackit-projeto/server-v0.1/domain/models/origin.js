var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var OriginScheema = new Schema({
    name: {
        type: String,
        unique: true
    },
    number: {
        type: Number
    },
    id: {
        type: String,
        unique: true
    },
    company_id: {
        type: String,
        required: [true, "Erro ao salvar, recarregue a página"]
    },
    companyId: {
        type: Schema.Types.ObjectId,
        ref: 'Company'
    }
});


OriginScheema.pre('save', function (next) {
    this.companyId = this.company_id;
    next();
});
module.exports.Origin = mongoose.model('origin', OriginScheema);