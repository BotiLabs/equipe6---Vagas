var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var TypeSchema = new Schema({
    discription: {
        type: String,
        required: [true, 'A descrição é obrigatória']
    },
    id: {
        type: String,
        required: [true, 'O id é obrigatório']
    },
    idWithCompany: {
        type: String,
        unique: true,
        sparse: true
    },
    company_id: {
        type: String,
        required: [true, "Erro ao salvar, recarregue a página"]
    },
    companyId: {
        type: Schema.Types.ObjectId,
        ref: 'Company'
    }
});

TypeSchema.pre('save', function (next) {
    this.companyId = this.company_id;
    this.idWithCompany = this.company_id + this.id;
    next();
});

module.exports.Type = mongoose.model('Type', TypeSchema);