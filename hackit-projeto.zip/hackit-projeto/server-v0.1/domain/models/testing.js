var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var TestingSchema = new Schema({
    type: {
        type: String,
        required: [true, "Informe o tipo de avaliação"]
    },
    theme: {
        type: String,
        required: [true, "Informe o quesito."]
    },
    question: {
        type: String,
        required: [true, "Informe o enunciado da questão"]
    },
    answers: [{
        answer: {
            type: String
        },
        weight: {
            type: Number
        }
    }],
    date: Date,
    company_id: String,

    testing: [{
        questionsId: {
            type: String
        },
        theme: {
            type: String
        },
        answer: {
            // _id: { type: String},
            // answer: { type: String },
            // weight: { type: Number }
        }
    }],
    company_id: {
        type: String,
        required: [true, "Erro ao salvar, recarregue a página"]
    },
    companyId: {
        type: Schema.Types.ObjectId,
        ref: 'Company'
    }
});

TestingSchema.pre('save', function (next) {
    this.companyId = this.company_id;
    next();
});

module.exports.Testing = mongoose.model('Testing', TestingSchema);