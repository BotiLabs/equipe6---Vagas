var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var hour = new Date().getTime();
var date = new Date(hour);

var SearchOfOpportunityScheema = new Schema({
    userEmail: {
        type: String
    },
    userFirstName: {
        type: String
    },
    customerName: {
        type: String
    },
    nameSearch: {
        type: String
    },
    location: {
        type: String
    },
    businessUnit: {
        type: Number
    },
    status: {
        type: Number
    },
    number: {
        type: Number
    },
    numberOpp: {
        type: Number
    },
    priority: {
        type: Number
    },
    specialities: [],
    registrationDate: {
        type: Date,
        default: date
    },
    company_id: {
        type: String,
        required: [true, "Erro ao salvar, recarregue a página"]
    },
    companyId: {
        type: Schema.Types.ObjectId,
        ref: 'Company'
    }
});

SearchOfOpportunityScheema.pre('save', function (next) {
    this.companyId = this.company_id;
    next();
});
module.exports.SearchOp = mongoose.model('searchOfOpportunity', SearchOfOpportunityScheema);