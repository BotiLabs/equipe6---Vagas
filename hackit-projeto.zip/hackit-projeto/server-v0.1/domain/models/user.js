var mongoose = require('mongoose');
var Schema = mongoose.Schema;
var crypto = require('crypto');
var uniqueValidator = require('mongoose-unique-validator');

var UserSchema = new Schema({
    firstName: {
        type: String,
        required: 'O nome é obrigatório'
    },
    lastName: {
        type: String,
        required: 'O sobrenome é obrigatório'
    },
    email: {
        type: String,
        // unique: true,
        match: [/.+\@.+\..+/, "Informe um endereço de e-mail válido"],
    },
    username: {
        type: String,
        // unique: true,
        required: 'O nome de usuário é obrigatório',
        trim: true
    },
    password: {
        type: String,
        required: 'A senha é obrigatória',
        validate: [
            (password) => {
                return password && password.length > 6;
            }, 'A senha deve ser maior que 6 caracteres'
        ]
    },
    salt: {
        type: String
    },
    provider: {
        type: String,
        required: 'O provider é obrigatório'
    },
    providerId: String,
    providerData: {},
    emailWithCompany: {
        type: String,
        unique: true,
        trim: true
    },
    usernameWithCompany: {
        type: String,
        unique: true,
        trim: true
    },
    approved: {
        type: Boolean,
        default: false
    },
    watch: [{
        type: Schema.Types.ObjectId
    }],
    profileImage: {
        type: String
    },
    lastChangeCode: Number,
    changeValidated: {
        type: Boolean,
        default: false
    },
    company_id: {
        type: String
    },
    companyId: {
        type: Schema.Types.ObjectId,
        ref: 'Company'
    },
    loginCount: {
        type: Number
    },
    lastLoginDate: {
        type: Date,
        default: undefined
    }

});

UserSchema.pre('save', function (next) {
    if (this.password) {
        this.salt = new Buffer(crypto.randomBytes(16).toString('base64'), 'base64');
        this.password = this.hashPassword(this.password);
    }
    this.companyId = this.company_id;
    next();
});

UserSchema.methods.hashPassword = function (password) {
    return crypto.pbkdf2Sync(password, this.salt, 10000, 64, 'sha512').toString('base64');
};

UserSchema.methods.authenticate = function (password) {
    return this.password == this.hashPassword(password);
};

UserSchema
    .virtual('user_info')
    .get(function () {
        return {
            '_id': this._id,
            'username': this.username,
            'email': this.email
        };
    });


UserSchema.set('toJSON', {
    getters: true,
    virtuals: true
});
UserSchema.plugin(uniqueValidator, {
    message: 'Este usuário já existe'
});
//module.exports.UserSchema = UserSchema;
module.exports.User = mongoose.model('User', UserSchema);