var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var EmailSchema = new Schema({
    email: String
});
module.exports.Email = mongoose.model('Email', EmailSchema);