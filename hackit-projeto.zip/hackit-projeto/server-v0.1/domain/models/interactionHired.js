var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var hour = new Date().getTime();
var date = new Date(hour);

var InteractionHiredSchema = new Schema({
    candidateId: {
        type: Schema.Types.ObjectId,
        ref: 'Candidate',
        required: 'O candidato da interação é obrigatório'
    },
    userEmail: {
        type: String,
        required: 'O e-mail do usuário é obrigatório'
    },
    userFirstName: {
        type: String,
        required: 'O nome do usuário é obrigatório'
    },
    opportunityId: {
        type: String
    },
    opportunityName: {
        type: String
    },
    registrationDate: {
        type: Date,
        default: date
    },
    action: {
        type: Number,
        required: 'A ação da interação é obrigatória'
    },
    profile: {
        type: Number,
        required: 'A o perfil da interação é obrigatório'
    },
    observation: {
        type: String
    },
    interactionType: {
        type: Number
    },
    opportunity: {
        type: Schema.Types.ObjectId,
        ref: 'Opportunity'
    },
    status: {
        type: Number,
        required: 'O status da interação é obrigatório'
    },
    visible: {
        type: Boolean,
        default: true
    },
    opportunityNumber: {
        type: Number
    },
    company_id: {
        type: String,
        required: [true, "Erro ao salvar, recarregue a página"]
    },
    companyId: {
        type: Schema.Types.ObjectId,
        ref: 'Company'
    }
});

InteractionHiredSchema.pre('save', function (next) {
    this.companyId = this.company_id;
    next();
})
module.exports.InteractionHired = mongoose.model('InteractionHired', InteractionHiredSchema);