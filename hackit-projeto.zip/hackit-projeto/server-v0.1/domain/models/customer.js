var mongoose = require('mongoose');
var Schema = mongoose.Schema;


var CustomerScheema = new Schema({
    name: {
        type: String,
        required: 'O nome é obrigatório'
    },
    visible: {
        type: Boolean,
        default: true
    },
    blockedCustomer: {
        type: Boolean,
        default: true
    },
    unity: {},
    registrationDate: {
        type: Date,
        default: undefined
    },
    company_id: {
        type: String,
        required: [true, "Erro ao salvar, recarregue a página"]
    },
    companyId: {
        type: Schema.Types.ObjectId,
        ref: 'Company'
    }
});

CustomerScheema.pre('save', function (next) {
    this.companyId = this.company_id;
    next();
})
module.exports.Customer = mongoose.model('Customer', CustomerScheema);