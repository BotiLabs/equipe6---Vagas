var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var ActionScheema = new Schema({
    name: {
        type: String,
        unique: true
    },
    number: {
        type: Number
    },
    id: {
        type: String,
        unique: true,
        required: [true, "A ação da interação é obrigatória"]
    },
    //Atualmente não utilizaremos isto, pois todas as empresas utilizarão as mesmas ações, caso um dia seja customizado, descomentar todas as linhas que estão comentadas.
    // company_id: {
    //     type: String,
    //     required: [true, "Erro ao salvar, recarregue a página"]
    // },
    // companyId: {
    //     type: Schema.Types.ObjectId,
    //     ref: 'Company'
    // }
});


// ActionScheema.pre('save', function (next) {
//     this.companyId = this.company_id;
//     next();
// })
module.exports.Action = mongoose.model('action', ActionScheema);