var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var SoftSkillSchema = new Schema({
    softskill: {
        type: String,
        required: [true, "Informe o nome da competência"],
        trim:true
    },
    nameWithCompany: {
        type: String,
        unique: true
    },
    visible: {
        type: Boolean,
        default: true
    },
    company_id: {
        type: String,
        required: [true, "Erro ao salvar, recarregue a página"]
    },
    companyId: {
        type: Schema.Types.ObjectId,
        ref: 'Company'
    }
});

SoftSkillSchema.pre('save', function (next) {
    this.companyId = this.company_id;
    next();
});

module.exports.SoftSkills = mongoose.model('SoftSkills', SoftSkillSchema);