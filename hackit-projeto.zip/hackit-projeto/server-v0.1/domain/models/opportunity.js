var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var hour = new Date().getTime();
var date = new Date(hour);
var OpportunitySchema = new Schema({
    name: {
        type: String,
        required: 'O nome da vaga é obrigatório',
        trim: true
    },
    description: {
        type: String
    },
    responsible: {
        type: String,
        required: 'O responsável pela vaga é obrigatório',
        trim: true
    },
    value: {
        type: String,
        required: 'O valor da vaga é obrigatório'
    },
    profile: {
        type: Number
    },
    customerName: {
        type: String,
        required: 'O nome do cliente é obrigatório'
    },
    location: {
        type: String
    },
    businessUnit: {
        type: Number,
        required: 'A unidade de negócio é obrigatória'
    },
    status: {
        type: Number,
        required: 'O status é obrigatório'
    },
    specialities: [],
    softSkills: [],
    isActive: {
        type: Boolean,
        default: false
    },
    number: {
        type: Number
    },
    candidates: [{
        type: Schema.Types.ObjectId
    }],
    registrationDate: {
        type: Date,
        default: undefined
    },
    emailResponsible: {
        type: String
    },
    priority: {
        type: Number
    },
    visible: {
        type: Boolean,
        default: true
    },
    opportunityLocation: {
        type: Object
    },
    qtdOpportunities: {
        type: Number
    },
    initialQtd: {
        type: Number
    },
    historic: [],
    emailWatching: [],
    involvedPeople: [{
        name: {
            type: String,
            required: 'O nome da pessoa envolvida é obrigatório'
        },
        position: {
            type: String,
            required: 'O cargo da pessoa envolvida é obrigatório'
        },
        email: {
            type: String
        },
    }],
    closedDate: {
        type: Date,
        default: undefined
    },
    lastAlterationDate: {
        type: Date,
        default: undefined
    },
    slaApproval: {
        type: Date,
        default: undefined
    },
    company_id: {
        type: String,
        required: [true, "Erro ao salvar, recarregue a página"]
    },
    companyId: {
        type: Schema.Types.ObjectId,
        ref: 'Company'
    }
});

OpportunitySchema.pre('save', function (next) {
    this.companyId = this.company_id;
    next();
});
module.exports.Opportunity = mongoose.model('Opportunity', OpportunitySchema);