var mongoose = require('mongoose');
var Schema = mongoose.Schema;
var crypto = require('crypto');
var uniqueValidator = require('mongoose-unique-validator');

var UserExternalScheema = new Schema({
    fullName: {
        type: String,
        required: 'O nome é obrigatório'
    },
    email: {
        type: String,
        match: [/.+\@.+\..+/, "Informe um endereço de e-mail válido"],
    },
    password: {
        type: String,
        required: 'A senha é obrigatória',
        validate: [
            (password) => {
                return password && password.length > 6;
            }, 'A senha deve ser maior que 6 caracteres'
        ]
    },
    salt: {
        type: String
    },
    provider: {
        type: String,
        required: 'O provider é obrigatório'
    },
    providerId: String,
    providerData: {},
    approved: {
        type: Boolean,
        default: false
    },
    profileImage: {
        type: String
    },
    registrationDate: {
        type: Date,
        default: undefined
    },
    emailWithCompany: {
        type: String,
        unique: true,
        trim: true
    },
    userName: {
        type: String,
        required: true
    },
    company_id: {
        type: String
    },
    companyId: {
        type: Schema.Types.ObjectId,
        ref: 'Company'
    }
});

UserExternalScheema.pre('save', function (next) {
    if (this.password) {
        this.salt = new Buffer(crypto.randomBytes(16).toString('base64'), 'base64');
        this.password = this.hashPassword(this.password);
    }
    this.companyId = this.company_id;
    next();
});

UserExternalScheema.methods.hashPassword = function (password) {
    return crypto.pbkdf2Sync(password, this.salt, 10000, 64, 'sha512').toString('base64');
};

UserExternalScheema.methods.authenticate = function (password) {
    return this.password == this.hashPassword(password);
};

UserExternalScheema.plugin(uniqueValidator, {
    message: 'Este usuário já existe'
});
//module.exports.UserSchema = UserSchema;
module.exports.UserExternal = mongoose.model('UserExternal', UserExternalScheema);