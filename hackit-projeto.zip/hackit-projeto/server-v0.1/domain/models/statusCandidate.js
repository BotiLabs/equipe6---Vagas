var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var StatusOfCandidateScheema = new Schema({
    name: {
        type: String,
        unique: true
    },
    color: {
        type: String
    },
    number: {
        type: Number
    },
    status_id: {
        type: String,
        unique: true
    },
    company_id: {
        type: Schema.Types.ObjectId,
        ref: 'Company'
    },
    companyId: {
        type: Schema.Types.ObjectId,
        ref: 'Company'
    }
});

StatusOfCandidateScheema.pre('save', function (next) {
    this.companyId = this.company_id;
    next();
});
module.exports.StatusOfCandidate = mongoose.model('statusOfCandidate', StatusOfCandidateScheema);