var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var QualificationScheema = new Schema({
    email: {
        type: String
    },
    name: {
        type: String
    },
    noAscentName: {
        type: String
    },
    date: {
        type: Date,
        default: undefined
    },
    mainSkills: [],
    secondarySkills: [],
    position: String,
    discription: {
        type: String
    },
    desiredHiring: [],
    visible: {
        type: Boolean,
        default: true
    },
    company_id: {
        type: String,
        required: [true, "Erro ao salvar, recarregue a página"]
    },
    companyId: {
        type: Schema.Types.ObjectId,
        ref: 'Company'
    }
});

QualificationScheema.pre('save', function (next) {
    this.companyId = this.company_id;
    next();
});

module.exports.Qualification = mongoose.model('Qualification', QualificationScheema);