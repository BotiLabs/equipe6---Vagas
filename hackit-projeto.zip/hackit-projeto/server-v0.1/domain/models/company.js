var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var CompanySchema = new Schema({
    name: {
        type: String,
        required: [true, "Informe o nome da Empresa"]
    },
    tag: {
        type: String,
        unique: true
    },
    tenant: {
        type: String,
        unique: true
    }
});


module.exports.Company = mongoose.model('Company', CompanySchema);