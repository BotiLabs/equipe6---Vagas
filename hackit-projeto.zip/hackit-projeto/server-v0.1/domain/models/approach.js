var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var ApproachScheema = new Schema({
    name: {
        type: String,
        unique: true
    },
    number: {
        type: Number
    },
    id: {
        type: String,
        unique: true
    },
    company_id: {
        type: String,
        required: [true, "Erro ao salvar, recarregue a página"]
    },
    companyId: {
        type: Schema.Types.ObjectId,
        ref: 'Company'
    }
});


ApproachScheema.pre('save', function (next) {
    this.companyId = this.company_id;
    next();
})
module.exports.Approach = mongoose.model('approach', ApproachScheema);