var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var ConfigurationSchema = new Schema({

    interactionEmail: {
        type: Boolean,
        default: true,
    },

    reprovalEmail: {
        type: Boolean,
        default: true,
    },

    statusRobot: {
        type: Boolean,
        default: true,
    },
    company_id: {
        type: String
    },
    companyId: {
        type: Schema.Types.ObjectId,
        ref: 'Company'
    },
});

ConfigurationSchema.pre('save', function (next) {
    this.companyId = this.company_id;
    next();
})
module.exports.Configuration = mongoose.model('Configuration', ConfigurationSchema);