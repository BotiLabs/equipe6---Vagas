var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var TestingtypeSchema = new Schema({
    theme: {
        type: String,
        required: [true, "Informe o tema."]
    },
    date: {
        type: Date,
        required: [true, "Informe a data do cadastro."]
    },
    active: {
        type: Boolean,
        required: [true, "Informe se o candidato é ativo ou inativo."]
    },
    company_id: {
        type: String,
        required: [true, "Erro ao salvar, recarregue a página"]
    },
    companyId: {
        type: Schema.Types.ObjectId,
        ref: 'Company'
    }
});

TestingtypeSchema.pre('save', function (next) {
    this.companyId = this.company_id;
    next();
});

module.exports.Testingtype = mongoose.model('Testingtype', TestingtypeSchema);