var mongoose = require('mongoose');
var Schema = mongoose.Schema;


var FunctionScheema = new Schema({
    name: {
        type: String,
        required: 'O nome é obrigatório'
    },
    nameWithCompany: {
        type: String,
        unique: true,
        sparse: true
    },
    visible: {
        type: Boolean,
        default: true
    },
    registrationDate: {
        type: Date,
        default: undefined
    },
    company_id: {
        type: String,
        required: [true, "Erro ao salvar, recarregue a página"]
    },
    companyId: {
        type: Schema.Types.ObjectId,
        ref: 'Company'
    }
});

FunctionScheema.pre('save', function (next) {
    this.companyId = this.company_id;
    this.nameWithCompany = this.name + this.company_id;
    next();
})
module.exports.Function = mongoose.model('Function', FunctionScheema);