var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var hour = new Date().getTime();
var date = new Date(hour);

var NotificationUserScheema = new Schema({
    userEmail: {
        type: String
    },
    candidateId: {
        type: Schema.Types.ObjectId,
        ref: 'Candidate',
        required: 'O candidato da interação é obrigatório'
    },
    responsibleEmail: {
        type: String
    },
    userFirstName: {
        type: String
    },
    registrationDate: {
        type: Date,
        default: date
    },
    discriptionNotification: {
        type: String
    },
    originNotification: {
        type: String
    },
    number: {
        type: Number
    },
    typeOfNotification: {
        type: Number
    },
    company_id: {
        type: String,
        required: [true, "Erro ao salvar, recarregue a página"]
    },
    companyId: {
        type: Schema.Types.ObjectId,
        ref: 'Company'
    }
});

NotificationUserScheema.pre('save', function (next) {
    this.companyId = this.company_id;
    next();
});
module.exports.NotificationUser = mongoose.model('Notification', NotificationUserScheema);