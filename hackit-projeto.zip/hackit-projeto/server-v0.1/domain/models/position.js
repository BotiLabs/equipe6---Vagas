var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var PositionScheema = new Schema({
    name: {
        type: String,
        unique: true
    },
    number: {
        type: String,
        unique: true,
        required: [true, "Informe o id do cargo"]
  
    },
    company_id: {
        type: String,
        required: [true, "Erro ao salvar, recarregue a página"]
    },
    companyId: {
        type: Schema.Types.ObjectId,
        ref: 'Company'
    }
});

PositionScheema.pre('save', function (next) {
    this.companyId = this.company_id;
    next();
});

module.exports.Position = mongoose.model('position', PositionScheema);