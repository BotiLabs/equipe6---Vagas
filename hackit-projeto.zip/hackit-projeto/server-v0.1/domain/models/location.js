var mongoose = require('mongoose');
var Schema = mongoose.Schema;


var LocationScheema = new Schema({
    streetAddress: {
        type: String,
        trim: true
    },
    district: {
        type: String,
        required: 'O bairro é obrigatório',
        trim: true
    },
    state: {
        type: String,
        required: 'O estado é obrigatório',
        trim: true
    },
    discription: {
        type: String,
        required: 'A descrição é obrigatória',
        trim: true
    },
    opportunityLocation: {
        type: String
    },
    clientLocation: {
        type: Schema.Types.ObjectId,
        ref: 'Customer'
    },
    blockedLocation: {
        type: Boolean,
        default: true
    },
    company_id: {
        type: String,
        required: [true, "Erro ao salvar, recarregue a página"]
    },
    companyId: {
        type: Schema.Types.ObjectId,
        ref: 'Company'
    }
});

LocationScheema.pre('save', function (next) {
    this.companyId = this.company_id;
    next();
})
module.exports.Location = mongoose.model('Location', LocationScheema);