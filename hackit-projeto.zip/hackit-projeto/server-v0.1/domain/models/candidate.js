var mongoose = require('mongoose');
var Schema = mongoose.Schema;
var mongooseAggregatePaginate = require('mongoose-aggregate-paginate');


var hour = new Date().getTime();
var date = new Date(hour);

var CandidateSchema = new Schema({
    name: {
        type: String,
        required: [true, "Informe o nome completo do candidato"],
        trim: true
    },
    noAscentName: {
        type: String,
        trim: true
    },
    position: {
        type: String,
        default: "Outro cargo"
    },
    email: {
        type: String,
        match: [/.+\@.+\..+/, "Informe um endereço de e-mail válido"],
        trim: true
    },
    emailWithCompany: {
        type: String,
        match: [/.+\@.+\..+/, "Informe um endereço de e-mail válido"],
        unique: true,
        trim: true
    },
    status: {
        type: Number,
        default: 0
    },
    profile: {
        type: Number
    },
    phone: {
        type: String
    },
    skills: [],
    softSkills: [],
    curriculum: {
        type: String
    },
    yearsOfExperience: {
        type: Number
    },
    registrationDate: {
        type: Date,
        default: undefined
    },
    githubUrl: {
        type: String
    },
    linkedinUrl: {
        type: String
    },
    opportunities: [{
        type: Schema.Types.ObjectId,
        ref: 'Opportunity'
    }],
    origin: {
        type: String,
        default: "Outro"
    },
    isBlocked: {
        type: Boolean,
        default: false
    },
    rank: {
        type: Number
    },
    hiringType: {
        type: Number
    },
    desiredHiring: [],
    actualValue: {
        type: String
    },
    desiredValue: {
        type: String
    },
    typeOfOrigin: {
        type: Number
    },
    userEmail: {
        type: String
    },
    visible: {
        type: Boolean,
        default: true
    },
    relevance: {
        type: Object
    },
    textCv: {
        type: String
    },
    historic: [],
    lastInteractionDate: {
        type: Date
    },
    mainSkills: [],
    secondarySkills: [],
    discription: {
        type: String
    },
    dateOfBirth: {
        type: Date
    },
    cep: {
        type: String
    },
    district: {
        type: String,
        trim: true
    },
    city: {
        type: String,
        trim: true
    },
    state: {
        type: String,
        trim: true
    },
    approachRs: {
        type: String,
        trim: true
    },
    company_id: {
        type: String,
        required: [true, "Erro ao salvar, recarregue a página"]
    },
    companyId: {
        type: Schema.Types.ObjectId,
        ref: 'Company'
    },
    like:{
        type: Number,
        default: 0
    },
    silver:{
        type: Boolean,
        default: false
    },
    dislike:{
        type: Number,
        default: 0
    },    
    fillPercentage: {
        type: Number,
    }
});

CandidateSchema.pre('save', function (next) {
    this.companyId = this.company_id;
    next();
})
CandidateSchema.plugin(mongooseAggregatePaginate);
module.exports.Candidate = mongoose.model('Candidate', CandidateSchema);