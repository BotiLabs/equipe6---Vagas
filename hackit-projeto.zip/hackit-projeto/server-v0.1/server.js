process.env.PORT = process.env.PORT || 3000;
process.env.NODE_ENV = process.env.NODE_ENV || 'development';

var passport = require('./config/passport');

var express = require('express');
var app = express();
var httpapp = express();
var io = null;
var fs = require('fs');
var cookieParser = require('cookie-parser');
var path = require('path');

require('./middlewares')(app);
require('./config/dbStart');
require('./api/app')(app);

passport = passport();
app.use(express.static(path.join(__dirname, 'src')));
app.use(cookieParser());
app.all('*', function (req, res) {
    res.sendFile(path.join(path.join(__dirname, '../ui-client/src/index.html')));
});

if (process.env.NODE_ENV === 'development') {
    var http = require('http').Server(app);
    http.listen(process.env.PORT, () => {
        console.log('API Running on PORT: ' + process.env.PORT + ' and Env: ' + process.env.NODE_ENV);
    });

    io = require('socket.io').listen(http);

    io.on('connection', (socket) => {
        console.log('user connected')
        socket.on('disconnect', function () {
            console.log('user disconnected');
        });
        socket.on('add-notification', (notification) => {
            io.emit('notification', {
                type: 'new-notification',
                text: notification
            });
        });
    });

} else if (process.env.NODE_ENV === 'homolog') {

    var server = require('https').createServer({
        key: fs.readFileSync("/etc/letsencrypt/live/qaapi.hapin.com.br/privkey.pem"),
        cert: fs.readFileSync("/etc/letsencrypt/live/qaapi.hapin.com.br/fullchain.pem"),
        ca: fs.readFileSync("/etc/letsencrypt/live/qaapi.hapin.com.br/chain.pem")
    }, app);

    io = require('socket.io').listen(server);

    io.on('connection', (socket) => {
        console.log('user connected')
        socket.on('disconnect', function () {
            console.log('user disconnected');
        });
        socket.on('add-notification', (notification) => {
            io.emit('notification', {
                type: 'new-notification',
                text: notification
            });
        });
    });

    server.listen(443);
} else {

    var server = require('https').createServer({
        key: fs.readFileSync("/etc/letsencrypt/archive/recrutamento-api.fcamara.com.br/privkey1.pem"),
        cert: fs.readFileSync("/etc/letsencrypt/archive/recrutamento-api.fcamara.com.br/fullchain1.pem"),
        ca: fs.readFileSync("/etc/letsencrypt/archive/recrutamento-api.fcamara.com.br/chain1.pem")
    }, app);

    io = require('socket.io').listen(server);

    io.on('connection', (socket) => {
        socket.on('disconnect', function () {
            console.log('user disconnected');
        });
        socket.on('add-notification', (notification) => {
            io.emit('notification', {
                type: 'new-notification',
                text: notification
            });
        });
    });

    server.listen(443);
}

httpapp.get('*', function (req, res) {
    res.redirect("https://" + req.headers['host'] + req.url)
})



module.exports = app;