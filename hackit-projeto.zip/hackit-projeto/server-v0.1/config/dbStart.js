var mongoose = require('mongoose');
var config = require('./config');

var mongoConnection = mongoose.connect(config.mongodb.uri, config.mongodb.options).then(success => {
    console.log('MongoDB successfully connected');
    return success;
  })
  .catch(err => {
    console.log('Error while connecting to mongodb: ', err);
    return err
  })

module.exports = {
  MongoConnection: mongoConnection
};