var username = '977936ed-d083-4e8d-88f7-4b48f25955ec';
var password = '87IWXUi3JQEE';
//var workspace_id = '787ce0e8-96c4-4d7e-96aa-7786a8baadba';
// var workspace_id = 'f7d23c0a-b491-4d57-a472-7e194505ca0a';
var workspace_id = '79046d65-74a0-4bb7-ae3c-3ec89769baf1';


module.exports = {
	username,
	password,
	workspace_id,
	secret: 'developmentSecret',
	mongodb: {
		uri: 'mongodb://ds133202.mlab.com:33202/productionhapin',
		options: {
			useNewUrlParser: true,
			user: 'hapinprodmulti',
			pass: 'h@pinProdMulti!1'
		}
	}
};