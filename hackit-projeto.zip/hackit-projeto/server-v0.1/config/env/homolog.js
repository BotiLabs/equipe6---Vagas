var username = '977936ed-d083-4e8d-88f7-4b48f25955ec';
var password = '87IWXUi3JQEE';
//var workspace_id = '787ce0e8-96c4-4d7e-96aa-7786a8baadba';
var workspace_id = '79046d65-74a0-4bb7-ae3c-3ec89769baf1';


module.exports = {
	username,
	password,
	workspace_id,
	secret: 'developmentSecret',
	mongodb: {
		// 	uri: 'mongodb://@ds245755.mlab.com:45755/hapinprod',
		// 	options: {
		// 		user: 'administratorprod', 
		// 		pass: 'hapin123'	
		// 	}	

		uri: 'mongodb://@ds147451.mlab.com:47451/multiempresas',
		options: {
			useNewUrlParser: true,
			user: 'multiEmpresas',
			pass: 'adminMultiEmpresas123'
		}

	}
};