var username = '977936ed-d083-4e8d-88f7-4b48f25955ec';
var password = '87IWXUi3JQEE';
//var workspace_id = '787ce0e8-96c4-4d7e-96aa-7786a8baadba';
var workspace_id = 'f7d23c0a-b491-4d57-a472-7e194505ca0a';

module.exports = {
	username,
	password,
	workspace_id,
	secret: 'developmentSecret',
	mongodb: {
		// uri: 'mongodb://@ds141514.mlab.com:41514/hapinfc',
		uri: 'mongodb://ds031088.mlab.com:31088/hackathon_boti',
		options: {
			useNewUrlParser: true,
			user: 'admin',
			pass: 'fcamara123'
			// user: 'administrator', 
			// pass: 'hapin123'	
		}
	}
};