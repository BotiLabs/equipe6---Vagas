var express           = require('express')    
    , cors            = require('cors')
    , bodyParser      = require('body-parser')    
    , methodOverride  = require('method-override')
    , morgan          = require('morgan')
    , responseTime    = require('response-time')
    , compress        = require('compression')
    , passport        = require('passport')
    , config          = require('./config/config');

    // , upload          = require('express-fileupload')
module.exports = (app) => {

    app.use(cors({ origin: '*' }));


    if (process.env.NODE_ENV === 'development')
    	app.use(morgan('dev'));
    else (process.env.NODE_ENV === 'production')
    	app.use(compress());


    app.use(bodyParser.urlencoded({
        parameterLimit: 100000,
        limit: '50mb',
        extended:true}));
        
    app.use(bodyParser.json({limit: '50mb'}));
    // app.use(upload());


    app.use(methodOverride('X-HTTP-Method-Override'));
    app.use(passport.initialize());

    app.use(responseTime());


};